/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************
 
     Name:     LTE MAC Convergence Layer
  
     Type:     C source file
  
     Desc:     C source code for Entry point fucntions
  
     File:     ys_mi.c
  
     Sid:      yw_ms_mi.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:47 2014
  
     Prg:      pk
  
**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_FILE_ID=254;
static int RLOG_MODULE_ID=1;

/** @file ys_mi.c
@brief This module acts as an interface handler for upper interface and 
manages Pst and Sap related information for upper interface APIs.
*/

/* header include files -- defines (.h) */

/* header/extern include files (.x) */
/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_lte.h"
#include "ctf.h"           /* CTF defines */
#include "lys.h"           /* layer management defines for LTE-CL */
#include "tfu.h"

#ifdef YS_MSPD
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "resultcodes.h"
#endif
#include "ys_ms.h"            /* defines and macros for CL */
#else
#include "ys_ms.h"            /* defines and macros for CL */
#endif /* YS_MSPD */
#include "ys_ms_err.h"        /* YS error defines */


/* header/extern include files (.x) */
#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"
#include "ctf.x"           /* CTF types */
#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"

#ifdef YS_MSPD
#include "ys_ms.x"         /* typedefs for CL */
#endif /* YS_MSPD */
#ifdef E_TM
#include "ys_ms_etm.x"
#endif /* E_TM */
#include "ss_diag.h"         /* Common logging frame work */
#ifdef TENB_T3K_SPEC_CHNGS
#include "appinit.h"
#include "rb_log.x"
#include "rb_ss.x"
#include "ltephy.h"
#endif /* TENB_T3K_SPEC_CHNGS*/

#ifdef LTE_ADV
/* LBT SIMULATOR */
void lbtSimulatorInit(void);
#endif

/*ys004.102 MSPD merge for PHY 1.7*/
/* local externs */
PRIVATE U16 ysLMMGenCfg ARGS((YsCfg *cfg, U16 index));
PRIVATE U16 ysLMMSapCfg ARGS((YsCfg *cfg, Elmnt sapType, U16 index));
PRIVATE Void ysLMMGenCntrl ARGS((
YsMngmt       *cntrl,
YsMngmt       *cfm,
Pst           *cfmPst,
U16           index
));
PRIVATE Void ysLMMSapCntrl ARGS((
YsMngmt       *cntrl,
YsMngmt       *cfm,
Pst           *cfmPst
));
PRIVATE Void ysLMMShutdown ARGS((U16 index));
PRIVATE S16 ysLMMStopPhy ARGS((CmLteCellId cellId));
PRIVATE Void ysDeleteTfuSap ARGS((
YsTfuSapCb           *tfuSap,
U16                  index
));
PRIVATE Void ysLMMFillCfmPst ARGS((
Pst           *reqPst,
Pst           *cfmPst,
YsMngmt       *cfm
));

#ifdef YS_MSPD
PUBLIC Void ysInitMainThreadPst ARGS((Void));
PUBLIC S16 ysInitMSFramework ARGS((Void));
#endif

#ifdef MSPD_CORE1_L2_STATS
extern S16 ysInitStatLogging ARGS((Void));
#endif

PRIVATE S16 ysLMMShutdowmPhy4IQ ARGS((Void));


/**
 * @brief Layer Manager Configuration request handler. 
 *
 * @details
 *
 *     Function : YsMiLysCfgReq
 *     
 *     This function handles the configuration
 *     request received from the Layer Manager.
 *     -# Based on the cfg->hdr.elmId.elmnt value it invokes one of the
 *        functions ysHdlGenCfg() or ysHdlSapCfg().
 *     -# Invokes YsMiLysCfgCfm() to send back the confirmation to the LM.
 *     
 *  @param[in]  Pst *pst, the post structure     
 *  @param[in]  YsMngmt *cfg, the configuration parameter's structure
 *  @return  S16
 *      -# ROK
 **/
PUBLIC S16 YsMiLysCfgReq
(
Pst      *pst,    /* post structure  */
YsMngmt  *cfg     /* config structure  */
)
{
   U16       ret = LCM_PRIM_OK;
   U16       reason = LCM_REASON_NOT_APPL;
   YsMngmt   *cfm = NULLP;
   Pst       cfmPst;

   TRC2(YsMiLysCfgReq)
   U16 indx = pst->dstInst; //cfg->t.cfg.s.tfuSap.cellId - CM_START_CELL_ID;
   
   RLOG2(L_INFO,"YsMiLysCfgReq(): pst->srcEnt=%d, pst->srcInst=%d", 
                  pst->srcEnt, pst->srcInst);
  YS_DIAG_LVL0(0x0d060001, YS_DIAG_NA, SS_DIAG_INV_ARG,
               "Convergence Layer Configuration Request, Entity = %d, Instance = %d",
                pst->srcEnt, pst->srcInst,0,0);
   /* Fill the post structure for sending the confirmation */
   ysLMMFillCfmPst(pst, &cfmPst, cfg);

   /* Initialize the cfg cfm structure */
   if (SGetSBuf(cfmPst.region, cfmPst.pool, (Data **)&cfm, sizeof(YsMngmt))
      != ROK)
   {
      RLOG0(L_FATAL, "YsMiLysCfgReq(): Memory Unavailable for Confirmation");
      RETVALUE(ROK);
   }
   cmMemset((U8 *)cfm, 0, sizeof(YsMngmt));

   cfm->hdr.elmId.elmnt = cfg->hdr.elmId.elmnt;
   cfm->hdr.transId=cfg->hdr.transId;
   switch(cfg->hdr.elmId.elmnt)
   {
      case STGEN:
         reason = ysLMMGenCfg(&cfg->t.cfg, indx); 
         RLOG1(L_INFO,"YsMiLysCfgReq(): Gen Cfg done with reason=%d.",
                                 reason);
         break;
      case STCTFSAP:
      case STTFUSAP:
         reason = ysLMMSapCfg(&cfg->t.cfg, cfg->hdr.elmId.elmnt, indx);
         RLOG2(L_INFO,"YsMiLysCfgReq(): SAP(Elmnt=%d) Cfg done with" 
                          "reason=%d.", cfg->hdr.elmId.elmnt, reason);
         break;
#ifdef E_TM
      case STETMCELL:
         /* Always enable unsolicited status in case of E_TM */
         ysCb.ysInit[indx].usta = TRUE;
         reason = ysLMMEtmCellCfg(&cfg->t.cfg, pst);
         RLOG2(L_INFO,"YsMiLysCfgReq(): SAP(Elmnt=%d) Cfg done with"
                          "reason=%d", cfg->hdr.elmId.elmnt, reason);
         break;
      case STETM:
           /* Place holder for ETM init function */
         reason = ysLMMEtminit(&cfg->t.cfg, pst);
         RLOG2(L_INFO,"SAP(Elmnt=%d) Cfg done with reason=%d",
               cfg->hdr.elmId.elmnt, reason);
         break;   
#endif /* E_TM */
      default:
         ret = LCM_PRIM_NOK;
         reason = LCM_REASON_INVALID_ELMNT;
         RLOG1(L_WARNING, "YsMiLysCfgReq(): Invalid Elmnt=%d",
                        cfg->hdr.elmId.elmnt);
         break;
   }

   if (reason != LCM_REASON_NOT_APPL)
   {
      ret = LCM_PRIM_NOK;
   }

   cfm->cfm.status = ret;
   cfm->cfm.reason = reason;

   YsMiLysCfgCfm(&cfmPst, cfm);
   
   SPutSBuf(pst->region, pst->pool, (Data *)cfg, sizeof(YsMngmt));
   cfg = NULLP;
   
   RETVALUE(ROK);
}/*-- YsMiLysCfgReq --*/

/**
 * @brief Layer Manager Statistics request handler. 
 *
 * @details
 *
 *     Function : YsMiLysStsReq
 *     
 *     This function handles the statistics
 *     request received from the Layer Manager.
 *      -# Based on sts->hdr.elmId.elmnt, it retrieves either general or SAP
 *      statistics from the ysCb global control block.
 *      -# If action=ARST, it will reset the statistics parameters in ysCb to 0.
 *      -# Invokes the YsMiLysStsCfm to send back the confirmation to LM.
 *     
 *  @param[in]  Pst *pst, the post structure     
 *  @param[in]  YsMngmt *sts, the statistics parameter's structure
 *  @return  S16
 *      -# ROK
 **/
PUBLIC S16 YsMiLysStsReq
(
Pst      *pst,    /* post structure  */
YsMngmt  *sts     /* statistics structure  */
)
{
   Pst            cfmPst;
   YsMngmt        *cfm    = NULLP;
   YsTfuSapCb     *tfuSap = NULLP;

   TRC2(YsMiLysStsReq)
   U16 indx = sts->t.cfg.s.tfuSap.cellId - CM_START_CELL_ID;
      RLOG3(L_INFO,"StsReq for elmnt= %d pst->srcEnt=%d action=%d",
            sts->hdr.elmId.elmnt, 
            pst->srcEnt, sts->t.sts.action);
   /* Fill the post structure for sending the confirmation */
   ysLMMFillCfmPst(pst, &cfmPst, sts);

   /* Initialize the cfg cfm structure */
   if (SGetSBuf(cfmPst.region, cfmPst.pool, (Data **)&cfm, 
                                       sizeof(YsMngmt)) != ROK)
   {
      RLOG0(L_FATAL, "YsMiLysStsReq(): Memory Unavailable for Confirmation");
      SPutSBuf(pst->region, pst->pool, (Data *)sts, sizeof(YsMngmt));
      sts = NULLP;
      RETVALUE(ROK);
   }
   cmMemset((U8 *)cfm, 0, sizeof(YsMngmt));

   SGetDateTime(&cfm->t.sts.dt);
   cfm->cfm.status = LCM_PRIM_OK;
   cfm->cfm.reason = LCM_REASON_NOT_APPL;
   cfm->hdr.elmId.elmnt = sts->hdr.elmId.elmnt;
   cfm->t.sts.action = sts->t.sts.action;

   /* Check if General Config Done */
   if(ysCb.ysInit[indx].cfgDone != TRUE) 
   {
      cfm->cfm.status = LCM_PRIM_NOK;
      cfm->cfm.reason = LCM_REASON_GENCFG_NOT_DONE;
      YsMiLysStsCfm(&cfmPst,cfm);
      RLOG0(L_ERROR, "YsMiLysStsReq(): Gen Cfg not done");
      SPutSBuf(pst->region, pst->pool, (Data *)sts, sizeof(YsMngmt));
      sts = NULLP;
      RETVALUE(ROK);
   }

   switch(sts->hdr.elmId.elmnt)
   {
      case STCTFSAP:
         cmMemcpy((U8 *)&cfm->t.sts.s.ctfSts, (U8 *)&ysCb.ctfSap.ctfSts,
                  sizeof(YsCtfSapSts));

         /* check if action is read and reset */
         if(sts->t.sts.action == ARST)
            cmMemset((U8 *)&ysCb.ctfSap.ctfSts, 0, sizeof(YsCtfSapSts));

         break;

      case STTFUSAP:
         if (sts->t.sts.sapInst >= ysCb.genCfg.maxTfuSaps)
         {
            RLOG1(L_ERROR, "YsMiLysCfgReq(): Invalid SSAP ID %d ",
                              sts->t.sts.sapInst);
            cfm->cfm.status = LCM_PRIM_NOK;
            cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
         }
         else
         {
            tfuSap = ysCb.tfuSapLst[sts->t.sts.sapInst];

            if(tfuSap != NULLP)
            {
               cmMemcpy((U8 *)&cfm->t.sts.s.tfuSts, (U8 *)&tfuSap->tfuSts,
                     sizeof(YsTfuSapSts));

               /* check if action is read and reset */
               if(sts->t.sts.action == ARST)
                  cmMemset((U8 *)&tfuSap->tfuSts, 0, sizeof(YsTfuSapSts));
            }
            else
            {
               cfm->cfm.status = LCM_PRIM_NOK;
               cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
            }
         }
         break;

      case STL1PHY:
         if (sts->t.sts.sapInst >= ysCb.genCfg.maxTfuSaps)
         {
            RLOG1(L_ERROR, "YsMiLysCfgReq(): Invalid SSAP ID %d ",
                           sts->t.sts.sapInst);
            cfm->cfm.status = LCM_PRIM_NOK;
            cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
         }
         else
         {
            tfuSap = ysCb.tfuSapLst[sts->t.sts.sapInst];

            if(tfuSap != NULLP)
            {
               cmMemcpy((U8 *)&cfm->t.sts.s.phySts, (U8 *)&tfuSap->phySts,
                     sizeof(YsL1PhySts));

               /* check if action is read and reset */
               if(sts->t.sts.action == ARST)
                  cmMemset((U8 *)&tfuSap->phySts, 0, sizeof(YsL1PhySts));
            }
            else
            {
               cfm->cfm.status = LCM_PRIM_NOK;
               cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
            }
         }
         break;

      default:
         cfm->cfm.status = LCM_PRIM_NOK;
         cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
         RLOG1(L_WARNING, "YsMiLysStsReq(): Invalid Elmnt = %d",
                           sts->hdr.elmId.elmnt);
         break;     
   }
   YsMiLysStsCfm(&cfmPst,cfm);
   SPutSBuf(pst->region, pst->pool, (Data *)sts, sizeof(YsMngmt));
   sts = NULLP;
   RETVALUE(ROK);
}/*-- YsMiLysStsReq --*/

/**
 * @brief Layer Manager Status request handler. 
 *
 * @details
 *
 *     Function : YsMiLysStaReq
 *     
 *     This function handles the solicited status
 *     request received from the Layer Manager.
 *      -# Based on sta->hdr.elmId.elmnt, it retrieves the status of a
 *      particular SAP from the ysCb global control block.
 *      -# Invokes the YsMiLysStaCfm to send back the confirmation to LM.
 *     
 *  @param[in]  Pst *pst, the post structure     
 *  @param[in]  YsMngmt *sta, the status parameter's structure
 *  @return  S16
 *      -# ROK
 **/
PUBLIC S16 YsMiLysStaReq
(
Pst      *pst,    /* post structure  */
YsMngmt  *sta     /* status structure  */
)
{
   Pst            cfmPst;
   YsMngmt        *cfm    = NULLP;
   YsTfuSapCb     *tfuSap = NULLP;

   TRC2(YsMiLysStaReq)
   U16 indx = pst->dstInst; //sta->t.cfg.s.tfuSap.cellId - CM_START_CELL_ID;
   
   RLOG2(L_INFO,"YsMiLysStaReq(): staReq for elmnt= %d pst->srcEnt=%d",
                  sta->hdr.elmId.elmnt, pst->srcEnt);
   /* Fill the post structure for sending the confirmation */
   ysLMMFillCfmPst(pst, &cfmPst, sta);


   /* Initialize the cfg cfm structure */
   if (SGetSBuf(cfmPst.region, cfmPst.pool, (Data **)&cfm, sizeof(YsMngmt))
      != ROK)
   {
      RLOG0(L_FATAL, "YsMiLysStaReq(): Memory Unavailable for Confirmation");
      SPutSBuf(pst->region, pst->pool, (Data *)sta, sizeof(YsMngmt));
      sta = NULLP;
      RETVALUE(ROK);
   }
   cmMemset((U8 *)cfm, 0, sizeof(YsMngmt));
   cfm->hdr.elmId.elmnt = sta->hdr.elmId.elmnt;

   /* Check if General Config Done */
   if(ysCb.ysInit[indx].cfgDone != TRUE) 
   {
      SGetDateTime(&cfm->t.ssta.dt);
      cfm->cfm.status = LCM_PRIM_NOK;
      cfm->cfm.reason = LCM_REASON_GENCFG_NOT_DONE;
      cfm->hdr.elmId.elmnt = sta->hdr.elmId.elmnt;
      YsMiLysStaCfm(&cfmPst, cfm);
      RLOG0(L_ERROR, "YsMiLysStaReq(): Gen Cfg not done");
      SPutSBuf(pst->region, pst->pool, (Data *)sta, sizeof(YsMngmt));
      sta = NULLP;
      RETVALUE(ROK);
   }

   switch(sta->hdr.elmId.elmnt)
   {
#ifdef YS_MSPD
      case STSID:
#endif
         SGetDateTime(&cfm->t.ssta.dt);
         ysGetSId(&cfm->t.ssta.s.sysId);
         cfm->cfm.status = LCM_PRIM_OK;
         cfm->cfm.reason = LCM_REASON_NOT_APPL;
         YsMiLysStaCfm(&cfmPst, cfm);
         break;
      case STCTFSAP:
         cfm->cfm.status = LCM_PRIM_OK;
         cfm->cfm.reason = LCM_REASON_NOT_APPL;
         SGetDateTime(&cfm->t.ssta.dt);
         cfm->t.ssta.s.ctfSapSta.sapState = ysCb.ctfSap.sapState;
         YsMiLysStaCfm(&cfmPst, cfm);
         break;

      case STTFUSAP:
         cfm->cfm.status = LCM_PRIM_OK;
         cfm->cfm.reason = LCM_REASON_NOT_APPL;
         SGetDateTime(&cfm->t.ssta.dt);

         if (sta->t.ssta.sapInst >= ysCb.genCfg.maxTfuSaps)
         {
            RLOG1(L_ERROR, "YsMiLysStaReq(): Invalid SSAP ID %d ",
                           sta->t.ssta.sapInst);
            cfm->cfm.status = LCM_PRIM_NOK;
            cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
         }
         else
         {
            tfuSap = ysCb.tfuSapLst[sta->t.ssta.sapInst];

            if(tfuSap != NULLP)
            {
               cfm->t.ssta.s.tfuSapSta.sapState = tfuSap->sapState;
            }
            else
            {
               RLOG1(L_ERROR, "YsMiLysStaReq(): Invalid SSAP ID %d ",
                              sta->t.ssta.sapInst);
               cfm->cfm.status = LCM_PRIM_NOK;
               cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
            }
         }
         YsMiLysStaCfm(&cfmPst, cfm);
         break;

      case STL1PHY:
         cfm->cfm.status = LCM_PRIM_OK;
         cfm->cfm.reason = LCM_REASON_NOT_APPL;
         SGetDateTime(&cfm->t.ssta.dt);

         if (sta->t.ssta.sapInst >= ysCb.genCfg.maxTfuSaps)
         {
            RLOG1(L_ERROR, "YsMiLysStaReq(): Invalid SSAP ID %d ",
                           sta->t.ssta.sapInst);
            cfm->cfm.status = LCM_PRIM_NOK;
            cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
         }
         else
         {
            tfuSap = ysCb.tfuSapLst[sta->t.ssta.sapInst];

            if((tfuSap != NULLP) && (tfuSap->cellCb != NULLP))
            {
               cfm->t.ssta.s.phyState = tfuSap->cellCb->phyState;
            }
            else
            {
               RLOG1(L_ERROR, "YsMiLysStaReq(): Invalid SSAP ID %d ",
                              sta->t.ssta.sapInst);
               cfm->cfm.status = LCM_PRIM_NOK;
               cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
            }
         }
         YsMiLysStaCfm(&cfmPst, cfm);
         break;

      default:
         cfm->cfm.status = LCM_PRIM_NOK;
         cfm->cfm.reason = LCM_REASON_INVALID_ELMNT;
         YsMiLysStaCfm(&cfmPst, cfm);
         RLOG1(L_WARNING, "YsMiLysStaReq(): Invalid elmnt=%d",
                        sta->hdr.elmId.elmnt);
         break;     
   }
   SPutSBuf(pst->region, pst->pool, (Data *)sta, sizeof(YsMngmt));
   sta = NULLP;
   RETVALUE(ROK);
}/*-- YsMiLysStaReq --*/

/**
 * @brief Layer Manager Control request handler. 
 *
 * @details
 *
 *     Function : YsMiLysCntrlReq
 *     
 *     This function handles the control
 *     request received from the Layer Manager.
 *      -# Based on cntrl->hdr.elmId.elmnt, cntrl->t.cntrl.action
 *      and cntrl->t.cntrl.subAction, it performs the appropriate control action
 *      of SAP (enable/disable), Debug (enable/disable), Trace (enable/disable)
 *      and layer shutdown.
 *      -# Invokes the YsMiLysCntrlCfm to send back the confirmation to LM.
 *     
 *  @param[in]  Pst *pst, the post structure     
 *  @param[in]  YsMngmt *cntrl, the control parameter's structure
 *  @return  S16
 *      -# ROK
 **/
PUBLIC S16 YsMiLysCntrlReq
(
Pst      *pst,    /* post structure  */
YsMngmt  *cntrl   /* control structure  */
)
{
   S16       ret = ROK;            /* return value */
   Pst       cfmPst;
   YsMngmt   *cfm = NULLP;
   
   TRC2(YsMiLysCntrlReq)
   U16 indx = pst->dstInst; //cntrl->t.cfg.s.tfuSap.cellId - CM_START_CELL_ID;
   
   RLOG3(L_ALWAYS,"YsMiLysCntrlReq():cntrlReq for elmnt= %d, action=%d," 
                   "subaction=%d", cntrl->hdr.elmId.elmnt,
                   cntrl->t.cntrl.action, cntrl->t.cntrl.subAction);
   
   STKLOG(STK_MD_YS,STK_LOG_INFO,"YsMiLysCntrlReq():cntrlReq for elmnt= %d, action=%d," 
                   "subaction=%d\n", cntrl->hdr.elmId.elmnt,
                   cntrl->t.cntrl.action, cntrl->t.cntrl.subAction);
   
   /* Fill the post structure for sending the confirmation */
   ysLMMFillCfmPst(pst, &cfmPst, cntrl);

   /* Initialize the cfg cfm structure */
   if (SGetSBuf(cfmPst.region, cfmPst.pool, (Data **)&cfm, sizeof(YsMngmt))
      != ROK)
   {
      RLOG0(L_FATAL, "YsMiLysCntrlReq(): Memory Unavailable for Confirmation");
      SPutSBuf(pst->region, pst->pool, (Data *)cntrl, sizeof(YsMngmt));
      cntrl = NULLP;
      RETVALUE(ROK);
   }
   cmMemset((U8 *)cfm, 0, sizeof(YsMngmt));
   cfm->hdr.elmId.elmnt = cntrl->hdr.elmId.elmnt;
   cfm->t.cntrl.action = cntrl->t.cntrl.action;
   cfm->t.cntrl.subAction = cntrl->t.cntrl.subAction;

   /* Check if General Config Done*/
   if(ysCb.ysInit[indx].cfgDone != TRUE)
   {
      cfm->cfm.status = LCM_PRIM_NOK;
      cfm->cfm.reason = LCM_REASON_GENCFG_NOT_DONE;
      cfm->hdr.elmId.elmnt = cntrl->hdr.elmId.elmnt;
      YsMiLysCntrlCfm(&cfmPst, cfm);
      RLOG0(L_ERROR, "YsMiLysCntrlReq(): Gen Cfg not done.");
      SPutSBuf(pst->region, pst->pool, (Data *)cntrl, sizeof(YsMngmt));
      cntrl = NULLP;
      RETVALUE(ROK);
   }
 
   /* General Config done, process the Control request */   
   switch(cntrl->hdr.elmId.elmnt)
   {
      case STGEN:
         ysLMMGenCntrl(cntrl, cfm, &cfmPst, indx);
         break;
      case STTFUSAP:
      case STCTFSAP:
         ysLMMSapCntrl(cntrl, cfm, &cfmPst);
         break;
#ifdef E_TM
      case STETM:
         ysLMMEtmCntrl(cntrl, cfm, &cfmPst);
         break;
#endif /* E_TM */
      default:
         cfm->cfm.status = LCM_PRIM_NOK;
         cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
         YsMiLysCntrlCfm(&cfmPst, cfm);
         RLOG1(L_WARNING, "YsMiLysCntrlReq(): invalid elmnt=%d",
         cntrl->hdr.elmId.elmnt);
         break;
   }
   SPutSBuf(pst->region, pst->pool, (Data *)cntrl, sizeof(YsMngmt));
   cntrl = NULLP;
   RETVALUE(ret);
}/*-- YsMiLysCntrlReq --*/

/**
 * @brief General Configuration Handler. 
 *
 * @details
 *
 *     Function : ysLMMGenCfg
 *     
 *     This function in called by YsMiLysCfgReq(). It handles the
 *     general configuration of the CL layer. It initializes 
 *     the YsCb. Returns
 *     reason for success/failure of this function.
 *     
 *  @param[in]  YsCfg *cfg, the Configuaration info 
 *  @return  U16
 *      -# LCM_REASON_NOT_APPL 
 *      -# LCM_REASON_INVALID_MSGTYPE
 *      -# LCM_REASON_MEM_NOAVAIL
 **/
PRIVATE U16 ysLMMGenCfg
(
YsCfg *cfg,            /* Configuaration info */
U16 index
)
{
   U16         ret = LCM_REASON_NOT_APPL;
   Size        memSize;           /* amount of static memory required */
   YsGenCfg   *genCfg;
   U16         idx;
   YsUeCb      ueCb;
   U16         offset;

   TRC2(ysLMMGenCfg)

   U16 indx = index; //cfg->s.tfuSap.cellId - CM_START_CELL_ID;
   
   RLOG0(L_INFO,"ysLMMGenCfg(): General Configuration Request");
   /* Check if General Configuration is done already */
   if (ysCb.ysInit[indx].cfgDone == TRUE)
   {
      RETVALUE(LCM_REASON_INVALID_MSGTYPE);
   }

#ifdef LTE_ADV
   /* LBT SIM INIT */
   lbtSimulatorInit();
#endif

   ysMsInit();
   genCfg = &cfg->s.genCfg;

   /* copy the general configuration structure */
   ysCb.genCfg = *genCfg;
   RLOG1(L_INFO,"enblSIAndPagngLog=%d", genCfg->enblSIAndPagngLog);

   /* Update the Pst structure for LM interface */
   cmMemcpy((U8 *)&ysCb.ysInit[indx].lmPst, (U8 *)&genCfg->lmPst,
             sizeof(Pst));

   ysCb.ysInit[indx].lmPst.srcProcId = ysCb.ysInit[indx].procId;
   /* ysCb.ysInit.lmPst.srcEnt = ysCb.ysInit.ent; */
   ysCb.ysInit[indx].lmPst.srcEnt = ENTTF;
   ysCb.ysInit[indx].lmPst.srcInst = ysCb.ysInit[indx].inst;
   ysCb.ysInit[indx].lmPst.event = EVTNONE;

   /* Calculate the memory requirement */
   memSize = genCfg->maxTfuSaps * (sizeof(YsTfuSapCfg) + sizeof(YsTfuSapCfg *));

   /* reserve static memory */
   if ((SGetSMem(ysCb.ysInit[indx].region, memSize, &ysCb.ysInit[indx].pool)) != ROK)
      RETVALUE(LCM_REASON_MEM_NOAVAIL);

   memSize = genCfg->maxTfuSaps * sizeof(YsTfuSapCfg *);

   if(indx == 0)
   {
      if ((ysCb.tfuSapLst = (YsTfuSapCb **)ysUtlMalloc(memSize, indx)) == NULLP)
      {
         (Void) SPutSMem(ysCb.ysInit[indx].region, ysCb.ysInit[indx].pool);
         RETVALUE(LCM_CAUSE_MEM_ALLOC_FAIL);
      }

      for (idx = 0;  idx < genCfg->maxTfuSaps;  idx++)
      {
         *(ysCb.tfuSapLst + idx) = NULLP;
      }
   }

   offset = (U16)((PTR)&ueCb.ueHlEnt - (PTR)&ueCb);
   ret = cmHashListInit(&(ysCb.ueHLst[indx]),      /* hash list Cp */
            (U16)ysCb.genCfg.nmbUe,             /* HL bins */
            offset,                             /* Offset of HL Entry */
            FALSE,                              /* Allow dup. keys ? */
            CM_HASH_KEYTYPE_DEF,                /* HL key type */
            ysCb.ysInit[indx].region,                 /* Mem region for HL */
            ysCb.ysInit[indx].pool);                  /* Mem pool for HL */
   if(ret != ROK)
   {
      YS_DBG_ERR((_ysp, "cmHashListInit: ueHLst failed \n"));
      (Void) SPutSMem(ysCb.ysInit[indx].region, ysCb.ysInit[indx].pool);
      RETVALUE(LCM_CAUSE_MEM_ALLOC_FAIL);
   }

#ifdef MSPD_CORE1_L2_STATS
   ysInitStatLogging();
#endif

   /* Set Config done in TskInit */
   ysCb.ysInit[indx].cfgDone = TRUE;
#ifdef MSPD
   ysInitMainThreadPst();
#endif
   RETVALUE(ret);
}

/**
 * @brief SAP Configuration Handler. 
 *
 * @details
 *
 *     Function : ysLMMSapCfg
 *     
 *     This function in called by YsMiLysCfgReq(). It handles the
 *     interface SAP configuration of the CL layer. It 
 *     initializes the sapState to LYS_UNBND. Returns
 *     reason for success/failure of this function.
 *     
 *  @param[in]  YsCfg *cfg, the Configuaration info 
 *  @return  U16
 *      -# LCM_REASON_GENCFG_NOT_DONE
 *      -# LCM_REASON_INVALID_SAP
 *      -# LCM_REASON_NOT_APPL
 **/
PRIVATE U16 ysLMMSapCfg
(
YsCfg *cfg,            /* Configuaration info */
Elmnt sapType,             /* Sap Type */
U16   index
)
{
   U16               ret = LCM_REASON_NOT_APPL;
   YsTfuSapCb        *tfuSap = NULLP;
   YsCtfSapCb        *ctfSap = NULLP;

   TRC2(ysLMMSapCfg)
   U16 indx = index; //cfg->s.tfuSap.cellId - CM_START_CELL_ID;
   
   RLOG1(L_INFO,"ysLMMSapCfg(): SAP Config Requested for sapType=%d",
                        sapType);
   /* Check if Gen Config has been done */
   if(ysCb.ysInit[indx].cfgDone != TRUE)
      RETVALUE(LCM_REASON_GENCFG_NOT_DONE);

   switch(sapType)
   {   
      case STCTFSAP:
         ctfSap = &ysCb.ctfSap;
         if(ctfSap->sapState == LYS_NOT_CFG)
         { 
            ctfSap->sapState = LYS_UNBND;
            ctfSap->sapPst.dstEnt = cfg->s.ctfSap.ent;
            ctfSap->sapPst.dstInst = cfg->s.ctfSap.inst;
            ctfSap->sapPst.dstProcId = cfg->s.ctfSap.procId;
            /* ctfSap->sapPst.srcEnt = ysCb.ysInit.ent; */
            ctfSap->sapPst.srcEnt = ENTTF;
            ctfSap->sapPst.srcInst = ysCb.ysInit[indx].inst;
            ctfSap->sapPst.srcProcId = ysCb.ysInit[indx].procId;

           /* With multicore support layer shall use the assigned region
              and pool from SSI */
#if defined(SS_MULTICORE_SUPPORT) && defined(SS_M_PROTO_REGION)
            ctfSap->sapPst.region = ysCb.ysInit[indx].region;
            ctfSap->sapPst.pool = ysCb.ysInit[indx].pool;
#else
            ctfSap->sapPst.region = cfg->s.ctfSap.mem.region;
            ctfSap->sapPst.pool = cfg->s.ctfSap.mem.pool;
#endif
            ctfSap->sapPst.selector = cfg->s.ctfSap.selector;
            ctfSap->sapPst.route = cfg->s.ctfSap.route;
            ctfSap->sapPst.prior = cfg->s.ctfSap.prior;
            ctfSap->suId = cfg->s.ctfSap.suId;
            ctfSap->spId = cfg->s.ctfSap.spId;
         }
         break;

      case STTFUSAP:

         /* get out the pointer to the SSAP from the SSAP list */
         if (cfg->s.tfuSap.spId >= ysCb.genCfg.maxTfuSaps)
         {
            RLOG1(L_ERROR, "YsMiLysCfgReq(): Invalid SSAP ID %d ",
                           cfg->s.tfuSap.spId);
            RETVALUE(LCM_REASON_INVALID_PAR_VAL);
         }

         /* Get Sap control block */
         tfuSap = ysCb.tfuSapLst[cfg->s.tfuSap.spId];
   
         if(tfuSap != NULLP)
         {
            RETVALUE(ROK);
         }

         /* allocate the SSAP and put it in the SSAP list */
         if ((tfuSap = (YsTfuSapCb *)ysUtlMalloc(sizeof(YsTfuSapCb), indx)) == NULLP)
         {
            RETVALUE(LCM_REASON_MEM_NOAVAIL);
         }

         cmMemcpy((U8 *)&tfuSap->tfuSapCfg, (U8 *)&cfg->s.tfuSap,
                  sizeof(YsTfuSapCfg));

         tfuSap->sapState = LYS_UNBND;
         tfuSap->sapPst.dstEnt = cfg->s.tfuSap.ent;
         tfuSap->sapPst.dstInst = cfg->s.tfuSap.inst;
         tfuSap->sapPst.dstProcId = cfg->s.tfuSap.procId;
         /* tfuSap->sapPst.srcEnt = ysCb.ysInit.ent; */
         tfuSap->sapPst.srcEnt = ENTTF;
         tfuSap->sapPst.srcInst = ysCb.ysInit[indx].inst;
         tfuSap->sapPst.srcProcId = ysCb.ysInit[indx].procId;

         /* With multicore support layer shall use the assigned region
           and pool from SSI */
#if defined(SS_MULTICORE_SUPPORT) && defined(SS_M_PROTO_REGION)
         tfuSap->sapPst.region = ysCb.ysInit[indx].region;
         tfuSap->sapPst.pool = ysCb.ysInit[indx].pool;
#else
         tfuSap->sapPst.region = cfg->s.tfuSap.mem.region;
         tfuSap->sapPst.pool = cfg->s.tfuSap.mem.pool;
#endif
         tfuSap->sapPst.selector = cfg->s.tfuSap.selector;
         tfuSap->sapPst.route = cfg->s.tfuSap.route;
         tfuSap->sapPst.prior = cfg->s.tfuSap.prior;
         tfuSap->suId = cfg->s.tfuSap.suId;
         tfuSap->spId = cfg->s.tfuSap.spId;
#ifndef YS_MSPD
#else
         tfuSap->type = cfg->s.tfuSap.type;
         tfuSap->cellCb = NULLP;
        /* Place tfuSapCb in ysCb's TfuSap list */
         ysCb.tfuSapLst[cfg->s.tfuSap.spId] = tfuSap;     

         tfuSap->cellCb = ysMsCfgGetCellCfg(cfg->s.tfuSap.cellId);
#endif /* YS_MSPD */
         break;

      default:
         /* would never reach here */
         break;
   }
   RETVALUE(ret);
}

/***********************************************************
 *
 *     Func : ysLMMGenCntrl 
 *        
 *
 *     Desc : Processes the LM control request for STGEN elmnt.
 *            
 *
 *     Ret  : Void
 *
 *     Notes: 
 *
 *     File : ys_mi.c 
 *
 **********************************************************/
PRIVATE Void ysLMMGenCntrl 
(
YsMngmt       *cntrl,
YsMngmt       *cfm,
Pst           *cfmPst,
U16           index
)
{
   S16 ret;

   TRC2(ysLMMGenCntrl)
   U16 indx = index; //cntrl->t.cfg.s.tfuSap.cellId - CM_START_CELL_ID;
   
   RLOG0(L_ALWAYS,"ysLMMGenCntrl(): Control Req for STGEN");
   cfm->cfm.status = LCM_PRIM_OK;
   cfm->cfm.reason = LCM_REASON_NOT_APPL;
   
   switch(cntrl->t.cntrl.action)
   {
      case AENA:
         /* Action is Enable */
         switch(cntrl->t.cntrl.subAction)
         {
            case SATRC:
            /* Enable Traces */
               ysCb.ysInit[indx].trc = TRUE;
               ysCb.trcLen = cntrl->t.cntrl.s.trcLen;
               break;

            case SAUSTA:   
            /* Enable Unsolicited Status (alarms) */
               ysCb.ysInit[indx].usta = TRUE;
               break;

            case SADBG:
            /* Enable Debug Printing */
#ifdef DEBUGP
#ifdef MSPD
/*
               ysCb.ysInit.dbgMask |= cntrl->t.cntrl.s.ysDbgCntrl.dbgMask;
               */
#else
               ysCb.ysInit[indx].dbgMask |= cntrl->t.cntrl.s.ysDbgCntrl.dbgMask;
#endif
#endif
               break;
#ifdef SS_DIAG
            case SALOG:
               ysCb.ysInit[indx].logMask =  cntrl->t.cntrl.s.logMask;
               break;
#endif
            default:
               cfm->cfm.status = LCM_PRIM_NOK;
               cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
               RLOG1(L_WARNING, "ysLMMGenCntrl(): invalid subaction=%d",
               cntrl->t.cntrl.subAction);
               break;
         }
         break;
      case ADISIMM:
         /* Action is Diable immidiately */
         switch(cntrl->t.cntrl.subAction)
         {
            case SATRC:
            /* Disable Traces */
               ysCb.ysInit[indx].trc = FALSE;
               break;
            case SAUSTA:
            /* Disable Unsolicited Status (alarms) */
               ysCb.ysInit[indx].usta = FALSE;
               break;
            case SADBG:
            /* Disable Debug Printing */
#ifdef DEBUGP
               ysCb.ysInit[indx].dbgMask &=~cntrl->t.cntrl.s.ysDbgCntrl.dbgMask;
#endif
               break;
#ifdef SS_DIAG
            case SALOG:
               ysCb.ysInit[indx].logMask = cntrl->t.cntrl.s.logMask;
               break;
#endif
            case SASTOPL1:
               ret = ysLMMStopPhy(cntrl->t.cntrl.s.cellId);
               if(ret != ROK)
               {
                  cfm->cfm.status = LCM_PRIM_NOK;
                  cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
               }
               break;
            case SAIQDATA:
			   ysLMMShutdowmPhy4IQ();
			   break;
            default:
               cfm->cfm.status = LCM_PRIM_NOK;
               cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
               RLOG1(L_WARNING, "ysLMMGenCntrl(): invalid subaction=%d",
                            cntrl->t.cntrl.subAction);
               break;
         }
         break;
      case ASHUTDOWN:
         /* Free all the memory dynamically allocated by CL */
         ysLMMShutdown(indx);
         break;
#ifdef TENB_STATS
      case ARST:
         STKLOG(STK_MD_YS,STK_LOG_INFO,"LYS ARST CNTRL\n");
         switch(cntrl->t.cntrl.subAction)
         {
            case SAACNT:
               ysCb.statsPer = cntrl->t.cntrl.s.statsPer;
               STKLOG(STK_MD_YS,STK_LOG_INFO,"LYS SAACNT CNTRL[%d]\n", (int)ysCb.statsPer);
               break;
         }
         break;
#endif
      default:
         cfm->cfm.status = LCM_PRIM_NOK;
         cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
         RLOG1(L_WARNING, "ysLMMGenCntrl(): invalid action=%d",
                        cntrl->t.cntrl.action);
         break;
   }

   YsMiLysCntrlCfm(cfmPst, cfm);
   RETVOID;
}

/***********************************************************
 *
 *     Func : ysLMMSapCntrl 
 *        
 *
 *     Desc : Processes the LM control request for STxxxSAP elmnt.
 *            
 *
 *     Ret  : Void
 *
 *     Notes: 
 *
 *     File : ys_mi.c
 *
 **********************************************************/
PRIVATE Void ysLMMSapCntrl 
(
YsMngmt       *cntrl,
YsMngmt       *cfm,
Pst           *cfmPst
)
{
   TRC2(ysLMMSapCntrl)

   RLOG1(L_INFO,"ysLMMSapCntrl(): Control Req for SAP (%d)",
                  cntrl->hdr.elmId.elmnt);
   /* Only TFU Sap can be controlled by LM */
   switch(cntrl->hdr.elmId.elmnt)
   {
      case STCTFSAP:
         switch(cntrl->t.cntrl.action)
         {
            case ADEL:
               cmMemset((U8 *)&ysCb.ctfSap, 0, sizeof(YsCtfSapCb));
               ysCb.ctfSap.sapState = LYS_NOT_CFG;
               cfm->cfm.status = LCM_PRIM_OK;
               cfm->cfm.reason = LCM_REASON_NOT_APPL;
               break;
            default:
               cfm->cfm.status = LCM_PRIM_NOK;
               cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
               RLOG1(L_WARNING, "ysLMMSapCntrl(): invalid action=%d",
                           cntrl->t.cntrl.action);
               break;
         }
         break;

      case STTFUSAP:
         switch(cntrl->t.cntrl.action)
         {
            case ADEL:
               if(ysCb.tfuSapLst[cntrl->t.cntrl.s.ysSapCntrl.spId] != NULLP)
               {
                  ysDeleteTfuSap(ysCb.tfuSapLst
                           [cntrl->t.cntrl.s.ysSapCntrl.spId], cfmPst->srcInst);
                  cfm->cfm.status = LCM_PRIM_OK;
                  cfm->cfm.reason = LCM_REASON_NOT_APPL;
               }
               else
               {
                  cfm->cfm.status = LCM_PRIM_NOK;
                  cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
                  RLOG1(L_ERROR, "ysLMMSapCntrl(): invalid sapId=%d",
                           cntrl->t.cntrl.s.ysSapCntrl.spId);
               }
               break;

            default:
               cfm->cfm.status = LCM_PRIM_NOK;
               cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
               RLOG1(L_WARNING, "ysLMMSapCntrl(): invalid action=%d",
                              cntrl->t.cntrl.action);
               break;
         }
         break;
      default:
         /* Would never here. */
         RETVOID;
   }
   YsMiLysCntrlCfm(cfmPst, cfm);
   RETVOID;
}

/***********************************************************
 *
 *     Func : ysLMMShutdown
 *        
 *
 *     Desc : Handles the CL layer shutdown request.
 *            
 *
 *     Ret  : Void
 *
 *     Notes: 
 *
 *     File : ys_mi.c 
 *
 **********************************************************/
PRIVATE Void ysLMMShutdown
(
U16 index
)
{
   U16   idx;
#ifdef YS_MSPD
  // YsCellCb  *pCellCb;
   //YsCellCb  *nCellCb;
   //S16       ret;

  // pCellCb = NULLP;
   //nCellCb = NULLP;
   //ret = ROK;

#endif /* YS_MSPD */
   
   TRC2(ysLMMShutdown)

   RLOG0(L_ALWAYS,"ysLMMShutdown(): Layer Shutdown Requested");

   STKLOG(STK_MD_YS,STK_LOG_INFO,"ysLMMShutdown(): Layer Shutdown Requested");

   /* remove the tfusap list memory */
   if (ysCb.tfuSapLst != NULLP)
   {
      for (idx=0; idx < ysCb.genCfg.maxTfuSaps; ++idx)
      {
         if (ysCb.tfuSapLst[idx])
         {
            ysDeleteTfuSap(ysCb.tfuSapLst[idx], index);
            ysCb.tfuSapLst[idx] = NULLP;
         }
      }

      /* Free Memory for the TSAP List */
      ysUtlDeAlloc((Data *)ysCb.tfuSapLst, 
                (ysCb.genCfg.maxTfuSaps * sizeof(YsTfuSapCfg *)), index);

      ysCb.tfuSapLst = NULLP;
   }

   for (idx = 0; idx < CM_LTE_MAX_CELLS; idx++)
   {
      if (ysCb.cellCfgLst[idx] != NULLP)
      {
         ysMsCfgDelCellCfg(ysCb.cellCfgLst[idx]->cellId); 
      }
   }

   /* call back the task initialization function to intialize
    * the global YsCb Struct */
   ysActvInit(ysCb.ysInit[index].ent, ysCb.ysInit[index].inst, ysCb.ysInit[index].region, 
              ysCb.ysInit[index].reason);

   RETVOID;
}

/*
*
*       Fun:   ysDeleteTfuSap
*
*       Desc:  This function implements TFU SAP control.
*
*       Ret:   void
*
*       Notes: None
*
*       File : ys_mi.c 
*
*/
PRIVATE Void ysDeleteTfuSap
(
YsTfuSapCb           *tfuSap,               /* SSAP Control Block */
U16                  index
)
{

   TRC2(ysDeleteTfuSap)

   RLOG0(L_INFO,"ysDeleteTfuSap(): SAP delete Requested");

   /* remove the TFUSAP from the TFUSAP list */
   *(ysCb.tfuSapLst + tfuSap->spId) = NULLP;
   ysUtlDeAlloc((Data *)tfuSap, sizeof(YsTfuSapCb), index);
   
   RETVOID;

} /* end of ysDeleteTfuSap() */ 

/**
 * @brief Layer Manager Unsolicited Status Indication generation. 
 *
 * @details
 *
 *     Function : ysLMMStaInd 
 *     
 *     This API is used by the other modules of CL to send a unsolicited
 *     status indication to the Layer Manager.
 *     
 *  @param[in]  U16 category, the Alarm category.
 *  @param[in]  U16 event, the Alarm event.
 *  @param[in]  U16 cause, the cause of the Alarm.
 *  @param[in]  YsUstaDgn *dgn, Alarm Diagonostics.
 *  @return  S16
 *      -# ROK
 **/
PUBLIC S16 ysLMMStaInd
(
U16 category,
U16 event,
U16 cause,
YsUstaDgn *dgn,
U16 index
)
{
   /*  Fix for memory Corruption */
   YsMngmt    *usta;

   TRC2(ysLMMStaInd)

   RLOG3(L_INFO,"ysLMMStaInd(): category=%d, event=%d, cause=%d",
                        category, event, cause);
   
   if(ysCb.ysInit[index].usta == FALSE)
   {
      RLOG0(L_INFO,"ysLMMStaInd(): USTA Ind Disabled.");
      RETVALUE(ROK);
   }
   if (SGetSBuf(ysCb.ysInit[index].lmPst.region, ysCb.ysInit[index].lmPst.pool,
            (Data **)&usta, sizeof(YsMngmt)) != ROK)
   {
      RLOG0(L_FATAL, "ysLMMStaInd(): Memory Unavailable for Status Indication");
      RETVALUE(RFAILED);
   }
   cmMemset((U8 *)usta, 0, sizeof(YsMngmt));

   /* fill in the category, event and cause */
   usta->t.usta.cmAlarm.category = category;
   usta->t.usta.cmAlarm.event = event;
   usta->t.usta.cmAlarm.cause = cause;

   SGetDateTime(&usta->t.usta.cmAlarm.dt);
   if (dgn != NULLP)
   {
      cmMemcpy((U8 *)&usta->t.usta.dgn, (U8 *)dgn, sizeof(YsUstaDgn));
   }

   RETVALUE(YsMiLysStaInd(&ysCb.ysInit[index].lmPst, usta));
}

/***********************************************************
 *
 *     Func : ysLMMFillCfmPst 
 *        
 *
 *     Desc : Fills the Confirmation Post Structure cfmPst using the reqPst 
 *            and the cfm->hdr.response.
 *            
 *
 *     Ret  : Void
 *
 *     Notes: 
 *
 *     File : ys_mi.c
 *
 **********************************************************/
PRIVATE Void ysLMMFillCfmPst
(
Pst           *reqPst,
Pst           *cfmPst,
YsMngmt       *cfm
)
{
   TRC2(ysLMMFillCfmPst)
   U16 indx = reqPst->dstInst; //cfm->t.cfg.s.tfuSap.cellId - CM_START_CELL_ID;
   /* cfmPst->srcEnt    = ysCb.ysInit.ent; */
   cfmPst->srcEnt = ENTTF;
   cfmPst->srcInst   = ysCb.ysInit[indx].inst;
   cfmPst->srcProcId = ysCb.ysInit[indx].procId;
   cfmPst->dstEnt    = reqPst->srcEnt;
   cfmPst->dstInst   = reqPst->srcInst;
   cfmPst->dstProcId = reqPst->srcProcId;

   cfmPst->selector  = cfm->hdr.response.selector;
   cfmPst->prior     = cfm->hdr.response.prior;
   cfmPst->route     = cfm->hdr.response.route;
#ifdef SS_LOCKLESS_MEMORY
   cfmPst->region    = ysCb.ysInit[indx].region;
#else
   cfmPst->region    = cfm->hdr.response.mem.region;
#endif /* SS_LOCKLESS_MEMEORY */
   cfmPst->pool      = cfm->hdr.response.mem.pool;

   RETVOID;
}

/***********************************************************
 *
 *     Func : ysLMMStopPhy
 *        
 *
 *     Desc : Handles the L1 layer shutdown request.
 *            
 *
 *     Ret  : S16
 *
 *     Notes: 
 *
 *     File : ys_mi.c 
 *
 **********************************************************/
PRIVATE S16 ysLMMStopPhy
(
CmLteCellId cellId
)
{
   S16 ret;
   YsCellCb        *cellCb;
   
   TRC2(ysLMMStopPhy)

   RLOG0(L_INFO,"ysLMMStopPhy(): L1 Layer stop Requested");
   
   ret = ROK;

#ifdef YS_MSPD
   if((cellCb = ysMsCfgGetCellCfg(cellId)) == NULLP) 
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellId,"Cell doesn't exist ");
      RETVALUE(RFAILED);
   }

   ret = ysMsCfgSm(cellCb, YS_MS_EVENT_STOP, NULLP);
   if (ret != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellId,"sending stop req to PHY failed");
   }

#else
   if((cellCb = ysUtlGetCellCfg(cellId)) == NULLP) 
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellId,"Cell doesn't exist ");
      RETVALUE(RFAILED);
   }


   if (ret != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellId,"ysPcEncStopReqAndSend2Phy(): failed");
   }
#endif /* YS_MSPD*/

   RETVALUE(ret);
}

/***********************************************************
 *
 *     Func : ysLMMShutdowmPhy4IQ
 *        
 *
 *     Desc : Handles the L1 layer shutdown request for IQ data.
 *            
 *
 *     Ret  : S16
 *
 *     Notes: 
 *
 *     File : ys_mi.c 
 *
 **********************************************************/
PRIVATE S16 ysLMMShutdowmPhy4IQ()
{
   S16 ret = ROK;
   YsCellCb        *pCellCb = NULLP;

   for(U16 cellId = CM_START_CELL_ID; cellId < (CM_START_CELL_ID + CM_LTE_MAX_CELLS); cellId++)
   {
      if((pCellCb = ysMsCfgGetCellCfg(cellId)) == NULLP) 
      {
         RLOG_ARG0(L_ERROR,DBG_CELLID,cellId,"Cell doesn't exist ");
         RETVALUE(RFAILED);
      }

      RLOG_ARG0(L_ERROR,DBG_CELLID,pCellCb->cellId,"ysLMMShutdowmPhy4IQ: L1 Layer shutdown Requested");
      ret = ysMsSndPhyShutDwn(pCellCb);
      if (ret != ROK)
      {
         RLOG_ARG0(L_ERROR,DBG_CELLID,pCellCb->cellId,"sending shutdown req to PHY failed");
      }
   }

   RETVALUE(ret);
}



#ifdef TENB_T3K_SPEC_CHNGS

/**
 * @brief Layer Manager LogStreamInfo request handler. 
 *
 * @details
 *
 *     Function : YsMiLysLogStrmInfoReq
 *     
 *     This function handles the log stream info
 *     request received from the Layer Manager.
 *      -# Invokes the YsMiLysLogStrmInfoCfm to send back the confirmation to LM.
 *     
 *  @param[in]  Pst *pst, the post structure     
 *  @param[in]  YsMngmt *logStrmInfo, the statistics parameter's structure
 *  @return  S16
 *      -# ROK
 **/
PUBLIC S16 YsMiLysLogStrmInfoReq
(
Pst      *pst,    /* post structure  */
YsMngmt  *logStrmInfo     /* logStrmInfo structure  */
)
{
   Pst                    cfmPst;
   YsCtfLogStrmInfoCfm    *cfm    = NULLP;
   extern SysStayInfo     syscoreinfo[4];
   extern U32             gPhyLogsEnableMask;

   TRC2(YsMiLysLogStrmInfoReq)
   U16 indx = pst->dstInst; //logStrmInfo->t.cfg.s.tfuSap.cellId - CM_START_CELL_ID;
   
   RLOG2(L_INFO,"YsMiLysLogStrmInfoReq(): LogStrmInfo for elmnt= %d" 
          "pst->srcEnt=%d ", logStrmInfo->hdr.elmId.elmnt, 
          pst->srcEnt);
   /* Fill the post structure for sending the confirmation */
   ysLMMFillCfmPst(pst, &cfmPst, logStrmInfo);

   /* Initialize the cfg cfm structure */
   if (SGetSBuf(cfmPst.region, cfmPst.pool, (Data **)&cfm, 
       sizeof(YsCtfLogStrmInfoCfm)) != ROK)
   {
      RLOG0(L_FATAL, "YsMiLysLogInfoReq(): Memory Unavailable for Confirmation");
      SPutSBuf(pst->region, pst->pool, (Data *)logStrmInfo, sizeof(YsMngmt));
      logStrmInfo = NULLP;
      RETVALUE(ROK);
   }
   cmMemset((U8 *)cfm, 0, sizeof(YsCtfLogStrmInfoCfm));

   cfm->status.status = LCM_PRIM_OK;
   cfm->status.reason = LCM_REASON_NOT_APPL;
   cfm->logStrmInfoReqType = logStrmInfo->hdr.elmId.elmnt;

   /* Check if General Config Done */
   if(ysCb.ysInit[indx].cfgDone != TRUE) 
   {
      cfm->status.status = LCM_PRIM_NOK;
      cfm->status.reason = LCM_REASON_GENCFG_NOT_DONE;
      YsMiLysLogStrmInfoCfm(&cfmPst,cfm);
      RLOG0(L_ERROR, "YsMiLysLogStrmInfoReq(): Gen Cfg not done");
      SPutSBuf(pst->region, pst->pool, (Data *)logStrmInfo, sizeof(YsMngmt));
      logStrmInfo = NULLP;
      RETVALUE(ROK);
   }
   /*CCPU MLOG log Stream info(addr/size) req*/
   if((osCp.dep.mLog[0].logBuf->buf != NULLP) &&
    ((logStrmInfo->hdr.elmId.elmnt & CCPUMLOGSTRMINFO) == CCPUMLOGSTRMINFO))
   {
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].logStrmInfoTyp = CCPUMLOGSTRMINFO;
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].stat = TRUE;
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].bufAddr = 
    (U32)osCp.dep.mLog[0].logBuf->buf;
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].bufSize = 
    sizeof(osCp.dep.mLog[0].logBuf->buf);     
      cfm->numOfLogStrmInfo++;
   }
   /*MLOG log stream info(addr/size) req*/
   if((MLogGetFileLocation() != NULLP ) &&
    ((logStrmInfo->hdr.elmId.elmnt & MLOGSTRMINFO) == MLOGSTRMINFO))
   {
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].logStrmInfoTyp = MLOGSTRMINFO;
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].stat = 
    (gPhyLogsEnableMask & LTE_BS_PHY_ENABLE_MLOG)?TRUE:FALSE; 
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].bufAddr = 
    (U32)MLogGetFileLocation();
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].bufSize = 
    (MLOG_FRAME_LIMIT * MLOG_FRAME_SIZE *(CPU_NUM + MLOG_DEVICE_COUNT)); 
      cfm->numOfLogStrmInfo++;
   }
   /*SYSCOREIFO log stream info(addr/size) req*/
   if((syscoreinfo != NULLP) &&
    ((logStrmInfo->hdr.elmId.elmnt & SYSCORELOGSTRMINFO)  == 
     SYSCORELOGSTRMINFO))
   {
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].logStrmInfoTyp = SYSCORELOGSTRMINFO;
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].stat = TRUE;
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].bufAddr = (U32)syscoreinfo;
      cfm->logStrmInfo[cfm->numOfLogStrmInfo].bufSize = sizeof(syscoreinfo);
      cfm->numOfLogStrmInfo++;
   }
   /*Handle in case of any error/unknown log stream info type*/
   if(cfm->numOfLogStrmInfo == 0)
   {
      cfm->status.status = LCM_PRIM_NOK;
      cfm->status.reason = LCM_REASON_INVALID_ELMNT;
   }
   /*Send cfm to LM*/
   YsMiLysLogStrmInfoCfm(&cfmPst,cfm);

   SPutSBuf(pst->region, pst->pool, (Data *)logStrmInfo, sizeof(YsMngmt));
   logStrmInfo = NULLP;

   RETVALUE(ROK);
}/*-- YsMiLysLogStrmInfoReq --*/
#endif /* TENB_T3K_SPEC_CHNGS*/

/********************************************************************30**
  
         End of file:     yw_ms_mi.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:47 2014
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---     sgm                   1. eNodeB 1.2 release
/main/1      ys004.102     vr              1. MSPD merge for PHY 1.7
*********************************************************************91*/


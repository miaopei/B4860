/*-----------------------------------------------------------
 * i_fapi_vsm.h
 *
 * Qualcomm Vendor Specific Physical interface internal header
 *
 * The definitions are compatible with DAN Vendor Specific version x.y
 * as described in "FAPI API - Vendor Specific fields" document revision r.t
 *
 * Copyright (c) 2013-2017 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 *-----------------------------------------------------------
 */

#ifndef _I_FAPI_VS_H
#define _I_FAPI_VS_H
#define FAPI_VER_NUM FAPI_VER_NUM_3_0_6

/*
 * -----------------------------------------------------------
 * Include section
 * -----------------------------------------------------------
 */

/*
 * -----------------------------------------------------------
 * MACRO (define) section
 * -----------------------------------------------------------
 */


/*
 * -----------------------------------------------------------
 * Type definition section
 * -----------------------------------------------------------
*/

/*********************************
*  Vendor Specific Tag Message Types
*********************************
*/
typedef enum
{
    FAPI_E_RPT_ULSCH_VSM                            = 0x01, // Associated with RX_ULSCH.Indication
    FAPI_E_HARQ_PUCCH_VSM                           = 0x02, // Associated with HARQ.Indication
    FAPI_E_HARQ_PUSCH_VSM                           = 0x03, // Associated with HARQ.Indication
    FAPI_E_RPT_SR_VSM                               = 0x04, // Associated with RX_SR.Indication
    FAPI_E_RPT_CQI_PUCCH_VSM                        = 0x05, // Associated with RX_CQI.Indication
    FAPI_E_RPT_CQI_PUSCH_VSM                        = 0x06, // Associated with RX_CQI.Indication
    FAPI_E_RPT_RACH_VSM                             = 0x07, // Associated with RACH.Indication
    FAPI_E_RPT_SRS_VSM                              = 0x08, // Associated with SRS.Indication
    FAPI_E_CFG_CFI_VSM                              = 0x0e, // Associated with CONFIG.request
    FAPI_E_CFG_VERSION_VSM                          = 0x0f, // Associated with CONFIG.request
    FAPI_E_CFG_ETM_VSM                              = 0x10, // Associated with CONFIG.request (for Test Mode)
    FAPI_E_PARAM_RSP_MAX_TTI_VSM                    = 0x11, // Associated with PARAM.response
    FAPI_E_NI_REQ_VSM                               = 0x12, // Associated with UL_CONFIG.request
    FAPI_E_CFG_PHY_CHANGE_LIST_VSM                  = 0x13, // change list num
    FAPI_E_CFG_PHY_COMPILATION_MODE_VSM             = 0x14, // compilation mode (mirroring and system mode)
    FAPI_E_CFG_API_VER_VSM                          = 0x15, // Obsolete. Associated with CONFIG.request
    FAPI_E_PARAM_RSP_CAR_ID_VSM                     = 0x16, // Associated with PARAM.response
    FAPI_E_CFG_PHY_VERSION_VSM                      = 0x17, // PHY SW/HW version
    FAPI_E_CFG_POWER_BOOST_REQ_VSM                  = 0x18, // Associated with DL_CONFIG.request
    FAPI_E_CFG_RF_TOPOLOGY_VSM                      = 0x19, // RF Topology
    FAPI_E_CFG_EMTC_INDICATION_REP_MODE_VSM         = 0x1A, // Determines how L1 reports to L2 ULSCH.indicaiton and CRC.indication messages for CAT-M allocations. Value 0 - Send Indication only on last repetition.
    FAPI_E_CFG_LBT_DATA_TX_CHANNELS_MODE_VSM        = 0x1B, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_AUXILIARY_TX_CHANNELS_MODE_VSM   = 0x1C, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_DATA_RX_CHANNELS_MODE_VSM        = 0x1D, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_AUXILIARY_RX_CHANNELS_MODE_VSM   = 0x1E, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_FILLER_SIGNAL_ENABLE_VSM         = 0x1F, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_WCUBS_ENABLE_VSM                 = 0x20, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_DRS_WCUBS_ENABLE_VSM             = 0x21, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_MAX_PACKET_DECODE_LENGTH_VSM     = 0x22, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_WCUBS_GRANULARITY_VSM            = 0x23, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_MIN_TXOP_VSM                     = 0x24, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_TXOP_SYNC_ENABLE_VSM             = 0x25, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_TXOP_SYNC_PLMN_IDS_VSM           = 0x26, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_RFFE_MODE_VSM                    = 0x27, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_IDLE_SENSING_VSM                 = 0x28, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_LTEU_COEXISTENCE_VSM             = 0x29, // Associated with CONFIG.request (LBT)
    FAPI_E_CFG_LBT_STATE_MACHINE_MODE_VSM           = 0x2A, // Associated with CONFIG.request (LBT)
    FAPI_E_LBT_PDSCH_REQ_VSM                        = 0x2B, // Associated with LBT_DL_CONFIG.request
    FAPI_E_LBT_DRS_REQ_VSM                          = 0x2C, // Associated with LBT_DL_CONFIG.request
    FAPI_E_LBT_PDSCH_RSP_VSM                        = 0x2D, // Associated with LBT_DL_CONFIG.indication
    FAPI_E_LBT_DRS_RSP_VSM                          = 0x2E, // Associated with LBT_DL_CONFIG.indication

    FAPI_E_VSM_TAG_LAST
} FAPI_E_VSM_TYPE;

typedef enum
{
    FAPI_E_EMTC_SEND_IND_ON_LAST_REPETITION     = 0x00,
    FAPI_E_EMTC_SEND_IND_ON_EVERY_REPETITION_SF = 0x01,
    FAPI_E_VSM_EMTC_LAST
} FAPI_E_VSM_EMTC_IND_REPORT_MODE;

typedef enum
{
    FAPI_E_CAT_GEN              = 0x00, // FAPI general params
    FAPI_E_CAT_RF               = 0x01, // FAPI RF related params
    FAPI_E_CAT_PHICH            = 0x02, // FAPI PHICH related params
    FAPI_E_CAT_SCH              = 0x03, // FAPI SCH related params
    FAPI_E_CAT_PRACH            = 0x04, // FAPI PRACH related params
    FAPI_E_CAT_PUSCH            = 0x05, // FAPI PUSCH related params
    FAPI_E_CAT_PUCCH            = 0x06, // FAPI PUCCH related params
    FAPI_E_CAT_SRS              = 0x07, // FAPI SRS related params
    FAPI_E_CAT_UL_RS            = 0x08, // FAPI Uplink Reference Signal related params
    FAPI_E_CAT_TDD              = 0x09, // FAPI TDD structure related params
    FAPI_E_CAT_PHY_CAPABILITY   = 0x0a, // FAPI PHY capabilities report
    FAPI_E_CAT_LAA              = 0x0b, // FAPI LAA params
    FAPI_E_CAT_EMTC             = 0x0c, // CAT-M params
    FAPI_E_CAT_VSM              = 0x0d, // Vendor Specific params
    FAPI_E_VSM_CFG_REP_CAT_LAST
} FAPI_E_VSM_CFG_REP_CAT;

/*****************************************
*  Common header that is included
*  at the beginning of all
*  FAPI Vendor Specific TLV message structure
******************************************
*/

typedef struct PACK_STRUCT FAPI_S_VSM_TLV_HDR {
    FAPI_UINT16           tag;                   // TLV tag
    FAPI_UINT8            length;                //Length in bytes of TLV including tag, length, padding and value fields
    FAPI_UINT8            padding;               // Alignment padding
} FAPI_T_VSM_TLV_HDR;


typedef struct PACK_STRUCT FAPI_S_VSM_HDR {
    FAPI_UINT16                         num_tlv;//Number of TLVs included in this message
    FAPI_UINT16                         size;   //Size in bytes of vendor specific message body including num_tlv, size and included TLVs
} FAPI_T_VSM_HDR;

typedef struct PACK_STRUCT FAPI_S_VSM_CFG_REP_TLV {
    FAPI_T_VSM_TLV_HDR      tlv_hdr;             // VSM TLV Header: tag + length
    FAPI_UINT32             value;               // Value to report
} FAPI_T_VSM_CFG_REP_TLV;


typedef struct PACK_STRUCT FAPI_S_VSM_CFG_REP_CAT {
    FAPI_UINT16             category;            // TLV category. one of FAPI_E_VSM_CFG_REP_CAT
    FAPI_UINT16             num_tlv;             // Number of TLVs included in this message
    FAPI_T_VSM_CFG_REP_TLV  tlvs[];              // array of CFG Report TLVs
} FAPI_T_VSM_CFG_REP_CAT;

typedef struct PACK_STRUCT FAPI_S_VSM_CFG_REPORT {
    FAPI_T_MSG_HDR          msg_hdr;
    FAPI_UINT8              n_categories;        // Number of categories reported
    FAPI_UINT8              padding[3];          // Size of the message - including 'n_categories' and 'size'
    FAPI_T_VSM_CFG_REP_CAT  categories[];        // array of CFG Report categories
}FAPI_T_VSM_CFG_REPORT;

/********************************************
*  FAPI Physical Interface Vendor Specific Messages
*********************************************
*/

// RX.ULSCH.Indication:
typedef struct PACK_STRUCT FAPI_S_RX_ULSCH_IND_VSM_TAG_VALUE {
    FAPI_UINT16                 rnti;                           //RNTI number for which the following indications are related (0.65535)
    FAPI_UINT8                  rssi;                           //Signal strength Integrated over all the received antennas and normalized to full BW (0:1:130 - -130:1:0 [dBm])
    FAPI_UINT8                  padding1;                       //Alignment padding
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
    FAPI_UINT16                 first_decoded_repetition;       //1- 2048; 0xffff - crc_error; First repetition instance in which the received ULSCH was succesfully decoded
    FAPI_UINT8                  padding[2];                     //Alignment padding
#endif //FAPI_VER_NUM_3_0_6
} FAPI_T_RX_ULSCH_IND_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_RX_ULSCH_IND_VSM_TAG {
    FAPI_T_VSM_TLV_HDR                  tag_header;     //VS tag header
    FAPI_T_RX_ULSCH_IND_VSM_TAG_VALUE   value;
} FAPI_T_RX_ULSCH_IND_VSM_TAG;

typedef struct PACK_STRUCT FAPI_S_RX_ULSCH_IND_VSM_MSG {
    FAPI_T_VSM_HDR              vsm_header;     //VS Message header
    FAPI_T_RX_ULSCH_IND_VSM_TAG tlvs[];         //TLVs
} FAPI_T_RX_ULSCH_IND_VSM_MSG;

// HARQ.Indication:
typedef struct PACK_STRUCT FAPI_S_HARQ_IND_PUCCH_VSM_TAG_VALUE {
    FAPI_UINT16                 rnti;           //RNTI number for which the following indications are related (0.65535)
    FAPI_UINT8                  rssi;           //Signal strength Integrated over all the received antennas and normalized to full BW (0:1:130 - -130:1:0 [dBm])
    FAPI_UINT8                  snr;            //Snr (0..120 - -20:0.5:40 [dB])
} FAPI_T_HARQ_IND_PUCCH_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_HARQ_IND_PUSCH_FDD_VSM_TAG_VALUE {
    FAPI_UINT16                 rnti;           //RNTI number for which the following indications are related (0.65535)
    FAPI_UINT8                  padding[2];     //Alignment padding
} FAPI_T_HARQ_IND_PUSCH_FDD_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_HARQ_IND_PUSCH_TDD_VSM_TAG_VALUE {
    FAPI_UINT16                 rnti;           //RNTI number for which the following indications are related (0.65535)
    FAPI_UINT8                  bundling;       // The best matched number of ack/nack per layer 0..3
    FAPI_UINT8                  padding;        //Alignment padding
} FAPI_T_HARQ_IND_PUSCH_TDD_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_HARQ_IND_VSM_TAG {
    FAPI_T_VSM_TLV_HDR                          tag_header;     //VS tag header
    union {
        FAPI_T_HARQ_IND_PUCCH_VSM_TAG_VALUE     pucch;
        FAPI_T_HARQ_IND_PUSCH_FDD_VSM_TAG_VALUE pusch_fdd;
        FAPI_T_HARQ_IND_PUSCH_TDD_VSM_TAG_VALUE pusch_tdd;
    }                                           value;          // All data-structures whithin value are of the same size
} FAPI_T_HARQ_IND_VSM_TAG;

typedef struct PACK_STRUCT FAPI_S_HARQ_IND_VSM_MSG {
    FAPI_T_VSM_HDR              vsm_header;     //VS Message header
    FAPI_T_HARQ_IND_VSM_TAG     tlvs[];         //TLVs
} FAPI_T_HARQ_IND_VSM_MSG;

// SR.Indication
typedef struct PACK_STRUCT FAPI_S_SR_IND_VSM_TAG_VALUE {
    FAPI_UINT16                 rnti;           //RNTI number for which the following indications are related (0.65535)
    FAPI_UINT8                  rssi;           //Signal strength Integrated over all the received antennas and normalized to full BW (0:1:130 - -130:1:0 [dBm])
    FAPI_UINT8                  snr;            //Snr (0..120 - -20:0.5:40 [dB])
} FAPI_T_SR_IND_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_SR_IND_VSM_TAG {
    FAPI_T_VSM_TLV_HDR          tag_header;     //VS tag header
    FAPI_T_SR_IND_VSM_TAG_VALUE value;
} FAPI_T_SR_IND_VSM_TAG;

typedef struct PACK_STRUCT FAPI_S_SR_IND_VSM_MSG {
    FAPI_T_VSM_HDR              vsm_header;     //VS Message header
    FAPI_T_SR_IND_VSM_TAG       tlvs[];         //TLVs
} FAPI_T_SR_IND_VSM_MSG;

// CQI.Indication:
typedef struct PACK_STRUCT FAPI_S_CQI_IND_PUCCH_VSM_TAG_VALUE {
    FAPI_UINT16                 rnti;           //RNTI number for which the following indications are related (0.65535)
    FAPI_UINT8                  rssi;           //Signal strength Integrated over all the received antennas and normalized to full BW (0:1:130 - -130:1:0 [dBm])
    FAPI_UINT8                  padding;
} FAPI_T_CQI_IND_PUCCH_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_CQI_IND_PUSCH_VSM_TAG_VALUE {
    FAPI_UINT16                 rnti;           //RNTI number for which the following indications are related (0.65535)
    FAPI_UINT8                  padding[2];     //Alignment padding
} FAPI_T_CQI_IND_PUSCH_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_CQI_IND_VSM_TAG {
    FAPI_T_VSM_TLV_HDR                          tag_header;     //VS tag header
    union {
        FAPI_T_CQI_IND_PUCCH_VSM_TAG_VALUE      pucch;
        FAPI_T_CQI_IND_PUSCH_VSM_TAG_VALUE      pusch;
    }                                           value;          // All data-structures whithin value are of the same size
} FAPI_T_CQI_IND_VSM_TAG;

typedef struct PACK_STRUCT FAPI_S_CQI_IND_VSM_MSG {
    FAPI_T_VSM_HDR              vsm_header;     //VS Message header
    FAPI_T_CQI_IND_VSM_TAG      tlvs[];         //TLVs
} FAPI_T_CQI_IND_VSM_MSG;


// RACH.Indication
typedef struct PACK_STRUCT FAPI_S_RACH_IND_VSM_TAG_VALUE {
    FAPI_UINT8                  preamable_id;       //The detected preamble (0..63)
    FAPI_UINT8                  rssi;               //Signal strength Integrated over all the received antennas and normalized to full BW (0:1:130 - -130:1:0 [dBm])
    FAPI_UINT8                  detection_metric;   //(0..63 0:1:63 [dB])
    FAPI_UINT8                  padding;            //Alignment padding
} FAPI_T_RACH_IND_VSM_TAG_VALUE;


typedef struct PACK_STRUCT FAPI_S_RACH_IND_VSM_TAG {
    FAPI_T_VSM_TLV_HDR              tag_header;     //VS tag header
    FAPI_T_RACH_IND_VSM_TAG_VALUE   value;
} FAPI_T_RACH_IND_VSM_TAG;

typedef struct PACK_STRUCT FAPI_S_RACH_IND_VSM_MSG {
    FAPI_T_VSM_HDR              vsm_header;     //VS Message header
    FAPI_T_RACH_IND_VSM_TAG     tlvs[];         //TLVs
} FAPI_T_RACH_IND_VSM_MSG;

// SRS.Indication
typedef struct PACK_STRUCT FAPI_S_SRS_IND_VSM_TAG_VALUE {
    FAPI_UINT16                 rnti;           //RNTI number for which the following indications are related (0.65535)
    FAPI_UINT8                  rssi;           //Signal strength Integrated over all the received antennas and normalized to full BW (0:1:130 - -130:1:0 [dBm])
    FAPI_UINT8                  padding;        //Alignment padding
} FAPI_T_SRS_IND_VSM_TAG_VALUE;


typedef struct PACK_STRUCT FAPI_S_SRS_IND_VSM_TAG {
    FAPI_T_VSM_TLV_HDR              tag_header;     //VS tag header
    FAPI_T_SRS_IND_VSM_TAG_VALUE    value;
} FAPI_T_SRS_IND_VSM_TAG;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_VSM_MSG {
    FAPI_T_VSM_HDR              vsm_header;     //VS Message header
    FAPI_T_SRS_IND_VSM_TAG      tlvs[];         //TLVs
} FAPI_T_SRS_IND_VSM_MSG;

//
// New MEASUREMENT.Indication FAPI message, transmitted each frame and contains different RF conditions
// Occupies the message type of 0x8c which is reserved by the FAPI standard
//
typedef struct PACK_STRUCT FAPI_S_RX_MEASUREMENT_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //SF, SFN at which the reported message is related [15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT8                  avg_ni;             //Noise and Interference Signal strength measured and averaged over all the non-allocated resources. This value is integrated over all the received antennas and normalized to full BW 0:1:130 -130:1:0 [dBm]
    FAPI_UINT8                  avg_ant1_rssi;      //Received signal strength from antenna 1 averaged over all scheduled data RBs in this SF as measured by PHY. Integer value representing: [-130:1:0]dBm (0..130)
    FAPI_UINT8                  avg_ant2_rssi;      //Received signal strength from antenna 2 averaged over all scheduled data RBs in this SF as measured by PHY. Integer value representing: [-130:1:0]dBm (0..130)
    FAPI_UINT8                  avg_ant3_rssi;      //Received signal strength from antenna 3 averaged over all scheduled data RBs in this SF as measured by PHY. Integer value representing: [-130:1:0]dBm (0..130)
    FAPI_UINT8                  avg_ant4_rssi;      //Received signal strength from antenna 4 averaged over all scheduled data RBs in this SF as measured by PHY. Integer value representing: [-130:1:0]dBm (0..130)
    FAPI_UINT8                  rx_ant1_gain;       //Rx gain of antenna 1 in dB. (0..100, 0xFF if not present).
    FAPI_UINT8                  rx_ant2_gain;       //Rx gain of antenna 2 in dB. (0..100, 0xFF if not present).
    FAPI_UINT8                  rx_ant3_gain;       //Rx gain of antenna 3 in dB. (0..100, 0xFF if not present).
    FAPI_UINT8                  rx_ant4_gain;       //Rx gain of antenna 4 in dB. (0..100, 0xFF if not present).
    FAPI_UINT8          padding;                    //Alignment padding
} FAPI_T_RX_MEASUREMENT_IND;

//
// New NI.Indication FAPI message, transmitted when VSM NI_PDU is recieved.
// Occupies the message type of 0x8d which is reserved by the FAPI standard
//
typedef struct PACK_STRUCT FAPI_S_RX_NI_PRB {
    FAPI_UINT8                       ni;             //Each RB reports one NI Value, range 0:1:130, 0xFF when the PRB is allocated to PRACH or PUCCH,-130:1:0 [dBm]
} FAPI_T_RX_NI_PRB;

typedef struct PACK_STRUCT FAPI_S_RX_NI_IND {
    FAPI_T_MSG_HDR                      msg_hdr;        //Message header
    FAPI_UINT32                         handle;         //An opaque handling returned in the NI.indication
    FAPI_UINT16                         sf_sfn;         //SFN/SF at which the reported measurements were performed [15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                         n_rb;           //Number of UL RBs/NI Reports according with BW, range 1:100
    FAPI_T_RX_NI_PRB                    rb[];
} FAPI_T_RX_NI_IND;


/*** Vendor Specific messages ***/
typedef struct PACK_STRUCT FAPI_S_VSM_TLV {
    FAPI_T_VSM_TLV_HDR                  tag_header;     //VS tag header
    FAPI_UINT32                         value[];
} FAPI_T_VSM_TLV;

    typedef struct PACK_STRUCT FAPI_S_VSM_MSG {
    FAPI_T_VSM_HDR                      vsm_header;     //VS Message header
    FAPI_T_VSM_TLV                      tlvs[];         //TLVs
} FAPI_T_VSM_MSG;

/*** Vendor Specific UL CONFIG REQUEST messages ***/
typedef struct PACK_STRUCT FAPI_S_NI_PDU_VSM_VALUE {
    FAPI_UINT32                         handle;         //An opaque handling returned in the NI.indication
} FAPI_T_NI_PDU_VSM_VALUE;


/*** Vendor Specific DL CONFIG REQUEST messages ***/
typedef struct PACK_STRUCT FAPI_S_POWER_BOOST_VSM_TAG_VALUE {
    FAPI_UINT16                         power_boost;    //Normalized value levels (relative) to accommodate different Tx Power Boosting used by eNb. range 0...12000 (Representing -6dB to 6dB in 0.001dB steps. (Value will be rounded to 0.5dB steps)
    FAPI_UINT8                          padding[2];     //Alignment padding
} FAPI_T_POWER_BOOST_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_POWER_BOOST_VSM_TAG {
    FAPI_T_VSM_TLV_HDR                  tag_header;     //VS tag header
    FAPI_T_POWER_BOOST_VSM_TAG_VALUE    value;
} FAPI_T_POWER_BOOST_VSM_TAG;

typedef struct PACK_STRUCT FAPI_S_POWER_BOOST_VSM_MSG {
    FAPI_T_VSM_HDR                  vsm_header;     //VS Message header
    FAPI_T_POWER_BOOST_VSM_TAG      tlv[];         //TLV
} FAPI_T_POWER_BOOST_VSM_MSG;

/*** Vendor Specific Configuration messages ***/
//CONFIG.request
//CFI
typedef struct PACK_STRUCT FAPI_S_CFG_CFI_VSM_TAG_VALUE {
    FAPI_UINT8                          cfi;            //Number of symbols for DL control (1-4)
    FAPI_UINT8                          padding[3];     //Alignment padding
} FAPI_T_CFG_CFI_VSM_TAG_VALUE;

//Version
typedef struct PACK_STRUCT FAPI_S_CFG_VERSION_VSM_TAG_VALUE {
    FAPI_UINT16                         vs_major_ver;   //Major version number of Vendor Specific API  (0 - 65535)
    FAPI_UINT8                          vs_minor_ver;   //Minor version number of Vendor Specific API  (0 - 255)
    FAPI_UINT8                          padding;        //Alignment padding
} FAPI_T_CFG_VERSION_VSM_TAG_VALUE;

//Test Mode
typedef struct PACK_STRUCT FAPI_S_CFG_ETM_VSM_TLV {
    FAPI_UINT8                          test_mode_enabled;  //Whether to this a Test Mode run
    FAPI_UINT8                          disable_all_zeros;  //Whether to disable the all-zeros mode even though PHY is running in Test Mode
    FAPI_UINT8                          disable_mi_override;//Whether to disable the hard-coded PHICH MI even though PHY is running in Test Mode
    FAPI_UINT8                          padding[1];         //Alignment padding
} FAPI_T_CFG_ETM_VSM_TLV;

//---------------------------------------------------------
// Release 13 support:

typedef struct PACK_STRUCT FAPI_S_CFG_EMTC_INDICATION_REP_MODE_VSM_TLV {
    FAPI_UINT32                         emtc_indication_rep_mode;
} FAPI_T_CFG_EMTC_INDICATION_REP_MODE_VSM_TLV;

// LAA configuration
// Data Channel Rx Mode
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_DATA_RX_CHANNELS_MODE_VSM_TAG_VALUE {
    FAPI_UINT32                         data_ch_rx_mode;            // Indicates whether W-CUBS is transmitted in the data channel
} FAPI_T_CFG_LBT_DATA_RX_CHANNELS_MODE_VSM_TAG_VALUE;

// Auxilairy Channel Rx Mode
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_AUXILIARY_RX_CHANNELS_MODE_VSM_TAG_VALUE {
    FAPI_UINT32                         aux_ch_rx_mode;         // Indicates whether W-CUBS is transmitted in the auxiliary channel.
} FAPI_T_CFG_LBT_AUXILIARY_RX_CHANNELS_MODE_VSM_TAG_VALUE;

// Data Channel Tx Mode
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_DATA_TX_CHANNELS_MODE_VSM_TAG_VALUE {
    FAPI_UINT32                         data_ch_tx_mode;            // Indicates the energy detection and packet detection mode in the data channel.
} FAPI_T_CFG_LBT_DATA_TX_CHANNELS_MODE_VSM_TAG_VALUE;

// Auxiliary Channel Tx Mode
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_AUXILIARY_TX_CHANNELS_MODE_VSM_TAG_VALUE {
    FAPI_UINT32                         aux_ch_tx_mode;         // Indicates whether W-CUBS is transmitted in the auxiliary channel.
} FAPI_T_CFG_LBT_AUXILIARY_TX_CHANNELS_MODE_VSM_TAG_VALUE;

// Filller Signal Enable
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_FILLER_SIGNAL_ENABLE_VSM_TAG_VALUE {
    FAPI_UINT32                         filler_enable;          // Indicates if filler signal transmission is enabled.
} FAPI_T_CFG_LBT_FILLER_SIGNAL_ENABLE_VSM_TAG_VALUE;

// W-CUBS Enable
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_WCUBS_ENABLE_VSM_TAG_VALUE {
    FAPI_UINT32                         wcubs_enable;           // Indicates if W-CUBS transmission is enabled
} FAPI_T_CFG_LBT_WCUBS_ENABLE_VSM_TAG_VALUE;

// DRS W-CUBS Enable
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_DRS_WCUBS_ENABLE_VSM_TAG_VALUE {
    FAPI_UINT32                         drs_wcubs_enable;           // Indicates if W-CUBS shall be transmitted before DRS.
} FAPI_T_CFG_LBT_DRS_WCUBS_ENABLE_VSM_TAG_VALUE;

// Max Packet Decode Length
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_MAX_PACKET_DECODE_LENGTH_VSM_TAG_VALUE {
    FAPI_UINT32                         max_packet_decode_usec;     // Max packet length in microseconds to decode
} FAPI_T_CFG_LBT_MAX_PACKET_DECODE_LENGTH_VSM_TAG_VALUE;

// W-CUBS Granularity
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_WCUBS_GRANULARITY_VSM_TAG_VALUE {
    FAPI_UINT32                         wcubs_granularity;          // Indicates the W-CUBS granularity in microseconds
} FAPI_T_CFG_LBT_WCUBS_GRANULARITY_VSM_TAG_VALUE;

// Min TXOP
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_MIN_TXOP_VSM_TAG_VALUE {
    FAPI_UINT32                         min_lte_txop;           // Minimal TXOP in subframes.
} FAPI_T_CFG_LBT_MIN_TXOP_VSM_TAG_VALUE;

// TXOP sync Enable
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_TXOP_SYNC_ENABLE_VSM_TAG_VALUE {
    FAPI_UINT32                         txop_sync_enable;           // Indicates whether L1 shall sync its TXOP with other eNBs (reuse-1).
} FAPI_T_CFG_LBT_TXOP_SYNC_ENABLE_VSM_TAG_VALUE;

// TXOP sync PLMN ID
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_TXOP_SYNC_PLMN_IDS_VSM_TAG_VALUE {
    FAPI_UINT32                         txop_sync_plmn_id;          // PLMN ID which is used to detect friendly eNB. L2 may send up to 8 instances of this TLV within LBT_CONFIG.request message in order to config multiple PLMN IDs.
} FAPI_T_CFG_LBT_TXOP_SYNC_PLMN_IDS_VSM_TAG_VALUE;

// RFFE
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_RFFE_MODE_VSM_TAG_VALUE {
    FAPI_UINT32                         rffe_mode;
} FAPI_T_CFG_LBT_RFFE_MODE_VSM_TAG_VALUE;

// Continuos Sensing
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_IDLE_SENSING_TAG_VALUE {
    FAPI_UINT32                         idle_sensing;           // Indicates if we run LBT with Idle sensing.
} FAPI_T_CFG_LBT_IDLE_SENSING_TAG_VALUE;

// Coexistence with LTEu UEs
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_LTEU_COEXISTENCE_VSM_TAG_VALUE {
    FAPI_UINT32                         coexsistence_lteu;          // Indicates if we support coexsistence with LTEu UEs or not.
} FAPI_T_CFG_LBT_LTEU_COEXISTENCE_VSM_TAG_VALUE;

// LBT state machine mode
typedef struct PACK_STRUCT FAPI_S_CFG_LBT_STATE_MACHINE_MODE_VSM_TAG_VALUE {
    FAPI_UINT32                         sm_mode;            // Indicates the LBT state machine mode
} FAPI_T_CFG_LBT_STATE_MACHINE_MODE_VSM_TAG_VALUE;


//PARAM.response
//Maximum users per TTI
typedef struct PACK_STRUCT FAPI_S_MAX_USERS_VSM_VALUE {
    FAPI_UINT8                          max_dl_users;   //Maximum users per TTI for each DL request
                                                        //(different RNTIs not including public channels)
    FAPI_UINT8                          max_ul_users;   //Maximum users per TTI for each UL request
                                                        //(different RNTIs not including public channels)
    FAPI_UINT8                          padding[2];     //Alignment padding
} FAPI_T_MAX_USERS_VSM_VALUE;

//Primary LTE carrier number
typedef struct PACK_STRUCT FAPI_S_PARAM_RSP_LTE_CAR_ID {
    FAPI_UINT32                         carrier_id;
} FAPI_T_PARAM_RSP_LTE_CAR_ID;

//PHY version
typedef struct PACK_STRUCT FAPI_S_PHY_CHANGE_LIST_TLV {
    FAPI_UINT32                         cl_num;     //Maximum users per TTI for each UL/DL request
} FAPI_T_PHY_CHANGE_LIST_TLV;

typedef struct PACK_STRUCT FAPI_S_PHY_VERSION_TLV {
    FAPI_UINT8                          chipnum;
    FAPI_UINT8                          feature_release;
    FAPI_UINT8                          release_candidate;
    FAPI_UINT8                          snapshot;
} FAPI_T_PHY_VERSION_TLV;

typedef struct PACK_STRUCT FAPI_S_PHY_COMPILATION_MODE_TLV {
    FAPI_UINT8                          system_mode;        //Maximum users per TTI for each UL/DL request
    FAPI_UINT8                          mirroring_mode;     //Maximum users per TTI for each UL/DL request
    FAPI_UINT8                          padding[2];     //Maximum users per TTI for each UL/DL request
} FAPI_T_PHY_COMPILATION_MODE_TLV;

//RF Topology
typedef struct PACK_STRUCT FAPI_S_RF_TOPOLOGY_TLV {
    FAPI_UINT32                         rf_topology;     //RF Topology
} FAPI_T_RF_TOPOLOGY_TLV;

// LAA LBT_DL_CONFIG_REQ
typedef struct PACK_STRUCT FAPI_S_LBT_PDSCH_REQ_VSM_PDU {
    FAPI_UINT32                  m_cca;              // Indicates the value of WeCCA defer factor (m) in slots.
    FAPI_UINT32                  M_cca ;             // Indicates the value of agg. CSMA backoff counter (N) in slots.
    FAPI_UINT32                  one_shot_enabled;   // In Japan, when transmitting more than 4 msec, B2B mechanism is activated, where
                                                //immediately after TX, a 34 usec window is checked.
                                                //if vacant - eNB can resume TX
                                                //o/w - abandon
}FAPI_T_LBT_PDSCH_REQ_VSM_PDU;

typedef struct PACK_STRUCT FAPI_S_LBT_DRS_REQ_VSM_PDU {
    FAPI_UINT32                  n_cca;              // Indicates the value of the initial defer factor (n).
    FAPI_UINT32                  N_cca ;             // Indicates the initial value of the backoff counter (N).
    FAPI_UINT32                  force_tx;           // Indicates whether DRS shall be transmitted regardless of CCA result. Values: 0 = Do not force Tx (Reserved for LAA), 1 = Force Tx
} FAPI_T_LBT_DRS_REQ_VSM_PDU;

// LAA LBT_DL_CONFIG_IND
typedef struct PACK_STRUCT FAPI_S_LBT_PDSCH_RSP_VSM_TAG_VALUE {
    FAPI_UINT32                  reason;                         // Indicates the success/failure reason.
    FAPI_UINT32                  cubs_and_filler_duration;       // Indicates the duration in microseconds the channel was occupied before first downlink subframe (equals to W-CUBS packet duration + filler signal duration). Valid when LBT result = SUCCESS.
    FAPI_UINT32                  remaining_backoff_counter;      // Backoff counter (N) value at the time the message was generated. Valid when LBT result  = FAILURE.
    FAPI_UINT32                  remaining_csma_backoff_counter; // CSMA Backoff counter (M) value at the time the message was generated. Valid when LBT result  = FAILURE.
    FAPI_UINT32                  nav;                            // NAV value in microseconds at the time the message was generated. Valid when LBT result = FAILURE.
} FAPI_T_LBT_PDSCH_RSP_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_LBT_PDSCH_PDU_VSM_TAG {
    FAPI_T_VSM_TLV_HDR              tag_header;     //VS tag header
    FAPI_T_LBT_PDSCH_RSP_VSM_TAG_VALUE  value;
} FAPI_T_LBT_PDSCH_PDU_VSM_TAG;

typedef struct PACK_STRUCT FAPI_S_LBT_DRS_RSP_VSM_TAG_VALUE {
    FAPI_UINT32                  reason;             // Indicates the success/failure reason.
} FAPI_T_LBT_DRS_RSP_VSM_TAG_VALUE;

typedef struct PACK_STRUCT FAPI_S_DRS_PDU_VSM_TAG {
    FAPI_T_VSM_TLV_HDR              tag_header;     //VS tag header
    FAPI_T_LBT_DRS_RSP_VSM_TAG_VALUE    value;
} FAPI_T_DRS_PDU_VSM_TAG;

typedef struct PACK_STRUCT FAPI_S_LBT_DL_IND_VSM_MSG {
    FAPI_T_VSM_HDR              vsm_header;     //VS Message header
    FAPI_UINT32                      tlvs[];         //TLVs
} FAPI_T_LBT_DL_IND_VSM_MSG;

// LBT measurments indication
typedef struct PACK_STRUCT FAPI_S_LBT_VSM_MEAS_IND{
    FAPI_T_MSG_HDR          msg_hdr;                    //Message header
    FAPI_UINT16                  sf_sfn;                     //Indicates the SF/SFN in which the measurements were performed. [15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT32                  meas_duration;              //Duration in microseconds of the reported measurement period
    FAPI_UINT32                  ed;                         //Number of slots in current measurement period where ED > ED threshold. Generated when LBT Indication is sent during LBT periods and at the end of the subframe during Idle periods
    FAPI_UINT32                  pure_ed;                    //Number of slots in current measurement period where ED > ED_threshold and there is no overlapping with packet detections (including NAV). Generated when LBT Indication is sent during LBT periods and at the end of the subframe during Idle periods
    FAPI_UINT32                  non_friendly_ed;            //Number of slots in current measurement period where ED > ED threshold that overlap non friendly eNodeB detections (Including NAV).    Generated when LBT Indication is sent during LBT periods and at the end of the subframe during Idle periods
    FAPI_UINT32                  pd;                         //Sum duration in microseconds of all packet detections during the measurement period. Generated when LBT Indication is sent during LBT periods and at the end of the subframe during Idle periods
    FAPI_UINT32                  non_friendly_pd;            //Sum duration in microseconds of all non-friendly eNodeB packet detections during the measurement period. Generated when LBT Indication is sent during LBT periods and at the end of the subframe during Idle periods
    FAPI_UINT32                  pd_crc_ok;                  // Num of decoded packets with CRC ok
    FAPI_UINT32                  pd_crc_error;               // Num of decoded packets with CRC failure
    FAPI_UINT32                  lte_txop;                   //LTE TXOP in subframes. Generated when the medium is won and an LBT success indication is sent to L2
    FAPI_UINT32                  reuse1;                     //Sum duration in microseconds where TX overlapped with friendly eNodeB transmission. Generated when the medium is won and an LBT success indication is sent to L2
    FAPI_UINT32                  cubs_and_filler_duration;   //Sum duration in microseconds of W-CUBS and filler transmission during the measurement period. Generated when the medium is won and an LBT success indication is sent to L2
    FAPI_UINT32                  rssi;
} FAPI_T_LBT_VSM_MEAS_IND;

/*
 * -----------------------------------------------------------
 * Platform-specific section
 * -----------------------------------------------------------
 */

#endif //_I_FAPI_VS_H


/*
 * -----------------------------------------------------------
 * End of file
 * -----------------------------------------------------------
 */









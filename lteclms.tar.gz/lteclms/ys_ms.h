/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/**********************************************************************

    Name:   LTE MAC Convergence layer

    Type:   C include file

    Desc:   Defines required by LTE MAC Convergence Layer for MSPD PHY

    File:   ys_ms.h

    Sid:      ys_ms.h@@/main/TeNB_Main_BR/6 - Mon Aug 11 16:42:36 2014

    Prg:    hs

**********************************************************************/

#ifndef __YS_MS_H__
#define __YS_MS_H__


#include "rl_interface.h"
#include "rl_common.h"


#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
#ifndef BATCH_PROCESSING_DL
#define BATCH_PROCESSING_DL
#endif
#ifndef BATCH_PROCESSING_UL
#define BATCH_PROCESSING_UL
#endif
#endif

#define YS_LOG_UL_DIRECTION 0
#define YS_LOG_DL_DIRECTION 1

#define YS_TTI_START_MAX_DELAY 0.25
#define YS_MAX_DAT_REQ_DELAY   0.75
/* Reduced from 1.0 to 0.92 so that API is not delivered to PHY after dummy */ 
/* API is generated. */
#define YS_TTI                 0.92
#ifdef RGL_SPECIFIC_CHANGES
#ifdef XEON_SPECIFIC_CHANGES
#define MAX_NUM_L1_MESSAGES_PER_TTI  40
#else
#define MAX_NUM_L1_MESSAGES_PER_TTI  20
#endif
#else
#define MAX_NUM_L1_MESSAGES_PER_TTI  10
#endif
#define YS_SI_RNTI        0xffff
#define YS_P_RNTI         0xfffe
#define YS_MAX_RARNTI     10

#ifdef RG_SCH_DYNDLDELTA
#define YS_DYN_DELTA_CHG_ENB 1
#endif
#ifdef MSPD_CORE1_L2_STATS

#define EVTYSSELFMSGSTAT  1

/* Memset to value */
#define YS_MEM_SET(_arg, _val, _size) \
{ \
  cmMemset((U8 *)_arg, (U8)_val, _size); \
}


#define YS_FREE_BUF(_buf)           \
{                                   \
   if (_buf != NULLP)               \
   {\
      SPutMsg(_buf);                \
   }\
      _buf = NULLP;\
}

#endif
#ifndef CA_PHY
#define YS_CQIPMICONF_MSK         0x3  /* CQIPMICONFIG bitmask for CQI valididty -  ccpu129502  */
#else
#define YS_CQIPMICONF_MSK         0x1  /* CQIPMICONFIG bitmask for CQI valididty */
#endif

#ifdef LTE_ADV
#define YS_HARQ_ACKNACK_CONF_MSK  0x1  /* HARQ Confident bitmask for HARQ ACK/NACK Good/bad */
#define YS_RI_CONF_MSK            0x1  /* RI Confident Bitmask for Good/Bad */
#endif


#ifdef RGL_SPECIFIC_CHANGES
#define YS_MS_TTI_DIFF(_cur, _prev) ((U32)(_cur - _prev) / 150000.0) 
#define MS_TIME_DIFF_US(_cur, _prev) ((U32)(_cur - _prev) / 250)
#else
#define MS_TIME_DIFF_US(_cur, _prev) ((U32)(_cur - _prev) / 250)
#define MS_TIME_DIFF_CLK(_cur, _prev) (U32)(_cur - _prev)
#define MS_US_CLK 250

#define MS_CHK_TIME(endTm,startTm,limit) \
{\
   U32 _diffTime = MS_TIME_DIFF_CLK(endTm, startTm);\
   if (_diffTime > limit * MS_US_CLK)\
   {\
      MSPD_DBG (" process Time is %luus, exceeds %uus\n", _diffTime / MS_US_CLK, limit);\
   }\
}
#endif

/* This is the maximum RXSDU_IND count from the PHY per subframe. 
 * As per the discussion with MSPD we should receive only one 
 * RXSDU_IND(PUCCH or PUSCH) per UE in a particular subframe. 
 * And this should be changed based on the number of UEs.*/ 
#define MAX_UL_PHY_MSG_PER_TTI  TENB_MAX_UE_SUPPORTED

#ifdef YS_PHY_STOP_AUTO
/*Can be changed as required  '0' when this flag is disabled*/
#define YS_MS_SF_COUNT     0  
#else
/*Do not change as required  '0' when this flag is disabled*/
#define YS_MS_SF_COUNT     0 
#endif

#define YS_MS_DB_UNIT 256
/*ys004.102 :  Merged MSPD code with phy 1.7 */

#define YS_FREE_SDU(_sdu) \
{\
   if (_sdu != NULLP) \
   {\
      cmFreeMem ((Ptr)(_sdu));\
      _sdu = NULLP;\
   }\
}

/* added , phy instance id should always be 0*/
#define YS_PHY_INST_ID             0
/*#define YS_PHY_CELL_ID             1*/
#define YS_MAX_CELL_HASH_BINS      2

#define YS_MS_ACCESS_MODE_OFDMA     0
#define YS_MS_ACCESS_MODE_SCFDMA    1
#define YS_MS_FAST_FW_PRE_LOCK_NUM  1600

#define YS_MS_GET_CH_BW(_cfg)        \
((_cfg.dlBw == CTF_BW_RB_6) ?  0 :   \
 (_cfg.dlBw == CTF_BW_RB_15) ? 1 :   \
 (_cfg.dlBw == CTF_BW_RB_25) ? 2 :   \
 (_cfg.dlBw == CTF_BW_RB_50) ? 3 :   \
 (_cfg.dlBw == CTF_BW_RB_75) ? 4 : 5 )

#define YS_MS_GET_DUP_MODE(_cfg) \
((_cfg.duplexMode == CTF_DUPMODE_FDD) ? 0 : 1)

#define YS_MS_GET_RSRC_BW(_cfg)      \
((_cfg.scSpacing == CTF_SC_SPACING_15KHZ) ? 12 : 24)

#define YS_MS_GET_NUM_TX_ANT(_cfg)         \
((_cfg.antPortsCnt == CTF_AP_CNT_1) ? 1 :    \
 (_cfg.antPortsCnt == CTF_AP_CNT_2) ? 2 : 4)

/* As per the specification 36.101
   Table F.5.3-1
*/
#define YS_MS_GET_FFT_SIZE(_cfg)        \
((_cfg.dlBw == CTF_BW_RB_6)  ? 128  :   \
 (_cfg.dlBw == CTF_BW_RB_15) ? 256  :   \
 (_cfg.dlBw == CTF_BW_RB_25) ? 512  :   \
 (_cfg.dlBw == CTF_BW_RB_50) ? 1024 :   \
 (_cfg.dlBw == CTF_BW_RB_75) ? 2048 : 2048 )

#define YS_MS_GET_DL_BW(_cfg)         \
((_cfg.dlBw == CTF_BW_RB_6) ?  6 :    \
 (_cfg.dlBw == CTF_BW_RB_15) ? 15 :   \
 (_cfg.dlBw == CTF_BW_RB_25) ? 25 :   \
 (_cfg.dlBw == CTF_BW_RB_50) ? 50 :   \
 (_cfg.dlBw == CTF_BW_RB_75) ? 75 : 100 )

#define YS_MS_GET_UL_BW(_cfg)         \
((_cfg.ulBw == CTF_BW_RB_6) ?  6 :    \
 (_cfg.ulBw == CTF_BW_RB_15) ? 15 :   \
 (_cfg.ulBw == CTF_BW_RB_25) ? 25 :   \
 (_cfg.ulBw == CTF_BW_RB_50) ? 50 :   \
 (_cfg.ulBw == CTF_BW_RB_75) ? 75 : 100 )

#define YS_MS_GET_REF_SIG_POW(_cfg) (_cfg.refSigPwr + 30)

#define YS_MS_GET_RE_PER_PRB(_cfg)            \
((_cfg.antPortsCnt == CTF_AP_CNT_1) ? 80 :    \
 (_cfg.antPortsCnt == CTF_AP_CNT_2) ? 76 : 72)

#define YS_MS_GET_CP_TYPE(_cfg)      \
((_cfg.cycPfx == CTF_CP_NORMAL) ? 0 : 1)

#define YS_RACH_REPORT_MODE_INDV   0
#define YS_RACH_REPORT_MODE_GLOBAL 1

#define YS_TX_SDU_CFM_DIS          0
#define YS_TX_SDU_CFM_ENB          1

#define YS_SDU_CFG_NO_SHARED_MEM   0
#define YS_SDU_CFG_PTR             1

#define YS_PHY_INIT_SFN            0
#define YS_PHY_INIT_SF             0
#define YS_PHY_INIT_SLOT           0

#define YS_NUM_PHY_CELLS           3
/* This value is CGI , can be 20bit length for MACRO eNB and 28Bit length 
 * for HOME eNB 
 * CCPU eNodeB is of type MACRO, so limiting this to 2 power 20 
 */
#define YS_NUM_LOG_CELLS           1048576

#define YS_NUM_SFN                 1024
#define YS_NUM_SUB_FRAMES          10
#define YS_TOTL_SUB_FRAMES_IN_SFN  10240


#define YS_MEM_SDU_SIZE            1024

#ifdef TFU_TDD
#define YS_NUM_PRACH_TDD_CFG       64
#define YS_NUM_TDD_SF_CFG          7
#define YS_NUM_PRACH_TDD_MAP       64
#define YS_ODD_SF_OFFSET           10
#define YS_NUM_CFG_PER_PRACH_CFG   7

#define YS_DRA_NA                  -1
#define YS_DRA_0_POINT_5           0
#define YS_DRA_1                   1
#define YS_DRA_2                   2
#define YS_DRA_3                   3
#define YS_DRA_4                   4
#define YS_DRA_5                   5
#define YS_DRA_6                   6

#define YS_rRA_NA                  -1
#define YS_rRA_0                   0
#define YS_rRA_1                   1
#define YS_rRA_2                   2

#define YS_FREQ_RES_IDX_0          0
#define YS_FREQ_RES_IDX_1          1
#define YS_FREQ_RES_IDX_2          2
#define YS_FREQ_RES_IDX_3          3
#define YS_FREQ_RES_IDX_4          4
#define YS_FREQ_RES_IDX_5          5

#define YS_PRACH_NOT_PRSNT         0x0
#define YS_PRACH_FREQ_IDX_0        0x1
#define YS_PRACH_FREQ_IDX_1        0x2
#define YS_PRACH_FREQ_IDX_2        0x4
#define YS_PRACH_FREQ_IDX_3        0x8
#define YS_PRACH_FREQ_IDX_4        0x16
#define YS_PRACH_FREQ_IDX_5        0x32

#define YS_SF_0                    0
#define YS_SF_1                    1
#define YS_SF_2                    2
#define YS_SF_3                    3
#define YS_SF_4                    4
#define YS_SF_5                    5
#define YS_SF_6                    6
#define YS_SF_7                    7
#define YS_SF_8                    8
#define YS_SF_9                    9



#define YS_TDD_DL_SUBFRAME     1
#define YS_TDD_UL_SUBFRAME     2
#define YS_TDD_SPL_SUBFRAME    3
#define YS_DL_MAX_HARQ_FDBK    8

#define YS_MS_ADD_TO_CRNT_TIME(crntTime, toFill, incr)          \
   if ((crntTime.subframe + (incr)) >= 10)   \
      toFill.sfn = (crntTime.sfn + \
            (crntTime.subframe + (incr))/10) \
                                                % 1024;\
   else                                                  \
      toFill.sfn = crntTime.sfn;                              \
   toFill.subframe = (crntTime.subframe + (incr)) % 10;

#endif /*end of TDD*/

#define YS_NUM_PRACH_FDD_CFG       64
#define YS_NUM_PRACH_PRES_ARR      TENB_MAX_UE_SUPPORTED

#define YS_NUM_SR_CFG              157

#define YS_NUM_SRS_CFG              637

#define YS_SR_PERIOD_5             5
#define YS_SR_PERIOD_10            10
#define YS_SR_PERIOD_20            20
#define YS_SR_PERIOD_40            40
#define YS_SR_PERIOD_80            80

#define YS_SRS_PERIOD_2             2
#define YS_SRS_PERIOD_5             5
#define YS_SRS_PERIOD_10            10
#define YS_SRS_PERIOD_20            20
#define YS_SRS_PERIOD_40            40
#define YS_SRS_PERIOD_80            80
#define YS_SRS_PERIOD_160           160
#define YS_SRS_PERIOD_320           320

#define YS_NUM_CQI_CFG              541

#define YS_CQI_PERIOD_1             1
#define YS_CQI_PERIOD_5             5
#define YS_CQI_PERIOD_10            10
#define YS_CQI_PERIOD_20            20
#define YS_CQI_PERIOD_40            40
#define YS_CQI_PERIOD_80            80
#define YS_CQI_PERIOD_160           160
#define YS_CQI_PERIOD_32            32
#define YS_CQI_PERIOD_64            64
#define YS_CQI_PERIOD_128           128

#define YS_PREAM_FRMT_NA           -1
#define YS_PREAM_FRMT_0            0
#define YS_PREAM_FRMT_1            1
#define YS_PREAM_FRMT_2            2
#define YS_PREAM_FRMT_3            3
#define YS_PREAM_FRMT_4            4

enum{
   YS_MS_INV_EVENT = 0,
   YS_MS_EVENT_PARAM,
   YS_MS_EVENT_PARAM_RSP,
   YS_MS_EVENT_CFG,
   YS_MS_EVENT_CFG_RSP,
   YS_MS_EVENT_START_RSP,
   YS_MS_EVENT_STOP,
   YS_MS_EVENT_STOP_RSP,
   YS_MS_EVENT_CFG_LAA,
   YS_MS_EVENT_LAA_SCAN_REQ,
   YS_MS_EVENT_LAA_SCAN_IND,
   YS_MS_MAX_EVNT
};
#if 0
/* LTE_UNLICENSED */
#define YS_MS_MAX_EVNT             11




#define YS_MS_INV_EVENT            0
#define YS_MS_EVENT_CFG            1
#define YS_MS_EVENT_CFG_RSP        2
//#define YS_MS_EVENT_START          4
#define YS_MS_EVENT_START_RSP      3
#define YS_MS_EVENT_STOP           4  /* PST-CelReset changed from 5 t0 4*/
#define YS_MS_EVENT_STOP_RSP       5  /* PST-CelReset changed from 6 t0 5*/


/* LTE_UNLICENSED */
#define YS_MS_EVENT_CFG_LAA        6
#define YS_MS_EVENT_LAA_SCAN_REQ   7
#define YS_MS_EVENT_LAA_SCAN_IND   8
#endif



#if 0
/*CNM Events*/
#define YS_MS_CNM_EVENT_STOP       0  
#define YS_MS_CNM_EVENT_STOP_RSP   1  
#define YS_MS_CNM_NMM_START        0  
#endif

#define YS_ENB_UL_SCH              5
#define YS_ENB_RACH                6
#define YS_ENB_UCI                 7

#define YS_BCH_RNTI                0xffff

#define YS_NUM_OF_RA_RNTIS         1
#define YS_NUM_OF_TBS              1
#define YS_NUM_OF_PREAMBLES        1
#define YS_NUM_OF_RACH_OCCASIONS   1


#define YS_NUM_UES                 TENB_MAX_UE_SUPPORTED + 61

#define YS_NUM_MODULATION          8

#define YS_REPEAT_CYCLE      1
#define YS_PERSIST_ENABLE    0

#define ACKNACKREPT          0

#define NOMPDSCHRSEPROFF     0

#define YS_CODING_DESC       TURBOCDR
#define YS_BLK_CODE_CAT      1
#define YS_BLK_CODE_CAT_DIS  0
#define YS_CRC_SCRAMBLING    0
#define YS_SINGLE_MAPPING    1
#define YS_TX_PWR_CNTRL      0
#define YS_HALF_ITERATIONS  16

/* PUCCH Definitions */
#define YS_PUCCH_CRC_LEN     0
#define YS_PUCCH_COD_DES     0
#define YS_PUCCH_BLK_CAT     0
#define YS_PUCCH_MCS_TYP     0

/* PUCCH Message Types */
#define YS_MS_SR_REQ       0x0001    /* SR type */
#define YS_MS_SRS_REQ      0x0002    /* SRS type */
#define YS_MS_CQI_REQ      0x0004    /* CQI type */
#define YS_MS_HARQ_REQ     0x0008    /* HARQ type */

/* OFFSET BETWEEN PHY AND MAC */
#define YS_MS_PHYMAC_SF_OFFSET   0x01
/* Message allocation types */
#define YS_MS_MSG_COMMON   0		/* Common area */
#define YS_MS_MSG_FAST     1		/* I-CPU with direct access */

#define YS_MS_MAX_SDU_SZ 8192 /* Maximum size of the SDU in bytes */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
#define YS_MS_MAX_MEM_SIZE 12288
#define YS_MS_MAX_ZBC_API_POINT 600 
#endif

#ifdef TENB_T2K3K_SPECIFIC_CHANGES
#ifdef TENB_AS_SECURITY
#define YS_MS_MAX_QUEUE 2                          /*This can be changed upto a max
                                               of 64 based on performance*/
#define YS_MS_MAX_JOBS_IN_QUEUE 32      /*This can be changed upto a max of 256
                                    based on performance*/
#endif
#endif
/* Free of message header */
#define YS_FREE_MSG(_msg)           \
{                                   \
   if (_msg != NULLP)               \
   {                                \
      MsgFreeBuffercmFreeMem (_msg);\
      _msg = NULLP;                 \
   }                                \
}

/* Memory allocation/free macros */
#define YS_MS_ALLOC(_buf, _size)\
{\
   if (SGetSBuf(ysCb.ysInit[0].region, ysCb.ysInit[0].pool, (Data **)&_buf,   \
                (Size) _size) == ROK)                                   \
   {                                                                    \
      cmMemset((U8 *)(_buf), 0, _size);                                 \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      (_buf) = NULLP;                                                   \
   }                                                                    \
}

#define YS_MS_FREE(_buf, _size, index)\
{\
    if (_buf != NULLP)                                               \
   {                                                                 \
      (Void) SPutSBuf(ysCb.ysInit[index].region, ysCb.ysInit[index].pool,          \
            (Data *) _buf, (Size) _size);                            \
      _buf = NULLP;                                                  \
   }                                                                 \
}

#define YS_MS_ALLOC_BUF(_buf, index)\
{\
   if (SGetMsg(ysCb.ysInit[index].region, 2 /* ysCb.ysInit.pool */,       \
   (Buffer **)&_buf) != ROK)                               \
   {                                                       \
      (_buf) = NULLP;                                      \
   }                                                       \
}

#define YS_MS_FREE_BUF(_buf)\
{\
   if (_buf != NULLP)                                      \
   {                                                       \
      SPutMsg(_buf);                                       \
	  _buf = NULLP;										   \
   }                                                       \
}

#define   YS_MS_LAST_CHAN_OFFSET   4
#define   YS_MS_CI_POWER           -32768
#define   PAD                      0x00000000

#define YS_MS_PRIM_TMG_DIFF        2
/* Increment sfn and subframe */
#define YS_INCR_TIMING_INFO(_timingInfo, _delta)                        \
{                                                                       \
   _timingInfo.subframe += _delta;										\
   if (_timingInfo.subframe >= YS_NUM_SUB_FRAMES)                       \
   {																	\
      _timingInfo.subframe -= YS_NUM_SUB_FRAMES;						\
      _timingInfo.sfn += 1;                              				\
      if(_timingInfo.sfn >= YS_NUM_SFN)                                 \
      { \
         _timingInfo.sfn -= YS_NUM_SFN;									\
         _timingInfo.hfn += 1;                                          \
         if (_timingInfo.hfn >= YS_NUM_SFN)								\
            _timingInfo.hfn -= YS_NUM_SFN;								\
      } \
   }	\
}

#define  YsUiTfuBndReq TfUiTfuBndReq
#define  YsUiTfuUbndReq TfUiTfuUbndReq
#define  YsUiTfuSchBndReq TfUiTfuSchBndReq
#define  YsUiTfuSchUbndReq TfUiTfuSchUbndReq
#define  YsUiTfuRecpReq TfUiTfuRecpReq
#define  YsUiTfuCntrlReq TfUiTfuCntrlReq
#define  YsUiTfuDatReq TfUiTfuDatReq
#ifdef L2_OPTMZ
#define  YsUiTfuDelDatReq TfUiTfuDelDatReq
#endif
#define  YsUiCtfCnmInitSyncReq TfUiCtfCnmInitSyncReq
#define  YsUiCtfCnmInitSyncRsp TfUiCtfCnmInitSyncRsp
#define  YsUiCtfCnmCellSyncReq TfUiCtfCnmCellSyncReq
#define  YsUiCtfCnmCellSyncRsp TfUiCtfCnmCellSyncRsp
#define  YsUiCtfCnmCellSyncInd TfUiCtfCnmCellSyncInd

#define YS_MS_SETBITRANGE(_buf, _start, _len, _val) \
   ysMsSetBitRange (_buf, _start, _len, _val)

#ifndef CCPU_MLOG
#define YS_DELYD_PRINTF(_ARG_STR, _ARG_VAL) \
{\
	uart_printf(_ARG_STR, _ARG_VAL);\
}
#else
#define YS_DELYD_PRINTF(_ARG_STR, _ARG_VAL)
#endif

/* HARQ */
#define YS_TIMING_INFO_SAME(_t1, _t2) (((_t1).sfn == (_t2).sfn) && \
      ((_t1).subframe == (_t2).subframe))

#define YS_MS_FILL_PHY_LIST_ELEM(_pElem, _frameNum, _sfNum, _msgPtr, _size, _type)\
{\
(_pElem)->frameNumber = (_frameNum);\
(_pElem)->MessageType = (_type);\
(_pElem)->subframeNumber = (_sfNum);\
(_pElem)->MessageLen = (_size);\
(_pElem)->Next = NULLP;\
(_pElem)->MessagePtr = (U8*)(_msgPtr);\
}

#define YS_MS_CEIL(_a, _b) (((_a) + (_b) - 1)/(_b))

#define YS_MS_DECR_TIME(crntTime, toFill, dcr)  do  \
{                                                  \
   if (crntTime.sfn == 0)                          \
{                                                  \
   if ((crntTime.subframe - (dcr)) < 0)              \
   {                                               \
      toFill.sfn = YS_NUM_SFN - 1;                 \
   }                                               \
   else                                            \
   {                                               \
   toFill.sfn = crntTime.sfn;                      \
   }                                               \
}                                                  \
else                                               \
{                                                  \
   if ((crntTime.subframe - (dcr)) < 0)              \
   {                                               \
   toFill.sfn = crntTime.sfn - 1;                  \
   }                                               \
   else                                            \
   toFill.sfn = crntTime.sfn;                      \
}                                                  \
   toFill.subframe = \
   (YS_NUM_SUB_FRAMES + crntTime.subframe - (dcr)) % (YS_NUM_SUB_FRAMES);   \
}while(0)

#ifndef YS_MS_NO_TA
#define YS_MS_TA_THROTTLED(_ue)  ((_ue)->tarptInfo.lnk.node != NULL)
#ifdef PHY_3829
#define YA_MS_TA_AVG_TIME         32
#define YA_MS_TA_AVG_TIMElog2     5
#define YS_MS_TA_AVG_MIN_CQI_DB   -3
#define YS_MS_TA_AVG_MIN_CQI      ((YS_MS_TA_AVG_MIN_CQI_DB * 2) + 128)
#endif
#endif

#define YS_MS_PHY_SHUTDOWN_CFM  0x01;
#define YS_MS_TX_PWR_DOWN_CFM  0x02;
#define YS_MS_TX_PWR_UP_CFM    0x04;
#ifdef TENB_RTLIN_CHANGES
#define YS_RX_TASK_PRIORITY 99
#endif
#define YS_ADD_PELEM_L1MSG_LIST(subframe, cellCb, pElem)\
{\
   U32 numL1Msg = cellCb->dlEncL1Msgs[subframe].numL1Msg; \
   cellCb->dlEncL1Msgs[subframe].l1Msg[numL1Msg] =  pElem; \
   cellCb->dlEncL1Msgs[subframe].numL1Msg++;\
}

#ifdef ENABLE_CNM
/* Adding macros for CNM message Id's */
/* Macros for ICTA Msg Id's */
#define YS_CNM_ICTA_START_REQ   90
#define YS_CNM_ICTA_START_RESP  91
#define YS_CNM_ICTA_STOP_REQ    92
#define YS_CNM_ICTA_STOP_RESP   93
#define YS_CNM_ICTA_SYNC_IND    96
#define YS_CNM_ICTA_FOE_REQ     98
#define YS_CNM_ICTA_FOE_RESP    99
#define YS_CNM_INIT_SYNC_REQ    100

#define YS_CNM_MAX_VENDOR_LIST  6 /* same MAX_VENDOR_LIST listed in interface API header file */
#define YS_CNM_MAX_EARFCN_TABLE_SIZE 8 /* from freq band 33 to 40
                                        * For FDD, this needs to be modified
                                        * */
#define YS_CNM_RADIO_ELMNT_SIZE 20 /* From the CNM API doc */


#define NMM_START_MSG_LEN       26 
#define NMM_STOP_MSG_LEN        4  
#define NMM_PBCH_CFG_REQ_LEN    11
#define NMM_CELL_SEARCH_REQ_LEN 8

#define YS_MS_MAX_PCI_COUNT    50
#define YS_MS_MAX_VENDOR_FIELD_SIZE 6
#endif


/* LTE_UNLICENSED */
#define SCHED_OFF 0
#define SCHED_ON  1



#endif /* __YS_MS_H__ */
/********************************************************************30**

         End of file:     ys_ms.h@@/main/TeNB_Main_BR/6 - Mon Aug 11 16:42:36 2014

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      pk   1. initial release.
/main/1    ys004.102  vr   1. Merged MSPD code with phy 1.7
*********************************************************************91*/

/*=============================================================================
 *An test application that will transmit data from krait to q6 via danipc
 *
 *Copyright (c) 2014 Qualcomm Technologies, Inc. All Rights Reserved.
 *Qualcomm Technologies Proprietary and Confidential.
 *=============================================================================*/
//#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <getopt.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netpacket/packet.h>
#include <linux/if.h>
#include <time.h>
#include <stdint.h>
#include "danipc_ioctl.h"
//#include "procPrivsWrapper.h"
#include <linux/capability.h>
#include <pthread.h>
#include "fapiApiInternal.h"
#include "envopt.h"             /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "resultcodes.h"

#include "ssi.h"           /* system services */
#include "gen.h"                /* general layer */
#include "tfu.h"
#include "ctf.h"
#include "LtePhyL2Api.h"
#include "ys_ms.h"
#include "apidefs.h"
#include "lys.h"  

#include "gen.x"                /* general layer */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"

#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#include "ctf.x"

#include "ys_ms.x"

//#include "procPrivsWrapper.h"

#include <fcntl.h>	
#include <sys/stat.h>
#include <errno.h>
#include <getopt.h>
#include <linux/if.h>
#include <linux/capability.h>
#include <sys/time.h>
#include <sys/types.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <sys/vfs.h>
#include <netdb.h>
#include <signal.h>

#include "ys_qcms.h"

#include <time.h>


#define DANIPC_DEV_NM             "/dev/danipc0"
#define SUCCESS              0
#define FAILURE              1
typedef  fd_set fd_Set;
#define NUM_MAX_CARRIER 2
unsigned int 			ll_dst_addr[NUM_MAX_CARRIER];
unsigned int            ll_prio[NUM_MAX_CARRIER];
int          			ipcFd = -1;
unsigned int 			ll_src_addr[NUM_MAX_CARRIER];
static struct 			danipc_cdev_mmsg ipc_mmsg[NUM_MAX_CARRIER];
int          			l3l2Port_g = 0;
FAPI_UINT32  ttiNum[NUM_MAX_CARRIER]            = {0, 0};
FAPI_UINT32  ttiLastNum        = 0;
FAPI_UINT32  timeoutCount      = 0;
#define MMSG_BUFSZ            (MAX_DATA_LEN+START_PAYLOAD)
#define MAX_DATA_LEN               DANIPC_MAX_BUF-16
#define MSGID_TOOLONG       0x2E

#define KRAIT_IPC_FIFO_HIGH        1
#define EGTPU_FALSE                0
#define EGTPU_TRUE                 1
#define START_PAYLOAD              64
#define EGTPU_NBUF                 128
#define MAX_MMSG_RX                8
#define IPC_x86REC_MAX_RECVLEN (DANIPC_MAX_BUF-sizeof(sizeof(struct danipc_cdev_msghdr)))
static unsigned char    ipc_mmsgbuf[NUM_MAX_CARRIER][DANIPC_BUFS_MAX_NUM_BUF][MMSG_BUFSZ];
typedef struct timeval timeVal;
       

extern U8 qcCarrierId;

#define PACK_STRUCT __attribute__((packed))

#define SZ_512K 524288
#define IFACE_NAME "danipc"
#define  IPC_HIGH_REMOTENAME "LTEL2_DATA_MOD_HIGH"
#define  IPC_LOW_REMOTENAME "LTEL2_DATA_MOD_LOW"
#define  IPC_HIGH_LOCALNAME "LTEL3_DATA_HIGH"
#define  IPC_LOW_LOCALNAME "LTEL3_DATA_LOW"

#define  IPC_HIGH_REMOTENAME_C1 "LTEL2_DATA_MOD_HIGH_C1"
#define  IPC_HIGH_LOCALNAME_C1 "LTEL3_DATA_HIGH_C1"


//static char remoteHighName[MAX_AGENT_NAME] = {0};
static char remoteLowName[MAX_AGENT_NAME] = {0};


#define MAX_DATA_LEN DANIPC_MAX_BUF-16

//static char databufHigh[MAX_DATA_LEN];
static char databufLow[MAX_DATA_LEN];


static char             myname[NUM_MAX_CARRIER][MAX_AGENT_NAME] = {
   IPC_HIGH_LOCALNAME,
   IPC_HIGH_LOCALNAME_C1
};

static char             remote[NUM_MAX_CARRIER][MAX_AGENT_NAME] = {
   IPC_HIGH_REMOTENAME,
   IPC_HIGH_REMOTENAME_C1
};

//static unsigned myid = INVALID_ID;

static danipc_addr_t remoteHigh_addr;
static danipc_addr_t remoteLow_addr;

Bool g_ys_DC = FALSE;
//#define MAX(a,b) ( (a) > (b) ? (a) : (b) )


EXTERN YsCb ysCb;

/* Packet socket fd */
static int sockfd[2] = { -1, -1 };

static int ifindex[2] = { -1, -1 };
static unsigned cookie[2] = { -1, -1 };

typedef enum
{
	IPC_E_LOW		  = 0x0,
	IPC_E_HIGH		  = 0x01,
 	IPC_E_NUM
} IPC_TYPE_K;

extern S16 ys_qcMsgHndlr(PTR qcl1Msg);
extern S16 ys_qcMsgForwd(Data *qcMsg, S32 msgLen, int carrierId);

void lteFD_ZERO(fd_Set *set)
{
  FD_ZERO(set);
}

int select_wrapper(int nfds, fd_Set *readfds, fd_Set *writefds,
                  fd_Set *exceptfds, timeVal *timeout)

{
  
	return  select(nfds,readfds,writefds,exceptfds,timeout);
}

static inline void
init_ipc_mmsg(int cnt, int carrierId)
{
  int i;
  if ( cnt <= 0 )
  {
      cnt = DANIPC_BUFS_MAX_NUM_BUF;
  }
  
  ipc_mmsg[carrierId].msgs.num_entry = cnt;
  for (i = 0; i < cnt; i++)
  {
     ipc_mmsg[carrierId].msgs.entry[i].data_len = MMSG_BUFSZ;
     ipc_mmsg[carrierId].msgs.entry[i].data = ipc_mmsgbuf[carrierId][i] + START_PAYLOAD;
  }

}
void lteFD_CLR(int fd, fd_Set *set)
{
    FD_CLR(fd,set);
}

void lteFD_SET(int fd, fd_Set *set)
{
  FD_SET(fd,set);
}
int lteFD_ISSET(int fd, fd_Set *set)
{
   return FD_ISSET(fd,set);
}


static int
get_iface_index(const unsigned prio, const char *ifname)
{
          struct ifreq ifr;
          int rc;

          strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name));
          ifr.ifr_name [IFNAMSIZ - 1] = 0;

          rc = ioctl(sockfd[prio], SIOCGIFINDEX, &ifr);
          if (rc == 0)
          {
              rc = ifr.ifr_ifindex;
          }
          else
          {
          	perror ("ioctl(SIOCGIFINDEX)");
			return rc;
          }
		    STKLOG(STK_MD_YS,STK_LOG_INFO,"get_iface_index OK \n");	 
          return rc;
}


#if 0
static int register_agent(const unsigned prio)
{
        struct danipc_reg danipc_reg = {
           requested_lid:     myid,
           prio:     prio
        };
        struct ifreq ifr;
        int rc;
		printf("register_agent myname:%s \n",myname);  

        strncpy(danipc_reg.name, myname, sizeof(danipc_reg.name));
        ifr.ifr_data = (char *)&danipc_reg;
        strncpy (ifr.ifr_name, IFACE_NAME,sizeof(IFACE_NAME));
		printf("register_agent before ioctl\n");  
        rc = ioctl(sockfd[prio], DANIPC_IOCS_REGISTER, &ifr);
		printf("register_agent rc:%d \n",rc);  
        if (rc == 0) {
                printf("requested local ID = 0x%x; assigned local ID = 0x%x\n",
                danipc_reg.requested_lid, danipc_reg.assigned_lid);
                cookie[prio] = danipc_reg.cookie;
        }
        else {
                perror("ioctl(DANIPC_IOCS_REGISTER)");
        }
		printf("register_agent OK \n");  

        return rc;
}
#endif

static int bind_to_iface(const unsigned prio)
{
        struct sockaddr_ll ll_src_address;
        int rc;

        memset(&ll_src_address, 0, sizeof(ll_src_address));
        ll_src_address.sll_family = AF_PACKET;
        ll_src_address.sll_protocol = cookie[prio];
        ll_src_address.sll_ifindex = ifindex[prio];

        rc = bind(sockfd[prio], (struct sockaddr*)&ll_src_address, sizeof(ll_src_address));

        if (rc < 0)
		{
		    perror("bind");
        }
		STKLOG(STK_MD_YS,STK_LOG_INFO,"bind_to_iface return rc:%d\n",rc);  

        return rc;
}

#if 0
static int ipc_registration(const unsigned prio)
{
        int rc = -1;
        socklen_t optlen;
        int sendbuff, recvbuff;

        memset(myname,0,MAX_AGENT_NAME);		
        memset(remote,0,MAX_AGENT_NAME);
		if(prio == IPC_E_HIGH)
		{
		#if 0
		    if(qcCarrierId == 1)
		    {
				strcpy(myname,IPC_HIGH_LOCALNAME_C1);
				strcpy(remote,IPC_HIGH_REMOTENAME_C1);
		    }
			else
			#endif
			{
				strcpy(myname,IPC_HIGH_LOCALNAME);
				strcpy(remote,IPC_HIGH_REMOTENAME);
			}
		}
		else if(prio == IPC_E_LOW)
		{
			strcpy(myname,IPC_LOW_LOCALNAME);
			strcpy(remote,IPC_LOW_REMOTENAME);
		}
		else
		{
			printf("input prio:%d Error\n",prio);
			exit(1);
		}
		printf("input prio:%d,myname:%s\n",prio,myname);

        if (prio > IPC_E_HIGH) {
                fprintf(stderr, "%s: incorrect prio = %u\n", __func__, prio);
                exit(1);
        }


        /* Open a packet socket */
        sockfd[prio] = socket(PF_PACKET, SOCK_DGRAM, 0);
        /*increase SO_SNDBUFF*/
        optlen = sizeof(sendbuff);
        rc = getsockopt(sockfd[prio], SOL_SOCKET, SO_SNDBUF, &sendbuff, &optlen);

        if (rc == -1) {
                printf("Error getsockopt one");
                exit(1);
        }
        else {
                printf("send buffer size = %d\n", sendbuff);
        }

        sendbuff = SZ_512K;
        optlen = sizeof(sendbuff);
        rc = setsockopt(sockfd[prio], SOL_SOCKET, SO_SNDBUF, &sendbuff, sizeof(sendbuff));
        if (rc == -1) {
                printf("Error setsockopt one");
                exit(1);
        }
        else {
                printf("set send buffer size to %d\n", sendbuff);
        }

        /*increase SO_RCVBUFF*/
        optlen = sizeof(recvbuff);
        rc = getsockopt(sockfd[prio], SOL_SOCKET, SO_RCVBUF, &recvbuff, &optlen);
        if (rc == -1) {
                printf("Error getsockopt one\n");
                exit(1);
        }
        else {
                printf("recv buffer size = %d\n", recvbuff);
        }

        recvbuff = SZ_512K;
        optlen = sizeof(recvbuff);
        rc = setsockopt(sockfd[prio], SOL_SOCKET, SO_RCVBUF, &recvbuff, sizeof(recvbuff));
        if (rc == -1) {
                printf("Error setsockopt one\n");
                exit(1);
        }
        else {
                printf("set recv buffer size to %d\n", recvbuff);
        }

        if (sockfd[prio] >= 0) {
                ifindex[prio] = get_iface_index(prio, IFACE_NAME);
                if (ifindex[prio] >= 0) 
				{
                        rc = register_agent(prio);
                        if (rc == 0)
                        {
                                rc = bind_to_iface(prio);
                        }
                        else
                        {
                                fprintf(stderr, "register_agent() failed: %d\n", rc);
                        }
                }
                else 
				{
                        fprintf (stderr, "cannot obtain index of " IFACE_NAME " interface\n");
						printf ("cannot obtain index of  interface:%d\n",IFACE_NAME);
                }
        }
        else
		{
                perror ("socket");
        }
        /* Don't care of an error: OS will clean everything. */
        return rc;
}
static int write_packet(const unsigned prio, char *data, const int len, danipc_addr_t dst_addr)
{
        const struct sockaddr_ll ll_dst_address = {
                sll_ifindex: ifindex[prio],
                sll_protocol: cookie[prio],
                sll_halen: sizeof(danipc_addr_t),
                sll_addr: { dst_addr }
        };
        int rc;

        rc = sendto(sockfd[prio], data, len, 0,
                (struct sockaddr *)&ll_dst_address, sizeof(ll_dst_address));

        if (rc != len)
		{
			perror("sendto");
			printf ("sendto return send len:%d\n",rc);
			return -1;
        }

        return rc;
}
#endif


static int danipc_get_addr_by_name(const char *name,const unsigned prio)
{
        struct danipc_name danipc_name;
        struct ifreq ifr;
        int rc;

        strncpy(danipc_name.name, name, sizeof(danipc_name.name));
        ifr.ifr_data = (char *)&danipc_name;
        strncpy(ifr.ifr_name, IFACE_NAME, sizeof(IFACE_NAME));
		STKLOG(STK_MD_YS,STK_LOG_INFO,"danipc_get_addr_by_name,mypri:%d\n",prio);
		if(prio >= IPC_E_NUM)
		{
			STKLOG(STK_MD_YS,STK_LOG_ERR,"Input error");
			return -1;

		}
		STKLOG(STK_MD_YS,STK_LOG_INFO,"DANIPC_IOCG_NAME2ADDR:%d\n",DANIPC_IOCG_NAME2ADDR);
        rc = ioctl(sockfd[prio], DANIPC_IOCG_NAME2ADDR, &ifr);
        if (rc == 0)
        {       if(prio == IPC_E_LOW)
        	    {
                     remoteLow_addr = danipc_name.addr;
        	    }
		        else
		        {
					remoteHigh_addr = danipc_name.addr;
		        }
        }
        else
		{
			perror("ioctl(DANIPC_IOCG_NAME2ADDR)");
        }

        return rc;
}


#if 0
static int read_socket(const unsigned prio)
{
        struct sockaddr_ll ll_src_addr;
        socklen_t addrlen = sizeof(ll_src_addr);
        int rc;
		char databuffer[100] ={0};

        //memset(&ll_src_addr, 0, sizeof(ll_src_addr));

        rc = recvfrom(sockfd[prio], databuffer, sizeof(databuffer), 0,
                (struct sockaddr *)&ll_src_addr, &addrlen);
        if (rc <= 0)
                perror("recvfrom");

        return rc;
}
#endif

#if 0
void ipc_highRecProc(void)
{
	struct sockaddr_ll ll_src_address;
	socklen_t addrlen = sizeof(ll_src_address);
	int rc;
	Data  *buff;
//	U16  u16MaxQcIfLen = 1500;
	FAPI_T_MSG_HDR*  pstrQcMsgHdr = NULLP;
	//static U16 sf_sfn_last = 0;
  
	while(1)
	{		
		//memset(&ll_src_addr, 0, sizeof(ll_src_addr));	
		if(SGetSBuf(ysCb.ysInit[index].region, ysCb.ysInit[index].pool,&buff,MaxQcIfLen)!= ROK)
		{		
			STKLOG(STK_MD_YS,STK_LOG_INFO,"ipc_highRecProc SGetSBuf failed.\n");
        	SPutSBuf(ysCb.ysInit[index].region, ysCb.ysInit[index].pool,buff,MaxQcIfLen);			
			continue;
		} 
		rc = recvfrom(sockfd[IPC_E_HIGH], buff, MaxQcIfLen, 0,
					(struct sockaddr *)&ll_src_address, &addrlen);
		if (rc <= 0)
		{
			perror("recvfrom");			
			STKLOG(STK_MD_YS,STK_LOG_INFO,"recvfrom, error\n");
			continue;
		}
		pstrQcMsgHdr =(FAPI_T_MSG_HDR*)buff;
		if(pstrQcMsgHdr->type == FAPI_E_SF_IND)
		{
		#if 0
		    if(sf_sfn_last == ((FAPI_T_SF_IND*)pstrQcMsgHdr)->sf_sfn)
		    {
		        printf("*************************same SF_SFN %d",((FAPI_T_SF_IND*)pstrQcMsgHdr)->sf_sfn);
		    }
			
			sf_sfn_last = ((FAPI_T_SF_IND*)pstrQcMsgHdr)->sf_sfn;
			printf("p %d %d\n",sf_sfn_last>>4,sf_sfn_last&0x0F);
		#endif
		}
		//handle the received data.			
		ys_qcMsgForwd(buff,rc,0);		
	}
	
	return;

}

void ipc_lowRecProc(void)
{
	struct sockaddr_ll ll_src_address;
	socklen_t addrlen = sizeof(ll_src_address);
	int rc;

	while(1)
	{		
		//memset(&ll_src_addr, 0, sizeof(ll_src_addr));			
		rc = recvfrom(sockfd[IPC_E_LOW], databufLow, sizeof(databufLow), 0,
					(struct sockaddr *)&ll_src_address, &addrlen);
		if (rc <= 0)
		{
			perror("recvfrom");
		}
		//handle the received data.			
		STKLOG(STK_MD_YS,STK_LOG_INFO,"ipc_highRecProc received data:%d \n",rc);	
	}
	return;

}
#endif
U8 phySubFrame = 10;
CmLteTimingInfo g_phyTimingInfo; 
void ys_setDC(Bool isDc)
{
    g_ys_DC = isDc;
}
void receiveQCPhyMsgNewDC()
{
    FAPI_UINT8 *recvData_p = NULL;
    Data *buff;
    Data *buffSfC1; /* buff for carrier 1 SF Ind */
    S32  bytesRead = -1;
    fd_Set readfds;
    int highestFD = 0;
    int retval = 0;
    int pktidx;
    int ipc_pktcnt = -1;
    FAPI_T_MSG_HDR*  msgHead;
    U8  i = 0;

    lteFD_ZERO(&readfds);
    lteFD_SET(ipcFd, &readfds);
    highestFD = ipcFd;

    retval = select_wrapper(highestFD + 1, &readfds, 0, 0, NULL);
    if (retval > 0)
    {
        if (lteFD_ISSET(ipcFd,&readfds))
        {
            for(i = 0; i < NUM_MAX_CARRIER; i++)
            {
                ipc_mmsg[i].hdr.src = ll_dst_addr[i];
                ipc_mmsg[i].hdr.dst = ll_src_addr[i];
                ipc_mmsg[i].hdr.prio = ll_prio[i];
                init_ipc_mmsg(ipc_pktcnt, i);
                ipc_pktcnt = ioctl(ipcFd, DANIPC_IOCS_MMSGRECV, &ipc_mmsg[i]);
                if(ipc_pktcnt < 0)
                {
                    STKLOG(STK_MD_YS,STK_LOG_ERR,"%s,line:%d fail to read MMSG from danipc socket, error:%s.\n",__func__,__LINE__,strerror(errno));
                    fflush(stdout);
                }
                else
                {
                    for (pktidx = 0; pktidx < ipc_pktcnt; pktidx++)
                    {
                        recvData_p = ipc_mmsg[i].msgs.entry[pktidx].data;
                        bytesRead = ipc_mmsg[i].msgs.entry[pktidx].data_len;
                        if ((bytesRead > 0) && (bytesRead <= IPC_x86REC_MAX_RECVLEN))
                        {
                            if(SGetStaticBuffer(ysCb.ysInit[i].region, ysCb.ysInit[i].pool,&buff, bytesRead, 0)!= ROK)
                            {
                                STKLOG(STK_MD_YS,STK_LOG_ERR,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                                fflush(stdout);
                                exit(-1);
                            }

                            memcpy(buff,recvData_p,bytesRead);
                            msgHead = (FAPI_T_MSG_HDR*)recvData_p;
                            if(msgHead->type == FAPI_E_SF_IND)
                            {
                                phySubFrame = (U8)(((FAPI_T_SF_IND*)recvData_p)->sf_sfn&0x0F);
                                g_phyTimingInfo.sfn = (U8)(((FAPI_T_SF_IND*)recvData_p)->sf_sfn >> 4);
								g_phyTimingInfo.subframe = phySubFrame;
                                /* alloc SF ind buff for carrier 1 in the second MAC threads memory region */
                                if(SGetStaticBuffer(ysCb.ysInit[1].region, ysCb.ysInit[1].pool,&buffSfC1, bytesRead, 0)!= ROK)
                                {
                                    STKLOG(STK_MD_YS,STK_LOG_ERR,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                                    fflush(stdout);
                                    exit(-1);
                                }
                                memcpy(buffSfC1,recvData_p,bytesRead);
                                if( NULLP != ysCb.cellCfgLst[0])
                                {
                                   ys_qcMsgForwd(buff, bytesRead, 0);
                                }
                                if( NULLP != ysCb.cellCfgLst[1])
                                {
                                   ys_qcMsgForwd(buffSfC1, bytesRead, 1);
                                }
                                
                            }
                            else
                            {
                               ys_qcMsgForwd(buff, bytesRead, i);
                            }
                        }
                        else
                        {
                            STKLOG(STK_MD_YS,STK_LOG_ERR,"%s,line:%d fail to read from l3l2 port, error:%s\n",__func__,__LINE__,strerror(errno));
                        }
                    } /*end of for loop for ipc_pktcnt*/
                }
            }
            lteFD_CLR(ipcFd,&readfds);
        }
    }
    else
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"MMSG from danipc socket error %s\n", strerror(errno));
        fflush(stdout);
    }
}


void receiveQCPhyMsgNew()
{
    FAPI_UINT8 *recvData_p = NULL;
    Data *buff;
    S32 bytesRead = -1;
    fd_Set readfds;
    int highestFD = 0;
    int retval = 0;
    int pktidx;
    int ipc_pktcnt = -1;
    FAPI_T_MSG_HDR*  msgHead;
    U8 i = 0;

    lteFD_ZERO(&readfds);
    lteFD_SET(ipcFd, &readfds);
    highestFD = ipcFd;
   
    retval = select_wrapper(highestFD + 1, &readfds, 0, 0, NULL);
    if (retval > 0)
    {
        if (lteFD_ISSET(ipcFd,&readfds))
        {
            for(i = 0; i < NUM_MAX_CARRIER; i++)
            {
                ipc_mmsg[i].hdr.src = ll_dst_addr[i];
                ipc_mmsg[i].hdr.dst = ll_src_addr[i];
                ipc_mmsg[i].hdr.prio = ll_prio[i];
                init_ipc_mmsg(ipc_pktcnt, i);
                ipc_pktcnt = ioctl(ipcFd, DANIPC_IOCS_MMSGRECV, &ipc_mmsg[i]);
                if(ipc_pktcnt < 0)
                {
                    STKLOG(STK_MD_YS,STK_LOG_ERR,"%s,line:%d fail to read MMSG from danipc socket, error:%s.\n",__func__,__LINE__,strerror(errno));
                    fflush(stdout);
                }
                else
                {
                    for (pktidx = 0; pktidx < ipc_pktcnt; pktidx++ )
                    {
                        recvData_p = ipc_mmsg[i].msgs.entry[pktidx].data;
                        bytesRead = ipc_mmsg[i].msgs.entry[pktidx].data_len;
                        if ((bytesRead > 0) && (bytesRead <= IPC_x86REC_MAX_RECVLEN))
                        {
                           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, bytesRead, 0)!= ROK)
                            {
                                STKLOG(STK_MD_YS,STK_LOG_ERR,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                                fflush(stdout);
                                exit(-1);
                            }

                            memcpy(buff,recvData_p,bytesRead);
                            msgHead = (FAPI_T_MSG_HDR*)recvData_p;
                            if(msgHead->type == FAPI_E_SF_IND)
                            {
                                phySubFrame = (U8)(((FAPI_T_SF_IND*)recvData_p)->sf_sfn&0x0F);
                            }
                            ys_qcMsgForwd(buff, bytesRead, i);
                        }
                        else
                        {
                            STKLOG(STK_MD_YS,STK_LOG_ERR,"%s,line:%d fail to read from l3l2 port, error:%s\n",__func__,__LINE__,strerror(errno));
                        }
                    } /*end of for loop for ipc_pktcnt*/
                }
            }
            lteFD_CLR(ipcFd,&readfds);
        }
    }
    else
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"MMSG from danipc socket error %s\n", strerror(errno));
        fflush(stdout);
    }
}

#if 0
void receiveQCPhyMsg()
{
   //FAPI_UINT8 buf[IPC_x86REC_MAX_RECVLEN] = {0};
   FAPI_UINT8 *recvData_p = NULL;
   char *buff;
   int bytesRead = -1;
   fd_Set readfds;
   int highestFD = 0;
   int retval = 0;
   //int transactionId = 0;
   //FAPI_UINT8 hdrLen = 0;
   int pktidx;
   int ipc_pktcnt = -1;
   //int pktcnt = -1; // Init all on first loop
   //int len;
   FAPI_T_MSG_HDR*  msgHead;
   YsCellCb    *primaryCellCb;
   YsCellCb    *secondaryCellCb;
   CmLteCellId primaryCellId = 1;
   CmLteCellId secondaryCellId = 2;

   primaryCellCb = (YsCellCb*)ysMsCfgGetCellCfg(primaryCellId);
   secondaryCellCb = (YsCellCb*)ysMsCfgGetCellCfg(secondaryCellId);
   if(primaryCellCb == NULLP || secondaryCellCb == NULLP)
   {
      printf("\n ezhimgu cellCb is null, not try to recive phy message, sleep 2 \n");      
      fflush(stdout);
      sleep(2);
      return;
   }

#if 0   
   //if(cellCb->phyState == LYS_PHY_STATE_IDLE)
   extern State   g_phyState;
   if(g_phyState == LYS_PHY_STATE_IDLE)
   {
      printf("\n ezhimgu phy is in ideal status, not try to recive phy message, sleep 2 \n");
      fflush(stdout);
      sleep(2);
      return;
   }   
#endif

   lteFD_ZERO(&readfds);
    highestFD = 0;
    if (ipcFd > 0)
        l3l2Port_g = ipcFd;
    // fd to receive from L2 PDCP
    if (l3l2Port_g > 0)
    {
        lteFD_SET(l3l2Port_g,&readfds);
        if (l3l2Port_g > highestFD)
        {
            highestFD = l3l2Port_g;
        }
    }
    retval = select_wrapper(highestFD + 1, &readfds, 0, 0, NULL);
    if (retval > 0)
    {
        //fd to receive from l2 PDCP
        if (lteFD_ISSET(l3l2Port_g,&readfds))
        {
            ipc_mmsg.hdr.src = ll_dst_addr;
            ipc_mmsg.hdr.dst = ll_src_addr;
            ipc_mmsg.hdr.prio = ll_prio;
            init_ipc_mmsg(ipc_pktcnt);
            ipc_pktcnt = ioctl(l3l2Port_g,DANIPC_IOCS_MMSGRECV,&ipc_mmsg);
            if(ipc_pktcnt < 0)
            {
                printf("%s,line:%d fail to read MMSG from danipc socket, error:%s.\n",__func__,__LINE__,strerror(errno));
            }
            else
            {
              
           
                for (pktidx = 0; pktidx < ipc_pktcnt; pktidx++ )
                {
                    recvData_p = ipc_mmsg.msgs.entry[pktidx].data;
                    bytesRead = ipc_mmsg.msgs.entry[pktidx].data_len;
                    if ((bytesRead > 0) && (bytesRead <= IPC_x86REC_MAX_RECVLEN))
                    {
                        if(SGetSBuf(ysCb.ysInit.region, ysCb.ysInit.pool,&buff,MaxQcIfLen)!= ROK)
                          {     
                             printf("receiveMsg SGetSBuf failed.\n");
                             SPutSBuf(ysCb.ysInit.region, ysCb.ysInit.pool,buff,MaxQcIfLen);         
                             //continue;
                    }
   
                    memcpy(buff,recvData_p,bytesRead);
                    //FAPI_UINT32 offset = *((FAPI_UINT32 *)recvData_p);
                    msgHead = (FAPI_T_MSG_HDR*)recvData_p;
					#if 0
                    if(ipc_pktcnt >2 )
              		{
              			printf("ioctl get ipc_mmsg ipc_pktcnt:%d %x\n",ipc_pktcnt,msgHead->type);
              		}
					#endif
                    //printf("get ipc_mmsg length:%d,msgType:%d\n",bytesRead,msgHead->type);
                    if(msgHead->type == FAPI_E_SF_IND)
                    {   
                        //printf("sf \n");
                       ttiNum++;
                    }
                 #if 0
                    ys_qcMsgForwd(buff,bytesRead);
                 #endif
                    ys_qcMsgHndlr((Void *)buff); 
                    
                 #if 0
                    len = ipc_sendData2X86(ipc_mmsg.msgs.entry[pktidx].data,bytesRead);
                    if(len < 0)
                    {
                       printf("ipc_sendData2X86 error, send:%d msg len:%d\n",len,bytesRead);
                       continue;
                    }
                 #endif
                    }
                    else
                    {
                        printf("%s,line:%d fail to read from l3l2 port, error:%s\n",__func__,__LINE__,strerror(errno));
                    }
                } /*end of for loop for ipc_pktcnt*/
            }
            lteFD_CLR(l3l2Port_g,&readfds);
        }
    }

}
#endif

int ipc_initItf()
{
       int carrierId;
       unsigned myId = INVALID_ID;
       unsigned prio = KRAIT_IPC_FIFO_HIGH;
       int rc = 0;

	    do
	    {
	       ipcFd = open(DANIPC_DEV_NM, O_RDWR|O_NONBLOCK);
	    }while(ipcFd<0);

       STKLOG(STK_MD_YS,STK_LOG_INFO,"Current EnodeB Version is BaiBS_QRTBB_2.2.1");
       STKLOG(STK_MD_YS,STK_LOG_INFO,"ipc_initItf open succ,fd:%d\n",ipcFd);
       for (carrierId = 0; carrierId < NUM_MAX_CARRIER; carrierId++)
       {         
          struct danipc_name      danipc_name;
          struct danipc_reg       danipc_reg = {
                  requested_lid:    myId,
                  prio:    prio };
       
          /*register agent*/
          strcpy(danipc_reg.name, myname[carrierId]);
          
      	STKLOG(STK_MD_YS,STK_LOG_INFO,"ipc_initItf %s \n", danipc_reg.name);
		
       rc = ioctl(ipcFd, DANIPC_IOCS_REGISTER, &danipc_reg);
		  
       if (rc != 0)
       {
          STKLOG(STK_MD_YS,STK_LOG_ERR,"%s,line:%d, ipc register agent returns error %s\n", __func__, __LINE__, strerror(errno));
          fflush(stdout);
          return FAILURE;
       }
      	
       ll_src_addr[carrierId] = danipc_reg.assigned_lid;
       ll_prio[carrierId] = danipc_reg.prio;
          /*set ipc remote address*/
       strcpy(danipc_name.name, remote[carrierId]);
		  
      
	      do
	      {
	         rc = (int)ioctl(ipcFd, DANIPC_IOCG_NAME2ADDR, &danipc_name);
	      }while(rc != 0);

         ll_dst_addr[carrierId] = danipc_name.addr;
      	STKLOG(STK_MD_YS,STK_LOG_INFO,"ll_src_addr:%d,prio:%d,ll_dst_addr:%d\n",ll_src_addr[carrierId],ll_prio[carrierId],ll_dst_addr[carrierId]);
       }
      
       return SUCCESS;
}

int ipc_init()
{
    
	if (ipc_initItf())
   {
      return FAILURE;
   }

	return SUCCESS;
}


int ipc_sendMsgbyIpcHigh(char *data, const int len, const int carrierId)
{
    int bytesWritten = 0;
    int sendLength = 0;


    if(carrierId >= NUM_MAX_CARRIER)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"skip msg to carrier %d\n", carrierId);
        return SUCCESS;
    }
    struct danipc_cdev_msghdr *sndHdr = (struct danipc_cdev_msghdr *)(data - sizeof(struct danipc_cdev_msghdr));

    sndHdr->dst = ll_dst_addr[carrierId];
    sndHdr->src = ll_src_addr[carrierId];
	sndHdr->prio = ll_prio[carrierId];
	sendLength = sizeof(struct danipc_cdev_msghdr)+len;
	//printf("ipc_sendMsgbyIpcHigh,ll_src_addr:%d,prio:%d,ll_dst_addr:%d\n",ll_src_addr,ll_prio,ll_dst_addr);

	bytesWritten = write(ipcFd,(char*)sndHdr, sendLength);
	if(bytesWritten != sendLength)
	{
		STKLOG(STK_MD_YS,STK_LOG_ERR,"ipc_sendMsgbyIpcHigh failed, bytesWritten:%d,len:%d\n",bytesWritten,sendLength);
		return FAILURE;
	}

	return SUCCESS;
}

#if 0
int ipc_sendMsgbyIpcLow(char *data, const int len)
{
    int rc;

	
	 if (!remoteLow_addr) {
        rc = danipc_get_addr_by_name(remoteLowName,IPC_E_LOW);
                if (rc < 0) {
                        fprintf(stderr, "cannot get address of agent %s!\n",
                                remoteLowName);
                        exit(-2);
                }
        }
    return rc = write_packet(IPC_E_HIGH,data,len,remoteLow_addr);	
}
#endif



#include "ac_shmMgr.h"

#define AC_SHM_SIZE 0x400000

typedef struct 
{
   fsl_usmmgr_t usmmgr;
   U8* shm_baseVaddr_p;  //base visual address
   U8* shm_endVaddr_p;   //end visual address
   U8* shm_nextVAddr_p;   //the addr will be used by the next alloc
} AC_SHM_CTX;

AC_SHM_CTX g_acShmCtx;

void ac_shmIniit()
{
   int ret = 0;
   fsl_usmmgr_t usmmgr;
   mem_range_t memRange;

   usmmgr = fsl_usmmgr_init();
   if (!usmmgr) {
		printf("Error in Initializing User Space Memory Manager\n");
		return;
	}
   memRange.size = AC_SHM_SIZE;
   ret = fsl_usmmgr_alloc(&memRange, usmmgr);

	if (ret) {
		printf("\n Unable to allocate memory from shm_alloc \n");
		exit(-1);
	}
   printf("range of free pool P=%llx V=%p S=%x\n", memRange.phys_addr, memRange.vaddr,
	       memRange.size);
   
   g_acShmCtx.usmmgr = usmmgr;
   g_acShmCtx.shm_baseVaddr_p = (U8*)memRange.vaddr;
   g_acShmCtx.shm_endVaddr_p = g_acShmCtx.shm_baseVaddr_p + memRange.size;
   g_acShmCtx.shm_nextVAddr_p = g_acShmCtx.shm_baseVaddr_p;
}

U8* ac_shmAlloc(U32 size)
{
   U8* shmAddr_p;

   if(g_acShmCtx.shm_nextVAddr_p + size > g_acShmCtx.shm_endVaddr_p)
   {
      g_acShmCtx.shm_nextVAddr_p = g_acShmCtx.shm_baseVaddr_p;
   }
   shmAddr_p = g_acShmCtx.shm_nextVAddr_p;
   g_acShmCtx.shm_nextVAddr_p +=  size;
   if(shmAddr_p + size > g_acShmCtx.shm_endVaddr_p)
   {
      FORCE_CRASH;
   }
   return shmAddr_p;
}

U8* ac_shmV2P(U8* visualAddr_p)
{
   return fsl_usmmgr_v2p(visualAddr_p, g_acShmCtx.usmmgr);
}


fsl_usmmgr_t* ac_getUsmMgr()
{
   return &(g_acShmCtx.usmmgr);
}
U8* ac_getAvaiShmAddr()
{
   return g_acShmCtx.shm_nextVAddr_p;
}

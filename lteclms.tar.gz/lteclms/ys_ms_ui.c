/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************
 
     Name:     LTE MAC Convergence Layer
  
     Type:     C source file
  
     Desc:     C source code for upper interface of Convergence Layer
  
     File:     ys_ms_ui.c
  
     Sid:      yw_ms_ui.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:50 2014
  
     Prg:      rk
  
**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_MODULE_ID=1;
static int RLOG_FILE_ID=234;
#include <stdlib.h>

/* Trillium Includes */
#include "envopt.h"        /* Environment options */
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#include "gen.h"           /* General */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common timer defines */
#include "cm_tkns.h"       /* Common tokens defines */
#include "cm_mblk.h"       /* Common memory allocation library defines */
#include "cm_llist.h"      /* Common link list defines  */
#include "cm_hash.h"       /* Common hashlist defines */
#include "cm_lte.h"        /* Common LTEE defines */
#include "ys_ms_err.h"        /* CL error header file */
#include "tfu.h"
#include "ctf.h"
#include "lys.h"
#include "ys_ms.h"

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "spaccdrv.h" /*sumanth*/
#endif
#endif


#include "gen.x"           /* General */
#include "ssi.x"           /* System services */

#include "cm5.x"           /* Common timer library */
#include "cm_tkns.x"       /* Common tokens */
#include "cm_mblk.x"       /* Common memory allocation */
#include "cm_llist.x"      /* Common link list */
#include "cm_hash.x"       /* Common hashlist */
#include "cm_lte.x"        /* Common LTE includes */
#include "cm_lib.x"
#include "tfu.x"
#include "ctf.x"
#include "lys.x"

/* Silicon Includes */
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "resultcodes.h"
#endif
#ifndef TENB_RTLIN_CHANGES
#include "syscore.h"
#include "lte_entry.h"
#endif /*TENB_RTLIN_CHANGES*/

#include "ys_ms.x"

#ifdef QCBC_PLATFORM
#include "ys_qcms.h"
#endif

/*ys004.102 :  Merged MSPD code with phy 1.7 */

Bool      prntDbg = FALSE;
PRIVATE S16 ysUiChkAndGetTfuSap ARGS((
SpId       spId,
YsTfuSapType type,
YsTfuSapCb **tfuSapCb
));

void Print_Pucch_info( YsCellCb *cellCb, TfuRecpReqInfo *recpReq);
PRIVATE S16 ysUiChkAndGetCtfSap (SpId spId, YsCtfSapCb **ctfSapCb);
#ifdef TENB_AS_SECURITY
PUBLIC S16 YsMsUlmPrcKenbCfg (CtfAsKeyInfo *kenbInf,CtfAskeyCfmInfo *kdfCfm);
#endif

/* CL Control Block Structure */
PUBLIC YsCb ysCb;

#ifdef YS_MIB_WARND
/*variable introduced for temp testing */
extern Bool  acceptPrimsFrmMac;
#endif
#ifdef SS_4GMX_LCORE
U8 ysCellConfigDone = 0;
#endif

/**
 * @brief Handler for Bind request from RRM towards CL.
 *
 * @details
 *
 *     Function : YsUiCtfBndReq
 *     
 *     This function handles the bind request from RRM.
 *     
 *           
 *  @param[in]  Pst  *pst
 *  @param[in]  SuId suId
 *  @param[in]  SpId spId
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiCtfBndReq
(
Pst  *pst,
SuId suId,
SpId spId
)
#else
PUBLIC S16 YsUiCtfBndReq(pst, suId, spId)
Pst  *pst;
SuId suId;
SpId spId;
#endif
{
   Pst       retPst;
   S16       ret;
   YsUstaDgn dgn;

   TRC2(YsUiCtfBndReq)

   RLOG2(L_INFO,"YsUiCtfBndReq(): suId = %d; spId = %d;", suId, spId);
   ret = ROK;

   cmMemcpy((U8 *)&retPst, (U8 *)pst, sizeof(Pst));
   retPst.dstProcId = pst->srcProcId;
   retPst.dstEnt    = pst->srcEnt;
   retPst.dstInst   = pst->srcInst;
   retPst.srcProcId = pst->dstProcId;
   retPst.srcEnt    = pst->dstEnt;
   retPst.srcInst   = pst->dstInst;
   U16 indx = pst->dstInst;
   
   if(spId == ysCb.ctfSap.spId)
   {
      /* Check the state of the SAP */
      switch (ysCb.ctfSap.sapState)
      {
         case LYS_NOT_CFG: /* SAP Not configured */
            RLOG0(L_INFO,"SAP Not Configured");
            ret = YsUiCtfBndCfm(&retPst, suId, CM_BND_NOK);
            break;

         case LYS_UNBND: /* SAP is not bound */
            RLOG0(L_INFO,"SAP Not yet bound");
            ysCb.ctfSap.sapState = LYS_BND;
            ysCb.ctfSap.suId = suId;
            ysCb.ctfSap.sapPst.dstProcId = pst->srcProcId;
            ysCb.ctfSap.sapPst.dstEnt    = pst->srcEnt;
            ysCb.ctfSap.sapPst.dstInst   = pst->srcInst;
            /* Send Bind Confirm with status as SUCCESS */
            ret = YsUiCtfBndCfm(&ysCb.ctfSap.sapPst, suId, CM_BND_OK);
            dgn.type = LYS_USTA_DGNVAL_SAP;
            ysLMMStaInd (LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_OK,
                  LCM_CAUSE_UNKNOWN, &dgn, indx);
            break;

         case LYS_BND: /* SAP is already bound*/
            RLOG0(L_INFO,"SAP already bound");

            ret = YsUiCtfBndCfm(&ysCb.ctfSap.sapPst, suId, CM_BND_OK);
            break;
         default: /* Should Never Enter here */
            RLOG1(L_WARNING,"Invalid SAP State:%d in YsUiCtfBndReq failed",ysCb.ctfSap.sapState);
            ret = YsUiCtfBndCfm(&retPst, suId, CM_BND_NOK);
            break;
      }
   }
   else
   {
      RLOG1(L_ERROR,"Invalid SAP Id:%d YsUiCtfBndReq failed",ysCb.ctfSap.spId);
      dgn.type = LYS_USTA_DGNVAL_SAP;
      ysLMMStaInd (LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
            LCM_CAUSE_INV_SAP, &dgn, indx);
      ret = YsUiCtfBndCfm(&retPst, suId, CM_BND_NOK);
   }
   RETVALUE(ret);
}  /* YsUiCtfBndReq */

/**
 * @brief API for unbind request from RRM towards CL. 
 *
 * @details
 *
 *     Function: YsUiCtfUbndReq
 *     
 *     This API is invoked by RRM towards CL to unbind CTF SAP. 
 *     These API validates the Pst, spId, suId and transfers the unbind request
 *     specific information to corresponding ownership module (GOM) API.
 *
 *           
 *  @param[in]  Pst    *pst
 *  @param[in]  SuId   suId
 *  @param[in]  Reason reason
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiCtfUbndReq
(
Pst    *pst,
SpId   spId,
Reason reason
)
#else
PUBLIC S16 YsUiCtfUbndReq(pst, spId, reason)
Pst    *pst;
SpId   spId;
Reason reason;
#endif
{
   TRC2(YsUiCtfUbndReq)

   RLOG2(L_INFO,"YsUiCtfUbndReq: spId = %d; reason = %d ", spId, reason);

   /* SAP Id validation */
   if(spId == ysCb.ctfSap.spId)
   {
      switch (ysCb.ctfSap.sapState)
      {
         case LYS_BND: /* SAP is already bound*/
            /* setting SAP state to UN BOUND */
            RLOG0(L_INFO,"SAP Is Bound");
            ysCb.ctfSap.sapState = LYS_UNBND;
            break;
         default:
            RLOG1(L_WARNING,"Invalid SAP State:%d YsUiCtfUbndReq failed",ysCb.ctfSap.sapState);
            RETVALUE(RFAILED);
      }
   }
   else
   {
      RLOG1(L_ERROR,"Invalid SAP Id:%d YsUiCtfUbndReq failed",ysCb.ctfSap.spId);
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
}  /* YsUiCtfUbndReq */

/** 
 * @brief Cnm Init sync  Request from RRC.
 *
 *     Function: YsUiCtfCnmInitSyncReq 
 *
 * @details This primitive is used by APP for triggering Init CNM sync request to CL:
 * @param[in] pst Pointer to the service user task configuration structure.
 * @param[in] spId The service provider SAP ID.
 * @param[in] transId The transaction identifier.
 * @param[in] ctfCnmInitSyncReq Pointer to the CNM configuration information.
 *
 * @return S16
 *  -# ROK
 *  -# RFAILED
 *
*/
#ifdef ANSI
PUBLIC S16 YsUiCtfCnmInitSyncReq 
(
Pst*                 pst,
SpId                 spId,
CtfCfgTransId *      transId,
CtfCnmInitSyncReq*   cnmInitSyncReq
)
#else
PUBLIC S16 YsUiCtfCnmInitSyncReq (pst, spId, transId, cfgReqInfo) 
Pst*                 pst;
SpId                 spId;
CtfCfgTransId *      transId;
CtfCnmInitSyncReq*   cnmInitSyncReq;
#endif
{
   S16   ret = ROK;
   SPutSBuf (pst->region, pst->pool, (Data *)cnmInitSyncReq,
         sizeof(CtfCnmInitSyncReq));

   RETVALUE(ret);
}


/** 
 * @brief Cnm Cell sync Request from RRC.
 *
 *     Function: YsUiCtfCnmCellSyncReq 
 *
 * @details This primitive is used by APP for triggering Cell CNM sync request to CL:
 * @param[in] pst Pointer to the service user task configuration structure.
 * @param[in] spId The service provider SAP ID.
 * @param[in] transId The transaction identifier.
 * @param[in] ctfCnmCellSyncReq Pointer to the CNM configuration information.
 *
 * @return S16
 *  -# ROK
 *  -# RFAILED
 *
*/
#ifdef ANSI
PUBLIC S16 YsUiCtfCnmCellSyncReq 
(
Pst*                 pst,
SpId                 spId,
CtfCfgTransId  *     transId,
CtfCnmCellSyncReq*   cnmCellSyncReq
)
#else
PUBLIC S16 YsUiCtfCnmCellSyncReq (pst, spId, transId, cnmCellSyncReq) 
Pst*                 pst;
SpId                 spId;
CtfCfgTransId   *    transId;
CtfCnmCellSyncReq*   cnmCellSyncReq;
#endif
{
 /* Store the CNM Cell sync Config Info 
   * trigger the CNM state transaction
   */
   SPutSBuf (pst->region, pst->pool, (Data *)cnmCellSyncReq,
		   sizeof(CtfCnmCellSyncReq));

   RETVALUE(ROK);
}


/** 
 * @brief Configuration Request from RRM.
 *
 *     Function: YsUiCtfCfgReq
 *
 * @details This primitive is used by RRM for the following at PHY:
 *          - Configure Cell related parameters.
 *          - Reconfigure cell related parameters.
 *          - Release a cell context.
 *          - Configure UE specific information.
 *          - Reconfigure UE specific information.
 *          - Release UE specific configuration.
 * The cell specific configuration is identified using a cell identifier.
 * The UE specific configuration is identified using a cell identifier and 
 * UE identifier.
 * The configuration request primitive is assocated with a transaction 
 * identifier to correlate the configuration confirm returned by PHY.
 *
 * @param[in] pst Pointer to the service user task configuration structure.
 * @param[in] spId The service provider SAP ID.
 * @param[in] transId The transaction identifier.
 * @param[in] cfgReqInfo Pointer to the PHY(Cell/UE) configuration information.
 *
 * @return S16
 *  -# ROK
 *  -# RFAILED
 *
*/
#ifdef ANSI
PUBLIC S16 YsUiCtfCfgReq
(
Pst*                 pst,
SpId                 spId,
CtfCfgTransId        transId,
CtfCfgReqInfo*       cfgReqInfo
)
#else
PUBLIC S16 YsUiCtfCfgReq(pst, spId, transId, cfgReqInfo)
Pst*                 pst;
SpId                 spId;
CtfCfgTransId        transId;
CtfCfgReqInfo*       cfgReqInfo;
#endif
{
   S16       ret;
   YsCtfSapCb  *ctfSapCb;
   /* ys005.102 : Added new local variable */
   YsCellCb  *cellCb;

   TRC2(YsUiCtfCfgReq)
   /*uart_printf("YsUiCtfCfgReq(): spId = %d; transId = %p;\n",
            spId, transId.trans);*/
   U16 indx =  cfgReqInfo->u.cfg.u.cellCfg.cellId - CM_START_CELL_ID;
   ret = ROK;
   /* ys005.102 : Initailzing cellCb to NULL */
   cellCb = NULLP;

   if(ysUiChkAndGetCtfSap(spId, &ctfSapCb) != ROK)
   {
      YsUiCtfCfgCfm(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,
            transId, CTF_CFG_CFM_NOK);
/* ys005.102 : vendor specific parameter support */
#ifdef CTF_VER3
      if(cfgReqInfo->vendorParams.paramBuffer != NULLP )
      {   
         SPutSBuf (pst->region, pst->pool, (Data *)cfgReqInfo->vendorParams.paramBuffer,
           cfgReqInfo->vendorParams.buffLen);
           cfgReqInfo->vendorParams.paramBuffer = NULLP;
      }
#endif
      SPutSBuf (pst->region, pst->pool, (Data *)cfgReqInfo,
         sizeof(CtfCfgReqInfo));
         cfgReqInfo = NULLP;

      RETVALUE(RFAILED);
   }

   switch(cfgReqInfo->cfgType)
   {
      case CTF_CONFIG:
         {
            switch(cfgReqInfo->u.cfg.cfgElem)
            {
               case CTF_CELL_CFG:
                 /* ys005.102 : vendor specific parameter support changes */
                 if((cellCb = ysMsCfgGetCellCfg(cfgReqInfo->u.cfg.u.cellCfg.cellId)) != NULLP)
                 {
                    RLOG_ARG0(L_ERROR,DBG_CELLID,cfgReqInfo->u.cfg.u.cellCfg.cellId,
                          "Cell Configuration exist for cell Failed ");
                    RETVALUE(RFAILED);
                 }  

                 if ((cellCb = (YsCellCb *)ysUtlMalloc(sizeof(YsCellCb), indx)) == NULLP)
                 {
                    RLOG_ARG0(L_ERROR,DBG_CELLID,cfgReqInfo->u.cfg.u.cellCfg.cellId,
                          "ysAlloc failed in ysMsCfgAddCellCfg");
                    RETVALUE(RFAILED);
                 }
#ifdef CTF_VER3
                 cmMemset((U8 *)&(cellCb->vendorParams), 0, sizeof(YsMsCellCfg));
                 cmMemcpy((U8 *)&cellCb->vendorParams, (U8 *)cfgReqInfo->vendorParams.paramBuffer, cfgReqInfo->vendorParams.buffLen );
#endif     
                  ret = ysMsCfgAddCellCfg(&cfgReqInfo->u.cfg.u.cellCfg,cellCb);
                  if( ret == ROK)
                  {
                     ctfSapCb->ctfSts.numCellCfg++;
                  }

                  break;

               case CTF_UE_CFG:
                  ret = ysMsCfgAddUeCfg(&cfgReqInfo->u.cfg.u.dedCfg);
                  if( ret == ROK)
                     ctfSapCb->ctfSts.numUeCfg++;
                  break;

               default:
                  RLOG1(L_WARNING,"Invalid cfgElem:%d YsUiCtfCfgReq failed",cfgReqInfo->u.cfg.cfgElem);
                  ret = RFAILED;

            }
         }
         break;

      case CTF_RECONFIG:
         {
            switch(cfgReqInfo->u.reCfg.cfgElem)
            {
               case CTF_CELL_CFG:
                  ret = ysMsCfgModCellCfg(&cfgReqInfo->u.reCfg.u.cellRecfg);
                  break;

               case CTF_UE_CFG:
                  ret = ysMsCfgModUeCfg(&cfgReqInfo->u.reCfg.u.dedRecfg);
                  break;
               /* Starts - Fix for CR ccpu00123185 */
               case CTF_TX_PWR_CFG:
                  /* Code to be added as part of MSPD 1.8 integration */
#ifdef MSPD                 
                  RLOG1(L_DEBUG,"Received CTF_TX_PWR_CFG for RefSigPwr=%d", 
                             cfgReqInfo->u.reCfg.u.cellRecfg.pdschCfg.refSigPwr);
                  RLOG1(L_DEBUG,"Received CTF_TX_PWR_CFG for pilotSigPwr=%d", 
                             cfgReqInfo->u.reCfg.u.cellRecfg.pilotSigPwr);
                  RLOG1(L_DEBUG,"Received CTF_TX_PWR_CFG for priSigPwr=%d", 
                             cfgReqInfo->u.reCfg.u.cellRecfg.priSigPwr);
                  RLOG1(L_DEBUG,"Received CTF_TX_PWR_CFG for secSigPwr=%d", 
                             cfgReqInfo->u.reCfg.u.cellRecfg.secSigPwr);
#endif
                  if(cfgReqInfo->u.reCfg.u.cellRecfg.secSigPwr < 0)
                  {
                     transId.trans[8] = YS_MS_TX_PWR_DOWN_CFM;
                     /*PCI Mod design:: APP will send PWR_DWN to CL
                      * and expected STOP_IND back to app. APP will send
                      * the CELL_RECFG with updated PCI after that.
                      * As we dont send StopReq to PHY for brining power 
                      * down, triggering dummy stop indication to app*/
                     STKLOG(STK_MD_YS,STK_LOG_INFO," Rcvd Powr down..triggring stopInd...\n"); 
#ifndef RGL_SPECIFIC_CHANGES
                     ysUlHdlEnbStopInd(cfgReqInfo->u.reCfg.u.cellRecfg.cellId);
#endif
                  }
                  else
                  {
                     transId.trans[8] = YS_MS_TX_PWR_UP_CFM;
                  }
                  ret = ysMsCfgModTxPwrCfg(&cfgReqInfo->u.reCfg.u.cellRecfg);
                  break;
               /* Ends - Fix for CR ccpu00123185 */

               default:
                  RLOG1(L_WARNING,"Invalid cfgElem:%d YsUiCtfCfgReq failed",cfgReqInfo->u.reCfg.cfgElem);
                  ret = RFAILED;

            }
         }
         break;

      case CTF_DELETE:
         {
            switch(cfgReqInfo->u.release.cfgElem)
            {
               case CTF_CELL_CFG:
             RLOG1(L_DEBUG," PST: Calling ysMsCfgDelCellCfg cellId: %d ",cfgReqInfo->u.release.u.cellRel.cellId);
                  ret = ysMsCfgDelCellCfg(cfgReqInfo->u.release.u.cellRel.cellId);
                  break;

               case CTF_UE_CFG:
                  ret = ysMsCfgDelUeCfg(&cfgReqInfo->u.release.u.dedRel);
                  break;

               default:
                  RLOG1(L_WARNING,"Invalid cfgElem:%d YsUiCtfCfgReq failed",(ErrVal)cfgReqInfo->u.release.cfgElem);
                  ret = RFAILED;

            }
         }
         break;

      default:
         RLOG1(L_WARNING,"Invalid cfgType:%d YsUiCtfCfgReq failed",(ErrVal)cfgReqInfo->cfgType);
         ret = RFAILED;
   }

   /* Send Cfg confirm */
   if(ret != ROK)
   {
      RLOG1(L_ERROR,"Invalid cfgElem:%d YsUiCtfCfgReq failed",(ErrVal)cfgReqInfo->u.reCfg.cfgElem);
     RLOG0(L_DEBUG," Sending UECFG Fail");
      YsUiCtfCfgCfm(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,
            transId, CTF_CFG_CFM_NOK);
   }// Sudhanshu WR Change
   else
   {
      RLOG2(L_DEBUG," Sending success cfgtype %d cfgReqType %d",cfgReqInfo->cfgType,cfgReqInfo->u.cfg.cfgElem);
      //printf (" Sending success cfgtype %d cfgReqType %d",cfgReqInfo->cfgType,cfgReqInfo->u.cfg.cfgElem);
      if((cfgReqInfo->cfgType != CTF_CONFIG) || (cfgReqInfo->u.cfg.cfgElem != CTF_CELL_CFG))
      {
        YsUiCtfCfgCfm(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,transId, CTF_CFG_CFM_OK);
      }
#ifdef SS_4GMX_LCORE
      /* Added to track heap memory access */
      ysCellConfigDone = 1;
#endif
   }

   cmMemcpy((U8 *)&(ysCb.ctfSap.transId),(U8 *)&transId,sizeof(CtfCfgTransId));
   /*   ysCb.ctfSap.transId = transId; */

/* ys005.102 : vendor specific parameter support changes */
#ifdef CTF_VER3
      if(cfgReqInfo->vendorParams.paramBuffer != NULLP )
      {
         SPutSBuf (pst->region, pst->pool, (Data *)cfgReqInfo->vendorParams.paramBuffer,
            cfgReqInfo->vendorParams.buffLen);
            cfgReqInfo->vendorParams.paramBuffer = NULLP;
      }
#endif

   SPutSBuf (pst->region, pst->pool, (Data *)cfgReqInfo,
      sizeof(CtfCfgReqInfo));

   RETVALUE(ret);
}  /* YsUiCtfCfgReq */

#ifdef TENB_AS_SECURITY
/**
 * @brief Handler for Bind request from RRM towards CL.
 *
 * @details
 *
 *     Function : YsUiCtfKdfReq
 *     
 *     This function handles the bind request from RRM.
 *     
 *           
 *  @param[in]  Pst  *pst
 *  @param[in]  SuId suId
 *  @param[in]  SpId spId
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiCtfKdfReq
(
Pst  *pst,
SpId spId,
CtfCfgTransId        transId,
CtfKdfReqInfo  *kdfReqInfo
)
#else
PUBLIC S16 YsUiCtfKdfReq(pst, suId, spId)
Pst  *pst;
SuId suId;
SpId spId;
#endif
{
   RETVALUE(ROK);

}  /* YsUiCtfBndReq */
#endif

/*
 *
 *       Fun:   ysUiChkAndGetCtfSap
 *
 *       Desc:  This function checks SAP state and returns 
 *              sapCb if present
 *
 *       Ret:   ROK     - success
 *              RFAILED - failure
 *
 *       Notes: None 
 *
 *       File:  ys_ms_ui.c
 *
 */

#ifdef ANSI
PRIVATE S16 ysUiChkAndGetCtfSap
(
SpId       spId,
YsCtfSapCb **ctfSapCb
)
#else
PRIVATE S16 ysUiChkAndGetCtfSap(spId, ctfSapCb)
SpId       spId;
YsCtfSapCb **ctfSapCb;
#endif
{
   TRC3(ysUiChkAndGetCtfSap);

   *ctfSapCb = NULLP;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if(spId == ysCb.ctfSap.spId)
   {
      switch(ysCb.ctfSap.sapState)
      {
         case LYS_BND: /* SAP is already bound */
            RLOG0(L_INFO,"SAP Is already Bound");
            break;
         default: /* Should never reach here */
            RLOG1(L_WARNING,"Invalid SAP State:%d ysUiChkAndGetCtfSap failed",(ErrVal)ysCb.ctfSap.sapState);
            RETVALUE(RFAILED);
      }

      *ctfSapCb = &ysCb.ctfSap;
   }
   else
   {
      RLOG1(L_ERROR,"Invalid SAP Id:%d ysUiChkAndGetCtfSap failed",(ErrVal)spId);
      RETVALUE(RFAILED);
   }
#else
   *ctfSapCb = &ysCb.ctfSap;
#endif
   RETVALUE(ROK);
} /* ysUiChkAndGetCtfSap */

/**
 * @brief Handler for Bind request.
 *
 * @details
 *
 *     Function : YsUiTfuBndReq
 *     
 *     This function handles the bind request from MAC Service User.
 *     
 *           
 *  @param[in]  Pst  *pst
 *  @param[in]  SuId suId
 *  @param[in]  SpId spId
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiTfuBndReq
(
Pst  *pst,
SuId suId,
SpId spId
)
#else
PUBLIC S16 YsUiTfuBndReq(pst, suId, spId)
Pst  *pst;
SuId suId;
SpId spId;
#endif
{
   S16         ret;
   YsTfuSapCb  *tfuSap;
   Pst         retPst;
   YsUstaDgn dgn;

   TRC2(YsUiTfuBndReq)

   ret = ROK;

   RLOG2(L_INFO,"YsUiTfuBndReq(): suId = %d; spId = %d;", suId, spId);

   cmMemcpy((U8 *)&retPst, (U8 *)pst, sizeof(Pst));
   retPst.dstProcId = pst->srcProcId;
   retPst.dstEnt    = pst->srcEnt;
   retPst.dstInst   = pst->srcInst;
   retPst.srcProcId = pst->dstProcId;
   retPst.srcEnt    = pst->dstEnt;
   retPst.srcInst   = pst->dstInst;
   U16 indx = pst->dstInst;
   if(spId >= (SpId)ysCb.genCfg.maxTfuSaps)
   {
      YS_LOGERR_INTPAR(EYSXXX, (ErrVal)spId,
            "Invalid SAP Id:YsUiTfuSchBndReq failed\n");
      YsUiTfuBndCfm(&retPst, suId, CM_BND_NOK);
      RETVALUE(RFAILED);
   }

   tfuSap = *(ysCb.tfuSapLst + spId);

   if(tfuSap == NULLP)
   {
      RLOG1(L_ERROR,"tfuSap is NULL for spId %d :YsUiTfuBndReq failed",(ErrVal)spId);
      
      YsUiTfuBndCfm(&retPst, suId, CM_BND_NOK);
      RETVALUE(RFAILED);
   }

   if (tfuSap->tfuSapCfg.type != LYS_TFU_USR_SAP)
   {
      YS_LOGERR_INTPAR(EYSXXX, (ErrVal)spId,
            "Invalid SAP type:YsUiTfuBndReq failed\n");
      YsUiTfuBndCfm(&retPst, suId, CM_BND_NOK);
      RETVALUE(RFAILED);
   }

   /* Check the state of the SAP */
   switch (tfuSap->sapState)
   {
      case LYS_NOT_CFG: /* SAP Not configured */
         RLOG0(L_INFO,"SAP Not Configured");
         ret = YsUiTfuBndCfm(&retPst, suId, CM_BND_NOK);
         break;

      case LYS_UNBND: /* SAP is not bound */
         RLOG0(L_INFO,"SAP Not yet bound");
         tfuSap->suId          = suId;
         tfuSap->sapPst.dstProcId = pst->srcProcId;
         tfuSap->sapPst.dstEnt    = pst->srcEnt;
         tfuSap->sapPst.dstInst   = pst->srcInst;


         tfuSap->sapState = LYS_BND;
         /* Send Bind Confirm with status as SUCCESS */
         ret = YsUiTfuBndCfm(&tfuSap->sapPst, suId, CM_BND_OK);
            dgn.type = LYS_USTA_DGNVAL_SAP;
            ysLMMStaInd (LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_OK,
                  LCM_CAUSE_UNKNOWN, &dgn, indx);
         break;

      case LYS_BND: /* SAP is already bound*/
         RLOG0(L_INFO,"SAP already bound");
         ret = YsUiTfuBndCfm(&tfuSap->sapPst, suId, CM_BND_OK);
         break;

      default: /* Should Never Enter here */
         RLOG1(L_WARNING,"Invalid SAP State:%d YsUiTfuBndReq failed",(ErrVal)tfuSap->sapState);
         dgn.type = LYS_USTA_DGNVAL_SAP;
         ysLMMStaInd (LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
               LCM_CAUSE_INV_SAP, &dgn, indx);
         ret = YsUiTfuBndCfm(&retPst, suId, CM_BND_NOK);
         break;
   }

   RETVALUE(ret);
}  /* YsUiTfuBndReq */

/**
 * @brief API for unbind request from MAC towards CL. 
 *
 * @details
 *
 *     Function: YsUiTfuUbndReq
 *     
 *     This API is invoked by MAC towards CL to unbind TFU SAP. 
 *     These API validates the Pst, spId, suId and transfers the unbind request
 *     specific information to corresponding ownership module (GOM) API.
 *
 *           
 *  @param[in]  Pst    *pst
 *  @param[in]  SuId   suId
 *  @param[in]  Reason reason
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiTfuUbndReq
(
Pst    *pst,
SpId   spId,
Reason reason
)
#else
PUBLIC S16 YsUiTfuUbndReq(pst, spId, reason)
Pst    *pst;
SpId   spId;
Reason reason;
#endif
{
   YsTfuSapCb  *tfuSapCb;

   TRC2(YsUiTfuUbndReq)

   RLOG2(L_INFO,"YsUiTfuUbndReq: spId = %d; reason = %d ", spId, reason);

   if(ysUiChkAndGetTfuSap(spId, LYS_TFU_USR_SAP, &tfuSapCb) != ROK)
   {
      RETVALUE(RFAILED);
   }

   tfuSapCb->sapState = LYS_UNBND;

   RETVALUE(ROK);
}  /* YsUiTfuUbndReq */

/**
 * @brief Handler for TFU sap Bind request.
 *
 * @details
 *
 *     Function : YsUiTfuSchBndReq
 *     
 *     This function handles the bind request from Scheduler. 
 *     
 *           
 *  @param[in]  Pst  *pst
 *  @param[in]  SuId suId
 *  @param[in]  SpId spId
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiTfuSchBndReq
(
Pst  *pst,
SuId suId,
SpId spId
)
#else
PUBLIC S16 YsUiTfuSchBndReq(pst, suId, spId)
Pst  *pst;
SuId suId;
SpId spId;
#endif
{
   S16         ret;
   YsTfuSapCb  *schTfuSap;
   Pst         retPst;
   YsUstaDgn dgn;

   TRC2(YsUiTfuSchBndReq)

   ret = ROK;

   RLOG2(L_INFO,"YsUiTfuSchBndReq(): suId = %d; spId = %d;", suId, spId);

   cmMemcpy((U8 *)&retPst, (U8 *)pst, sizeof(Pst));
   retPst.dstProcId = pst->srcProcId;
   retPst.dstEnt    = pst->srcEnt;
   retPst.dstInst   = pst->srcInst;
   retPst.srcProcId = pst->dstProcId;
   retPst.srcEnt    = pst->dstEnt;
   retPst.srcInst   = pst->dstInst;
   U16 indx = pst->dstInst;
   
   if(spId >= (SpId)ysCb.genCfg.maxTfuSaps)
   {
      RLOG1(L_ERROR,"Invalid SAP Id:%d YsUiTfuSchBndReq failed",(ErrVal)spId);
      YsUiTfuSchBndCfm(&retPst, suId, CM_BND_NOK);
      RETVALUE(RFAILED);
   }

   schTfuSap = *(ysCb.tfuSapLst + spId);

   if(schTfuSap == NULLP)
   {
      RLOG1(L_ERROR,"Invalid SAP Id:%d YsUiTfuSchBndReq failed",(ErrVal)spId);
      YsUiTfuSchBndCfm(&retPst, suId, CM_BND_NOK);
      RETVALUE(RFAILED);
   }

   if (schTfuSap->tfuSapCfg.type != LYS_TFU_SCH_SAP)
   {
      RLOG1(L_ERROR,"Invalid SAP type:%d YsUiTfuBndReq failed",(ErrVal)spId);
      YsUiTfuSchBndCfm(&retPst, suId, CM_BND_NOK);
      RETVALUE(RFAILED);
   }

   /* Check the state of the SAP */
   switch (schTfuSap->sapState)
   {
      case LYS_NOT_CFG: /* SAP Not configured */
         RLOG0(L_INFO,"SAP Not Configured");
         ret = YsUiTfuSchBndCfm(&retPst, suId, CM_BND_NOK);
         break;

      case LYS_UNBND: /* SAP is not bound */
         RLOG0(L_INFO,"SAP Not yet bound");
         schTfuSap->suId             = suId;
         schTfuSap->sapPst.dstProcId = pst->srcProcId;
         schTfuSap->sapPst.dstEnt    = pst->srcEnt;
         schTfuSap->sapPst.dstInst   = pst->srcInst;

         schTfuSap->sapState = LYS_BND;
         /* Send Bind Confirm with status as SUCCESS */
         ret = YsUiTfuSchBndCfm(&schTfuSap->sapPst, suId, CM_BND_OK);
         dgn.type = LYS_USTA_DGNVAL_SAP;
         ysLMMStaInd (LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_OK,
               LCM_CAUSE_UNKNOWN, &dgn, indx);
         break;

      case LYS_BND: /* SAP is already bound*/
         RLOG0(L_INFO,"SAP already bound");
         ret = YsUiTfuSchBndCfm(&schTfuSap->sapPst, suId, CM_BND_OK);
         break;

      default: /* Should Never Enter here */
         RLOG1(L_WARNING,"Invalid SAP State:%d YsUiTfuSchBndReq failed",(ErrVal)schTfuSap->sapState);
         dgn.type = LYS_USTA_DGNVAL_SAP;
         ysLMMStaInd (LCM_CATEGORY_INTERFACE, LCM_EVENT_BND_FAIL,
               LCM_CAUSE_INV_SAP, &dgn, indx);
         ret = YsUiTfuSchBndCfm(&retPst, suId, CM_BND_NOK);
         break;
   }
   

   RETVALUE(ret);
}  /* YsUiTfuSchBndReq */

/**
 * @brief API for unbind request from MAC towards CL. 
 *
 * @details
 *
 *     Function: YsUiTfuSchUbndReq
 *     
 *     This API is invoked by MAC towards CL to unbind TFU SAP. 
 *     These API validates the Pst, spId, suId and transfers the unbind request
 *     specific information to corresponding ownership module (GOM) API.
 *
 *           
 *  @param[in]  Pst    *pst
 *  @param[in]  SuId   suId
 *  @param[in]  Reason reason
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiTfuSchUbndReq
(
Pst    *pst,
SpId   spId,
Reason reason
)
#else
PUBLIC S16 YsUiTfuSchUbndReq(pst, spId, reason)
Pst    *pst;
SpId   spId;
Reason reason;
#endif
{
   YsTfuSapCb  *tfuSapCb;

   TRC2(YsUiTfuSchUbndReq)

   RLOG2(L_INFO,"YsUiTfuSchUbndReq: spId = %d; reason = %d ", spId, reason);

   if(ysUiChkAndGetTfuSap(spId, LYS_TFU_SCH_SAP, &tfuSapCb) != ROK)
   {
      RETVALUE(RFAILED);
   }

   tfuSapCb->sapState = LYS_UNBND;

   RETVALUE(ROK);
}  /* YsUiTfuSchUbndReq */

/**
 * @brief API for sending control information MAC to PHY
 *
 * @details
 *
 *     Function: YsUiTfuCntrlReq
 *     
 *     This API is invoked to send control information from MAC to RLC.
 *     It provides PHY with all the control information
 *       - PDCCH
 *       - PHICH
 *       - PCFICH
 *           
 *  @param[in]  pst
 *  @param[in]  spId
 *  @param[in]  cntrlReq pointer to TfuCntrlReqInfo
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiTfuCntrlReq
(
Pst             *pst,
SpId            spId,
TfuCntrlReqInfo *cntrlReq
)
#else
PUBLIC S16 YsUiTfuCntrlReq(pst, spId, cntrlReq)
Pst             *pst;
SpId            spId;
TfuCntrlReqInfo *cntrlReq;
#endif
{
   S16             ret;
   YsCellCb        *cellCb;
   YsTfuSapCb      *tfuSapCb;
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC2(YsUiTfuCntrlReq)
   /*starting Task*/
   SStartTask(&startTime, PID_CL_CNTRL_REQ_DL);

   ret = ROK;

#ifndef QCBC_PLATFORM 
#ifdef YS_MIB_WARND
   /*Handling for temp testing */
   if(!acceptPrimsFrmMac)
   {
      YS_FREE_SDU(cntrlReq);
      RETVALUE(ROK);
   } 
#endif
#endif 

/*{volatile trap=1; while(trap);}*/
   if(ysUiChkAndGetTfuSap(spId, LYS_TFU_SCH_SAP, &tfuSapCb) != ROK)
   {
   
      YS_FREE_SDU(cntrlReq);
      RETVALUE(RFAILED);
   }

   if((cellCb = ysMsCfgGetCellCfg(cntrlReq->cellId)) == NULLP)
   {
   
      RLOG_ARG0(L_ERROR,DBG_CELLID,cntrlReq->cellId, "ysMsCfgGetCellCfgFailed ");
      YS_FREE_SDU(cntrlReq);
      RETVALUE(RFAILED);
   }
   if(cellCb->phyState != LYS_PHY_STATE_RUN)
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"In TfuCntrlReq: cell %d PHY state not run\n", cntrlReq->cellId);
      RLOG_ARG0(L_ERROR, DBG_CELLID,cntrlReq->cellId,"PHY is not in running state ");
      YS_FREE_SDU(cntrlReq);
      RETVALUE(RFAILED);
   }
   tfuSapCb->tfuSts.numCntrlReqRcvd++;


#ifdef QCBC_PLATFORM
   ret = ys_qcPrcCntrlReq(cellCb, cntrlReq);
   return ret;
#else
   ret = ysMsDlmPrcCntrlReq(cellCb, cntrlReq);
#endif

   if(ret != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cntrlReq->cellId,"CntrlReq processing Failed ");
      STKLOG(STK_MD_YS,STK_LOG_ERR,"CntrlReq processing Failed \n");
      YS_FREE_SDU(cntrlReq);
      RETVALUE(RFAILED);
   }
//#ifndef RG_SCH_DYNDLDELTA
#ifndef SPLIT_RLC_DL_TASK
   YS_FREE_SDU(cntrlReq);
#endif
   /*stopping Task*/
   SStopTask(startTime, PID_CL_CNTRL_REQ_DL);
   RETVALUE(ret);
}  /* YsUiTfuCntrlReq*/

/**
 * @brief This Primitive carries the Data PDUs from MAC to PHY for transmission
 *
 * @details
 *
 *     Function: YsUiTfuDatReq
 *     
 * @details The data being sent in this primitive is meant to be transmitted on
 * the downlink channel PDSCH and PBCH (if present). To facilitate physical
 * layer processing, requisite control information is also sent along with the
 * data. 
 *           
 *  @param[in]  pst
 *  @param[in]  spId
 *  @param[in]  tfuDatReq pointer to TfuDatReqInfo
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiTfuDatReq
(
Pst             *pst,
SpId            spId,
TfuDatReqInfo   *datReq
)
#else
PUBLIC S16 YsUiTfuDatReq(pst, spId, datReq)
Pst             *pst;
SpId            spId;
TfuDatReqInfo   *datReq;
#endif
{
   YsCellCb *cellCb;
   YsTfuSapCb *tfuSapCb;
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
#ifdef TENB_RTLIN_CHANGES
   CmLteTimingInfo  timingInfo;
   U8               sfNum;
#endif


   TRC2(YsUiTfuDatReq)

   /*starting Task*/
   SStartTask(&startTime, PID_CL_DAT_REQ);
   //RLOG1(L_INFO,"YsUiTfuDatReq(): spId = %d;", spId);

#ifdef YS_MIB_WARND
   /*Handling for temp testing */
   if(!acceptPrimsFrmMac)
   {
      ysUtlFreeDatReq(datReq);
      RETVALUE(ROK);
   } 
#endif

   if(ysUiChkAndGetTfuSap(spId, LYS_TFU_USR_SAP, &tfuSapCb) != ROK)
   {
      ysUtlFreeDatReq(datReq);
      RETVALUE(RFAILED);
   }

   if((cellCb = ysMsCfgGetCellCfg(datReq->cellId)) == NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,datReq->cellId,"ysMsCfgGetCellCfgFailed ");
      ysUtlFreeDatReq(datReq);
      RETVALUE(ROK);
   }

   if(cellCb->phyState != LYS_PHY_STATE_RUN)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,datReq->cellId,"PHY is not in running state ");
      ysUtlFreeDatReq(datReq);
      RETVALUE(ROK);
   }
#if 0
    {
       CmLteTimingInfo tempTime;
       tempTime = cellCb->timingInfo;
       YS_INCR_TIMING_INFO(tempTime, 2)
       if(!(YS_TIMING_INFO_SAME(tempTime, datReq->timingInfo)))
       {
          printf("Incorrect datReq delta\n");
       }
    }
#endif

   tfuSapCb->tfuSts.numDatReqRcvd++;

#ifdef QCBC_PLATFORM
   return ys_qcPrcDataReq(cellCb, datReq);
#endif

#ifdef TENB_RTLIN_CHANGES
   timingInfo = datReq->timingInfo;
   sfNum      = timingInfo.subframe;
   if(cellCb->dlEncL1Msgs[sfNum].datReq != NULLP)
   {
      ysUtlFreeDatReq(cellCb->dlEncL1Msgs[sfNum].datReq);
      RLOG1(L_ERROR,"Dropping datReq for subframe:%d", sfNum);
     /* stop_printf("Previous Data Request still Persists, sfNum %u\n", sfNum); */
   }
  /* RLOG1(L_DEBUG,"Storing datReq for subframe:%d", sfNum);*/
   cellCb->dlEncL1Msgs[sfNum].datReq = datReq;
//#ifdef RG_SCH_DYNDLDELTA
#ifdef SPLIT_RLC_DL_TASK
   //Bool   infoRcvd = FALSE;
   /* Check for the delayed DatReq */
   if ((datReq->timingInfo.subframe) != ((cellCb->timingInfo.subframe + TFU_DLDATA_DLDELTA)% 10))
   {
      /* Updating cnt */
#ifdef SPLIT_RLC_DL_TASK
      rgStats.gDropDatReqCnt++;
#endif
      cellCb->dlEncL1Msgs[sfNum].isCrcToMacSnd = FALSE;
      YS_FREE_SDU(cellCb->dlEncL1Msgs[sfNum].cntrlReq);
      ysUtlFreeDatReq(datReq);
      cellCb->dlEncL1Msgs[sfNum].datReq = NULLP;
      RETVALUE(ROK);
   }
   //infoRcvd = ysChkSfInfoStatus(cellCb, sfNum);
   //if (TRUE == infoRcvd ) 
   if(TRUE == ysMsIsSubframeReadyToSend(sfNum))
   {
      ysMsSendSubframeToPhy(sfNum);

   }
#endif
#else
   if (((datReq->timingInfo.sfn * YS_NUM_SUB_FRAMES) + datReq->timingInfo.subframe)
      < ((cellCb->timingInfo.sfn * YS_NUM_SUB_FRAMES) + cellCb->timingInfo.subframe
      + TFU_DLDATA_DLDELTA)% YS_TOTL_SUB_FRAMES_IN_SFN)
   {
      RLOG4(L_DEBUG,"Delayed DatReq Dropped DatReq Time(%d,%d) CL time(%d,%d)",
         datReq->timingInfo.sfn, datReq->timingInfo.subframe, 
         cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
   }
   else
   {
      /* RLOG4(L_DEBUG,"Received datReq Time(%d,%d) CL time(%d,%d)",
         datReq->timingInfo.sfn, datReq->timingInfo.subframe, 
         cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);*/
      ysMsDlmPrcDatReq(cellCb, datReq);
      /* ccpu00128524 - Wait for completion of DatReq and then trigger 
       * TtiIndOnHqReceipt. This would assure completion of DatReq
       * Processing by CL and SCH will later process on TTI IND */
      if(cellCb->sndTtiIndOnHqRecptLater)
      {
         ysMsDlmPrcTtiIndOnHqReceipt(cellCb, FALSE);
         cellCb->sndTtiIndOnHqRecptLater = FALSE;
      }
   }
   ysUtlFreeDatReq(datReq);
#endif

/*stopping Task*/
  SStopTask(startTime, PID_CL_DAT_REQ);


   RETVALUE(ROK);
}  /* YsUiTfuDatReq*/

#ifdef L2_OPTMZ
/**
 * @brief This Primitive carries cellId and UeId for which datReq PDUs to be deleted
 *
 * @details
 *
 *     Function: YsUiTfuDelDatReq
 *     
 * @details This is used only when L2_OPTMZ flag is enabled. This is used to deleted datReq PDUs
 *          for the Ue for which UeId change has happened but datReq is still exist for old rnti
 *           
 *  @param[in]  pst
 *  @param[in]  spId
 *  @param[in]  tfuDelDatReq pointer to TfuDelDatReqInfo
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiTfuDelDatReq
(
Pst                *pst,
SpId               spId,
TfuDelDatReqInfo   *delDatReq
)
#else
PUBLIC S16 YsUiTfuDelDatReq(pst, spId, delDatReq)
Pst                 *pst;
SpId                spId;
TfuDelDatReqInfo    *delDatReq;
#endif
{
   U8                sfNum;
   TfuDatReqInfo     *datReq;
   YsCellCb          *cellCb = NULLP;
   CmLList           *cmLstEnt;
   TfuDatReqPduInfo  *pduInfo;

   TRC2(YsUiTfuDelDatReq)
  
   if((cellCb = ysMsCfgGetCellCfg(delDatReq->cellId)) == NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,delDatReq->cellId,"cellCb is not found in function YsUiTfuDelDatReq");
      RETVALUE(RFAILED);
   }

   if(cellCb->phyState != LYS_PHY_STATE_RUN)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,delDatReq->cellId,"PHY is not in running state ");
      RETVALUE(RFAILED);
   }
  
   sfNum = ((cellCb->timingInfo.subframe + TFU_DLDATA_DLDELTA)% 10);
   datReq = cellCb->dlEncL1Msgs[sfNum].datReq;
   if(datReq)
   {
      cmLstEnt = datReq->pdus.first;
      while (cmLstEnt != NULLP)
      {
         pduInfo = (TfuDatReqPduInfo*)cmLstEnt->node;
         STKLOG(STK_MD_YS,STK_LOG_INFO," YsUiTfuDelDatReq is invoked for cellId :%d DelReqUeId : %d pduUeId : %d datReq: %p  cellsfn :%d cellSf :%d datSfn :%d datSf :%d \n", delDatReq->cellId, delDatReq->ueId, pduInfo->rnti, (void *)cellCb->dlEncL1Msgs[sfNum].datReq, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe, datReq->timingInfo.sfn, datReq->timingInfo.subframe);
         if(delDatReq->ueId == pduInfo->rnti)
         {
            rgStats.dbgUeIdChngAndDatReqInClCnt[cellCb->cellId-1]++;
            cmLListDelFrm(&datReq->pdus, cmLstEnt);
            break;
         }
         cmLstEnt = cmLstEnt->next;
      }
   }
   RETVALUE(ROK);
}
#endif /* L2_OPTMZ*/


/**
 * @brief brief This primitive is sent from Scheduler to PHY.
 *
 * @details
 *
 *     Function: YsUiTfuRecpReq
 *     
 * @details This primitive provides PHY with all the information required by 
 * PHY to decode transmissions from the UE on either PUCCH or PUSCH.
 * -# On PUCCH UE can transmit the following
 *    -# SR
 *    -# HARQ feedback
 *    -# CQI report
 *    -# HARQ + CQI
 *    -# HARQ + SR
 * -# On PUSCH UE can transmit the following
 *    -# Data
 *    -# Data + CQI
 *    -# Data + HARQ Feedback
 * This primitive carries all the information for the expected subframe for all
 * the UEs that have been scheduled to transmit.
 *           
 *  @param[in]  pst
 *  @param[in]  spId
 *  @param[in]  recpReq Pointer to the TfuRecpReqInfo structure.
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 **/
#ifdef ANSI
PUBLIC S16 YsUiTfuRecpReq
(
Pst             *pst,
SpId            spId,
TfuRecpReqInfo  *recpReq
)
#else
PUBLIC S16 YsUiTfuRecpReq(pst, spId, recpReq)
Pst             *pst;
SpId            spId;
TfuRecpReqInfo  *recpReq;
#endif
{
   S16  ret;
   YsCellCb *cellCb;
   YsTfuSapCb *tfuSapCb;
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC2(YsUiTfuRecpReq)
   
   /*starting Task*/
   SStartTask(&startTime, PID_CL_RECP_REQ);


   ret = ROK;
#ifdef YS_MIB_WARND
   /*Handling for temp testing */
   if(!acceptPrimsFrmMac)
   {
      YS_FREE_SDU(recpReq);

      RETVALUE(ROK);
   } 
#endif
   if(ysUiChkAndGetTfuSap(spId, LYS_TFU_SCH_SAP, &tfuSapCb) != ROK)
   {
      YS_FREE_SDU(recpReq);
      RETVALUE(RFAILED);
   }

   if((cellCb = ysMsCfgGetCellCfg(recpReq->cellId)) == NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,recpReq->cellId,"ysMsCfgGetCellCfgFailed ");
      YS_FREE_SDU(recpReq);
      RETVALUE(RFAILED);
   }

   if(cellCb->phyState != LYS_PHY_STATE_RUN)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,recpReq->cellId,"PHY is not in running state ");
      YS_FREE_SDU(recpReq);
      RETVALUE(RFAILED);
   }
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
#if 0
    {
       CmLteTimingInfo tempTime;
       tempTime = cellCb->timingInfo;
       YS_INCR_TIMING_INFO(tempTime, 1)
       if(!(YS_TIMING_INFO_SAME(tempTime, recpReq->timingInfo)))
       {
          STKLOG(STK_MD_YS,STK_LOG_INFO," Incorrect recpReq delta\n");
       }
    }
#endif

      /* Validating sfn and subframe */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if((cellCb->timingInfo.sfn != recpReq->timingInfo.sfn) ||
         (cellCb->timingInfo.subframe != recpReq->timingInfo.subframe))
   {
      YsUstaDgn dgn;
      dgn.type = LYS_USTA_DGNVAL_SFN_SF;
      cmMemcpy((U8 *)&dgn.u.timingInfo, (U8 *)&cellCb->timingInfo,
            sizeof(CmLteTimingInfo));
      ysLMMStaInd (LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
            LCM_CAUSE_INV_PAR_VAL, &dgn, indx);
      RLOG4(L_FATAL, "Invalid Timing Info.. Expected SFN=%d Subframe=%d "
               "Received SFN=%d Subframe=%d",
               cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
               recpReq->timingInfo.sfn, recpReq->timingInfo.subframe);

      YS_FREE_SDU(recpReq);
      RETVALUE(RFAILED);
   }
#endif

   tfuSapCb->tfuSts.numRecpReqRcvd++;

#ifdef QCBC_PLATFORM
   ret = ys_qcUlmPrcRecpReq(cellCb, recpReq);
#else
   ret = ysMsUlmPrcRecpReq(cellCb, recpReq);
#endif

   if(ret != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,recpReq->cellId,"Failed to process Reception Request");
      YS_FREE_SDU(recpReq);
      RETVALUE(RFAILED);
   }
   /* changed , not sure what will happen */
   YS_FREE_SDU(recpReq);

   /*stopping Task*/
   SStopTask(startTime, PID_CL_RECP_REQ);
   RETVALUE(ret);
}  /* YsUiTfuRecpReq*/

void Print_Pucch_info( YsCellCb *cellCb, TfuRecpReqInfo *recpReq)
{
      CmLList          *cmLstEnt;

      TfuUeRecpReqInfo   *recpReqInfo;
   
       cmLstEnt = recpReq->ueRecpReqLst.first;

       while (cmLstEnt != NULLP)
       {
           recpReqInfo = (TfuUeRecpReqInfo*)cmLstEnt->node;

         if (recpReqInfo->type == TFU_RECP_REQ_PUCCH)
            {
              //RLOG3(L_DEBUG,"TFU_RECP_REQ_PUCCH recpReqTime [%d,%d] nCce %d", recpReq->timingInfo.sfn, recpReq->timingInfo.subframe,
          //    recpReqInfo->t.pucchRecpReq.t.nCce);
            }

         cmLstEnt = cmLstEnt->next;
      }

 }

/*
 *
 *       Fun:   ysUiChkAndGetTfuSap
 *
 *       Desc:  This function checks SAP state and returns 
 *              sapCb if present
 *
 *       Ret:   ROK     - success
 *              RFAILED - failure
 *
 *       Notes: None 
 *
 *       File:  ys_ms_ui.c
 *
 */

#ifdef ANSI
PRIVATE S16 ysUiChkAndGetTfuSap
(
SpId       spId,
YsTfuSapType type,
YsTfuSapCb **tfuSapCb
)
#else
PRIVATE S16 ysUiChkAndGetTfuSap(spId, type, tfuSapCb)
SpId       spId;
YsTfuSapType type;
YsTfuSapCb **tfuSapCb;
#endif
{
   YsTfuSapCb  *sap = NULLP;

   TRC3(ysUiChkAndGetTfuSap);

   sap = *(ysCb.tfuSapLst + spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if(sap == NULLP)
   {
      RLOG1(L_ERROR,"Invalid SAP Id:%d ysUiChkAndGetTfuSap failed",(ErrVal)spId);
      RETVALUE(RFAILED);
   }

   if (spId != sap->spId)
   {
      RLOG1(L_ERROR,"Invalid SAP Id:%d ysUiChkAndGetTfuSap failed",(ErrVal)spId);
      RETVALUE(RFAILED);
   }

   switch (sap->sapState)
   {
      case LYS_BND: /* SAP is already bound */
         break;

      default: /* Should never reach here */
         RLOG1(L_WARNING,"Invalid SAP State:%d YsUiTfuUbndReq failed",(ErrVal)sap->sapState);
         RETVALUE(RFAILED);
   }
#endif

   *tfuSapCb = sap;

   RETVALUE(ROK);
} /* ysUiChkAndGetTfuSap */

/********************************************************************30**
  
         End of file:     yw_ms_ui.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:50 2014
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      rk   1. initial release.
/main/1    ys004.102  vr   1. Merged MSPD code with phy 1.7
*********************************************************************91*/


/*
                    IMPORTANT LIMITATION(S) ON USE
                    
This files include the QC platform msg handle 
for Krait and Hexagon interface.
     

    
 
**********************************************************************/

#include "envopt.h"             /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "fapiApiInternal.h"
#include "fapiVsmApiInternal.h"
#include "ssi.h"           /* system services */
#include "gen.h"                /* general layer */
#include "tfu.h"
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "lys.h"
#include "resultcodes.h"
#include "ctf.h"
#include "ys_ms.h"
#include "ys_ms_err.h"
#include <assert.h> 
#include "ac_ltePhyL2Api.h"
//#include "dsp_boot.h"
#include "gen.x"                /* general layer */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"

#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#include "ctf.x"
#include "ac_ltePhyIpc.h"

#include "ys_ms.x"
#include "ys_qcms.h"
#include <sys/time.h>


void ys_qcLintTestRspHandle(FAPI_T_MSG_HDR*  pstrQcMsgHdr);
S16   ys_qcSendStartReq(const int carrierId);
S16 ys_qcSendConfigReq(YsCellCb   *cellCb);

typedef struct PACK_STRUCT FAPI_S_SFNCHECK{
        FAPI_T_MSG_HDR          msg_hdr; //Message header
        FAPI_UINT16             sf_sfn; //[15:4] SFN, range 0..1023
    }FAPI_SFNCHECK_S;

typedef struct qcPhyConfStr
{
    U8 u8IsCconfig;
    FAPI_T_CONFIG_TLV strParTlv;
}QC_PHYCONF_STRU;

#define NUM_MAX_CARRIER 2
typedef void *fsl_ipc_t;
EXTERN fsl_ipc_t ipc[NUM_MAX_CARRIER];
QC_PHYCONF_STRU  qcPhyConf[NUM_MAX_CARRIER][FAPI_E_INVALID_VALUE];
U32 qcTimeRecord[10] ={0};
static U32 sendTimes[3000] = {0};
extern QcUlMsgInfoS   ysQcPhyUlMsgInfo[YS_LTE_MAX_CELLS][YS_NUM_SUB_FRAMES];
EXTERN Bool g_ys_DC;
#ifdef LTE_TDD
PUBLIC U8 ysqcTddUlDlSubfrmTbl[7][10] = {
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME, YS_TDD_UL_SUBFRAME,   YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME, YS_TDD_DL_SUBFRAME,   YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME, YS_TDD_DL_SUBFRAME,   YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME}
};
#endif
FAPI_T_CONFIG_TLV qcPhyConfList[] =
{
    {1,   2,   0},
    {2,   2,   6000},
    {3,   2,   0},
    {4,   2,   0},
    {5,   2,   0},
    {240, 2,   0},
    {241, 2,   0},	
    {10,  2,  100},
    {11,  2,  100},
    {12,  2,  0},
    {13,  2,  1},
    {14,  2,  2}
    ,
    {20,  2,  0},
    {21,  2,  0},
    {22,  2,  3000},
    {30,  2,  8500},
    {31,  2,  8500},
    {32,  2,  1},

    {40,  2,  0},
    {41,  2,  0},
    {42,  2,  8},
    {43,  2,  0},
    {44,  2,  0},

    {50,  2,  0},
    {51,  2,  1},
    {52,  2,  1},

    {60,  2,  1},
    {61,  2,  0},
    {62,  2,  0},
    {63,  2,  0},

    {70,  2,  0},
    {71,  2,  0},
    {72,  2,  0},
    {73,  2,  0},

    {80,  2,  0},
    {81,  2,  0},
    {82,  2,  0}
};

U8 recordValue[12][10000] = {{0}};
S16 ys_qcTooLongMsgHandle(char *data, const int len, const int carrierId)
{
    U8 i;
    U8 segNum = len%MAX_SEND_LEN == 0? len/MAX_SEND_LEN : (len+(MAX_SEND_LEN-len%MAX_SEND_LEN))/MAX_SEND_LEN;
    U16 remainLen = len;
    S16 msgLen = 0;
    U16 rawDataLen = len;
    Data *buff;
    FAPI_T_LONGMSG_HDR*  pHead = NULLP;
    char* dataHead = data;
    static U8 count =0;
    static U8 sequence = 0;

    if(segNum>3)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"Test ys_qcTooLongMsgHandle too long lentgh\n");
        FORCE_CRASH;
    }
    msgLen = MAX_SEND_LEN + sizeof(FAPI_T_LONGMSG_HDR);
	if(SGetSBuf(ysCb.ysInit[carrierId].region, ysCb.ysInit[carrierId].pool,&buff,msgLen)!= ROK)
    {
        STKLOG(STK_MD_EPR,STK_LOG_ERR,"ys_qcToolongMsgHand SGetSBuf failed.\n");
        SPutSBuf(ysCb.ysInit[carrierId].region, ysCb.ysInit[carrierId].pool,buff,msgLen);			
        RETVALUE(RFAILED);
    }

    for(i = 0 ; i < segNum; i ++)
    {
        if(remainLen >= MAX_SEND_LEN)
        {
            msgLen = MAX_SEND_LEN + sizeof(FAPI_T_LONGMSG_HDR);
            rawDataLen = MAX_SEND_LEN;
        }
        else
        {
            msgLen = remainLen + sizeof(FAPI_T_LONGMSG_HDR);
            rawDataLen = remainLen;
        }

        pHead = (FAPI_T_LONGMSG_HDR*)buff;		
        pHead->type = MSGID_TOOLONG;
        pHead->sequence = sequence;
        pHead->currSeg = i;
        pHead->totalSeg = segNum;
        pHead->len = rawDataLen;
        memcpy(buff+sizeof(FAPI_T_LONGMSG_HDR),dataHead,rawDataLen);
        memcpy(recordValue[count],buff,msgLen);
        count++;
        if(count == 12)
        {
            count = 0;
        }
        ipc_sendMsgbyIpcHigh((char*)buff,msgLen,carrierId);
        remainLen -= rawDataLen;
        dataHead+=rawDataLen;
    }

    sequence++;
    if(sequence == 16)
    {
        sequence = 0;
    }
	SPutSBuf(ysCb.ysInit[carrierId].region, ysCb.ysInit[carrierId].pool,buff,MAX_SEND_LEN + sizeof(FAPI_T_LONGMSG_HDR)); 	 
    RETVALUE(ROK);
}

S16 ys_qcTooLongMsgHandleTest(char *data, const int len)
{
    U8 i;
    U8 segNum = len%MAX_SEND_LEN == 0? len/MAX_SEND_LEN : (len+(MAX_SEND_LEN-len%MAX_SEND_LEN))/MAX_SEND_LEN;
    U16 remainLen = len;
    S16 msgLen = 0;
    U16 rawDataLen = len;
    U8*  buff;
    FAPI_T_LONGMSG_HDR*  pHead = NULLP;
    char* dataHead = data;

    msgLen = MAX_SEND_LEN + sizeof(FAPI_T_LONGMSG_HDR);
	if(SGetSBuf(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff,msgLen)!= ROK)
    {
        STKLOG(STK_MD_EPR,STK_LOG_ERR,"ys_qcToolongMsgHand SGetSBuf failed.\n");
        SPutSBuf(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,buff,msgLen);			
        RETVALUE(RFAILED);
    }

    for(i = 0 ; i < segNum; i ++)
    {
        if(remainLen >= MAX_SEND_LEN)
        {
            msgLen = MAX_SEND_LEN + sizeof(FAPI_T_LONGMSG_HDR);
            rawDataLen = MAX_SEND_LEN;
        }
        else
        {
            msgLen = remainLen + sizeof(FAPI_T_LONGMSG_HDR);
            rawDataLen = remainLen;
        }

        pHead = (FAPI_T_LONGMSG_HDR*)buff;		
        pHead->type = MSGID_TOOLONG;
        pHead->currSeg = i;
        pHead->totalSeg = segNum;
        pHead->len = rawDataLen;
        memcpy(buff+sizeof(FAPI_T_MSG_HDR),dataHead,rawDataLen);
        ipc_sendMsgbyIpcHigh((char*)buff,msgLen,0/*,ysAnchorInfo.AnchorInfo[AnchorCount].fapiHenbAPort,ysAnchorInfo.AnchorInfo[AnchorCount].fapiHenbAIp*/);
        remainLen -= rawDataLen;
        dataHead+=rawDataLen;
    }
    
	SPutSBuf(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,buff,MAX_SEND_LEN + sizeof(FAPI_T_MSG_HDR)); 	 
    RETVALUE(ROK);
}

U16  ipcCalNewTxReqLen(FAPI_T_TX_REQ* pTxReq, U32 len)
{
    U16    i,pduNum,pduLenth, ntlv;
    U8    *pTmp;
    FAPI_T_TX_REQ_PDU *pTxReqPdu;
    U16   newMsgLen = sizeof(FAPI_T_TX_REQ);
    FAPI_T_TLV        *txBchTlv = NULL;

    pduNum = pTxReq->n_pdu;
    pTmp = (U8 *)&pTxReq->pdu[0];
    for(i = 0 ; i < pduNum; i ++)
    {
        pTxReqPdu = (FAPI_T_TX_REQ_PDU*)pTmp;
        if(pTxReqPdu->pdu_length <= 4) //nust be value tag, qc platform requirement
        {
            txBchTlv = &pTxReqPdu->tlv[0];
            pduLenth = sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(txBchTlv->value) + txBchTlv->length + (4-txBchTlv->length%4);
        }
        else
        {
            pduLenth = sizeof(FAPI_T_TX_REQ_PDU) + pTxReqPdu->n_tlv*sizeof(FAPI_T_TLV);
            ntlv = pTxReqPdu->n_tlv;
        }
        newMsgLen +=  pduLenth;
        if(pTxReqPdu->pdu_length % 4)
        {
            pTmp += pTxReqPdu->pdu_length + 4 - pTxReqPdu->pdu_length % 4;
        }
        else
        {
            pTmp += pTxReqPdu->pdu_length;
        }
    }

    return newMsgLen;
}
U8 ipcReconstrTxReqMsg2Pnt(FAPI_T_TX_REQ* pTxReq)
{
    U32 i,j;
    FAPI_T_TX_REQ_PDU* pTxReqPdu = NULL;
    U8*  pTmp = NULL;
    U16 pduNum;
    FAPI_T_TLV*  pTlv = NULL;
    U16 num = 0;
    U32  alloc_size = 0;

    pduNum = pTxReq->n_pdu;
    pTxReqPdu = &pTxReq->pdu[0];
    i = 0;
    while(i < pduNum)
    {
        pTlv = &pTxReqPdu->tlv[0];
        for(j = 0; j < pTxReqPdu->n_tlv; j ++)
        {
            if((pTlv->length+16) != (pTxReqPdu->pdu_length +sizeof(FAPI_UINT32 *)))
            {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"sizeerror %d  %d \n",pTlv->length,pTxReqPdu->pdu_length);
            }

            if(pTlv->length %4)
            {
                alloc_size = pTlv->length + 4- pTlv->length%4;
            }
            else
            {
                alloc_size = pTlv->length;
            }

            num = pTlv->length;
            pTmp = (U8*)pTlv;
            pTlv = (FAPI_T_TLV*)(pTmp + (sizeof(FAPI_T_TLV) - 4 + num)); //next one
        }
        num = pTxReqPdu->n_tlv;

        if(pTxReqPdu->pdu_length %4 )
        {
            num = pTxReqPdu->pdu_length+ 4 -pTxReqPdu->pdu_length %4;
        }
        else
        {
            num = pTxReqPdu->pdu_length;
        }
        pTxReqPdu =  (FAPI_T_TX_REQ_PDU*)((U8*)pTxReqPdu + num );
        ++i;
    }

    return 0;
}

PUBLIC S16  ys_qcSendtoPhy(char *data, const int len, const int carrierId)
{
    S16 ret;
    U32 usetime = 0;
    FAPI_SFNCHECK_S* pTmp;

    pTmp =(FAPI_SFNCHECK_S*)data;
    #ifdef NXP_PLATFORM
    if(pTmp->msg_hdr.type == FAPI_E_DL_CONFIG_REQ)
    {
        ret = fsl_ipc_send_msg(PA_TO_SC_DLCONF_REQUEST_CH, data, len, ipc[carrierId]);
    }
    else if(pTmp->msg_hdr.type == FAPI_E_UL_CONFIG_REQ)
    {
        ret = fsl_ipc_send_msg(PA_TO_SC_ULCONF_REQUEST_CH, data, len, ipc[carrierId]);
    }
    else if(pTmp->msg_hdr.type == FAPI_E_TX_REQ)
    {
        ret = fsl_ipc_send_msg(PA_TO_SC_TX_REQUEST_CH, data, len, ipc[carrierId]);
    }
    else if(pTmp->msg_hdr.type == FAPI_E_HI_DCI0_REQ)
    {
        ret = fsl_ipc_send_msg(PA_TO_SC_HIDCI0_REQUEST_CH, data, len, ipc[carrierId]);
    }
        
    #else
    if(pTmp->msg_hdr.type == FAPI_E_TX_REQ)
    {
        ipcReconstrTxReqMsg2Pnt((FAPI_T_TX_REQ*)data);
    }

    if(MAX_SEND_LEN < len)
    {
        return ys_qcTooLongMsgHandle(data,len, carrierId); 
    }

    ret = ipc_sendMsgbyIpcHigh(data,len,carrierId);
    #endif
    return ret;
}

YSQcTmrCb_S ysQcTmr[YS_TMR_NUM];

void ys_InitQcTmrCb()
{
    U8 i = 0;
    for(i= 0; i < YS_TMR_NUM; i ++)
    {
        ysQcTmr[i].evntTmr = 0xFFFF;
        ysQcTmr[i].remainTicks = 0xFFFF;
        ysQcTmr[i].tmrDual = 0;
        ysQcTmr[i].validFlag = 0;
    }
    return;
}

PUBLIC S16 ysRegInitTmr
(
Void
)
{
    U16                       idx;
    S16                       ret;

    /* initialize timing queues */
    ysStCb.tmrTqCp.tmrLen      = 1;
    ysStCb.tmrTqCp.nxtEnt = 0 ;

    for (idx = 0; idx < 1; idx++)
    {
        ysStCb.tmrTq[idx].first    = NULLP;
        ysStCb.tmrTq[idx].tail     = NULLP;
    }
    ys_InitQcTmrCb();

    ret = SRegTmr((Ent)ENTYS, (Inst)0,10,ysActvTmr);   
    if (ret != ROK)
    {
        //STKLOG(STK_MD_YS,STK_LOG_ERR,"SRegTmr Failed");
        RETVALUE(RFAILED);
    }

    RETVALUE(ROK);
} /* ysRegInitTmr */

S16 ysDeRegTmr()
{
   S16 ret;
   ret = SDeregTmr((Ent)ENTYS, (Inst)0,10,ysActvTmr);
   if (ret != ROK)
   {
       STKLOG(STK_MD_YS,STK_LOG_ERR,"SRegTmr Failed");
       RETVALUE(RFAILED);
   }

}


void ys_qcTmrPeriodHndl()
{
    U8 i = 0;
    Bool shouldUnregTimer = TRUE;
    for(i= 0; i < YS_TMR_NUM; i ++)
    {
        if(ysQcTmr[i].validFlag == 0) //do nothing
        {
            continue;
        }
        shouldUnregTimer = FALSE;
        ysQcTmr[i].remainTicks -=1;
        if(ysQcTmr[i].remainTicks <=0)
        {
            ys_PrcTmrExpiry(NULLP,ysQcTmr[i].evntTmr);
            ysQcTmr[i].remainTicks = ysQcTmr[i].tmrDual;
        }
    }
    if(shouldUnregTimer == TRUE)
    {
       ysDeRegTmr();
    }
    
    return;
}

/** @brief Invoked by system services to activate a task with
 *              a timer tick.
 *
 * @details
 *
 *     Function: ysActvTmr
 *
 *         Processing steps:
 *
 * @param[in] Void 
 * @return S16
 *        -# Success : ROK
 */

PUBLIC S16 ysActvTmr
(
 Ent ent,
 Inst  inst
)
{
    ys_qcTmrPeriodHndl();

    RETVALUE(ROK);
} /* end of ysActvTmr */


PUBLIC Void ys_StartTmr
(
S16       tmrEvnt,
U32       tmrVal,
Ptr       cb
)
{
    static U8 startFlag =0;

    if(startFlag == 0) //init timer here by first-time call
    {
        ysRegInitTmr();
        startFlag = 1;
    }

    if(tmrEvnt >= YS_TMR_NUM)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_StartTmr tmrEvnt:%u error\n",tmrEvnt);
        return;
    }
    ysQcTmr[tmrEvnt].evntTmr = tmrEvnt;
    ysQcTmr[tmrEvnt].remainTicks = tmrVal; //unit is 100ms according to current configure
    ysQcTmr[tmrEvnt].validFlag = 1;
    ysQcTmr[tmrEvnt].tmrDual = tmrVal;

    RETVOID;
}

PUBLIC Void ys_StopTmr
(
Ptr       cb,
S16       event
)
{
    if(event >= YS_TMR_NUM)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_StopTmr tmrEvnt:%u error\n",event);
        return;
    }
    ysQcTmr[event].validFlag = 0;

    return;
} /* end of wrStopTmr() */

PUBLIC Void ys_PrcTmrExpiry
(
Ptr      cb,
S16      tmrEvnt
)
{
    TRC2(ysPrcTmrExpiry)

    STKLOG(STK_MD_YS,STK_LOG_INFO,"received timer event:%d.\n",tmrEvnt);
    switch (tmrEvnt)
    {
        case YS_TMR_PARREQ_TMROUT0:
            ys_qcSendParReq(0);
        break;
        case YS_TMR_PARREQ_TMROUT1:
            ys_qcSendParReq(1);
        break;
        case YS_TMR_CONFREQ_TMROUT0:
            ys_qcSendConfigReq((YsCellCb*)ysMsGetCellCbFrmPhyInstId(0));
        break;
        case YS_TMR_CONFREQ_TMROUT1:
            ys_qcSendConfigReq((YsCellCb*)ysMsGetCellCbFrmPhyInstId(1));
        break;
        case YS_TMR_STARTREQ_TMROUT0:
            ys_qcSendStartReq(0);
        break;
        case YS_TMR_STARTREQ_TMROUT1:
            ys_qcSendStartReq(1);
        break;      
        default:
            STKLOG(STK_MD_YS,STK_LOG_ERR,"received unknow timer event:%d",tmrEvnt);
        break;
    }

    RETVOID;
}

void ys_qcConfigInit()
{
    U16 i, j;
        for (j = 0; j < NUM_MAX_CARRIER; j++)
        {
            for(i = 0; i < FAPI_E_INVALID_VALUE; i++)
            {
                qcPhyConf[j][i].u8IsCconfig =0;
                qcPhyConf[j][i].strParTlv.length = 0;
                qcPhyConf[j][i].strParTlv.tag = 0XFF;
                qcPhyConf[j][i].strParTlv.value = 0XFF;
            }
        }

    return;
}

void ys_qcUpdatePhyConfig(U8 TlvNum,FAPI_T_CONFIG_TLV* pLtv, int carrierId)
{
    U16 i;
    FAPI_T_CONFIG_TLV *pTmp = NULLP;
    pTmp = pLtv;

    for(i = 0; i < TlvNum &&  i < FAPI_E_INVALID_VALUE; i++)
    {
        if(pLtv->tag < FAPI_E_INVALID_VALUE)
        {
            qcPhyConf[carrierId][pLtv->tag].u8IsCconfig = 1;
            qcPhyConf[carrierId][pLtv->tag].strParTlv.length = pLtv->length;
            qcPhyConf[carrierId][pLtv->tag].strParTlv.value = pLtv->value;
        }
        else
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcUpdateHpyCOnfig, Ltv->tag:%d error!\n",pLtv->tag);
        }
        pLtv++;
    }

    return;
}

void ys_qcPrintTlv(U8 TlvNum,FAPI_T_CONFIG_TLV* pLtv)
{
    U16 i;
    FAPI_T_CONFIG_TLV *pTmp = NULLP;
    
    pTmp = pLtv;
    for(i = 0; i < TlvNum &&  i < FAPI_E_INVALID_VALUE; i++)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"Ltv->tag:%d,len:%d,val:%d!\n",pLtv->tag,pLtv->length,pLtv->value);
        pLtv++;
    }

    return;
}


void ys_qcPrintConfig()
{
    U16 i,j;
    
    STKLOG(STK_MD_YS,STK_LOG_INFO,"---***********qcPhyConf start*******----------\n");
    for (j = 0; j < NUM_MAX_CARRIER; j++)
    {
        for(i = 0; i < FAPI_E_INVALID_VALUE; i++)
        {
            if(qcPhyConf[j][i].u8IsCconfig)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"qcPhyConf[%d].u8IsCconfig:%d,length:%d,value:%d.\n",i, qcPhyConf[j][i].u8IsCconfig,
                qcPhyConf[j][i].strParTlv.length,qcPhyConf[j][i].strParTlv.value);
            }
        }
    }
    STKLOG(STK_MD_YS,STK_LOG_INFO,"---***********qcPhyConf Complete*******----------\n");

    return;
}

/*
	constract FAPI_E_CONFIG_REQ msg 
*/
S16 ys_qcSendConfigReq(YsCellCb   *cellCb)
{
#ifdef NXP_PLATFORM
#if 1
    FAPI_T_CONFIG_REQ* fapiConfigReq = NULLP;
    Data  *buff;
    S16 ret = 0;
    S32 totallen,fapiConfigReqSize;
    #ifdef LTE_TDD
    U8 tlvNum = 38;//sizeof(qcPhyConfList)/sizeof(qcPhyConfList[0]);
    #else
    U8 tlvNum = 36;
    #endif
    U8 vsm_tvl_length   = 0;
    U8 num_vsm_tlv = 0;
    FAPI_T_VSM_MSG* fapiConfigReqVsm;
    U16 indx = 0;
    S32 fapiVsmTlvSize = sizeof(FAPI_T_VSM_MSG) + (num_vsm_tlv*(sizeof(FAPI_T_VSM_TLV) + vsm_tvl_length));

    if(g_ys_DC == TRUE)
    {
        indx = cellCb->cellId - CM_START_CELL_ID;
    }

    fapiConfigReqSize = sizeof(FAPI_T_CONFIG_REQ) + tlvNum*sizeof(FAPI_T_CONFIG_TLV);
    totallen = fapiConfigReqSize+fapiVsmTlvSize; //if not support VSM TLV
    if(cellCb->cellInfo.dlBw == 25)//workaound for 5M, PHY will check SRS bandwidth for 5M, so need to add this tlv(0x46) only for 5M.
    {
        fapiConfigReqSize+=sizeof(FAPI_T_CONFIG_TLV);
        totallen+=sizeof(FAPI_T_CONFIG_TLV);
    }
    
    if(ysUtlAllocQCIPCSBuf(&buff,totallen, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"ipc_highRecProc SGetSBuf failed.\n");
        return(RFAILED);
    }
printf("totallen %d fapiConfigReqSize %d \n",totallen,fapiConfigReqSize);
    fapiConfigReq =(FAPI_T_CONFIG_REQ*)buff;
    fapiConfigReq->msg_hdr.type = FAPI_E_CONFIG_REQ;
    fapiConfigReq->msg_hdr.len = fapiConfigReqSize - sizeof(FAPI_T_MSG_HDR);
    #ifdef NXP_PLATFORM
    fapiConfigReq->msg_hdr.msgVdrSpecFlag = 0;
    #else
    fapiConfigReq->msg_hdr.len_ven = fapiVsmTlvSize;
    #endif
    fapiConfigReqVsm = (FAPI_T_VSM_MSG*) (((char*)fapiConfigReq) + fapiConfigReqSize);
    fapiConfigReq->n_tlv = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eDuplexMode;
//TBD, fill with value cellCb->cellCfg.txCfg.duplexMode
#ifdef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.txCfg.duplexMode;
#else
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 1;//cellCb->cellCfg.txCfg.duplexMode;
#endif
    
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePcfichPowerOffs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.cfiPowOs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePB;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pdschCfg.p_b;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eDlCpType;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.txCfg.cycPfx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eUlCpType;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.txCfg.cycPfx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_dlBW;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellInfo.dlBw;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_ulBW;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellInfo.ulBw;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_rsPower;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pilotSigPwr;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_txAntPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;//cellCb->cellCfg.txAntennaPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;


    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_rxAntPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;//cellCb->cellCfg.rxAntennaPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePHICH_resource;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.phichCfg.resource;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePHICH_duration;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.phichCfg.duration;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePHICH_powerOffs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSCH_pssEPRE;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.syncSigPowOs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSCH_sssEPRE;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.syncSigPowOs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSCH_cellId;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.cellIdGrpId *3 +cellCb->cellCfg.physCellId;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_cfgIdx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.prachCfgIndex;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_rootSeqIdx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.rootSequenceIndex;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_Ncs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.zeroCorrelationZoneCfg;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_HighSpdFlag;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.highSpeedFlag;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_freqOffs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.prachFreqOffset;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUSCH_hopMode;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschBasicCfg.hoppingMode;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUSCH_hopOffs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschBasicCfg.hoppingOffset;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUSCH_subBandsNum;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschBasicCfg.noOfsubBands;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUCCH_deltaShift;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pucchCfg.deltaShift+1;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUCCH_NcqiRb;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pucchCfg.nRB;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUCCH_NanCs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pucchCfg.nCS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUCCH_N1PucchAn;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pucchCfg.n1PUCCH;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
    
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_bwCfg;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
    
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_maxUpPts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv++;
    
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_srsSfrmCfg;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_srsAckSameSfrm;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 1;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
    if(cellCb->cellInfo.dlBw == 25)//workaound for 5M, PHY will check SRS bandwidth for 5M, so need to add this tlv(0x46) only for 5M.
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_bwCfg;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 3;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
#ifndef LTE_TDD
    //maybe TDD have the same issue?
    else if(cellCb->cellInfo.dlBw == 50)//workaound for 10M, PHY will check SRS bandwidth for 10M, so need to add this tlv(0x46) only for 10M.
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_bwCfg;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
#endif

    if(cellCb->cellCfg.puschCfg.puschUlRS.grpHopEnabled)
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_hopMode;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 1;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
    else if(cellCb->cellCfg.puschCfg.puschUlRS.seqHopEnabled)
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_hopMode;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
    else
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_hopMode;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_deltaSeqShift;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschUlRS.grpNum;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_cs1DMRS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschUlRS.cycShift;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#ifdef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eTdd_frmStrucCfg;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.tddSfCfg.sfAssignment;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eTdd_speSfrmPattern;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.tddSfCfg.spclSfPatterns;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#endif

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eDataReportMode;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#if 0
#ifdef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSFN_SF;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#endif
#endif
//#ifndef LTE_TDD
    
//#endif

    if(num_vsm_tlv > 0)
    {
        fapiConfigReqVsm->vsm_header.num_tlv    = num_vsm_tlv;
        fapiConfigReqVsm->vsm_header.size       = fapiVsmTlvSize;
        FAPI_T_VSM_TLV* fapiConfigReqVsmTlv = (FAPI_T_VSM_TLV*)&(fapiConfigReqVsm->tlvs[0]);

        //CFI
        fapiConfigReqVsmTlv->tag_header.tag     = FAPI_E_CFG_CFI_VSM;
        fapiConfigReqVsmTlv->tag_header.length  = sizeof(FAPI_T_CFG_CFI_VSM_TAG_VALUE);
        FAPI_T_CFG_CFI_VSM_TAG_VALUE* cfg_cfi_vsm_ptr = (FAPI_T_CFG_CFI_VSM_TAG_VALUE*)(&(fapiConfigReqVsmTlv->value));

        cfg_cfi_vsm_ptr->cfi        = 1;
        cfg_cfi_vsm_ptr->padding[0] = 0;
        cfg_cfi_vsm_ptr->padding[1] = 0;
        cfg_cfi_vsm_ptr->padding[2] = 0;
        fapiConfigReqVsmTlv = (FAPI_T_VSM_TLV *)(((U8*)fapiConfigReqVsmTlv) + (sizeof(FAPI_T_VSM_TLV) + sizeof(FAPI_T_CFG_CFI_VSM_TAG_VALUE)));

        //Version
        fapiConfigReqVsmTlv->tag_header.tag     = FAPI_E_CFG_VERSION_VSM;
        fapiConfigReqVsmTlv->tag_header.length  = sizeof(FAPI_T_CFG_VERSION_VSM_TAG_VALUE);
        FAPI_T_CFG_VERSION_VSM_TAG_VALUE* cfg_ver_vsm_ptr   = (FAPI_T_CFG_VERSION_VSM_TAG_VALUE* )(&(fapiConfigReqVsmTlv->value));

        cfg_ver_vsm_ptr->vs_major_ver   = 1;//(U16)(VSM_API_MAJOR);
        cfg_ver_vsm_ptr->vs_minor_ver   = 6;//(U16)(VSM_API_MINOR);
        cfg_ver_vsm_ptr->padding        = 0;
        fapiConfigReqVsmTlv = (FAPI_T_VSM_TLV *)(((U8*)fapiConfigReqVsmTlv) + (sizeof(FAPI_T_VSM_TLV) + sizeof(FAPI_T_CFG_VERSION_VSM_TAG_VALUE)));
    }
    printf("PA_TO_SC_CONFIG_REQUEST_CH indx %d cellCb->phyInstId %d\n",indx,cellCb->phyInstId);
     ret = fsl_ipc_send_msg(PA_TO_SC_CONFIG_REQUEST_CH, fapiConfigReq, totallen, ipc[indx]);
    //ret = ipc_sendMsgbyIpcHigh((char*)fapiConfigReq, totallen, cellCb->phyInstId);
    STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcSendConfigReq carrierId[%d] indx %d\n", cellCb->phyInstId,indx);
    ysUtlFreeQCIPCSBuf(buff,totallen, indx);
#endif
#if 0
    FAPI_T_CONFIG_REQ *fapiConfigReq = NULLP;
    FAPI_T_CONFIG_REQ buff;
    S16 ret = 0;
   
    U16 indx = 0;
    S32 totallen,fapiConfigReqSize;
    U8 tlvNum = 35;//sizeof(qcPhyConfList)/sizeof(qcPhyConfList[0]);
    U8 vsm_tvl_length   = 0;
    U8 num_vsm_tlv = 0;
    FAPI_T_VSM_MSG* fapiConfigReqVsm;
    //U16 indx = 0;
    S32 fapiVsmTlvSize = sizeof(FAPI_T_VSM_MSG) + (num_vsm_tlv*(sizeof(FAPI_T_VSM_TLV) + vsm_tvl_length));


    fapiConfigReqSize = sizeof(FAPI_T_CONFIG_REQ) + tlvNum*sizeof(FAPI_T_CONFIG_TLV);
    totallen = fapiConfigReqSize+fapiVsmTlvSize; //if not support VSM TLV

  printf("PA_TO_SC_CONFIG_REQUEST_CH ret --1\n");
#if 0
    fapiConfigReqSize = sizeof(FAPI_T_CONFIG_REQ) + tlvNum*sizeof(FAPI_T_CONFIG_TLV);
    totallen = fapiConfigReqSize+fapiVsmTlvSize; //if not support VSM TLV

    totallen=300;
    printf("PA_TO_SC_CONFIG_REQUEST_CH ret --11\n");
    if(ysUtlAllocQCIPCSBuf(&buff,totallen, 0) != ROK)
    {
     printf("ipc_highRecProc SGetSBuf failed. %d \n",totallen);
        stklog(STK_MD_YS,STK_LOG_INFO,"ipc_highRecProc SGetSBuf failed.\n");
        return(RFAILED);
    }
    printf("PA_TO_SC_CONFIG_REQUEST_CH ret --12\n");
#endif
    fapiConfigReq =(FAPI_T_CONFIG_REQ*)&buff;
    fapiConfigReq->msg_hdr.type = FAPI_E_CONFIG_REQ;
    fapiConfigReq->msg_hdr.len = fapiConfigReqSize - sizeof(FAPI_T_MSG_HDR);
    fapiConfigReq->msg_hdr.len_ven = fapiVsmTlvSize;
    fapiConfigReqVsm = (FAPI_T_VSM_MSG*) (((char*)fapiConfigReq) + fapiConfigReqSize);
    fapiConfigReq->n_tlv = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eDuplexMode;
//TBD, fill with value cellCb->cellCfg.txCfg.duplexMode
#ifdef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.txCfg.duplexMode;
#else
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 1;//cellCb->cellCfg.txCfg.duplexMode;
#endif
    
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePcfichPowerOffs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value =6000;// cellCb->cellCfg.cfiPowOs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePB;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.pdschCfg.p_b;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eDlCpType;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.txCfg.cycPfx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eUlCpType;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.txCfg.cycPfx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_dlBW;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 100;//cellCb->cellInfo.dlBw;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_ulBW;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 100;//cellCb->cellInfo.ulBw;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_rsPower;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value =0;// cellCb->cellCfg.pilotSigPwr;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_txAntPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;//cellCb->cellCfg.txAntennaPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;


    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eRF_rxAntPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;//cellCb->cellCfg.rxAntennaPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePHICH_resource;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.phichCfg.resource;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePHICH_duration;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.phichCfg.duration;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePHICH_powerOffs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSCH_pssEPRE;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 6000;//cellCb->cellCfg.syncSigPowOs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSCH_sssEPRE;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 6000;//cellCb->cellCfg.syncSigPowOs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSCH_cellId;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value =55;// cellCb->cellCfg.cellIdGrpId *3 +cellCb->cellCfg.physCellId;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_cfgIdx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 3;//cellCb->cellCfg.prachCfg.prachCfgIndex;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_rootSeqIdx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 22;//cellCb->cellCfg.prachCfg.rootSequenceIndex;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_Ncs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 10;//cellCb->cellCfg.prachCfg.zeroCorrelationZoneCfg;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_HighSpdFlag;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.prachCfg.highSpeedFlag;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePRACH_freqOffs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 5;//cellCb->cellCfg.prachCfg.prachFreqOffset;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUSCH_hopMode;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.puschCfg.puschBasicCfg.hoppingMode;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUSCH_hopOffs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 8;//cellCb->cellCfg.puschCfg.puschBasicCfg.hoppingOffset;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUSCH_subBandsNum;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 1;//cellCb->cellCfg.puschCfg.puschBasicCfg.noOfsubBands;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUCCH_deltaShift;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;//cellCb->cellCfg.pucchCfg.deltaShift+1;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUCCH_NcqiRb;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;//cellCb->cellCfg.pucchCfg.nRB;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUCCH_NanCs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.pucchCfg.nCS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_ePUCCH_N1PucchAn;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 16;//cellCb->cellCfg.pucchCfg.n1PUCCH;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
    printf("PA_TO_SC_CONFIG_REQUEST_CH ret --13\n");
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_bwCfg;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_srsSfrmCfg;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_srsAckSameSfrm;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 1;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
    #if 0
    if(cellCb->cellInfo.dlBw == 25)//workaound for 5M, PHY will check SRS bandwidth for 5M, so need to add this tlv(0x46) only for 5M.
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_bwCfg;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 3;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
#ifndef LTE_TDD
    //maybe TDD have the same issue?
    else if(cellCb->cellInfo.dlBw == 50)//workaound for 10M, PHY will check SRS bandwidth for 10M, so need to add this tlv(0x46) only for 10M.
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_bwCfg;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
#endif

    if(cellCb->cellCfg.puschCfg.puschUlRS.grpHopEnabled)
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_hopMode;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 1;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
    else if(cellCb->cellCfg.puschCfg.puschUlRS.seqHopEnabled)
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_hopMode;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
    else
        #endif
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_hopMode;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_deltaSeqShift;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.puschCfg.puschUlRS.grpNum;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eULRS_cs1DMRS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.puschCfg.puschUlRS.cycShift;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#ifdef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eTdd_frmStrucCfg;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.tddSfCfg.sfAssignment;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eTdd_speSfrmPattern;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.tddSfCfg.spclSfPatterns;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#endif

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eDataReportMode;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

#ifdef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSFN_SF;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#endif

#ifndef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = apiCfgTlvTag_eSRS_maxUpPts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv++;
#endif
    printf("PA_TO_SC_CONFIG_REQUEST_CH ret --14\n");
#if 0
    if(num_vsm_tlv > 0)
    {
        fapiConfigReqVsm->vsm_header.num_tlv    = num_vsm_tlv;
        fapiConfigReqVsm->vsm_header.size       = fapiVsmTlvSize;
        FAPI_T_VSM_TLV* fapiConfigReqVsmTlv = (FAPI_T_VSM_TLV*)&(fapiConfigReqVsm->tlvs[0]);

        //CFI
        fapiConfigReqVsmTlv->tag_header.tag     = FAPI_E_CFG_CFI_VSM;
        fapiConfigReqVsmTlv->tag_header.length  = sizeof(FAPI_T_CFG_CFI_VSM_TAG_VALUE);
        FAPI_T_CFG_CFI_VSM_TAG_VALUE* cfg_cfi_vsm_ptr = (FAPI_T_CFG_CFI_VSM_TAG_VALUE*)(&(fapiConfigReqVsmTlv->value));

        cfg_cfi_vsm_ptr->cfi        = 1;
        cfg_cfi_vsm_ptr->padding[0] = 0;
        cfg_cfi_vsm_ptr->padding[1] = 0;
        cfg_cfi_vsm_ptr->padding[2] = 0;
        fapiConfigReqVsmTlv = (FAPI_T_VSM_TLV *)(((U8*)fapiConfigReqVsmTlv) + (sizeof(FAPI_T_VSM_TLV) + sizeof(FAPI_T_CFG_CFI_VSM_TAG_VALUE)));

        //Version
        fapiConfigReqVsmTlv->tag_header.tag     = FAPI_E_CFG_VERSION_VSM;
        fapiConfigReqVsmTlv->tag_header.length  = sizeof(FAPI_T_CFG_VERSION_VSM_TAG_VALUE);
        FAPI_T_CFG_VERSION_VSM_TAG_VALUE* cfg_ver_vsm_ptr   = (FAPI_T_CFG_VERSION_VSM_TAG_VALUE* )(&(fapiConfigReqVsmTlv->value));

        cfg_ver_vsm_ptr->vs_major_ver   = 1;//(U16)(VSM_API_MAJOR);
        cfg_ver_vsm_ptr->vs_minor_ver   = 6;//(U16)(VSM_API_MINOR);
        cfg_ver_vsm_ptr->padding        = 0;
        fapiConfigReqVsmTlv = (FAPI_T_VSM_TLV *)(((U8*)fapiConfigReqVsmTlv) + (sizeof(FAPI_T_VSM_TLV) + sizeof(FAPI_T_CFG_VERSION_VSM_TAG_VALUE)));
    }
    #endif
    printf("PA_TO_SC_CONFIG_REQUEST_CH ret --15\n");
    ret = fsl_ipc_send_msg(PA_TO_SC_CONFIG_REQUEST_CH, fapiConfigReq, totallen, ipc[1]);
    printf("PA_TO_SC_CONFIG_REQUEST_CH ret %d \n",ret);
    //ret = ipc_sendMsgbyIpcHigh((char*)fapiConfigReq, totallen, cellCb->phyInstId);
    stklog(STK_MD_YS,STK_LOG_INFO,"ys_qcSendConfigReq carrierId[%d] \n",0);
    ysUtlFreeQCIPCSBuf(buff,totallen, 0);
#endif
#else
    FAPI_T_CONFIG_REQ* fapiConfigReq = NULLP;
    Data  *buff;
    S16 ret = 0;
    S32 totallen,fapiConfigReqSize;
    U8 tlvNum = 35;//sizeof(qcPhyConfList)/sizeof(qcPhyConfList[0]);
    U8 vsm_tvl_length   = 4;
    U8 num_vsm_tlv = 2;
    FAPI_T_VSM_MSG* fapiConfigReqVsm;
    U16 indx = 0;
    S32 fapiVsmTlvSize = sizeof(FAPI_T_VSM_MSG) + (num_vsm_tlv*(sizeof(FAPI_T_VSM_TLV) + vsm_tvl_length));
    printf("PA_TO_SC_CONFIG_REQUEST_CH ret --2\n");

    if(g_ys_DC == TRUE)
    {
        indx = cellCb->cellId - CM_START_CELL_ID;
    }

    fapiConfigReqSize = sizeof(FAPI_T_CONFIG_REQ) + tlvNum*sizeof(FAPI_T_CONFIG_TLV);
    totallen = fapiConfigReqSize+fapiVsmTlvSize; //if not support VSM TLV
    if(cellCb->cellInfo.dlBw == 25)//workaound for 5M, PHY will check SRS bandwidth for 5M, so need to add this tlv(0x46) only for 5M.
    {
        fapiConfigReqSize+=sizeof(FAPI_T_CONFIG_TLV);
        totallen+=sizeof(FAPI_T_CONFIG_TLV);
    }
    
    if(ysUtlAllocQCIPCSBuf(&buff,totallen, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ipc_highRecProc SGetSBuf failed.\n");
        return(RFAILED);
    }

    fapiConfigReq =(FAPI_T_CONFIG_REQ*)buff;
    fapiConfigReq->msg_hdr.type = FAPI_E_CONFIG_REQ;
    fapiConfigReq->msg_hdr.len = fapiConfigReqSize - sizeof(FAPI_T_MSG_HDR);
    #ifdef NXP_PLATFORM
    fapiConfigReq->msg_hdr.msgVdrSpecFlag = 0;
    #else
    fapiConfigReq->msg_hdr.len_ven = fapiVsmTlvSize;
    #endif
    fapiConfigReqVsm = (FAPI_T_VSM_MSG*) (((char*)fapiConfigReq) + fapiConfigReqSize);
    fapiConfigReq->n_tlv = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_GEN_CFG_DUPLEXING_MODE;
//TBD, fill with value cellCb->cellCfg.txCfg.duplexMode
#ifdef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;//cellCb->cellCfg.txCfg.duplexMode;
#else
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 1;//cellCb->cellCfg.txCfg.duplexMode;
#endif
    
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_GEN_CFG_PCFICH_PWR_OFF;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.cfiPowOs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_GEN_CFG_P_B;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pdschCfg.p_b;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_GEN_CFG_DL_CYC_PREFIX;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.txCfg.cycPfx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_GEN_CFG_UL_CYC_PREFIX;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.txCfg.cycPfx;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_RF_CFG_DL_CH_BW;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellInfo.dlBw;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_RF_CFG_UL_CH_BW;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellInfo.ulBw;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_RF_CFG_RS_POWER;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pilotSigPwr;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_RF_CFG_TX_ANT_PORTS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;//cellCb->cellCfg.txAntennaPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;


    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_RF_CFG_RX_ANT_PORTS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;//cellCb->cellCfg.rxAntennaPorts;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PHICH_CFG_RESOURCE;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.phichCfg.resource;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PHICH_CFG_DURATION;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.phichCfg.duration;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PHICH_CFG_POWER_OFF;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_SCH_CFG_PSS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.syncSigPowOs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_SCH_CFG_SSS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.syncSigPowOs;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_SCH_CFG_CELL_ID;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.cellIdGrpId *3 +cellCb->cellCfg.physCellId;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PRACH_CFG_CONFIG_IDX;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.prachCfgIndex;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PRACH_CFG_ROOT_SEQ_IDX;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.rootSequenceIndex;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PRACH_CFG_ZCZ_CONFIG;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.zeroCorrelationZoneCfg;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PRACH_CFG_HIGH_SPEED;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.highSpeedFlag;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PRACH_CFG_FREQ_OFF;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.prachCfg.prachFreqOffset;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PUSCH_CFG_HOPPING_MODE;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschBasicCfg.hoppingMode;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PUSCH_CFG_HOPPING_OFF;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschBasicCfg.hoppingOffset;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PUSCH_CFG_N_SUBBANDS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschBasicCfg.noOfsubBands;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PUCCH_CFG_DELTA_SHIFT;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pucchCfg.deltaShift+1;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PUCCH_CFG_N_CQI_RB;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pucchCfg.nRB;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PUCCH_CFG_N_AN_CS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pucchCfg.nCS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_PUCCH_CFG_N1_PUCCH_AN;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.pucchCfg.n1PUCCH;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
    if(cellCb->cellInfo.dlBw == 25)//workaound for 5M, PHY will check SRS bandwidth for 5M, so need to add this tlv(0x46) only for 5M.
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_SRS_CFG_BW_CONFIG;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 3;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
#ifndef LTE_TDD
    //maybe TDD have the same issue?
    else if(cellCb->cellInfo.dlBw == 50)//workaound for 10M, PHY will check SRS bandwidth for 10M, so need to add this tlv(0x46) only for 10M.
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_SRS_CFG_BW_CONFIG;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
#endif

    if(cellCb->cellCfg.puschCfg.puschUlRS.grpHopEnabled)
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_UL_RS_CFG_HOPPING;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 1;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
    else if(cellCb->cellCfg.puschCfg.puschUlRS.seqHopEnabled)
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_UL_RS_CFG_HOPPING;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 2;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
    else
    {
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_UL_RS_CFG_HOPPING;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
        fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
        fapiConfigReq->n_tlv ++;
    }
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_UL_RS_CFG_GRP_ASSIGN;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschUlRS.grpNum;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_UL_RS_CFG_CS1DMRS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.puschCfg.puschUlRS.cycShift;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#ifdef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_TDD_CFG_SF_ASSIGN;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.tddSfCfg.sfAssignment;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_TDD_CFG_S_SF_PATTERN;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = cellCb->cellCfg.tddSfCfg.spclSfPatterns;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#endif

    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_GEN_CFG_DATA_REP_MODE;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;

#ifdef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_GEN_CFG_SFN_SF;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv ++;
#endif

#ifndef LTE_TDD
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].tag = FAPI_E_SRS_CFG_MAX_UP_PTS;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].value = 0;
    fapiConfigReq->tlv[fapiConfigReq->n_tlv].length = 2;
    fapiConfigReq->n_tlv++;
#endif

    if(num_vsm_tlv > 0)
    {
        fapiConfigReqVsm->vsm_header.num_tlv    = num_vsm_tlv;
        fapiConfigReqVsm->vsm_header.size       = fapiVsmTlvSize;
        FAPI_T_VSM_TLV* fapiConfigReqVsmTlv = (FAPI_T_VSM_TLV*)&(fapiConfigReqVsm->tlvs[0]);

        //CFI
        fapiConfigReqVsmTlv->tag_header.tag     = FAPI_E_CFG_CFI_VSM;
        fapiConfigReqVsmTlv->tag_header.length  = sizeof(FAPI_T_CFG_CFI_VSM_TAG_VALUE);
        FAPI_T_CFG_CFI_VSM_TAG_VALUE* cfg_cfi_vsm_ptr = (FAPI_T_CFG_CFI_VSM_TAG_VALUE*)(&(fapiConfigReqVsmTlv->value));

        cfg_cfi_vsm_ptr->cfi        = 1;
        cfg_cfi_vsm_ptr->padding[0] = 0;
        cfg_cfi_vsm_ptr->padding[1] = 0;
        cfg_cfi_vsm_ptr->padding[2] = 0;
        fapiConfigReqVsmTlv = (FAPI_T_VSM_TLV *)(((U8*)fapiConfigReqVsmTlv) + (sizeof(FAPI_T_VSM_TLV) + sizeof(FAPI_T_CFG_CFI_VSM_TAG_VALUE)));

        //Version
        fapiConfigReqVsmTlv->tag_header.tag     = FAPI_E_CFG_VERSION_VSM;
        fapiConfigReqVsmTlv->tag_header.length  = sizeof(FAPI_T_CFG_VERSION_VSM_TAG_VALUE);
        FAPI_T_CFG_VERSION_VSM_TAG_VALUE* cfg_ver_vsm_ptr   = (FAPI_T_CFG_VERSION_VSM_TAG_VALUE* )(&(fapiConfigReqVsmTlv->value));

        cfg_ver_vsm_ptr->vs_major_ver   = 1;//(U16)(VSM_API_MAJOR);
        cfg_ver_vsm_ptr->vs_minor_ver   = 6;//(U16)(VSM_API_MINOR);
        cfg_ver_vsm_ptr->padding        = 0;
        fapiConfigReqVsmTlv = (FAPI_T_VSM_TLV *)(((U8*)fapiConfigReqVsmTlv) + (sizeof(FAPI_T_VSM_TLV) + sizeof(FAPI_T_CFG_VERSION_VSM_TAG_VALUE)));
    }

    ret = ipc_sendMsgbyIpcHigh((char*)fapiConfigReq, totallen, cellCb->phyInstId);
    STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcSendConfigReq carrierId[%d] \n", cellCb->phyInstId);
    ysUtlFreeQCIPCSBuf(buff,totallen, indx);
#endif
    if(ret)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcSendtoPhy return:%d\n",ret);
        exit(ret);
    }
    return(ret);
}

void ys_qcErrorIndHndl(FAPI_T_ERROR_IND* qcl1Msg)
{
    return;
}

extern U8 RachInterval[YS_LTE_MAX_CELLS];
extern U8 phySubFrame;
extern CmLteTimingInfo g_phyTimingInfo;
void  ys_qcSfIndHndlDC(FAPI_T_SF_IND*  strSfInd, int carrierId)
{
    U16 sfInf;
    YsCellCb    *cellCb;
    S16 ret;
    Bool     isDummyTti = FALSE;
    static U32 ttiNum = 0;
    U16 frame;
    U8 subframe;
    static U8 subframe_last[NUM_MAX_CARRIER] = {0, 0};
    U32 val = 0;
    U8 loop = 0;
    static U8 first_tti_flag[NUM_MAX_CARRIER] = {0, 0};
    U32 dura;
    static U32 SFover0dot8msNum = 0;
    static U32 SFover1msNum = 0;
    static U32 SFover1dot5msNum = 0;
    static U32 SFover2msNum = 0;
    static U32 testNum = 0;
    static U32 totalTimeDuration = 0;
    static U32 maxTimeDuration = 0;

    cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
    if(cellCb == NULLP)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ys cellcb is null\n");
        RETVOID;
    }

    if(RachInterval[carrierId] < 10)
    {
        RachInterval[carrierId]++;
    }

    if (first_tti_flag[carrierId] <= carrierId)
    {
        first_tti_flag[carrierId]++;

        if (cellCb->phyState != LYS_PHY_STATE_RUN)
        {
            cellCb->phyState = LYS_PHY_STATE_RUN;
        }

        for(loop = 0; loop <9; loop ++)
        {
            ysQcPhyUlMsgInfo[carrierId][loop].receivedCqiNum =0;
            ysQcPhyUlMsgInfo[carrierId][loop].receivedCrcNum =0;
            ysQcPhyUlMsgInfo[carrierId][loop].receivedHarqNum =0;
            ysQcPhyUlMsgInfo[carrierId][loop].receivedSrNum = 0;
            ysQcPhyUlMsgInfo[carrierId][loop].receivedUlschNum = 0;
        }

        subframe_last[carrierId] = strSfInd->sf_sfn &0x0F;
        ys_StopTmr(0,YS_TMR_STARTREQ_TMROUT0+carrierId);
        return;
    }

    if(((strSfInd->sf_sfn &0x0F) +10 - subframe_last[carrierId])%10 != 1)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"SF IND abormal, sfn (%d), subframe(%d),  carrierId(%d)\n", strSfInd->sf_sfn>>4, strSfInd->sf_sfn&0x0f, carrierId);
    }

    subframe_last[carrierId] = strSfInd->sf_sfn &0x0F;
    sfInf = strSfInd->sf_sfn;

    if(((sfInf&0x0F) +TIME_ADVANCE_QC)>9)
    {
        cellCb->timingInfo.subframe = ((sfInf&0x0F)+TIME_ADVANCE_QC)%10;
        cellCb->timingInfo.sfn      = ((sfInf>>4)+1)%1024; /* SFN is 12 bits from LSB */
    }
    else
    {
        cellCb->timingInfo.subframe = (sfInf&0x0F)+TIME_ADVANCE_QC;
        cellCb->timingInfo.sfn      = (sfInf>>4); /* SFN is 12 bits from LSB */
    }

    ysGT = cellCb->timingInfo.sfn * YS_NUM_SUB_FRAMES + cellCb->timingInfo.subframe;

    if(phySubFrame != cellCb->timingInfo.subframe)
    {
        STKLOG(STK_MD_YS,STK_LOG_WARNING,"carrierId[%d] ys_qcSfIndHndl process late, dummy this TTI[%d:%d], phyTime[%d, %d]\n",
               carrierId, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe, g_phyTimingInfo.sfn, g_phyTimingInfo.subframe);

        isDummyTti = TRUE;
    }

    if(carrierId == 0)
    {
        ret = ysMsDlmPrcTtiIndDC(NULLP, cellCb, isDummyTti);
        SIncrementTtiCount();
    }
    else if(carrierId == 1)
    {
        ysMsDlmPrc2ndTtiInd(NULLP, cellCb, isDummyTti);
    }
#ifdef LTE_TDD
    if(cellCb->isCrcExptd[sfInf&0x0F] == FALSE)
    {
        TfuCrcIndInfo   *crcIndInfo = NULLP;

        ret = ysUtlAllocEventMem((Ptr *)&crcIndInfo,sizeof(TfuCrcIndInfo), carrierId, __FUNCTION__,__LINE__);
        if(ret == RFAILED)
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"malloc failed for fake crc ind\n");
            return;
        } /* end of if statement */
        cmLListInit(&(crcIndInfo->crcLst));

        crcIndInfo->cellId = cellCb->cellId;
        if((sfInf&0x0F) >= 3)
        {
            crcIndInfo->timingInfo.sfn = (sfInf>>4);
        }
        else
        {
            crcIndInfo->timingInfo.sfn = (1024 +(sfInf>>4)-1)%1024;
        }
        crcIndInfo->timingInfo.subframe = (10 + (sfInf&0x0F)-3)%10;
        YsUiTfuCrcInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId,crcIndInfo);
    }

    cellCb->isCrcExptd[sfInf&0x0F] = FALSE;
#endif

#ifndef LTE_TDD
    if(cellCb->ulEncL1Msgs[cellCb->timingInfo.subframe].tfuCrcIndInfo)
	 {
			//printf("sent fake %d %d count %d\n",cellCb->ulEncL1Msgs[cellCb->timingInfo.subframe].tfuCrcIndInfo->timingInfo.sfn,cellCb->ulEncL1Msgs[cellCb->timingInfo.subframe].tfuCrcIndInfo->timingInfo.subframe,cellCb->ulEncL1Msgs[cellCb->timingInfo.subframe].tfuCrcIndInfo->crcLst.count);
		   YsUiTfuCrcInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId,cellCb->ulEncL1Msgs[cellCb->timingInfo.subframe].tfuCrcIndInfo);
		   cellCb->ulEncL1Msgs[cellCb->timingInfo.subframe].tfuCrcIndInfo = NULLP;
	 }
#endif

    return;
}


void  ys_qcSfIndHndl(FAPI_T_SF_IND*  strSfInd, int carrierId)
{
    U16 sfInf;
    YsCellCb    *cellCb;
    S16 ret;
    Bool     isDummyTti = FALSE;
    static U32 ttiNum = 0;
    U16 frame;
    U8 subframe;
    static U8 subframe_last[NUM_MAX_CARRIER] = {0, 0};
    U32 val = 0;
    U8 loop = 0;
    static U8 first_tti_flag[NUM_MAX_CARRIER] = {0, 0};
    U32 dura;
    static U32 SFover0dot8msNum = 0;
    static U32 SFover1msNum = 0;
    static U32 SFover1dot5msNum = 0;
    static U32 SFover2msNum = 0;
    static U32 testNum = 0;
    static U32 totalTimeDuration = 0;
    static U32 maxTimeDuration = 0;
    for(carrierId = 0; carrierId < (ysCb.numOfCells); carrierId++)
    {
        cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
        if(cellCb == NULLP)
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys cellcb is null\n");
            RETVOID;
        }

        if(RachInterval[carrierId] <10)
        {
            RachInterval[carrierId]++;
        }

        if (first_tti_flag[carrierId] == 0)
        {
            if (cellCb->phyState != LYS_PHY_STATE_RUN)
            {
                cellCb->phyState = LYS_PHY_STATE_RUN;
            }

            ys_StopTmr(0,YS_TMR_STARTREQ_TMROUT0+carrierId);

            first_tti_flag[carrierId] = 1;
            for(loop = 0; loop <9; loop ++)
            {
                ysQcPhyUlMsgInfo[carrierId][loop].receivedCqiNum =0;
                ysQcPhyUlMsgInfo[carrierId][loop].receivedCrcNum =0;
                ysQcPhyUlMsgInfo[carrierId][loop].receivedHarqNum =0;
                ysQcPhyUlMsgInfo[carrierId][loop].receivedSrNum = 0;
                ysQcPhyUlMsgInfo[carrierId][loop].receivedUlschNum = 0;
            }

            subframe_last[carrierId] = strSfInd->sf_sfn &0x0F;

            return;
        }

        if(((strSfInd->sf_sfn &0x0F) +10 - subframe_last[carrierId])%10 != 1)
        {
            STKLOG(STK_MD_YS,STK_LOG_WARNING,"SF IND abormal, sfn (%d), subframe(%d),  carrierId(%d)\n", strSfInd->sf_sfn>>4, strSfInd->sf_sfn&0x0f, carrierId);
        }

        subframe_last[carrierId] = strSfInd->sf_sfn &0x0F;
        sfInf = strSfInd->sf_sfn;

        #if 0
        if(((sfInf&0x0F) +TIME_ADVANCE_QC)>9)
        {
            cellCb->timingInfo.subframe = ((sfInf&0x0F)+TIME_ADVANCE_QC)%10;
            cellCb->timingInfo.sfn      = ((sfInf>>4)+1)%1024; /* SFN is 12 bits from LSB */
        }
        else
        {
            cellCb->timingInfo.subframe = (sfInf&0x0F)+TIME_ADVANCE_QC;
            cellCb->timingInfo.sfn      = (sfInf>>4); /* SFN is 12 bits from LSB */
        }
        #endif
        CmLteTimingInfo tmptimeInfo;
        tmptimeInfo.subframe = sfInf&0x0F;
        tmptimeInfo.sfn = sfInf>>4;
        YS_MS_DECR_TIME(tmptimeInfo, cellCb->timingInfo, 1);
#if 0
        if(((sfInf&0x0F) == 2)||((sfInf&0x0F) == 7))
        {
            ys_qcsendEmptyUlConfigReq( sfInf>>4, (sfInf&0x0F)-1, 0);
        }
#endif
        if(carrierId == YS_PHY_INST_ID)
        {
            handleACIPCMsg(SC_TO_PA_HARQ_INDICATION_CH, carrierId);
            handleACIPCMsg(SC_TO_PA_RACH_INDICATION_CH, carrierId);
            //handleACIPCMsg(SC_TO_PA_CRC_INDICATION_CH, carrierId);
            if(phySubFrame != cellCb->timingInfo.subframe)
            {
                isDummyTti = TRUE;
                STKLOG(STK_MD_YS,STK_LOG_WARNING,"ys_qcSfIndHndl process late, dummy this TTI[%d:%d]\n",
                       cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
            }
            ysGT = cellCb->timingInfo.sfn * YS_NUM_SUB_FRAMES + cellCb->timingInfo.subframe;
            ret = ysMsDlmPrcTtiInd(NULLP, cellCb, isDummyTti);
        }


        if(cellCb->isCrcExptd[sfInf&0x0F] == FALSE)
        {
            TfuCrcIndInfo   *crcIndInfo = NULLP;

            ret = ysUtlAllocEventMem((Ptr *)&crcIndInfo,sizeof(TfuCrcIndInfo), carrierId, __FUNCTION__,__LINE__);
            if(ret == RFAILED)
            {
                STKLOG(STK_MD_YS,STK_LOG_ERR,"malloc failed for fake crc ind\n");
                return;
            } /* end of if statement */
            cmLListInit(&(crcIndInfo->crcLst));

            crcIndInfo->cellId = cellCb->cellId;
            if((sfInf&0x0F) >= 3)
            {
                crcIndInfo->timingInfo.sfn = (sfInf>>4);
            }
            else
            {
                crcIndInfo->timingInfo.sfn = (1024 +(sfInf>>4)-1)%1024;
            }
            crcIndInfo->timingInfo.subframe = (10 + (sfInf&0x0F)-3)%10;
            YsUiTfuCrcInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId,crcIndInfo);
        }
    
        cellCb->isCrcExptd[sfInf&0x0F] = FALSE;

    #ifdef NXP_PLATFORM
        if(cellCb->ulEncL1Msgs[cellCb->timingInfo.subframe].tfuCrcIndInfo)
    	{
    		 YsUiTfuCrcInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId,cellCb->ulEncL1Msgs[cellCb->timingInfo.subframe].tfuCrcIndInfo);
    		 cellCb->ulEncL1Msgs[cellCb->timingInfo.subframe].tfuCrcIndInfo = NULLP;
    	}
    #endif
    }

    SIncrementTtiCount();
    return;
}

S16   ys_qcSendStopReq(int carrierId)
{
    S16 ret;
    FAPI_T_STOP_REQ  strStopReq;

    strStopReq.msg_hdr.len = 0;
    #ifdef NXP_PLATFORM
    strStopReq.msg_hdr.msgVdrSpecFlag = 0;
    #else
    strStopReq.msg_hdr.len_ven = 0;
    #endif
    strStopReq.msg_hdr.type = FAPI_E_STOP_REQ;

    ret = ipc_sendMsgbyIpcHigh((char*)&strStopReq, sizeof(FAPI_T_STOP_REQ), carrierId);

    return ret;
}

/*
	send FAPI_E_START_REQ to PHY
*/
S16   ys_qcSendStartReq(const int carrierId)
{
    S16 ret;
    FAPI_T_START_REQ  *strStartReq;

    #if 1
    if(ysUtlAllocQCIPCSBuf((Data **)&strStartReq, sizeof(FAPI_T_START_REQ), carrierId) != ROK)
    {
        STKLOG(STK_MD_EPR,STK_LOG_ERR,"ys_qcSendStartReq ysUtlAllocQCIPCSBuf failed.\n");
        return;
    }
 #endif

    strStartReq->msg_hdr.len = 0;
    #ifdef NXP_PLATFORM
    strStartReq->msg_hdr.msgVdrSpecFlag = 0;
    #else
    strStartReq->msg_hdr.len_ven = 0;
    #endif
    strStartReq->msg_hdr.type = FAPI_E_START_REQ;
   printf("ys_qcSendStartReq \n");
    #ifdef NXP_PLATFORM
    fsl_ipc_send_msg(PA_TO_SC_START_REQUEST_CH, strStartReq, sizeof(FAPI_T_START_REQ), ipc[carrierId]);
    #else
    ipc_sendMsgbyIpcHigh((char*)strStartReq, sizeof(FAPI_T_START_REQ), carrierId);
    #endif

    //ret = ipc_sendMsgbyIpcHigh((char*)strStartReq, sizeof(FAPI_T_START_REQ), carrierId);
    ysUtlFreeQCIPCSBuf((Data *)strStartReq, sizeof(FAPI_T_START_REQ), carrierId);

    return ret;
}

/*
	FAPI_E_CONFIG_RSP msg handle

*/
S16 ys_qcConfRspHndl(FAPI_T_CONFIG_RSP* qcConfRsp, const int carrierId)
{

    S16 ret;
    YsCellCb *cellCb;
    
    ys_StopTmr(NULLP, YS_TMR_CONFREQ_TMROUT0 + carrierId);
    STKLOG(STK_MD_YS,STK_LOG_INFO," ys_qcConfRspHndl carrierId[%d] \n", carrierId);

    if(qcConfRsp->error_code != FAPI_E_MSG_OK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ConfRsp errorcode:%d, carrier:%d\n",qcConfRsp->error_code, carrierId);
        fflush(stdout);
        return RFAILED;
    }

    cellCb = ysMsGetCellCbFrmPhyInstId(carrierId);   
    cellCb->phyState = LYS_PHY_STATE_CFG;
    if(((YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId))->phyState != LYS_PHY_STATE_CFG)
    {
        return ROK;
    }
    ys_qcSendStartReq(carrierId);
    ys_StartTmr(YS_TMR_STARTREQ_TMROUT0 + carrierId, 5, 0);
/*
    U8 cnt = ysCb.numOfCells;
    for(U8 i = 0; i < cnt; i++)
    {
        if(((YsCellCb*)ysMsGetCellCbFrmPhyInstId(i))->phyState != LYS_PHY_STATE_CFG)
        {
            return ROK;
        }
    }

    ys_qcSendStartReq(0);
    ys_StartTmr(YS_TMR_STARTREQ_TMROUT0, 5, 0);
*/
    YsUiCtfCfgCfm(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,
            ysCb.ctfSap.transId, CTF_CFG_CFM_OK);
    STKLOG(STK_MD_YS,STK_LOG_INFO," YsUiCtfCfgCfm transId %d\n",ysCb.ctfSap.transId);
    return ROK;
}

/*
   FAPI_E_PARAM_RSP msg handle function

*/
S16 ys_qcParRspHndl(FAPI_T_MSG_HDR* pstrParRsp, const int carrierId)
{
    YsCellCb    *cellCb;
    FAPI_T_PARAM_RSP* pRsp = (FAPI_T_PARAM_RSP*)pstrParRsp;

    ys_StopTmr(NULLP, YS_TMR_PARREQ_TMROUT0 + carrierId);

    if(pRsp->error_code != FAPI_E_MSG_OK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"Carrier %d ParRsp errorcode:%d,func:%s\n",carrierId, pRsp->error_code, __func__);
        return FAILURE;
    }
    else
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"ParRsp return carrierId[%d], n_tlv:%d.\n",carrierId, pRsp->n_tlv);
        ys_qcUpdatePhyConfig(pRsp->n_tlv,pRsp->tlv, carrierId);
    }
    
    /* Get the cellCb */
    cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
    cellCb->phyState = LYS_PHY_STATE_PARAM_RSP;
    if(((YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId))->phyState != LYS_PHY_STATE_PARAM_RSP)
    {
        return ROK;
    }
    ys_qcSendConfigReq((YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId));
    ys_StartTmr(YS_TMR_CONFREQ_TMROUT0 + carrierId, 5, 0);
    
/*
    U8 cnt = ysCb.numOfCells;
    for(U8 i = 0; i < cnt; i++)
    {
        if(((YsCellCb*)ysMsGetCellCbFrmPhyInstId(i))->phyState != LYS_PHY_STATE_PARAM_RSP)
        {
            return ROK;
        }
    }
    
    for(U8 i = 0; i < cnt; i++)
    {
        ys_qcSendConfigReq((YsCellCb*)ysMsGetCellCbFrmPhyInstId(i));
        ys_StartTmr(YS_TMR_CONFREQ_TMROUT0 + i, 5, 0);
    }
*/
    return ROK;
}

S16 ys_qcMsgHndlrNew(PTR qcl1Msg, S32 buffSize, int carrierId)
{
    FAPI_T_MSG_HDR*  pstrQcMsgHdr = NULLP;
    pstrQcMsgHdr =(FAPI_T_MSG_HDR*)qcl1Msg;
    S16 ret = FAILURE;
    U32 indx = 0;

    if(g_ys_DC == TRUE)
    {
        indx = carrierId;
    }

    if(ysCb.numOfCells)
    {
        switch(pstrQcMsgHdr->type)
        {
            case FAPI_E_PARAM_RSP:
                ret = ys_qcParRspHndl((FAPI_T_MSG_HDR *)qcl1Msg, carrierId);
                break;

            case FAPI_E_CONFIG_RSP:
                ret = ys_qcConfRspHndl((FAPI_T_CONFIG_RSP*)qcl1Msg, carrierId);
                break;

            case FAPI_E_STOP_IND:
                STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcMsgHndlr received FAPI_E_STOP_IND!\n");
                YS_DBG_ERR((_ysp, "received FAPI_E_STOP_IND! \n"));	
                break;

            case FAPI_E_ERROR_IND:
                ys_qcErrorIndHndl((FAPI_T_ERROR_IND*)qcl1Msg);
                break;

            case FAPI_E_SF_IND:
                if(g_ys_DC == TRUE)
                {
                    ys_qcSfIndHndlDC((FAPI_T_SF_IND*)qcl1Msg, carrierId);
                }
                else
                {
                    ys_qcSfIndHndl((FAPI_T_SF_IND*)qcl1Msg, carrierId);
                }
                break;

            case FAPI_E_RACH_IND:
                ys_qcRachIndHndl(pstrQcMsgHdr, carrierId);
                break;

            case FAPI_E_RX_ULSCH_IND:
                #ifdef NXP_PLATFORM
                ys_NxpRxUlschIndHndl(pstrQcMsgHdr, carrierId);
                #else
                ys_qcRxUlschIndHndl(pstrQcMsgHdr, carrierId)
                #endif
                break;

            case FAPI_E_CRC_IND:
#ifdef LTE_TDD
                ys_qcCrcIndHndl(pstrQcMsgHdr, carrierId);
#endif
                break;

            case FAPI_E_RX_SR_IND:
                ys_qcRxSrIndHndl(pstrQcMsgHdr, carrierId);
                break;

            case FAPI_E_HARQ_IND:
                ys_qcHarqIndHndl(pstrQcMsgHdr, carrierId);
                break;

            case FAPI_E_RX_CQI_IND:
                ys_qcRxDlCqiHndl(pstrQcMsgHdr, carrierId);
                break;

            case FAPI_E_SRS_IND:
                ys_qcPrcSrsInd(pstrQcMsgHdr, carrierId);
                break;

            case FAPI_E_RX_VSM_MEAS_IND:
                //printf("FAPI_E_RX_VSM_MEAS_IND \n");
                break;

            case MSGID_LINKTEST_RSP:
                ys_qcLintTestRspHandle(pstrQcMsgHdr);
                break;

            default:
                STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcMsgHndlr received unknown msgType:%d!!\n",pstrQcMsgHdr->type);
                break;
        }
    }
    SPutStaticBuffer(ysCb.ysInit[indx].region, ysCb.ysInit[indx].pool,(Data *)qcl1Msg, buffSize, 0);

    return ret;
}

S16 ys_qcMsgForwd(Data *qcMsg, S32 msgLen, int carrierId)
{
    S16          ret;
    Pst          pst;
    Buffer       *mBuf;
    U32          size = 0;
    U32          inst = 0;

    TRC2(ys_qcMsgForwd);
    if(g_ys_DC == TRUE)
    {
        inst = carrierId;
    }
    pst.selector = 0;
    pst.region = ysCb.ysInit[inst].region;
    pst.pool = ysCb.ysInit[inst].pool;
    pst.prior = PRIOR0;
    pst.route = RTESPEC;
    pst.dstEnt = ENTYS;
    pst.dstInst = inst;
#ifdef SS_MULTIPLE_PROCS       
    pst.dstProcId = ysCb.ysInit[inst].procId;
#else /* SS_MULTIPLE_PROCS */      
    pst.dstProcId = SFndProcId();
#endif /* SS_MULTIPLE_PROCS */
    pst.srcEnt = ENTYS;
    pst.srcInst = 0;
#ifdef SS_MULTIPLE_PROCS       
    pst.srcProcId = ysCb.ysInit[inst].procId;
#else /* SS_MULTIPLE_PROCS */      
    pst.srcProcId = SFndProcId();
#endif /* SS_MULTIPLE_PROCS */     
    pst.event = EVTLYSQCDATA;

    if(SGetMsg(ysCb.ysInit[inst].region, ysCb.ysInit[inst].pool, &mBuf) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"error: SGetMsg failed in %s\n", __func__);
        SPutStaticBuffer(ysCb.ysInit[inst].region, ysCb.ysInit[inst].pool, qcMsg, msgLen,0);
        RETVALUE(RFAILED);
    }
    
    cmPkPtr(qcMsg, mBuf);
    SPkS32(msgLen, mBuf);
    SPkU32(carrierId, mBuf);
    
    ret = SPstTsk(&pst, mBuf);

    RETVALUE(ret);
}

void ys_qcStartParReqTmr()
{
    ys_StartTmr(YS_TMR_PARREQ_TMROUT0,5,NULLP);
    return;
}

/*wrong procedure, skip param req....*/
PUBLIC S16 ys_qcSendParReq(int carrierId)
{
    FAPI_T_PARAM_REQ* strParReq;
    int ret;
    if(ysUtlAllocQCIPCSBuf((Data **)&strParReq, sizeof(FAPI_T_PARAM_REQ), carrierId) != ROK)
    {
        STKLOG(STK_MD_EPR,STK_LOG_ERR,"ys_qcSendParReq ysUtlAllocQCIPCSBuf failed.\n");
        return;
    }

    strParReq->msg_hdr.len = 0;
    #ifdef NXP_PLATFORM
    strParReq->msg_hdr.msgVdrSpecFlag= 0;
    #else
    strParReq->msg_hdr.len_ven = 0;
    #endif
    strParReq->msg_hdr.type = FAPI_E_PARAM_REQ;
    STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcSendParReq carrier %d", carrierId);
    #ifdef NXP_PLATFORM
    ret = fsl_ipc_send_msg(PA_TO_SC_PARAM_REQUEST_CH, strParReq, sizeof(FAPI_T_PARAM_REQ), ipc[carrierId]);
    printf("\n fsl_ipc_send_msg ret %x \n", ret);
    if (ret) {
		printf("\n fsl_ipc_send_msg ret %x \n", ret);
		exit(ret);
	}
    #else
    ipc_sendMsgbyIpcHigh((char*)strParReq, sizeof(FAPI_T_PARAM_REQ), carrierId);
    #endif
    ysUtlFreeQCIPCSBuf((Data *)strParReq, sizeof(FAPI_T_PARAM_REQ), carrierId);

    if(carrierId == 0)
    {
        ys_StartTmr(YS_TMR_PARREQ_TMROUT0,5,NULLP);
    }
    else if (carrierId == 1)
    {
        ys_StartTmr(YS_TMR_PARREQ_TMROUT1,5,NULLP);
    }
    
    RETVALUE(ROK);
}

/****************************************************************************
 * Function Name  : sendEmptyDlConfigReq
 * Inputs         : None
 * Outputs        : None
 * Returns        : None
 * Description    : This function will be used by either MAC OAM Player / MAC
 *                  Streamer to send empty FAPI DL_CONFIG.request message to
*                   PHY
 *****************************************************************************/
void ys_qcsendEmptyDlConfigReq(U16 frame, U8 subframe, int carrierId)
{
    TRC2(ys_qcsendEmptyDlConfigReq)
    FAPI_T_DL_CONFIG_REQ *fapiDlConfigReq;
    
    U8 len = sizeof(FAPI_T_DL_CONFIG_REQ);
    
    if(ysUtlAllocQCIPCSBuf((Data **)&fapiDlConfigReq,len, carrierId) != ROK)
    {
        STKLOG(STK_MD_EPR,STK_LOG_ERR,"ys_qcsendEmptyDlConfigReq SGetSBuf failed.\n");
        return;
    }
    fapiDlConfigReq->msg_hdr.type         = FAPI_E_DL_CONFIG_REQ;
    #ifdef NXP_PLATFORM
    fapiDlConfigReq->msg_hdr.msgVdrSpecFlag = 0;
    #else
    fapiDlConfigReq->msg_hdr.len_ven      = 0;
    #endif
    fapiDlConfigReq->msg_hdr.len          = sizeof(FAPI_T_DL_CONFIG_REQ) - sizeof(FAPI_T_MSG_HDR);

    fapiDlConfigReq->sf_sfn               = ((frame << 4) + (subframe & 0xF));
    fapiDlConfigReq->length               = sizeof(FAPI_T_DL_CONFIG_REQ) - sizeof(FAPI_T_MSG_HDR);
    fapiDlConfigReq->n_pdcch_symb         = 1;
    fapiDlConfigReq->n_dci                = 0;
    fapiDlConfigReq->n_pdu                = 0;
    fapiDlConfigReq->n_pdsch_rnti         = 0;
    fapiDlConfigReq->trans_power_pcfich   = 6000;
    #ifdef NXP_PLATFORM
    fsl_ipc_send_msg(PA_TO_SC_DLCONF_REQUEST_CH, (char*)fapiDlConfigReq, sizeof(FAPI_T_DL_CONFIG_REQ), ipc[carrierId]);
    #else
    ipc_sendMsgbyIpcHigh((char*)fapiDlConfigReq,sizeof(FAPI_T_DL_CONFIG_REQ),carrierId);
    #endif
    ysUtlFreeQCIPCSBuf((Data *)fapiDlConfigReq, len, carrierId);

    RETVOID;
}

/****************************************************************************
 * Function Name  : sendEmptyUlConfigReq
 * Inputs         : None
 * Outputs        : None
 * Returns        : None
 * Description    : This function will be used by either MAC OAM Player / MAC
 *                  Streamer to send empty FAPI UL_CONFIG.request message to
*                   PHY
 *****************************************************************************/
void ys_qcsendEmptyUlConfigReq(U16 frame, U8 subframe, int carrierId)
{
    FAPI_T_UL_CONFIG_REQ* fapiUlConfigReq;     

    if(ysUtlAllocQCIPCSBuf((Data **)&fapiUlConfigReq, sizeof(FAPI_T_UL_CONFIG_REQ), carrierId) != ROK)
    {
        STKLOG(STK_MD_EPR,STK_LOG_ERR,"ys_qcsendEmptyUlConfigReq SGetSBuf failed.\n");
        return;
    }

    fapiUlConfigReq->msg_hdr.type         = FAPI_E_UL_CONFIG_REQ;
    #ifdef NXP_PLATFORM
    fapiUlConfigReq->msg_hdr.msgVdrSpecFlag= 0;
    #else
    fapiUlConfigReq->msg_hdr.len_ven      = 0;
    #endif
    fapiUlConfigReq->msg_hdr.len          = sizeof(FAPI_T_UL_CONFIG_REQ) - sizeof(FAPI_T_MSG_HDR);

    fapiUlConfigReq->sf_sfn               = ((frame << 4) + (subframe & 0xF));
    fapiUlConfigReq->length               = sizeof(FAPI_T_UL_CONFIG_REQ) - sizeof(FAPI_T_MSG_HDR);
    fapiUlConfigReq->n_pdu                = 0;
    fapiUlConfigReq->rach_prach_frq_res   = 0;
    fapiUlConfigReq->srs_present          = 0;
    #ifdef NXP_PLATFORM
    fsl_ipc_send_msg(PA_TO_SC_ULCONF_REQUEST_CH, (char*)fapiUlConfigReq, sizeof(FAPI_T_UL_CONFIG_REQ), ipc[carrierId]);
    #else
    ipc_sendMsgbyIpcHigh((char*)fapiUlConfigReq,sizeof(FAPI_T_UL_CONFIG_REQ),carrierId);
    #endif
    ysUtlFreeQCIPCSBuf((Data *)fapiUlConfigReq, sizeof(FAPI_T_UL_CONFIG_REQ), carrierId);

    return;
}

void ys_qcsendLintTestReq(const int carrierId)
{
    struct  timeval    tv;
    struct  timezone   tz;
    U32 static count = 0;
    Data    *buff;
    U32 Len = 18000;
    if(count != 0)
    {
        //return;
    }
    
	if(SGetSBuf(ysCb.ysInit[carrierId].region, ysCb.ysInit[carrierId].pool,&buff,Len)!= ROK)
    {
        //SPutSBuf(ysCb.ysInit.region, ysCb.ysInit.pool,buff,dlConfigReqMsgSize);			
        return;
    }
    FAPI_T_MSG_HDR  *linkTestReq =(FAPI_T_MSG_HDR  * )buff;

    linkTestReq->len = count;//Len - sizeof(FAPI_T_MSG_HDR);
    #ifdef NXP_PLATFORM
    linkTestReq->msgVdrSpecFlag= 0;
    #else
    linkTestReq->len_ven = 0;
    #endif
    linkTestReq->type = MSGID_LINKTEST_REQ;

    ys_qcSendtoPhy((char*)linkTestReq,Len, carrierId);

	SPutSBuf(ysCb.ysInit[carrierId].region, ysCb.ysInit[carrierId].pool,buff,Len);
    count++;
    #if 1
    if(count == 3000)
    {
        count = 0;
    }
    #endif
    return;
}

void ys_qcLintTestRspHandle(FAPI_T_MSG_HDR*  pstrQcMsgHdr)
{
    struct  timeval    tv;
    struct  timezone   tz;
    static U32 testNum = 0;
    static U32 totalTimeDuration = 0;
    static U32 maxTimeDuration = 0;
    U32 val,dura;
    static U32 over1msNum = 0;
    static U32 over1dot5msNum = 0;
    static U32 over2msNum = 0;
    static U32 count = 0;
    static U32 seqLast = 0;
    gettimeofday(&tv,&tz);
    val = (U32) (tv.tv_sec*1000000+tv.tv_usec);
    testNum ++;

    if((pstrQcMsgHdr->len != 0)&&(((pstrQcMsgHdr->len - seqLast)!= 1)))
    {
        STKLOG(STK_MD_EPR,STK_LOG_WARNING,"OUT OF ORDER %u  %u \n",seqLast, pstrQcMsgHdr->len);
    }
    seqLast = pstrQcMsgHdr->len;
    dura = val - sendTimes[pstrQcMsgHdr->len];
    count++;
    if(count == 3000)
    {
        count = 0;
    }

#if 1
    maxTimeDuration = MAX(maxTimeDuration,dura);
    totalTimeDuration += dura;

    if(dura >= 1000 && dura < 1500)
    {
        over1msNum ++;
    }
    if(dura >= 1500 && dura < 2000)
    {
        over1dot5msNum ++;
    }
    if(dura >= 2000 )
    {
        over2msNum ++;
    }
    if(testNum % 1000 == 0)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"test times:%lu,max:%lu,avg:%lu,over1ms:%lu,over15:%lu,over2ms:%lu\n",
                testNum,maxTimeDuration,totalTimeDuration/testNum,
                over1msNum,over1dot5msNum,over2msNum);
    }
#endif

    return;
}


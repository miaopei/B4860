#ifndef __AC_SHMMGR_H__
#define __AC_SHMMGR_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include "fsl_usmmgr.h"
#include "fsl_bsc913x_ipc.h"
#include "fsl_ipc_errorcodes.h"
#include "ac_ltePhyIpc.h"
#include "envdep.h"
#include "ssi.h"

U8* ac_shmAlloc(U32 size);
U8* ac_shmV2P(U8* visualAddr_p);
void ac_shmIniit();
fsl_usmmgr_t* ac_getUsmMgr();
U8* ac_getAvaiShmAddr();


#endif /* __AC_SHMMGR_H__ */




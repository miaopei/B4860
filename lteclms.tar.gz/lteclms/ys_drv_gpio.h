#ifndef _YS_DRV_GPIO_H_
#define _YS_DRV_GPIO_H_

#ifdef RADIO_CLUSTER

#define GPIO_USIM_EN                    1
#define GPIO_USIM_DISABLE               0
#define GPIO_IOC_MAGIC                  'G'
#define GPIO_IOC_DIR_INPUT              _IO(GPIO_IOC_MAGIC, 0)  /*GPIO DIR INPUT*/
#define GPIO_IOC_DIR_OUTPUT             _IO(GPIO_IOC_MAGIC, 1)  /*GPIO DIR OUTPUT*/
#define GPIO_IOC_GET                    _IO(GPIO_IOC_MAGIC, 2)  /*SET GPIO*/
#define GPIO_IOC_SET                    _IO(GPIO_IOC_MAGIC, 3)  /*GET GPIO*/
#define GPIO_IOC_MISC_PIN_SELECT        _IO(GPIO_IOC_MAGIC, 4)  /*MISC PIN SELECT*/

int Gpio_Ctrl(unsigned char offset, unsigned int cmd, unsigned char data);
int drv_gpio_open();
int drv_gpio_close();
int drv_gpio_output_ctrl(unsigned char offset, unsigned char d);
int drv_gpio_gps_ctrl(unsigned char offset, unsigned char d);
int drv_set_gpio_10_value(unsigned char d);
#endif /*RADIO_CLUSTER*/

#endif /*_YS_DRV_GPIO_H_*/

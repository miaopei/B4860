/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************

     Name:     LTE MAC Convergence Layer

     Type:     C source file

     Desc:     C source code for ETM interface of Convergence Layer

     File:     ys_ms_etm.c

     Sid:      yw_ms_etm.c@@/main/TeNB_Main_BR/6 - Thu Apr 24 17:06:45 2014

     Prg:      nu

**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_MODULE_ID=1;
static int RLOG_FILE_ID=240;
/* Trillium Includes */
#include "envopt.h"        /* Environment options */
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#include "gen.h"           /* General */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common timer defines */
#include "cm_tkns.h"       /* Common tokens defines */
#include "cm_mblk.h"       /* Common memory allocation library defines */
#include "cm_llist.h"      /* Common link list defines  */
#include "cm_hash.h"       /* Common hashlist defines */
#include "cm_lte.h"        /* Common LTEE defines */
#include "ys_ms_err.h"        /* CL error header file */
#include "tfu.h"
#include "ctf.h"
#include "lys.h"
#include "ys_ms.h"

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "spaccdrv.h" /*sumanth*/
#endif
#endif
#include "e_tm.h"

#include "gen.x"           /* General */
#include "ssi.x"           /* System services */

#include "cm5.x"           /* Common timer library */
#include "cm_tkns.x"       /* Common tokens */
#include "cm_mblk.x"       /* Common memory allocation */
#include "cm_llist.x"      /* Common link list */
#include "cm_hash.x"       /* Common hashlist */
#include "cm_lte.x"        /* Common LTE includes */
#include "cm_lib.x"
#include "tfu.x"
#include "ctf.x"
#include "lys.x"

/* Silicon Includes */
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "apidefs.h"
#endif
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "supervisor.h"
#endif
#include "resultcodes.h"
#include "basetypes.h"

#include "ys_ms.x"
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "appinit.h"
#endif

/*ys004.102 :  Merged MSPD code with phy 1.7 */
#ifdef YS_ALL_PERF
#include "hal.h"
#endif
/* Placing all the contents of the file under E_TM flag */
#ifdef E_TM
PRIVATE S16 ysMsAddEtmCellCfg (CtfCellCfgInfo *cellCfg, YsMsCellCfg *etmPhyCfg);
PRIVATE S16 ysMsSndEtmVectors (YsCellCb    *cellCb);
PRIVATE Void ysMsFillDummyVectors ( MAC2PHY_QUEUE_EL **pElem, U16 frameNumber, U8 subframeNumber);
PRIVATE S16 ysMsEtmPhyStart (YsCellCb   *cellCb);
PRIVATE S16 ysMsEtmPhyReConfig (YsCellCb   *cellCb);

MAC2PHY_QUEUE_EL *pElemEtm = NULLP;

/**
 * @brief Cell Configuration handler 
 *
 * @details
 *
 *     Function : ysLMMEtmCellCfg 
 *     
 *     This function in called by YsMiLysCfgReq(). It handles the  
 *     cell configuration. Returns
 *     reason for success/failure of this function.
 *     
 *  @param[in]  YsCfg *cfg, the Configuaration info 
 *  @return  U16
 *      -# LCM_REASON_NOT_APPL 
 *      -# LCM_REASON_INVALID_MSGTYPE
 *      -# LCM_REASON_MEM_NOAVAIL
 **/
PUBLIC U16 ysLMMEtmCellCfg 
(
YsCfg *cfg,            /* Configuaration info */
Pst   *pst             /* Post Structure */
)
{
   U16    ret = LCM_REASON_NOT_APPL;
   CtfCellCfgInfo cellCfg;
   YsMsCellCfg etmPhyCfg;

   /* ETM Cell Cfg is received, hence enabling etm flag */
   memset(&cellCfg, 0, sizeof(CtfCellCfgInfo));
   cellCfg.cellId = cfg->s.cellCfg.cellId; 
   cellCfg.cellIdGrpId = cfg->s.cellCfg.cellIdGrpId; 

   cellCfg.physCellId = cfg->s.cellCfg.physCellId; 
   /* Bandwidth Config */
   cellCfg.bwCfg.pres = cfg->s.cellCfg.bwCfg.pres; 

   cellCfg.bwCfg.dlBw = cfg->s.cellCfg.bwCfg.dlBw;
   cellCfg.bwCfg.ulBw = cfg->s.cellCfg.bwCfg.ulBw;
   cellCfg.bwCfg.eUtraBand = cfg->s.cellCfg.bwCfg.eUtraBand;

   /* Basic transmission scheme */
   cellCfg.txCfg.pres = cfg->s.cellCfg.txCfg.pres;
   cellCfg.txCfg.duplexMode = cfg->s.cellCfg.txCfg.duplexMode;
      
   cellCfg.txCfg.scSpacing = cfg->s.cellCfg.txCfg.scSpacing;
   cellCfg.txCfg.cycPfx = cfg->s.cellCfg.txCfg.cycPfx;
   /* Antenna config */ 
   cellCfg.antennaCfg.antPortsCnt = cfg->s.cellCfg.antennaCfg.antPortsCnt;

   cellCfg.macRnti = cfg->s.cellCfg.macRnti;
   
   /* PRACH config */
   cellCfg.prachCfg.pres = cfg->s.cellCfg.prachCfg.pres;
   cellCfg.prachCfg.rootSequenceIndex = cfg->s.cellCfg.prachCfg.rootSequenceIndex;
   cellCfg.prachCfg.prachCfgIndex = cfg->s.cellCfg.prachCfg.prachCfgIndex;
   cellCfg.prachCfg.zeroCorrelationZoneCfg = cfg->s.cellCfg.prachCfg.zeroCorrelationZoneCfg; 
   cellCfg.prachCfg.highSpeedFlag = cfg->s.cellCfg.prachCfg.highSpeedFlag;
   cellCfg.prachCfg.prachFreqOffset = cfg->s.cellCfg.prachCfg.prachFreqOffset;

   cellCfg.pdschCfg.pres = cfg->s.cellCfg.pdschCfg.pres;
   cellCfg.pdschCfg.refSigPwr = cfg->s.cellCfg.pdschCfg.refSigPwr;
   cellCfg.pdschCfg.p_b =  cfg->s.cellCfg.pdschCfg.p_b;
   /* SRS UL config, setup case */
   cellCfg.srsUlCfg.pres =  cfg->s.cellCfg.srsUlCfg.pres;
   cellCfg.srsUlCfg.srsCfgType = cfg->s.cellCfg.srsUlCfg.srsCfgType;

   cellCfg.srsUlCfg.srsSetup.srsBw         = cfg->s.cellCfg.srsUlCfg.srsSetup.srsBw; 
   cellCfg.srsUlCfg.srsSetup.sfCfg         = cfg->s.cellCfg.srsUlCfg.srsSetup.sfCfg;
   cellCfg.srsUlCfg.srsSetup.srsANSimultTx = cfg->s.cellCfg.srsUlCfg.srsSetup.srsANSimultTx;
   cellCfg.srsUlCfg.srsSetup.srsMaxUpPts   = cfg->s.cellCfg.srsUlCfg.srsSetup.srsMaxUpPts; 
   cellCfg.priSigPwr = cfg->s.cellCfg.priSigPwr;
   cellCfg.secSigPwr  = cfg->s.cellCfg.secSigPwr;
      /* PHY configuration parameters */
   etmPhyCfg.opMode  = cfg->s.cellCfg.opMode;
   etmPhyCfg.counter = cfg->s.cellCfg.counter;
   etmPhyCfg.period  = cfg->s.cellCfg.period;

  /* Invoke CTF Interface API to configure PHY/CELL */ 
   ret = ysMsAddEtmCellCfg(&cellCfg, &etmPhyCfg);

   RETVALUE(ret);
}
/**
 * @brief ETM INIT handler 
 *
 * @details
 *
 *     Function : ysLMMEtminit
 *     
 *     This function in called by YsMiLysCfgReq(). It handles the  
 *     ETM initialisation. Returns
 *     reason for success/failure of this function.
 *     
 *  @param[in]  YsCfg *cfg, the Configuaration info 
 *  @return  U16
 *      -# LCM_REASON_NOT_APPL 
 *      -# LCM_REASON_INVALID_MSGTYPE
 *      -# LCM_REASON_MEM_NOAVAIL
 **/
PUBLIC U16 ysLMMEtminit 
(
YsCfg *cfg,            /* Configuaration info */
Pst   *pst             /* Post Structure */
)
{
   U16              ret = LCM_REASON_NOT_APPL;
   E_TM_CONFIG      etmInit;
   YsCellCb         *cellCb = NULLP;

   cellCb = (YsCellCb*)ysMsCfgGetCellCfg(cfg->s.etmCfg.cellId);
   if(cellCb == NULLP)
   {
      RLOG0(L_ERROR, DBG_CELLID,cfg->s.etmCfg.cellId,"cellCb is NULL");
      RETVALUE(RFAILED);
   }

   etmInit.model      = cfg->s.etmCfg.etmInit.tModel;
   etmInit.bw          = cfg->s.etmCfg.etmInit.bw;
   etmInit.e_rs        = cfg->s.etmCfg.etmInit.e_rs;
   etmInit.ant0        = cfg->s.etmCfg.etmInit.ant0;
   etmInit.ant1        = cfg->s.etmCfg.etmInit.ant1;
   etmInit.num_layers  = cfg->s.etmCfg.etmInit.num_layers;   
   etmInit.num_cw      = cfg->s.etmCfg.etmInit.num_cw;
   etmInit.tdd         = cfg->s.etmCfg.etmInit.tdd;

   RLOG1(L_DEBUG,"ETM_INIT: etmInit.model = %d ", etmInit.model );
   RLOG1(L_DEBUG,"ETM_INIT: etmInit.bw = %d ", etmInit.bw );
   RLOG1(L_DEBUG,"ETM_INIT: etmInit.e_rs = %d ", etmInit.e_rs );
   RLOG1(L_DEBUG,"ETM_INIT: etmInit.ant0 = %d ", etmInit.ant0 );
   RLOG1(L_DEBUG,"ETM_INIT: etmInit.ant1 = %d ", etmInit.ant1 );
   RLOG1(L_DEBUG,"ETM_INIT: etmInit.num_layers = %d ", etmInit.num_layers );
   RLOG1(L_DEBUG,"ETM_INIT: etmInit.num_cw = %d ", etmInit.num_cw );
   RLOG1(L_DEBUG,"ETM_INIT: etmInit.tdd = %d ", etmInit.tdd );

  /* Invoke  Interface API to initialise ETM */ 
   ret = etm_init(etmInit);
   if (ret == ROK)
   {
        cellCb->eTminit = TRUE; 
        RLOG0(L_INFO,"ysLMMEtminit(): ETM initialisation Done");
   }

   /* Prepare a vector and keep it ready */
   RLOG2(L_DEBUG,"etmInit: cellCb->timingInfo.sfn = %d, cellCb->timingInfo.subframe = %d", cellCb->timingInfo.sfn, cellCb->timingInfo.subframe );
   /* Always start with subframe and frame number as 0  */
   ret = etm_get_vectors(&pElemEtm, 0 /* cellCb->timingInfo.sfn*/, 0 /*cellCb->timingInfo.subframe*/);
   if (ROK != ret || NULLP == pElemEtm)
   { 
      RLOG0(L_DEBUG,"etm_get_vectors Failed!!!");
      pElemEtm = NULLP;
   }
   else
   { 
      RLOG0(L_DEBUG,"etm_init:etm_get_vectors: success:");
   } 
   RETVALUE(ret);
}

/***********************************************************
 *
 *     Func : ysLMMEtmCntrl 
 *        
 *
 *     Desc : Processes the LM control request for STxxxSAP elmnt.
 *            
 *
 *     Ret  : Void
 *
 *     Notes: 
 *
 *     File : ys_mi.c
 *
 **********************************************************/
PUBLIC Void ysLMMEtmCntrl 
(
YsMngmt       *cntrl,
YsMngmt       *cfm,
Pst           *cfmPst
)
{
   S16 ret;
   YsCellCb   *cellCb;
   TRC2(ysLMMEtmCntrl)

   RLOG1(L_INFO,"ysLMMEtmCntrl(): Control Req for ETM (%d)",
             cntrl->hdr.elmId.elmnt);
   /* Only TFU Sap can be controlled by LM */
   switch(cntrl->t.cntrl.action)
   {
      case AENA:
         cellCb = ysMsCfgGetCellCfg(cntrl->t.cntrl.s.cellId);
         if ( cellCb->isPhyStopped == TRUE )
         {
            ret = ysMsEtmPhyReConfig(cellCb);
         }
         else
         {
            ret = ysMsEtmPhyStart(cellCb); 
         }
        
         if ( ret != ROK ) 
         {
            cfm->cfm.status = LCM_PRIM_NOK;
            cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
         }
         else
         {
            cfm->cfm.status = LCM_PRIM_OK;
            cfm->cfm.reason = LCM_REASON_NOT_APPL;
         }
      break;
      case ADISIMM:
         cellCb = ysMsCfgGetCellCfg(cntrl->t.cntrl.s.cellId);
         ret = ysMsSmStRunEvtStop(cellCb, NULLP); 
         if ( ret != ROK ) 
         {
            cfm->cfm.status = LCM_PRIM_NOK;
            cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
         }
         else
         {
            cfm->cfm.status = LCM_PRIM_OK;
            cfm->cfm.reason = LCM_REASON_NOT_APPL;
            /* Stop the ETM also */
            cellCb->eTminit = FALSE; 
         }
         break;
      default:
         cfm->cfm.status = LCM_PRIM_NOK;
         cfm->cfm.reason = LCM_REASON_INVALID_PAR_VAL;
         RLOG1(L_WARNING, DBG_CELLID,cellCb->cellId,"invalid action=%d",cntrl->t.cntrl.action);
         break;
   }
   YsMiLysCntrlCfm(cfmPst, cfm);
   RETVOID;
}

/**
 * @brief API for handle cell configuration request from RRM
 *
 * @details
 *
 *     Function: ysMsAddEtmCellCfg
 *
 *     This API for handle cell configuration request from RRM
 *
 *  @param[in]
 *  @param[in]
 *  @return  S16
 *      -# ROK
 *      -# RFAILED
 **/
PRIVATE S16 ysMsAddEtmCellCfg
(
CtfCellCfgInfo *cellCfg,
YsMsCellCfg *etmPhyCfg
)
{
   S16       ret;
   YsCellCb  *cellCb;
   U16       idx;
   U16        offset;
   YsUeCb     ueCb;

   TRC2(ysMsAddEtmCellCfg)

   RLOG2(L_INFO,"ysMsAddEtmCellCfg(): cellId = %d physCellId = %d",
             cellCfg->cellId, cellCfg->physCellId);

   ret = ROK;
   cellCb    = NULLP;

   if(cellCfg->physCellId >= YS_NUM_PHY_CELLS)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCfg->physCellId,
            "Invalid phyCellId: ysMsAddEtmCellCfg failed");
      RETVALUE(RFAILED);
   }

   if(cellCfg->cellId >= (CM_START_CELL_ID + CM_LTE_MAX_CELLS))
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCfg->cellId,
            "Invalid cellId: ysMsAddEtmCellCfg failed");
      RETVALUE(RFAILED);
   }

   if((cellCb = ysMsCfgGetCellCfg(cellCfg->cellId)) != NULLP)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,cellCfg->cellId,"Cell Configuration exist ");
      RETVALUE(RFAILED);
   }

   if ((cellCb = (YsCellCb *)ysUtlMalloc(sizeof(YsCellCb), cellCfg->cellId - CM_START_CELL_ID)) == NULLP)
   {
      RLOG_ARG0(L_FATAL, DBG_CELLID,cellCfg->cellId,"ysAlloc failed ");
      RETVALUE(RFAILED);
   }
   idx = cellCfg->cellId - CM_START_CELL_ID;
   
   cmMemcpy((U8 *)&cellCb->cellCfg, (U8 *)cellCfg, sizeof(CtfCellCfgInfo));
   cellCb->cellId = cellCfg->cellId;
   cellCb->etmEnable  = TRUE;
   /* Fill Phy Cfg */
   cellCb->vendorParams.opMode = etmPhyCfg->opMode;
   cellCb->vendorParams.counter = etmPhyCfg->counter;
   cellCb->vendorParams.period = etmPhyCfg->period;

   /* 118146: Storing the cell Id in the globle cb */
   cellCb->phyState = LYS_PHY_STATE_IDLE;
   cellCb->gotRACH = 0;

   /* HARQ: Minor optimization to clean up the code */
   cellCb->cmnChScrInit = 3*cellCb->cellCfg.cellIdGrpId + 
   cellCb->cellCfg.physCellId;

   if (ysMsUlmPrcCellCfg(cellCb) != ROK)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,cellCb->cellId,"Procss CellCfg failed ");
      ysUtlDeAlloc((Data *)cellCb, sizeof(YsCellCb), idx);
      RETVALUE(RFAILED);
   }

   /* HARQ: Initializing the time here */
   cellCb->timingInfo.sfn = 1023;
   cellCb->timingInfo.subframe = 9;
#ifdef RG_ULSCHED_AT_CRC
   cellCb->crcSent[9] = 1;
#endif

   cellCb->cellId = cellCfg->cellId;
   ysCb.cellCfgLst[cellCb->cellId - CM_LTE_MAX_CELLS] = cellCb;

   if((cellCb = ysMsCfgGetCellCfg(cellCfg->cellId)) != NULLP)
   {
      uart_printf ("\n in ysMsAddEtmCellCfg still able to get cellId #1 \n");
   }

   ret = ysMsCfgSm(cellCb, YS_MS_EVENT_CFG, NULLP);
   if(ret != ROK)
   {
      RLOG0(L_ERROR, DBG_CELLID,cellCfg->cellId,"Config sm failed ");
      ysUtlDeAlloc((Data *)cellCb, sizeof(YsCellCb), idx);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);
}  /* ysMsAddEtmCellCfg*/

/*
*
*       Fun:    ysMsEtmPhyReConfig
*
*       Desc:   This function handles PHY configuration and reconfiguration 
*               
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_etm.c
*
*/

#define MY_1ENABLE_SVSR_API_LOGGER_DEF_MASK         ((1<<12)|(1<<17))

PRIVATE S16 ysMsEtmPhyReConfig
(
YsCellCb   *cellCb
)
{
   PGENMSGDESC  pMsgDesc;
   PINITPARM    msCfgReq;
   U32          l1Size;
   /* HARQ: PHY_API_CHANGE */
   PMAC2PHY_QUEUE_EL pElem;
   S16          ret;

   TRC3(ysMsEtmPhyReConfig);

   RLOG0(L_INFO,"Inside ysMsEtmPhyReConfig ");

#ifndef TENB_T2K3K_SPECIFIC_CHANGES
   SvsrLoggerSetMask(MY_1ENABLE_SVSR_API_LOGGER_DEF_MASK);
#endif

   l1Size = sizeof(GENMSGDESC) + sizeof(INITPARM);

#ifdef TL_ALLOC_ICC_MEM
      pMsgDesc = ysMsUtlAllocSvsrMsg(FALSE, l1Size);
#else
      pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg (FALSE);
#endif

   msCfgReq = (PINITPARM)(pMsgDesc + 1);
   cmMemset((U8 *)msCfgReq,(U8 )0,sizeof(INITPARM));
   pMsgDesc->msgType     = PHY_RECONFIG_REQ;
   pMsgDesc->phyEntityId = cellCb->phyInstId;
   pMsgDesc->msgSpecific = sizeof(INITPARM);

   ret = ysMsUtlFillCfgReq(msCfgReq, cellCb);

   /* PHY_API_CHANGE : Fill the linked list element */
#ifdef TL_ALLOC_ICC_MEM
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      /* HARQ_DBG */
      uart_printf("Memory Allocation failed for PHY list element for\
      PHY_RECONFIG_REQ at cellTime(%d,%d)\n",
      cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
      RETVALUE(RFAILED);
   }
/* Initialize timing info */
   cellCb->timingInfo.sfn = 1023;
   cellCb->timingInfo.subframe = 9;
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe,
          ysGetPhyPtr(pMsgDesc), l1Size, PHY_RECONFIG_REQ);
#else
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe,
         pMsgDesc, l1Size, PHY_RECONFIG_REQ);
#endif
   
/*   DiagDumpPhyApi((PTR)pMsgDesc);*/
#ifdef TL_ALLOC_ICC_MEM
   YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
  if(cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg >= MAX_NUM_L1_MESSAGES_PER_TTI)
  {
     stop_printf("NumL1Msg %d  greater than %d \n", cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg, 
                                                    MAX_NUM_L1_MESSAGES_PER_TTI);
  }  
#endif
   ysSendMsgToPhy(l1Size, pElem);
   RETVALUE(ret);
} /* ysMsEtmPhyReConfig */

/*
*
*       Fun:    ysMsEtmPhyStart
*
*       Desc:   This function handles the PHY_START Req from SM.
*               
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_etm.c
*
*/

PRIVATE S16 ysMsEtmPhyStart
(
YsCellCb   *cellCb
)
{
   S16         ret;
   PSTARTREQ   startReq;
   U32         l1Size;
   PGENMSGDESC pMsgDesc;
   /* PHY_API_CHANGE */
   PMAC2PHY_QUEUE_EL pElem;

   TRC3(ysMsEtmPhyStart);

   RLOG0(L_INFO,"Inside ysMsEtmPhyStart ");
   l1Size = sizeof(GENMSGDESC) + sizeof(STARTREQ);

   /* Allocate a message towards Phy using sysCore */
#ifdef TL_ALLOC_ICC_MEM
      pMsgDesc = ysMsUtlAllocSvsrMsg(FALSE, l1Size);
#else
   pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg (FALSE);
#endif
   if (pMsgDesc == NULLP)
   {
      RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId, "Unable to allocate memory for TxVector");
      MSPD_ERR("Unable to allocate memory for TxVector");
      RETVALUE (RFAILED);
   }

   startReq = (PSTARTREQ)(pMsgDesc );

   /* Filling the band ID for automating the ADI ID */
   RLOG1(L_DEBUG," cellCb->cellCfg.antennaCfg.antPortsCnt %d",
         cellCb->cellCfg.antennaCfg.antPortsCnt);

#ifndef TENB_T2K3K_SPECIFIC_CHANGES
   if (cellCb->vendorParams.opMode == 4)
   {
      U8 retVal = 1;

      if (cellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_2)
         retVal = Ad9361IRadioScheduleInit(cellCb->cellInfo.bandId,2,2,0,0,0) & 0xFF;
      else if (cellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_1)
         retVal = Ad9361IRadioScheduleInit(cellCb->cellInfo.bandId,1,1,0,0,0) & 0xFF;

      if (retVal)
      {
         RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "ADI Radio schedule init comand Failed ");
         RETVALUE(RFAILED);
      }
   }
#endif

   ret = ysMsUtlFillStartReq(startReq, cellCb);
   if (ret != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "Fill StartReq Failed ");
      RETVALUE(RFAILED);
   }

   /* PHY_API_CHANGE : Fill the linked list element */
#ifdef TL_ALLOC_ICC_MEM
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      /* HARQ_DBG */
      uart_printf("SvsrAllocMsg failed for PHY list element for \
            PHY_START_REQ at time(%d,%d)\n",
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
      RETVALUE(RFAILED);
   }
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe,
          ysGetPhyPtr(pMsgDesc), l1Size, PHY_START_REQ);
#else
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn,
         cellCb->timingInfo.subframe,
         pMsgDesc, l1Size, PHY_START_REQ);
#endif

   cellCb->phyState = LYS_PHY_STATE_CFG;

#ifdef TL_ALLOC_ICC_MEM
   YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
  if(cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg >= MAX_NUM_L1_MESSAGES_PER_TTI)
  {
     stop_printf("NumL1Msg %d  greater than %d \n", cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg, 
                                                    MAX_NUM_L1_MESSAGES_PER_TTI);
  }  
#endif
   ysSendMsgToPhy(l1Size, pElem);

   RETVALUE(ret);
} /* ysMsEtmPhyStart */

/*
*
*       Fun:   ysMsFillDummyVectors
*
*       Desc:  This primitive is used by CL to fill dummy ETM Vectors
*
*       Ret: Void
*
*       Notes: None
*
*       File:  ys_ms_li.c`
*
*/
PRIVATE Void ysMsFillDummyVectors
(
   MAC2PHY_QUEUE_EL **pElem,
   U16                frameNumber,
   U8                 subframeNumber
)
{   
    PGENMSGDESC buffer;
    U8* payload = NULLP; 
    DLSUBFRDESC *tmpDlSub;
    MAC2PHY_QUEUE_EL *tmpElem;
    U32 msgLen = 0;
    PMAC2PHY_QUEUE_EL pElemRx = NULL;
    PGENMSGDESC buffer_ul = NULL;
    ULSUBFRDESC *tmpUlSub = NULL;

    TRC2(ysMsFillDummyVectors)
    RLOG0(L_INFO,"ysMsFillDummyVectors() ");
    /* Dummy Tx */
    buffer = (PGENMSGDESC) SvsrAllocMsgEx(sizeof(DLSUBFRDESC)); 
    if (NULLP == buffer)
    {
       RLOG0(L_FATAL,"Svsr FAILED Invalid memory ...Exiting...");
       stop_printf("Svsr FAILED Invalid memory ...Exiting...\n");
       exit(-1);
    }
    buffer->phyEntityId = 0;
    buffer->msgType = PHY_TXSTART_REQ;
    /* Sending only the header */
    buffer->msgSpecific = (U32)&tmpDlSub->dlCh - (U32)tmpDlSub; 

    payload = (U8 *)(buffer + 1);
    tmpDlSub =  (DLSUBFRDESC *) payload;

    cmMemset((U8 *)tmpDlSub, 0, sizeof(DLSUBFRDESC));

    tmpDlSub->frameNumber = frameNumber;
    tmpDlSub->subframeNumber = subframeNumber;

    *pElem = (PMAC2PHY_QUEUE_EL )SvsrAllocMsgEx(sizeof(MAC2PHY_QUEUE_EL));
    if (NULLP == *pElem)
    {
       RLOG0(L_FATAL,"Svsr FAILED Invalid memory...Exiting...");
       stop_printf("SvsrAllocMsg FAILED Invalid memory...Exiting...\n");
       exit(-1);
    }

    pElemRx = (PMAC2PHY_QUEUE_EL )SvsrAllocMsgEx(sizeof(MAC2PHY_QUEUE_EL));
    if (NULLP == pElemRx)
    {
       RLOG0(L_FATAL,"Svsr FAILED Invalid memory...Exiting...");
       RLOG0(L_DEBUG,"Mem Allocation failed");
       exit(-1);
    }

    tmpElem = *pElem;
    tmpElem->frameNumber = frameNumber;
    tmpElem->subframeNumber = subframeNumber;
    tmpElem->MessageLen =  msgLen /* sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC)*/;
    tmpElem->Next = pElemRx;
    tmpElem->MessagePtr = (U8*)buffer;
    tmpElem->MessageType = PHY_TXSTART_REQ; 

    /* Dummy Rx */
    buffer_ul = (PGENMSGDESC) SvsrAllocMsgEx(sizeof(ULSUBFRDESC)); 
    if (NULLP == buffer)
    {
       RLOG0(L_FATAL,"Svsr FAILED Invalid memory...Exiting...");
       RLOG0(L_DEBUG,"Mem Allocation failed");
       exit(-1);
    }

    buffer_ul->phyEntityId = 0;
    buffer_ul->msgType = PHY_RXSTART_REQ;
    buffer_ul->msgSpecific = (U32)&tmpUlSub->ulCh - (U32)tmpUlSub;

    payload = (U8*) (buffer_ul + 1);

    tmpUlSub =  (ULSUBFRDESC *) payload;

    memset(tmpUlSub, 0, sizeof(ULSUBFRDESC));

    tmpUlSub->frameNumber = frameNumber;
    tmpUlSub->subframeNumber = subframeNumber;
    tmpUlSub->subframeType = 1/*ULRX*/;

    tmpElem = pElemRx;
    tmpElem->frameNumber = frameNumber;
    tmpElem->subframeNumber = subframeNumber;
    tmpElem->MessageLen =  msgLen; 
    tmpElem->Next = NULLP;
    tmpElem->MessagePtr = (U8*)buffer_ul;
    tmpElem->MessageType = PHY_RXSTART_REQ; 

    RETVOID;
}
/*
*
*       Fun:   ysMsSndEtmVectors
*
*       Desc:  This primitive is used by CL to send ETM Vectors to PHY
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_li.c`
*
*/
PRIVATE S16 ysMsSndEtmVectors 
(
   YsCellCb    *cellCb
)
{
   S16 ret = RFAILED; 
   U16 sfn = 0;                  /*!< System Frame Number */
   U8  subframe = 0;             /*!< Subframe number */

   TRC2(ysMsSndEtmVectors)
      
   RLOG0(L_INFO,"ysMsSndEtmVectors() ");
  
   if ( pElemEtm == NULLP  ) 
   {
     RLOG0(L_DEBUG,"Error: pElemEtm is NULL");
   }
   else
   {
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
      ret = SvsrSendMsg(0, IID_LTE_EX, pElemEtm, SVSR_MSG_OPT_DEFAULT);
#else
      ret = ysSendMsgToPhy(sizeof(GENMSGDESC), pElemEtm);
#endif
      if(ret != SUCCESS)
      {
         RLOG_ARG1(L_ERROR,DBG_CELLID,cellCb->cellId, "SvsrSendMsg returened error=%d ", ret);
         RLOG0(L_DEBUG,"SvsrSendMsg, Failed!!!!");
         RETVALUE(ROK);
      }
      else
      {
         RLOG0(L_INFO,"ysMsSndEtmVectors Success ");
      }
      subframe = (cellCb->timingInfo.subframe + 1) % YS_NUM_SUB_FRAMES;
      if (0 == subframe)
      {
         sfn = (cellCb->timingInfo.sfn + 1) % YS_NUM_SFN;
      }
      else
      {
        sfn = cellCb->timingInfo.sfn;
      }
      ret = etm_get_vectors(&pElemEtm, sfn, subframe);
      if (ROK != ret || NULLP == pElemEtm)
      { 
         RLOG0(L_DEBUG,"etm_get_vectors Failed!!!");
      }
      else
      { 
         RLOG0(L_DEBUG,"etm_get_vectors: sucess:");
      }    
   }
   RETVALUE(ret);
}/* end of ysMsSndEtmVectors */

/*
*
*       Fun:   ysMsLimEtmProcessMsg
*
*       Desc:  This primitive is used provide message to UL/DL modules
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_etm.c
*
*/
extern U32 noTti;
PUBLIC S16 ysMsLimEtmProcessMsg
(
Ptr   msg,
Bool  isfree,
Bool  isLstEnd
)
{
   S16         ret;
   YsCellCb    *cellCb;
   U8         rxEndOffset;
#ifdef YS_ALL_PERF
   Txt   _prntBuf[256];
#endif
#ifdef MSPD_MLOG_NEW
   U32  t1 = 0;
   U32  t2 = 0;
#endif
   YsUlL1Msg *ulRxSduInds = NULLP;
   Bool isFree = isfree;
#ifdef DLHQ_RTT_OPT
   Bool isUlCntrlLstEnd = FALSE;
   CmLteTimingInfo ulCntrlTiming;
#endif
   YsUstaDgn  dgn;
   U32 cause = LCM_CAUSE_UNKNOWN; 
   PGENMSGDESC    pMsgDesc;
   U8    msgType;
   U8   entityId;
#if 0 /* Added for Testing */
#ifdef E_TM
   E_TM_CONFIG      etmInit;
#endif /* E_TM */
#endif 

   /* crude workaround for now
    * when we receive the first MSGT_RESPONSE from the PHY we treat it like the
    * PHY_STOP_CONF and call ysMsLimEtmProcessMsg (all other MSGT_RESPONSE msgs
    * will not be passed to the LimProcessMsg) to go ahead in the state machine
    * successfully. There is a bug in the PHY, and it sends two MSGT_RESPONSE
    * messages, the first with success and the second with failure on receiving
    * the PHY_START_REQ msg. Fix will be done in the PHY and then this
    * workaround can be removed.
    */
   static int firstCall = TRUE;

   rxEndOffset = 2;

   TRC2(ysMsLimEtmProcessMsg)

      if(msg == NULLP)
      {
         RLOG_ARG0(L_ERROR, DBG_CELLID,entityId, "ysMsLimEtmProcessMsg(): Empty msg received ");
         MSPD_ERR("Empty msg received \n");
         RETVALUE(RFAILED);
      }
   ret = ROK;
   pMsgDesc = (PGENMSGDESC)msg;
   msgType = pMsgDesc->msgType; 
   entityId = pMsgDesc->phyEntityId;
   
   /* Get the cellCb */
   cellCb = (YsCellCb*)ysMsCfgGetCellCfg(entityId);
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   
   if(cellCb == NULLP)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,entityId, "cellCb is NULL");
      RETVALUE(RFAILED);
   }
   RLOG3(L_INFO,"ysMsLimEtmProcessMsg(): msgType=%d TTI (%d,%d)",
            msgType, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);

   switch(msgType)
   {
      case PHY_TXSTART_IND:
         {
            extern U32 robLogs[10];
            extern U32  startTti;
            extern U32 invaldl1Tti;
            static U32  prevTti = 0;
            PMSGIND  pMsgInd = (PMSGIND)msg;
            MSGIND   rxStartInd;
            /* HARQ: RxEndInd spoofing removed */
            MSGIND   rxEndInd;
            /* fetch the TTI generated time from the API
               as of now the last 4bytes in the PHY_TXSTART_IND */
            U32      l1Tti = *((U32 *)(pMsgInd + 1));
            U32      l2TtiStart;
            U8       lsf;
            double   driftDiff = 0;
            double   l2ProcTime = 0;
            double   l1Ttidiff = 0;
            Bool     isDummyTti = FALSE;
            CmLteTimingInfo  lastsf;

            /* Update the Delayed PHY TTI statistics */
            if (0 != startTti)
            {
               l1Ttidiff = YS_MS_TTI_DIFF(l1Tti, startTti);
               if ((l1Ttidiff < 0.9) || (l1Ttidiff > 1.1))
                  invaldl1Tti++;
            }

            startTti = l1Tti;
            l2TtiStart = GetTIMETICK();

            /* Time difference between the actual TTI generation at PHY and the
             *  TTI received time at CL */
            driftDiff = YS_MS_TTI_DIFF(l2TtiStart, l1Tti);

            /* collecting statistics  for L2 Processing time for each TTI*/
            {
               /* Time taken by L2 to process the previous TTI */
               l2ProcTime = YS_MS_TTI_DIFF(l2TtiStart, prevTti);
               if (l2ProcTime > 1)
                  if (l2ProcTime < 1.25)
                     robLogs[0]++;
                  else if (l2ProcTime < 1.5)
                     robLogs[1]++;
                  else if (l2ProcTime < 2)
                     robLogs[2]++;
                  else
                     robLogs[3]++;
               prevTti = l2TtiStart;
            }
            /* Cheking whether the TTI received is within the acceptable
             *  delay to start the processing at L2 so that it won't get stretched
             *  into next TTI. And this delay threshold is derived from the
             *  previous experiments */

            if (driftDiff > YS_TTI_START_MAX_DELAY)
            {
               RLOG3(L_DEBUG,"Marking as dummy TTI as it is picked late by (%f)ms."
                     " PrevSf cellTime(%d,%d)", driftDiff,
                     cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
               isDummyTti = TRUE;
               /* Updating Statistics */
               {
                  robLogs[4]++;
               }
            }
            else
            {
               isDummyTti = FALSE;
            }
#ifdef YS_ALL_PERF
            if (cellCb->capPerfData == TRUE)
            {
#if YS_PHY_STOP_AUTO
               cellCb->perfInfo[cellCb->ttiIndex].ttiStartTick = GetTIMETICK();
#else
               cellCb->perfInfo.ttiStartTick = GetTIMETICK();
#endif
            }

            if(cellCb->ttiIndex == 0)
               cellCb->perfInfo.ttiEndTick = cellCb->perfInfo.ttiStartTick;

            sprintf(_prntBuf, "%d\t%d\t%d\t%f\t%d",
                  cellCb->ttiIndex,cellCb->perfInfo.timingInfo.sfn, cellCb->perfInfo.timingInfo.subframe,
                  ((cellCb->perfInfo.ttiStartTick - cellCb->ttiPrevTick)/150000.0),
                  cellCb->perfInfo.avlMem);
            SPrint(_prntBuf);
#endif

            /* HARQ: RxEndInd spoofing removed */

            rxEndInd.subFrameNum = cellCb->timingInfo.subframe;
            rxEndInd.frameNumber = cellCb->timingInfo.sfn;

            lastsf.sfn = cellCb->timingInfo.sfn;
            lastsf.subframe = cellCb->timingInfo.subframe;
            /* HARQ: Increment the subframe number and sfn to mark new subframe */
            cellCb->timingInfo.subframe = (cellCb->timingInfo.subframe + 1) % YS_NUM_SUB_FRAMES;
            if (0 == cellCb->timingInfo.subframe)
            {
               cellCb->timingInfo.sfn = (cellCb->timingInfo.sfn + 1) % YS_NUM_SFN;
            }
            ysGT = cellCb->timingInfo.sfn * YS_NUM_SUB_FRAMES + cellCb->timingInfo.subframe;
            noTti++;
            RLOG4(L_INFO,"Received TxStart Indication cell Time (%d) (%d) TxStart Time (%d) (%d) ",
                     cellCb->timingInfo.sfn, cellCb->timingInfo.subframe, pMsgInd->frameNumber, pMsgInd->subFrameNum);
#if 0 /* Added for testing purpose */
            etmInit.model      = 1;
            etmInit.bw          = YS_BW_10_0_MHZ; 
            etmInit.e_rs        = 0;
            etmInit.ant0        = 1;
            etmInit.ant1        = 0;
            etmInit.num_layers  = 1;
            etmInit.num_cw      = 1;
            etmInit.tdd         = 0;
            ret = etm_init(etmInit);
            if (ret != ROK)
            {
               RLOG0(L_DEBUG,"etm_init FAILED");
            }
            else
            {
               RLOG0(L_DEBUG,"etm_init Successful");
               cellCb->eTminit = TRUE; 
            }

#endif /* if 1/0 */
            ret = ysMsSndEtmVectors(cellCb);
            if(ROK !=ret)
            {
               RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "Sending ETM Vectors Failed");
               break;
            }
            break;
         } 

      case PHY_INIT_IND:
         {
            PINITIND pInitInd = (PINITIND)msg;
            RLOG0(L_INFO,"Received Phy Init Indication ");
            if(pInitInd->status != SUCCESS)
            {
              RLOG0(L_DEBUG,"PHY_INIT FAILED!!!!!");
              cause = LCM_CAUSE_INV_PAR_VAL;
            }
            else
            {
              RLOG0(L_DEBUG,"PHY_INIT SUCCESS!!!!!");
            }
            /* Send Stauts indication to SM */
            cellCb->phyState = LYS_PHY_STATE_CFG;
            ysLMMStaInd(LCM_CATEGORY_INTERFACE,LYS_EVENT_ETM_CELLCFG,cause,&dgn, indx);
            break;
         }
      case PHY_START_CONF:
         {
            PINITIND pInitInd = (PINITIND)msg;
            RLOG0(L_INFO,"Received Phy Start Confirm");

            if(pInitInd->status != SUCCESS)
            {
               RLOG0(L_DEBUG,"PHY_START FAILED!!!!!");
               cause = LCM_CAUSE_INV_PAR_VAL;
            }
            else
            {
               RLOG0(L_DEBUG,"PHY_START SUCCESS!!!!!");
            }

            cellCb->phyState = LYS_PHY_STATE_RUN;
            cellCb->isPhyStopped = FALSE;
            ysLMMStaInd(LCM_CATEGORY_INTERFACE,LYS_EVENT_ETM_PHY_START,cause,&dgn, indx);
            break;
         }
      case PHY_STOP_IND:
         {
            RLOG0(L_DEBUG,"PST: Received Phy Stop Indication");
            break;
         }
      case PHY_RECONFIG_CNF:
         {
            PINITIND pInitInd = (PINITIND)msg;

            if(pInitInd->status != SUCCESS)
            {
               RLOG0(L_DEBUG,"PHY_RECONFIG FAILED!!!!!");
               cause = LCM_CAUSE_INV_PAR_VAL;
            }
            else
            {
               RLOG0(L_DEBUG,"PHY_RECONFIG SUCCESS!!!!!");
            }
            RLOG0(L_DEBUG,"PST: Received Phy RECONFIG CFM");

            ysMsEtmPhyStart(cellCb); 
            break;
         }

      case PHY_STOP_CONF:
         {
            PINITIND pInitInd = (PINITIND)msg;
            RLOG0(L_INFO,"Received Phy Stop Confirm");
            RLOG0(L_DEBUG,"PST: Received Phy Stop Confirm");
            if(pInitInd->status != SUCCESS)
            {
               RLOG0(L_DEBUG,"PHY_STOP FAILED!!!!!");
               cause = LCM_CAUSE_INV_PAR_VAL;
            }
            else
            {
               RLOG0(L_DEBUG,"PHY_STOP SUCCESS!!!!!");
            }
            cellCb->isPhyStopped = TRUE;
            /* Send Stauts indication to SM */
            ysLMMStaInd(LCM_CATEGORY_INTERFACE,LYS_EVENT_ETM_PHY_STOP,cause,&dgn, indx);
            cellCb->phyState = LYS_PHY_STATE_CFG;
            break;
         }
      case PHY_SHUTDOWN_CONF:
         {
            PINITIND pInitInd = (PINITIND)msg;
            RLOG0(L_INFO,"Received Phy Shutdown Confirm");
            RLOG0(L_DEBUG,"PST: Received Phy Shutdown Confirm");
            if(pInitInd->status != SUCCESS)
            {
               RLOG0(L_DEBUG,"PHY_SHUTDOWN FAILED!!!!!");
               cause = LCM_CAUSE_INV_PAR_VAL;
            }
            else
            {
               RLOG0(L_DEBUG,"PHY_SHUTDOWN SUCCESS!!!!!");
               STKLOG(STK_MD_YS,STK_LOG_INFO,"PHY_SHUTDOWN SUCCESS!!!!!\n");
            }
            cellCb->isPhyStopped = TRUE;
            /* Send Stauts indication to SM */
            ysLMMStaInd(LCM_CATEGORY_INTERFACE,LYS_EVENT_ETM_PHY_STOP,cause,&dgn, indx);
            cellCb->phyState = LYS_PHY_STATE_CFG;
            break;
         }
      default:
         RLOG1(L_WARNING,"ysMsLimEtmProcessMsg(): Invalid msg type %d", msgType);
         break;
   }

   if(ret != ROK)
   {
      if (isFree)
      {
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
         SvsrFreeIMem(msg);
#else
         ysFreePhyMsg(msg);
#endif
      }
      RLOG0(L_DEBUG,"ysMsLimEtmProcessMsg(): Failed to process message/NOT HANDLED!");
      RETVALUE(RFAILED);
   }
   if (isFree)
   {
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
      SvsrFreeIMem(msg);
#else
      ysFreePhyMsg(msg);
#endif
   }
   RETVALUE(ROK);
} /* end of ysMsLimEtmProcessMsg */

#endif /* E_TM */

/********************************************************************30**

         End of file:     yw_ms_etm.c@@/main/TeNB_Main_BR/6 - Thu Apr 24 17:06:45 2014

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      nu   1. initial release.
*********************************************************************91*/


/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/



/**********************************************************************

     Name:     LTE-SCL Layer

     Type:     C souce file

     Desc:     Phy UL Module. Configures and handles uplink.

     File:     ys_ms_ul.c

     Sid:      yw_ms_ul.c@@/main/TeNB_Main_BR/11 - Mon Aug 11 16:42:39 2014

     Prg:      mraj

**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_MODULE_ID=1;
static int RLOG_FILE_ID=235;

#include "stdlib.h"
/* Trillium Includes */
#include "envopt.h"        /* Environment options */
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#include "gen.h"           /* General */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common timer defines */
#include "cm_tkns.h"       /* Common tokens defines */
#include "cm_mblk.h"       /* Common memory allocation library defines */
#include "cm_llist.h"      /* Common link list defines  */
#include "cm_hash.h"       /* Common hashlist defines */
#include "cm_lte.h"        /* Common LTEE defines */
#include "ys_ms_err.h"        /* CL error header file */
#include "tfu.h"
#include "ctf.h"
#include "lys.h"
#include "ys_ms.h"

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "spaccdrv.h" /*sumanth*/
#endif
#endif

#include "gen.x"           /* General */
#include "ssi.x"           /* System services */

#include "cm5.x"           /* Common timer library */
#include "cm_tkns.x"       /* Common tokens */
#include "cm_mblk.x"       /* Common memory allocation */
#include "cm_llist.x"      /* Common link list */
#include "cm_hash.x"       /* Common hashlist */
#include "cm_lte.x"        /* Common LTE includes */
#include "cm_lib.x"
#include "tfu.x"
#include "ctf.x"
#include "lys.x"

/* Silicon Includes */
#ifdef INTEL_ALLOC_WLS_MEM
#include "wls_lib.h"
#endif
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "resultcodes.h"
#endif
#ifdef PHY_3_8_3
#ifdef XEON_SPECIFIC_CHANGES
#include "mlog_com.h"
#include "mlog.h"
#else
#include "tl_mlog.h"
#endif
#else
#include "mlog.h"
#endif

#include "ys_ms.x"
#include "tl_com.h"


#ifdef MSPD_TDD_DBG
EXTERN CmLteTimingInfo gCellTime;
#endif

#ifdef TFU_TDD
U8 mapTblFrmHarqToNumbrOfAcks[4] = {0, 3, 2, 1};
#endif
#ifdef CA_PHY
#ifdef TFU_TDD
EXTERN YsDlFdbkInfo ysDlFdbkForM234[3][4][2][2];
EXTERN YsDlFdbkInfo ysDlFdbkForM1[2][3][2][2];
EXTERN YsDlFdbkInfo ysDlHqFdbkOnPusch[2][2][2][2][2];
#endif
#ifdef DLHQ_STATS
U32 statsCntCl;
YsMsDlHqStats dlHqStatsCl[MAX_STATS_CNT] = {{0}};
#endif
#endif
int      delayedHarq =0;
/*ys004.102 :  Merged MSPD code with phy 1.7 */

EXTERN U16 g_MacRntiStart[2]; /*add by luopeng for ue stk log to web*/


PRIVATE S16 ysMsPrcUlSchSduInd ARGS((
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti	    rnti
));

PRIVATE S16 ysMsUpdCrcInd ARGS((
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		rnti
));
PRIVATE S16 ysMsPrcHarqInd ARGS((
YsCellCb        *cellCb,
CmLteTimingInfo *timingInfo,
U8              *hqBuf,
Bool            isPusch,
CmLteRnti       rnti,
U32             numHarqBits,
Bool isSplBundling
));

#ifdef TFU_UPGRADE
#if !defined(LTE_ADV) || !defined(TFU_TDD)
PRIVATE S16 ysMsPrcDlRiInd ARGS((
YsCellCb         *cellCb,
CmLteRnti        rnti,
CmLteTimingInfo  timingInfo,
U8               riByte
));
#endif
#endif

PRIVATE S16 ysMsPrcDlCqiInd ARGS((
YsCellCb         *cellCb,
CmLteRnti        rnti,
CmLteTimingInfo  timingInfo,
U8               numCqiBits,
U8               *cqiBits,
U8               *riPtr,
U8                cqiConfBitMask
));

#ifndef YS_MS_NO_ULCQI
PRIVATE S16 ysMsPrcUlCqiInd ARGS((
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		 rnti,
YsUeCb			*ueCb
));
#endif

PRIVATE S16 ysMsPrcSrInd ARGS((
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		 rnti
));


PRIVATE S16 ysMsPrcCqiPmiRiHqInd ARGS((
PRXSTATUSIND       pRxStatusInd,
YsCellCb            *cellCb
));

PRIVATE S16 ysMsPrcSrsInd ARGS((
PRXSTATUSIND       pRxStatusInd,
YsCellCb            *cellCb
));
#ifndef YS_MS_NO_TA
PRIVATE S16 ysMsPrcTmAdvInd ARGS((
PRXSDUIND       rxSduInd,
YsCellCb         *cellCb,
CmLteRnti		 rnti,
YsUeCb		    *ueCb
));
#endif


#ifdef TENB_AS_SECURITY
PUBLIC S16 ysMsKDF  (YsMsSecInfo *pSecInfo,  U8 *key);
#endif


PRIVATE S16 ysMsPrcPucchDeltaPwrInd ARGS((
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		 rnti,
YsUeCb          *ue
));

#ifndef TENB_RTLIN_CHANGES
extern S16 DiagDumpPhyApi(PTR vector);
#endif

U32     delayedApiCnt = 0;
static    U32     ysOneRachCompleted = 0;
#ifdef HARQ_STATISTICS
extern U32 totl_ulTbs;
extern U32 ulAcks;
extern U32 ulNacks;
extern U32 dlNacks;
extern U32 dlAcks;
#endif
extern U32 ulCqiRptCnt[16];
extern U32 dlCqiRptCnt[16];
extern U32 totDlCqiRpt;
extern U32 totUlCqiRpt;

extern U8  gRgFapiWiresharkEnable; /*add by luopeng for phy-l2 api send to wireshark 20171204*/


#ifdef CRAN_DEBUG_PRINT
U32 ulUespertti[18] = {0};
U32 ttiCount = 0;
#endif


#ifdef RSYS_WIRESHARK
#define YS_LCID_MASK 0x1F
#define YS_LCID_LEN 0x5
#define YS_F_BIT_MASK 0x80
#define YS_MIN_MAC_CE_LCID 0x19 /* LCID for MAC Control element(activation/deactivation) */
#define YS_MAC_CE_PADDING_LCID 0x1F/* LCID for Padding sub header */

#define YS_EXT_LCID(_lcId, _byte) {\
   (_lcId) = (_byte) & YS_LCID_MASK; \
}

#define YS_EXT_EXTN_BIT(_extnBit, _byte) {\
   (_extnBit) = ((_byte) >> YS_LCID_LEN) & 0x01; \
}

#define YS_EXT_F_BIT(_fBit, _byte) {\
   (_fBit) = (_byte) & YS_F_BIT_MASK;\
}

/*PRIVATE Void ysSendMsgToWireShark(Buffer *srcBuf,U16 rnti,U16 subFrame);*/
PUBLIC Bool ysCheckSrbOrCcch(Buffer *mBuf);
PRIVATE Bool ysValidateLcid(U32 lcId);
#endif
/****************ULM Modules ********************************/

/*********       Utility Functions **************************/


#ifndef TFU_UPGRADE
/*
*
*       Fun:   ysMsUlmDelSchLst
*
*       Desc:  Delete Scheduling Info
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsUlmDelSchLst
(
U16             period,
U16             offset,
U16             max,
CmLListCp       *lCp,
YsUeCb          *ueCb
)
{
   U16         tmpPeriod;
   CmLListCp  *tmpCp;
   CmLList    *cmLstEnt;

   tmpPeriod = period - 1;
   tmpPeriod = offset;
      RLOG_NULL(L_UNUSED,"CL delete UE:offset %d ", offset);
   do
   {
      tmpCp    = &lCp[tmpPeriod];
      cmLstEnt = tmpCp->first;

      while (cmLstEnt)
      {
         if (((YsUeCb*)(cmLstEnt->node))->ueId == ueCb->ueId)
         {
            cmLListDelFrm(tmpCp, cmLstEnt);
            ysUtlDeAlloc((Data*) cmLstEnt, sizeof(CmLList), 0);
            break;
         }
         else
         {
            cmLstEnt = cmLstEnt->next;
         }
      }
      tmpPeriod += period;
   }while (tmpPeriod<max);

   RETVALUE (ROK);
} /* End of ysMsUlmDelSchLst */

/*
*
*       Fun:   ysMsUlmSetSchLst
*
*       Desc:  Set Scheduling Info
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsUlmSetSchLst
(
U16             period,
U16             offset,
U16             max,
CmLListCp       *lCp,
YsUeCb          *ueCb,
U16             index
)
{
   U16              tmpPeriod;
   CmLListCp       *tmpCp;
   CmLList         *cmListEnt;

   tmpPeriod = offset;
   do
   {
      tmpCp = &lCp[tmpPeriod];

      /* Allocate Mem for list entity */
      cmListEnt = (CmLList*)ysUtlMalloc(sizeof(CmLList), index);
      if (!cmListEnt)
      {
         RLOG_ARG0(L_ERROR,DBG_CRNTI,ueCb->ueId,"ysUtlMalloc(): Failed Allocation");
         RETVALUE (RFAILED);
      }

      /* Save UE Control Block */
      cmListEnt->node = (PTR)ueCb;

      /* Adding List Element */
      cmLListAdd2Tail(tmpCp, cmListEnt);

      /* Moving to Next Element */
      tmpPeriod += period;

   }while (tmpPeriod<max);

   RETVALUE (ROK);
} /* End of ysMsUlmSetSchLst */

/*
*
*       Fun:   ysMsUlmPrcUeCfg
*
*       Desc:  Process Scheduling Info
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmPrcUeCfg
(
YsCellCb        *cellCb,
YsUeCb          *ueCb
)
{
   CtfDedCfgInfo   *ueDedCfg;
   CtfCqiRptModePeriodic   *periodicCqi;
   CtfDedSrsUlCfgInfo      *srsCfgInfo;
   CtfDedSRCfgInfo         *srCfgInfo;

   ueDedCfg = &ueCb->ueCfg;
   RLOG_NULL(L_UNUSED,"In ysMsUlmPrcUeCfg, ueId= %d",ueCb->ueId);
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   
   /* Cqi Configuration */
   if (ueDedCfg->cqiRptCfg.pres)
   {
      if (CTF_CQI_RPTMODE_PRDIOC == ueDedCfg->cqiRptCfg.reportingMode)
      {
         periodicCqi = &(ueDedCfg->cqiRptCfg.reportMode.periodicRpt);
         if (periodicCqi->cqiPeriodicCfgType == CTF_IE_CFG_SETUP)
         {
            ueCb->cqiCfgInfo = &ysCqiPmiCfgDb[periodicCqi->cqiSetup.cqiPmiCfgIndx];
            ysMsUlmSetSchLst(ueCb->cqiCfgInfo->cqiPeriod,
                  ueCb->cqiCfgInfo->cqiSfOffSet, YS_CQI_PERIOD_160,
                  cellCb->cqiPeriodList, ueCb, indx);
         }
      }
   }

   /* SRS Configuration */
   if (ueDedCfg->srsUlCfg.pres)
   {
      srsCfgInfo = &ueDedCfg->srsUlCfg;
      if (CTF_CONFIG == srsCfgInfo->dedSrsUlCfgType)
      {
         ueCb->srsCfgInfo = &ysSrsCfgDb[srsCfgInfo->dedSrsSetup.srsCfgIdx];
         ysMsUlmSetSchLst(ueCb->srsCfgInfo->srsPeriod,
               ueCb->srsCfgInfo->srsSfOffSet, YS_SRS_PERIOD_320,
               cellCb->srsPeriodList, ueCb, indx);
      }
   }

   /* SR Configuration */
   if (ueDedCfg->dedSRCfg.pres)
   {
      srCfgInfo = &ueDedCfg->dedSRCfg;
      if (CTF_CONFIG == srCfgInfo->dedSRCfgType)
      {
         ueCb->srCfgInfo = &ysSrCfgDb[srCfgInfo->dedSrSetup.srCfgIdx];
         ysMsUlmSetSchLst(ueCb->srCfgInfo->srPeriod,
               ueCb->srCfgInfo->srSfOffSet, YS_SR_PERIOD_80,
               cellCb->srPeriodList, ueCb, indx);
         RLOG_ARG3(L_ERROR,DBG_CRNTI,ueCb->ueId,"SR configuration: idx %d, period %d, offset %d",
            srCfgInfo->dedSrSetup.srCfgIdx,ueCb->srCfgInfo->srPeriod,
            ueCb->srCfgInfo->srSfOffSet);
      }
   }

   ueCb->timingAdvErrInfo.mSetDefaults = 1;

   RETVALUE (ROK);

} /* End of ysMsUlmPrcUeCfg */

/*
*
*       Fun:   ysMsUlmPrcDelUeCfg
*
*       Desc:  Delete UE Configuration
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmPrcDelUeCfg
(
YsCellCb        *cellCb,
YsUeCb          *ueCb
)
{
   CtfDedCfgInfo           *ueDedCfg;

   ueDedCfg = &ueCb->ueCfg;

   /* Removing UE Cqi Information */
   if (ueDedCfg->cqiRptCfg.pres)
   {
      ysMsUlmDelSchLst(ueCb->cqiCfgInfo->cqiPeriod,
            ueCb->cqiCfgInfo->cqiSfOffSet, YS_CQI_PERIOD_160,
                                     cellCb->cqiPeriodList, ueCb);
   }

   /* Removing UE SRS Information */
   if (ueDedCfg->srsUlCfg.pres)
   {
      ysMsUlmDelSchLst(ueCb->srsCfgInfo->srsPeriod,
            ueCb->srsCfgInfo->srsSfOffSet, YS_SRS_PERIOD_320,
                            cellCb->srsPeriodList, ueCb);
   }

   /* Removing UE SR Information */
   if (ueDedCfg->dedSRCfg.pres)
   {
      ysMsUlmDelSchLst(ueCb->srCfgInfo->srPeriod, ueCb->srCfgInfo->srSfOffSet, YS_SR_PERIOD_80,
            cellCb->srPeriodList, ueCb);
   }

   RETVALUE(ROK);

} /* End of ysMsUlmPrcDelUeCfg */

#endif /* TFU_UPGRADE */

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
PUBLIC S16 YsMsUlmPrcKenbStarCfg
(
CtfKenbStarInfo*       kenbInf,
CtfKenbStarCfmInfo       *kdfCfm
)
{

   S16       ret;
   YsMsSecInfo  *pSecInfo;
   U8 i;


   TRC2(YsMsUlmPrcKenbCfg)
   ret = ROK;

   YS_MS_ALLOC(pSecInfo , sizeof(YsMsSecInfo));
   if(pSecInfo == NULLP)
   {
      RLOG0(L_DEBUG,"YsMsUlmPrcKenbStarCfg failed");
     RETVALUE(RFAILED); /* KW_FIXX */
   }


   cmMemcpy(pSecInfo->hash_key,kenbInf->secKey,CTF_SEC_KEY_LEN);

   /* Building the String S = FC || P0 || L0 || P1 || L1 */

   /*Values are initialized as per section A7 33.401*/
   pSecInfo->strS[0] = 0x13;  pSecInfo->strS[3] = 0x00; pSecInfo->strS[4] = 0x02;
   pSecInfo->strS[7] = 0x00; pSecInfo->strS[8] = 0x02;


   RLOG2(L_DEBUG,"Value of Cellid, dl Freq is %d %d ", kenbInf->physCellId, kenbInf->dlCarrFreq);
   /*******************************************
    *************kENB* from kENB*************
    *******************************************/

   /*PCI*/
   pSecInfo->strS[1] = kenbInf->physCellId >> 8;
   pSecInfo->strS[2] = (U8)kenbInf->physCellId;

   /*DL frequency*/
   pSecInfo->strS[5] = kenbInf->dlCarrFreq >> 8;
   pSecInfo->strS[6] = (U8)kenbInf->dlCarrFreq;

   pSecInfo->strSlen = 9;

   /*RLOG3(L_DEBUG,"FREQ %d PCI %d length %d", kenbInf->dlCarrFreq, kenbInf->physCellId, strlen(pSecInfo->strS));

   RLOG0(L_DEBUG,"&&&&&&&&&&&&&&&&&STRING &&&&&&&&&&&&&&&&&&&&&&&");
   for(i=0;i<9;i++)
   RLOG1(L_DEBUG,"%x ", pSecInfo->strS[i]);*/

   ret = ysMsKDF(pSecInfo, kdfCfm->secKey);
   if(ret!=ROK)
   {
     RLOG0(L_ERROR, "ysMsKDF failed");
     RETVALUE(RFAILED);
   }/*End of if(ret!=ROK)*/


   YS_MS_FREE(pSecInfo, sizeof(YsMsSecInfo));


   RETVALUE(ROK);
}/*End of function*/


PUBLIC S16 YsMsUlmPrcKenbCfg
(
CtfAsKeyInfo*       kenbInf,
CtfAskeyCfmInfo       *kdfCfm
)
{

   S16       ret;
   YsMsSecInfo  *pSecInfo;


   TRC2(YsMsUlmPrcKenbCfg)
   ret = ROK;

   YS_MS_ALLOC(pSecInfo , sizeof(YsMsSecInfo));
   if(pSecInfo == NULLP)
   {
      RLOG0(L_DEBUG,"YsMsUlmPrcKenbCfg failed");
     RETVALUE(RFAILED); /* KW_FIXX */
   }


   cmMemcpy(pSecInfo->hash_key,kenbInf->secKey,CTF_SEC_KEY_LEN);

   /* Building the String S = FC || P0 || L0 || P1 || L1 */

   /*Values are initialized as per section A7 33.401*/
   pSecInfo->strS[0] = 0x15;  pSecInfo->strS[2] = 0x00; pSecInfo->strS[3] = 0x01;
   pSecInfo->strS[5] = 0x00; pSecInfo->strS[6] = 0x01;

   pSecInfo->strSlen = 7;

   /*******************************************
    *************CP Ciphering key*************
    *******************************************/
   pSecInfo->strS[1] = 0x3;
   pSecInfo->strS[4] = kenbInf->ciphAlgoType;

   ret = ysMsKDF(pSecInfo, kdfCfm->cpCiphKey);
   if(ret!=ROK)
   {
     RLOG0(L_ERROR, "ysMsSpaccClose failed");
     RETVALUE(RFAILED);
   }/*End of if(ret!=ROK)*/
   RLOG0(L_DEBUG,"UDAY: Ciphering Key Derived");



   /*******************************************
    *************UP Ciphering key*************
    *******************************************/
   pSecInfo->strS[1] = 0x5;
   pSecInfo->strS[4] = kenbInf->ciphAlgoType;

   ret = ysMsKDF(pSecInfo, kdfCfm->upCiphKey);
   if(ret!=ROK)
   {
     RLOG0(L_ERROR, "ysMsSpaccClose failed");
     RETVALUE(RFAILED);
   }/*End of if(ret!=ROK)*/

   RLOG0(L_DEBUG,"UDAY: Ciphering Key (UP) Derived");

   /*******************************************
    ************RRC Integrity key*************
    *******************************************/
   pSecInfo->strS[1] = 0x4;
   pSecInfo->strS[4] = kenbInf->intgAlgoType;

   ret = ysMsKDF(pSecInfo, kdfCfm->intKey);
   if(ret!=ROK)
   {
     RLOG0(L_ERROR, "ysMsSpaccClose failed");
     RETVALUE(RFAILED);
   }/*End of if(ret!=ROK)*/

   RLOG0(L_DEBUG,"UDAY: Integrity Key Derived");



   YS_MS_FREE(pSecInfo, sizeof(YsMsSecInfo));


   RETVALUE(ROK);
}/*End of function*/
#endif /* TENB_T2K3K_SPECIFIC_CHANGES */
#endif

/*
*       Fun:   ysMsSetupUlCqiInfo
*
*       Desc:
*
*       Ret:   Void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*/
PUBLIC void ysMsSetupUlCqiInfo
(
U8		  *sinrToCqi
)
{
   U32       sinr;
   U8        mcs;
   U8        sinrToMcs[256];
   U8        mcsToCqi[29];

   /*
    * SINR Index  Mcs Index
    * [0:101]     0           < 10% throughput
    * [102:103]   0           10% throughput
    * [104:105]   0           ...
    * [106:107]   0
    * [108:109]   0
    * [110:111]   0
    * [112:113]   0
    * [114:115]   0
    * [116:117]   0
    * [118:119]   0
    * [120:121]   0
    * [122:131]   1
    * [132:133]   2
    * [134:135]   3
    * [136:137]   4
    * [138:139]   5
    * [140:141]   6
    * [142:143]   7
    * [144:145]   8
    * [146:147]   9
    * 148         10
    * 149         11
    * 150         12
    * 151         13
    * 152         14
    * 153         15
    * 154         16
    * 155         17
    * 156         18
    * 157         19
    * 158         20
    * [159:162]   21
    * [163:166]   22
    * [167:170]   23
    * [171:174]   24
    * [175:178]   25
    * [179:182]   26
    * [183:186]   27
    * [187:190]   28
    * [191:255]   28
    */
   /* Based on above, fill SINR to MCS mapping */
   sinr = 0;
   /* if (sinr <= 101) cqi may be considered 0 */
   for (; sinr <= 121; ++sinr)
      sinrToMcs[sinr] = 0;
   for (; sinr <= 131; ++sinr)
      sinrToMcs[sinr] = 1;
   for (; sinr <= 133; ++sinr)
      sinrToMcs[sinr] = 2;
   for (; sinr <= 135; ++sinr)
      sinrToMcs[sinr] = 3;
   for (; sinr <= 137; ++sinr)
      sinrToMcs[sinr] = 4;
   for (; sinr <= 139; ++sinr)
      sinrToMcs[sinr] = 5;
   for (; sinr <= 141; ++sinr)
      sinrToMcs[sinr] = 6;
   for (; sinr <= 143; ++sinr)
      sinrToMcs[sinr] = 7;
   for (; sinr <= 145; ++sinr)
      sinrToMcs[sinr] = 8;
   for (; sinr <= 147; ++sinr)
      sinrToMcs[sinr] = 9;
   for (; sinr <= 148; ++sinr)
      sinrToMcs[sinr] = 10;
   for (; sinr <= 149; ++sinr)
      sinrToMcs[sinr] = 11;
   for (; sinr <= 150; ++sinr)
      sinrToMcs[sinr] = 12;
   for (; sinr <= 151; ++sinr)
      sinrToMcs[sinr] = 13;
   for (; sinr <= 152; ++sinr)
      sinrToMcs[sinr] = 14;
   for (; sinr <= 153; ++sinr)
      sinrToMcs[sinr] = 15;
   for (; sinr <= 154; ++sinr)
      sinrToMcs[sinr] = 16;
   for (; sinr <= 155; ++sinr)
      sinrToMcs[sinr] = 17;
   for (; sinr <= 156; ++sinr)
      sinrToMcs[sinr] = 18;
   for (; sinr <= 157; ++sinr)
      sinrToMcs[sinr] = 19;
   for (; sinr <= 158; ++sinr)
      sinrToMcs[sinr] = 20;
   for (; sinr <= 162; ++sinr)
      sinrToMcs[sinr] = 21;
   for (; sinr <= 166; ++sinr)
      sinrToMcs[sinr] = 22;
   for (; sinr <= 170; ++sinr)
      sinrToMcs[sinr] = 23;
   for (; sinr <= 174; ++sinr)
      sinrToMcs[sinr] = 24;
   for (; sinr <= 178; ++sinr)
      sinrToMcs[sinr] = 25;
   for (; sinr <= 182; ++sinr)
      sinrToMcs[sinr] = 26;
   for (; sinr <= 186; ++sinr)
      sinrToMcs[sinr] = 27;
   for (; sinr <= 254; ++sinr)
      sinrToMcs[sinr] = 28;
   sinrToMcs[sinr] = 28;

   /*
    * In MAC, for normal cyclic prefix, this is what we have
    * cqi=0  -> iTbs=0  -> iMcs=0
    * cqi=1  -> iTbs=0  -> iMcs=0
    * cqi=2  -> iTbs=0  -> iMcs=0
    * cqi=3  -> iTbs=2  -> iMcs=2
    * cqi=4  -> iTbs=4  -> iMcs=4
    * cqi=5  -> iTbs=6  -> iMcs=6
    * cqi=6  -> iTbs=8  -> iMcs=8
    * cqi=7  -> iTbs=10 -> iMcs=10
    * cqi=8  -> iTbs=12 -> iMcs=13
    * cqi=9  -> iTbs=15 -> iMcs=16
    * cqi=10 -> iTbs=16 -> iMcs=17
    * cqi=11 -> iTbs=19 -> iMcs=20
    * cqi=12 -> iTbs=21 -> iMcs=23
    * cqi=13 -> iTbs=23 -> iMcs=25
    * cqi=14 -> iTbs=25 -> iMcs=27
    * cqi=15 -> iTbs=26 -> iMcs=28
    */
   /* Based on above, fill mcs to cqi mapping */
   mcs = 0;
   mcsToCqi[mcs++] = 0;
   mcsToCqi[mcs++] = 0;
   mcsToCqi[mcs++] = 3; mcsToCqi[mcs++] = 3;
   mcsToCqi[mcs++] = 4; mcsToCqi[mcs++] = 4;
   mcsToCqi[mcs++] = 5; mcsToCqi[mcs++] = 5;
   mcsToCqi[mcs++] = 6; mcsToCqi[mcs++] = 6;
   mcsToCqi[mcs++] = 7; mcsToCqi[mcs++] = 7; mcsToCqi[mcs++] = 7;
   mcsToCqi[mcs++] = 8; mcsToCqi[mcs++] = 8; mcsToCqi[mcs++] = 8;
   mcsToCqi[mcs++] = 9;
   mcsToCqi[mcs++] = 10; mcsToCqi[mcs++] = 10; mcsToCqi[mcs++] = 10; mcsToCqi[mcs++] = 10;
   mcsToCqi[mcs++] = 11; mcsToCqi[mcs++] = 11; /* lichangwu 2017-10-31 a question here! */
   mcsToCqi[mcs++] = 12; mcsToCqi[mcs++] = 12;
   mcsToCqi[mcs++] = 13; mcsToCqi[mcs++] = 13;
   mcsToCqi[mcs++] = 14;
   mcsToCqi[mcs++] = 15;

   for (sinr = 0; sinr < 256; ++sinr)
      sinrToCqi[sinr] = mcsToCqi[sinrToMcs[sinr]];
}


/*
*
*       Fun:   ysMsUlmPrcCellCfg
*
*       Desc:  Process Cell Configuration
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmPrcCellCfg
(
YsCellCb        *cellCb
)
{
#ifndef TFU_UPGRADE
   U16                                idx;
#endif
   CtfPrachCfgInfo                   *prachCfg;
#ifndef TFU_TDD
   YsPrachFddCfgInfo                 *ysPrachInfo;
   U16                                subloop;
#else
   YsPrachTddMapInfo                 *tddMapInfo;
#endif
   YsPrachCb                         *rachCb;
   U16                                i;
   CtfPucchCfgInfo                   *pucchCfgInfo;
   CtfSrsUlCfgInfo                   *srsUlCfg;
   CtfPuschCfgInfo                   *puschCfg;
   CtfPuschCfgBasic                  *puschCfgBasic;
   CtfPuschUlRS                      *puschUlRs;

   /* L1 */
   RACHCTRL                          *rachCtl;
   ULSUBFRCMNCTRL                    *ulSubFrCmnCtrl;


#ifndef TFU_UPGRADE
   /* Initialize the Periodic Scheduling Lists */
   for (idx=0; idx<YS_SRS_PERIOD_320; idx++)
   {
      cmLListInit(&(cellCb->srsPeriodList[idx]));
   }
   for (idx=0; idx<YS_CQI_PERIOD_160; idx++)
   {
      cmLListInit(&(cellCb->cqiPeriodList[idx]));
   }
   for (idx=0; idx<YS_SR_PERIOD_80; idx++)
   {
      cmLListInit(&(cellCb->srPeriodList[idx]));
   }
#endif /* TFU_UPGRADE */

   /* Initialize RACH Scheduling */
   prachCfg            = &cellCb->cellCfg.prachCfg;
#ifndef TFU_TDD
   ysPrachInfo         = &ysPrachFddCfgDb[prachCfg->prachCfgIndex];
   rachCb             = &cellCb->prachCb;
   rachCb->rachCfgInfo = ysPrachInfo;
   rachCb->ysPrachPres = 0x00;

   /* ODD frames not support for FDD */
   RLOG2(L_DEBUG,"prachCfg->prachCfgIndex:%d, numSf:%d ",  prachCfg->prachCfgIndex, ysPrachInfo->numSf);
      for(subloop=0; subloop<ysPrachInfo->numSf; subloop++)
      {
         RLOG1(L_DEBUG,"ysPrachInfo->sf[subloop]:%d", ysPrachInfo->sf[subloop]);
         rachCb->ysPrachPres |= 0x01<<ysPrachInfo->sf[subloop];
      }
      RLOG1(L_DEBUG,"rachCb->ysPrachPres:%lu",rachCb->ysPrachPres );
#else
   rachCb             = &cellCb->prachCb;
   U16       idx;
   for (idx = 0; idx < YS_NUM_PRACH_PRES_ARR; idx++)
   {
      /* intializing the array */
      rachCb->ysPrachPresArr[idx] = YS_PRACH_NOT_PRSNT;
   }

   rachCb->rachCfgInfo = &ysPrachTddCfgDb[prachCfg->prachCfgIndex];
   rachCb->rachMapInfo = &ysPrachTddMapLstDb[prachCfg->prachCfgIndex]
                             [cellCb->cellCfg.tddSfCfg.sfAssignment];

   for(idx = 0; idx < rachCb->rachMapInfo->numCfg; idx++)
   {
      tddMapInfo = &rachCb->rachMapInfo->prachTddMapLst[idx];

      switch(tddMapInfo->t0RA)
      {
         case YS_ALL_SFN:
            if(tddMapInfo->fRA == YS_FREQ_RES_IDX_0)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                                                YS_PRACH_FREQ_IDX_0;
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                           tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_0;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_1)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                                                YS_PRACH_FREQ_IDX_1;
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                           tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_1;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_2)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                                                YS_PRACH_FREQ_IDX_2;
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                           tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_2;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_3)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                  YS_PRACH_FREQ_IDX_3;
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                  tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_3;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_4)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                  YS_PRACH_FREQ_IDX_4;
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                  tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_4;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_5)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                  YS_PRACH_FREQ_IDX_5;
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                  tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_5;
            }
            break;

         case YS_EVEN_SFN:
            if(tddMapInfo->fRA == YS_FREQ_RES_IDX_0)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                                                YS_PRACH_FREQ_IDX_0;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_1)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                                                YS_PRACH_FREQ_IDX_1;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_2)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                                                YS_PRACH_FREQ_IDX_2;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_3)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                                                YS_PRACH_FREQ_IDX_3;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_4)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                                                YS_PRACH_FREQ_IDX_4;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_5)
            {
               rachCb->ysPrachPresArr[tddMapInfo->sfNo] |= 
                                                YS_PRACH_FREQ_IDX_5;
            }
            break;

         case YS_ODD_SFN:
            if(tddMapInfo->fRA == YS_FREQ_RES_IDX_0)
            {
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                           tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_0;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_1)
            {
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                           tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_1;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_2)
            {
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                           tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_2;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_3)
            {
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                           tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_3;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_4)
            {
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                           tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_4;
            }
            else if(tddMapInfo->fRA == YS_FREQ_RES_IDX_5)
            {
               rachCb->ysPrachPresArr[YS_ODD_SF_OFFSET + 
                           tddMapInfo->sfNo] |= YS_PRACH_FREQ_IDX_5;
            }

            break;

         default:
            /* Never fall here */
            RLOG1(L_WARNING,"ysCtfPrachTddCfg(): Invalid t0RA = %d", 
                                                tddMapInfo->t0RA);
            break;
      }

   }
#endif
   /* Rach Predefine Control Information */
   rachCtl    = &cellCb->preDefVal.rachCtrl;
   if ((rachCtl->prachEnable = cellCb->cellCfg.prachCfg.pres) != 0)
   {
      prachCfg = &cellCb->cellCfg.prachCfg;
      rachCtl->rootSequenceIndex         = prachCfg->rootSequenceIndex;
      rachCtl->prachConfigIndex          = prachCfg->prachCfgIndex;

      rachCtl->highSpeedFlag             = prachCfg->highSpeedFlag;
      rachCtl->zeroCorrelationZoneConfig = prachCfg->zeroCorrelationZoneCfg;
      rachCtl->prachFreqOffset           = prachCfg->prachFreqOffset;
      RLOG_ARG5(L_ALWAYS,DBG_CELLID,cellCb->cellId,"rootSeqIndex %d , PrachConfigIndex %d highSpeedFlag %d , zeroCorr %d , PrachFreqOffset %d",
         rachCtl->rootSequenceIndex,
         rachCtl->prachConfigIndex,
         rachCtl->highSpeedFlag,
         rachCtl->zeroCorrelationZoneConfig, 
         rachCtl->prachFreqOffset);
   }
   else
   {
      RLOG_ARG5(L_ALWAYS,DBG_CELLID,cellCb->cellId,"prachEnable 0, rootSeqIndex %d , PrachConfigIndex %d highSpeedFlag %d , zeroCorr %d , PrachFreqOffset %d",
            rachCtl->rootSequenceIndex,
            rachCtl->prachConfigIndex,
            rachCtl->highSpeedFlag,
            rachCtl->zeroCorrelationZoneConfig, 
            rachCtl->prachFreqOffset);
   }
   /* SubFrame Common Control Structure */
   ulSubFrCmnCtrl    = &(cellCb->preDefVal.ulSubFrCmnCtrl);
   if (cellCb->cellCfg.pucchCfg.pres)
   {
      pucchCfgInfo    = &cellCb->cellCfg.pucchCfg;
      ulSubFrCmnCtrl->deltaPUCCHShift         = pucchCfgInfo->deltaShift+1;
      ulSubFrCmnCtrl->nRBCQI                  = pucchCfgInfo->nRB;
      ulSubFrCmnCtrl->nCSAn                   = pucchCfgInfo->nCS;
      ulSubFrCmnCtrl->n1PucchAN               = pucchCfgInfo->n1PUCCH;
#ifndef TFU_TDD
//      ulSubFrCmnCtrl->pad                     = PAD;
#endif
   } /* End of pucchCfg.pres */

   if (cellCb->cellCfg.srsUlCfg.pres)
   {
      srsUlCfg = &cellCb->cellCfg.srsUlCfg;
      ulSubFrCmnCtrl->srsBandwitdhConfig      = srsUlCfg->srsSetup.srsBw;
      ulSubFrCmnCtrl->srsSubframeConfig       = srsUlCfg->srsSetup.sfCfg;
      ulSubFrCmnCtrl->ackNackSRSSimultaneousTransmission
                                              = srsUlCfg->srsSetup.srsANSimultTx;
   }

   if (cellCb->cellCfg.puschCfg.pres)
   {
      puschCfg       = &cellCb->cellCfg.puschCfg;
      puschCfgBasic  = &puschCfg->puschBasicCfg;

      ulSubFrCmnCtrl->nSB                      = puschCfgBasic->noOfsubBands;
      ulSubFrCmnCtrl->hoppingMode              = puschCfgBasic->hoppingMode;
      ulSubFrCmnCtrl->enable64QAM              = puschCfgBasic->enable64QAM;
      ulSubFrCmnCtrl->puschhoppingOffset       = puschCfgBasic->hoppingOffset;

      puschUlRs      = &puschCfg->puschUlRS;
      ulSubFrCmnCtrl->groupHoppingEnabled      = puschUlRs->grpHopEnabled;
      ulSubFrCmnCtrl->groupAssignmentPUSCH     = puschUlRs->grpNum;
      ulSubFrCmnCtrl->sequenceHoppingEnabled   = puschUlRs->seqHopEnabled;
      ulSubFrCmnCtrl->cyclicShift              = puschUlRs->cycShift;
      ulSubFrCmnCtrl->padding                  = PAD;
   }

   switch(cellCb->cellCfg.bwCfg.dlBw)
      {
        case CTF_BW_RB_6 :
        cellCb->cellInfo.dlBw = 6;
      break;
      case CTF_BW_RB_15:
          cellCb->cellInfo.dlBw = 15;
      break;
      case CTF_BW_RB_25:
        cellCb->cellInfo.dlBw = 25;
      break;
      case CTF_BW_RB_50:
          cellCb->cellInfo.dlBw = 50;
      break;
      case CTF_BW_RB_75:
        cellCb->cellInfo.dlBw = 75;
      break;
      case CTF_BW_RB_100:
        cellCb->cellInfo.dlBw = 100;
      break;
     default:
        RLOG_ARG1(L_WARNING,DBG_CELLID,cellCb->cellId,"Invalid DL BW %u", cellCb->cellCfg.bwCfg.dlBw);
      }

   if (cellCb->cellInfo.dlBw > 63)
   {
      cellCb->cellInfo.rbgSize  = 4;
   }
   else if ( cellCb->cellInfo.dlBw > 26)
   {
      cellCb->cellInfo.rbgSize  = 3;
   }
   else if (cellCb->cellInfo.dlBw > 10)
   {
      cellCb->cellInfo.rbgSize  = 2;
   }
   else
   {
      cellCb->cellInfo.rbgSize  = 1;
   }

   switch(cellCb->cellCfg.bwCfg.ulBw)
      {
        case CTF_BW_RB_6 :
         cellCb->cellInfo.ulBw = 6;
       break;
      case CTF_BW_RB_15:
           cellCb->cellInfo.ulBw = 15;
       break;
      case CTF_BW_RB_25:
         cellCb->cellInfo.ulBw = 25;
       break;
      case CTF_BW_RB_50:
           cellCb->cellInfo.ulBw = 50;
       break;
      case CTF_BW_RB_75:
         cellCb->cellInfo.ulBw = 75;
       break;
      case CTF_BW_RB_100:
        cellCb->cellInfo.ulBw = 100;
         break;
     default:
         RLOG_ARG1(L_WARNING,DBG_CELLID,cellCb->cellId,"Invalid UL BW %u", cellCb->cellCfg.bwCfg.ulBw);
      }
/* Filling the band ID for automating the ADI ID */
   cellCb->cellInfo.bandId = cellCb->cellCfg.bwCfg.eUtraBand;

   switch(cellCb->cellCfg.phichCfg.resource)
   {
     case CTF_PHICH_RSRC_ONESIXTH:
       cellCb->cellInfo.phichSixNg = 1;
       break;
     case CTF_PHICH_RSRC_HALF:
       cellCb->cellInfo.phichSixNg = 3;
       break;
     case CTF_PHICH_RSRC_ONE:
       cellCb->cellInfo.phichSixNg = 6;
       break;
     case CTF_PHICH_RSRC_TWO:
       cellCb->cellInfo.phichSixNg = 12;
      break;
     default:
         RLOG_ARG1(L_WARNING,DBG_CELLID,cellCb->cellId,"Invalid NG config %u", cellCb->cellCfg.phichCfg.resource);
         break;
   }

   for (i = 0; i < YS_NUM_SUB_FRAMES; i++)
   {
      RLOG1(L_INFO,"ZEROING OUT the ulEncL1Msgs subframe (%d) ", i);
      cmMemset((U8*)&(cellCb->ulEncL1Msgs[i]), 0, (sizeof(YsUlEncL1Msgs)));
   }

   cellCb->cellInfo.numAntPorts = YS_MS_GET_NUM_TX_ANT(cellCb->cellCfg.antennaCfg);
   STKLOG(STK_MD_YS,STK_LOG_INFO,"CL:MIMO_DBG:: !!!! num Antenna ports =%d!!!!\n", cellCb->cellInfo.numAntPorts);
   cellCb->cellInfo.cmnTransMode = cellCb->cellInfo.numAntPorts > 1 ? TXDIVERSITY : SINGLEANT;

   RETVALUE(ROK);

} /* End of ysMsUlmPrcCellCfg*/

/*
*
*       Fun:   ysMsUlmPrcDelCellCfg
*
*       Desc:  Delete Cell Configuration
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmPrcDelCellCfg
(
YsCellCb        *cellCb
)
{
   /* No persistent memory from Ulm */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
  U8 loopCnt = 0;
  U16 idx = 0;

  while(loopCnt < YS_NUM_SUB_FRAMES )
  {
     if(cellCb->dlEncL1Msgs[loopCnt].txVector != NULLP)
     {
#ifdef TL_ALLOC_MEM
        TL_Free(ysCb.ysIccHdl, cellCb->dlEncL1Msgs[loopCnt].txVector);
#else
        ysFreePhyMsg(cellCb->dlEncL1Msgs[loopCnt].txVector);
#endif
     }

     if(cellCb->ulEncL1Msgs[loopCnt].rxVector != NULLP)
     {
#ifdef TL_ALLOC_MEM
        TL_Free(ysCb.ysIccHdl, cellCb->ulEncL1Msgs[loopCnt].rxVector);
#else
        ysFreePhyMsg(cellCb->ulEncL1Msgs[loopCnt].rxVector);
#endif
     }

     if(cellCb->dlEncL1Msgs[loopCnt].pDci0HiVector!= NULLP)
     {
#ifdef TL_ALLOC_MEM
        TL_Free(ysCb.ysIccHdl, cellCb->dlEncL1Msgs[loopCnt].pDci0HiVector);
#else
        ysFreePhyMsg(cellCb->dlEncL1Msgs[loopCnt].pDci0HiVector);
#endif
     }


     idx = 0;
     while(idx < cellCb->dlEncL1Msgs[loopCnt].numL1Msg)
     {
        if(cellCb->dlEncL1Msgs[loopCnt].l1Msg[idx] != NULLP)
        {
           ysFreePhyMsg(cellCb->dlEncL1Msgs[loopCnt].l1Msg[idx]);
           cellCb->dlEncL1Msgs[loopCnt].l1Msg[idx] = NULLP;
        }
        else
        {
           stop_printf("l1 Msg has NULL pointer but the numL1Msg"
                       " mismatches. subframe %d idx %d\n", loopCnt, idx);
        }
        idx++;
     }
     cellCb->dlEncL1Msgs[loopCnt].numL1Msg = 0;
     loopCnt++;
  }
#endif
   RETVALUE (ROK);
} /* End of ysMsUlmPrcDelCellcfg */

/*
*
*       Fun:   ysMsUlmPrcCellRecfg
*
*       Desc:  Process Cell Reconfiguration
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmPrcCellRecfg
(
YsCellCb        *cellCb
)
{

   /* TODO */

   RETVALUE (ROK);
} /* End Of ysMsUlmPrcCellRecfg */



#ifndef TFU_UPGRADE
/*
*
*       Fun:   ysMsUlmGetSchInfo
*
*       Desc:  Get the Scheduling Information for given list
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsUlmGetSchInfo
(
U8               type,
CmLListCp       *offsetList,
CmLteTimingInfo *timingInfo,
YsUeLst         *ueLst
)
{
   CmLList   *cmLstEnt;
   YsUeCb    *ueCb;

   TRC2(ysMsUlmGetSchInfo)

   /* Schedule invdividual UE */
   cmLstEnt = offsetList->first;
   while (cmLstEnt != NULLP)
   {
      Bool onPucch = FALSE;
      Bool alreadyOnPucch;
      ueCb = (YsUeCb*)(cmLstEnt->node);
      /* CL WORKAROUND ReEst Fix Start */
      alreadyOnPucch = ueCb->subFrInfo.onPucch;
      /* CL WORKAROUND ReEst Fix End */
      ueCb->subFrInfo.schPres    = TRUE;

      if (type & YS_MS_CQI_REQ)
      {
         onPucch    = TRUE;
         ueCb->subFrInfo.cqiPres    = TRUE;
      }
      else if (type & YS_MS_SR_REQ)
      {
         onPucch   = TRUE;
         ueCb->subFrInfo.srPres    = TRUE;
      }
      else
      {
         ueCb->subFrInfo.srsPres    = TRUE;
      }
      /* If ue is not scheduled on pusch, add to pucch/srs list if needed */
      if (!ueCb->subFrInfo.schReqInfo && !alreadyOnPucch && onPucch)
      {
         ueCb->subFrInfo.onPucch = onPucch;
         ueLst->pucchLst[ueLst->numPucch++] = ueCb;
      }
      if (type & YS_MS_SRS_REQ)
      {
         ueLst->srsLst[ueLst->numSrs++] = ueCb;
      }
      cmLstEnt                     = cmLstEnt->next;
   }

   RETVALUE(ROK);
} /* End of ysMsUlmGetSchInfo */



/*
*
*       Fun:   ysMsUlmGetRecpInfo
*
*       Desc:  Builds Reception Informaiton
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsUlmGetRecpInfo
(
YsCellCb        *cellCb,
TfuRecpReqInfo  *recpReq,
YsUeLst         *ysUeLst
)
{
   CmLList          *cmLstEnt;
   TfuUeRecpReqInfo *recpReqInfo;
   YsUeCb           *ueCb;
   YsSubFrInfo      *ysSubFrInfo;
   /* HARQ */
   U8               rxSduSf;

   cmLstEnt = recpReq->ueRecpReqLst.first;

   RLOG_NULL(L_UNUSED,"ysMsUlmGetRecpInfo (): (%d) (%d);",
            recpReq->timingInfo.sfn, recpReq->timingInfo.subframe));

   ysSubFrInfo = &cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].ysSubFrInfo;
   rxSduSf = (recpReq->timingInfo.subframe + 2) % YS_NUM_SUB_FRAMES;

   while (cmLstEnt != NULLP)
   {
      recpReqInfo = (TfuUeRecpReqInfo*)cmLstEnt->node;
      ueCb = ysMsCfgGetUe(cellCb, recpReqInfo->rnti);
      if  (!ueCb)
      {
         if (recpReqInfo->type == TFU_RECP_REQ_MSG3)
         {

            RLOG3(L_INFO,"ysMsUlmGetRecpInfo Filling in msg3RecpReq (): (%d) (%d) number (%d);",
                  recpReq->timingInfo.sfn, 
                  recpReq->timingInfo.subframe, 
                  ysSubFrInfo->msg3Lst.numMsg3);
            /* copy msg 3 recp requests */
            ysSubFrInfo->msg3Lst.msg3RecpLst[ysSubFrInfo->msg3Lst.numMsg3++] = *recpReqInfo;


            RLOG4(L_DEBUG,"ysMsUlmGetRecpInfo Filling in msg3RecpReq(%d) (%d) at cell time (%d,%d)",
                     recpReq->timingInfo.sfn, 
                     recpReq->timingInfo.subframe,
                     cellCb->timingInfo.sfn,
                     cellCb->timingInfo.subframe);
            RLOG2(L_DEBUG,": number (%d) rxSduSf(%d)",
                     ysSubFrInfo->msg3Lst.numMsg3, 
                     rxSduSf);

            cmLstEnt = cmLstEnt->next;
            continue;
         }
         else
         {
            RLOG_ARG0(L_ERROR,DBG_CRNTI,recpReqInfo->rnti,"Failed to find ueCb");
            MSPD_ERR("Failed to find ueCb for %d", recpReqInfo->rnti);
            RETVALUE (RFAILED);
         }
      }

      ueCb->subFrInfo.schPres           = TRUE;
      if (recpReqInfo->type == TFU_RECP_REQ_PUCCH)
      {
         if (!ueCb->subFrInfo.schReqInfo)
         {
            /* This assumes that pusch would have appeared
             * earlier */
            ysUeLst->pucchLst[ysUeLst->numPucch++]  = ueCb;
         }
         ueCb->subFrInfo.harqReqInfo = recpReqInfo;
      }
      else
      {
         ysUeLst->puschLst[ysUeLst->numPusch++]  = ueCb;
         ueCb->subFrInfo.schReqInfo = recpReqInfo;

      }

      cmLstEnt = cmLstEnt->next;
   } /* cmLstEnt while */

   RETVALUE(ROK);

} /* End of ysMsUlmGetRecpInfo */


/*
*
*       Fun:   ysMsUlmGetSubFrInfo
*
*       Desc:  Builds Sub Frame Information
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsUlmGetSubFrInfo
(
YsCellCb        *cellCb,
TfuRecpReqInfo  *recpReq
)
{
   YsSubFrInfo      *ysSubFrInfo;
   YsUeLst          *ueLst;
   CmLListCp        *offsetList;
   U16               offset;
   CmLteTimingInfo  *timingInfo;

   TRC2(ysMsUlmGetSubFrInfo)

   RLOG2(L_INFO,"ysMsUlmGetSubFrInfo (): (%d) (%d);",
            recpReq->timingInfo.sfn, recpReq->timingInfo.subframe));

   ysSubFrInfo = &cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].ysSubFrInfo;
   timingInfo  = &recpReq->timingInfo;

   if (ysSubFrInfo->pres)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"SubFrmInfo still persists");
      RETVALUE(RFAILED);
   }

   cmMemset((U8*)ysSubFrInfo, 0, sizeof(YsSubFrInfo));

   ueLst = &ysSubFrInfo->ueLst;
#ifndef TFU_TDD
   ysSubFrInfo->prachPres = (cellCb->prachCb.ysPrachPres &
         (0x01 << ((recpReq->timingInfo.sfn * YS_NUM_SUB_FRAMES)
                   + recpReq->timingInfo.subframe) % YS_NUM_PRACH_PRES_ARR))?1:0;
#else
   U8 prachTime;

   /* TDD_TODO: Add support for pream format 4 prach */
   /* As the TfuCntrlReq is posted every TTI, filling of rach present is enough.
      No need to add separate code*/
   prachTime = (recpReq->timingInfo.sfn & 0x1)* YS_NUM_SUB_FRAMES + 
                     recpReq->timingInfo.subframe;
   if((cellCb->prachCb.ysPrachPresArr[prachTime] !=
            YS_PRACH_NOT_PRSNT))
   {
      RLOG1(L_INFO,"RACH opportunity SF(%d)",
               timingInfo->subframe);
      ysSubFrInfo->prachPres = TRUE;
   }
#endif
   /* Get Ue PUCCH/PUSCH Info */
   ysMsUlmGetRecpInfo(cellCb, recpReq, ueLst);

   /* Get Sr Scheduling Info*/
   offset = (((timingInfo->sfn * YS_NUM_SUB_FRAMES) +
                  timingInfo->subframe) % YS_SR_PERIOD_80);
   offsetList = &(cellCb->srPeriodList[offset]);

   ysMsUlmGetSchInfo(YS_MS_SR_REQ, offsetList, &recpReq->timingInfo, ueLst);

   /* Get Srs Scheduling Info*/
   offset = (((timingInfo->sfn * YS_NUM_SUB_FRAMES) +
                  timingInfo->subframe) % YS_SRS_PERIOD_320);
   offsetList = &(cellCb->srsPeriodList[offset]);

   ysMsUlmGetSchInfo(YS_MS_SRS_REQ, offsetList, &recpReq->timingInfo, ueLst);


   /* Get CQI Scheduling Info */
   offset = (((timingInfo->sfn * YS_NUM_SUB_FRAMES) +
                  timingInfo->subframe) % YS_CQI_PERIOD_160);
   offsetList = &(cellCb->cqiPeriodList[offset]);

   ysMsUlmGetSchInfo(YS_MS_CQI_REQ, offsetList, &recpReq->timingInfo, ueLst);


   RETVALUE(ROK); /*Always a happy function*/

} /* End of ysMsUlmGetSubFrInfo */
#endif /* TFU_UPGRADE */

#ifdef CRAN_DEBUG_PRINT
/*
*
*       Fun:   printUlPerTtiInfo
*
*       Desc:  Prints Ul Per TTI Info
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
void printUlPerTtiInfo(YsCellCb *cellCb, TfuRecpReqInfo  *recpReq)
{
   YsSubFrInfo      *ysSubFrInfo;
   YsUeLst          *ueLst;
   CmLListCp        *offsetList;
   U16               offset;
   CmLteTimingInfo  *timingInfo;

   ysSubFrInfo = &cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].ysSubFrInfo;
   timingInfo  = &recpReq->timingInfo;

   if (ysSubFrInfo->pres)
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"\nSubFrmInfo still persists\n");
      return;
   }

   cmMemset((U8*)ysSubFrInfo, 0, sizeof(YsSubFrInfo));

   ueLst = &ysSubFrInfo->ueLst;
#ifndef TFU_TDD
   ysSubFrInfo->prachPres = (cellCb->prachCb.ysPrachPres &
         (0x01 << ((recpReq->timingInfo.sfn * YS_NUM_SUB_FRAMES)
                   + recpReq->timingInfo.subframe) % YS_NUM_PRACH_PRES_ARR))?1:0;
#else
   U8 prachTime;

   /* TDD_TODO: Add support for pream format 4 prach */
   /* As the TfuCntrlReq is posted every TTI, filling of rach present is enough.
      No need to add separate code*/
   prachTime = (recpReq->timingInfo.sfn & 0x1)* YS_NUM_SUB_FRAMES +
      recpReq->timingInfo.subframe;

   if((cellCb->prachCb.ysPrachPresArr[prachTime] !=
            YS_PRACH_NOT_PRSNT))
   {
      RLOG1(L_INFO,"RACH opportunity SF(%d)",
            timingInfo->subframe);
      ysSubFrInfo->prachPres = TRUE;
   }
#endif
   /* Print Ue PUCCH/PUSCH Info */
   /////////////////////////////////////////////
   CmLList          *cmLstEnt;
   TfuUeRecpReqInfo *recpReqInfo;
   YsUeCb           *ueCb;
   YsSubFrInfo      *ysSubFrInfo1;
   /* HARQ */
   U8               rxSduSf;
   U8               ueCntPerTti = 0;
   cmLstEnt = recpReq->ueRecpReqLst.first;

   ++ttiCount;
   RLOG_NULL(L_UNUSED,"ysMsUlmGetRecpInfo (): (%d) (%d);",
         recpReq->timingInfo.sfn, recpReq->timingInfo.subframe);

   ysSubFrInfo1 = &cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].ysSubFrInfo;
   rxSduSf = (recpReq->timingInfo.subframe + 2) % YS_NUM_SUB_FRAMES;

   while (cmLstEnt != NULLP)
   {
      recpReqInfo = (TfuUeRecpReqInfo*)cmLstEnt->node;
      ueCb = ysMsCfgGetUe(cellCb, recpReqInfo->rnti);
      if  (!ueCb)
      {
         if (recpReqInfo->type == 1)
         {

            RLOG3(L_INFO,"ysMsUlmGetRecpInfo Filling in "
                  "msg3RecpReq (): (%d) (%d) number (%d);",
                  recpReq->timingInfo.sfn,
                  recpReq->timingInfo.subframe,
                  ysSubFrInfo1->msg3Lst.numMsg3);
            /* copy msg 3 recp requests */
            ysSubFrInfo1->msg3Lst.msg3RecpLst[ysSubFrInfo1->msg3Lst.numMsg3++] = *recpReqInfo;

            cmLstEnt = cmLstEnt->next;
            continue;
         }
         else
         {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"Failed to find ueCb for %d", recpReqInfo->rnti);
            return;
         }
      }

      ueCb->subFrInfo.schPres           = TRUE;
      if (recpReqInfo->type == TFU_RECP_REQ_PUCCH)
      {
         if (!ueCb->subFrInfo.schReqInfo)
         {
            /* This assumes that pusch would have appeared
             * earlier */
            ueLst->pucchLst[ueLst->numPucch++]  = ueCb;
         }
         ueCb->subFrInfo.harqReqInfo = recpReqInfo;
      }
      else
      {
         ueLst->puschLst[ueLst->numPusch++]  = ueCb;
         ueCb->subFrInfo.schReqInfo = recpReqInfo;
         ueCntPerTti++;
      }

      cmLstEnt = cmLstEnt->next;
   } /* cmLstEnt while */

   if (ueCntPerTti < 18)
   {
      ++ulUespertti[ueCntPerTti];
      if (ttiCount % 30000 == 0)
      {
         STKLOG(STK_MD_YS,STK_LOG_INFO,"\n\nUL Scheduling Done in last 30s, Nil=%d, 1UE=%d 2UE=%d 3UE=%d 4UE=%d 5UE=%d 6UE=%d 7UE=%d \n \
               8UE=%d 9UE=%d 10UE=%d 11UE=%d 12UE=%d 13UE=%d 14UE=%d 15UE=%d 16UE=%d 17UE=%d per TTI\n\n",
               ulUespertti[0],  ulUespertti[1],
               ulUespertti[2],  ulUespertti[3],
               ulUespertti[4],  ulUespertti[5],
               ulUespertti[6],  ulUespertti[7],
               ulUespertti[8],  ulUespertti[9],
               ulUespertti[10], ulUespertti[11],
               ulUespertti[12], ulUespertti[13],
               ulUespertti[14], ulUespertti[15],
               ulUespertti[16], ulUespertti[17]);
         
         ulUespertti[0]  = 0;
         ulUespertti[1]  = 0;
         ulUespertti[2]  = 0;
         ulUespertti[3]  = 0;
         ulUespertti[4]  = 0;
         ulUespertti[5]  = 0;
         ulUespertti[6]  = 0;
         ulUespertti[7]  = 0;
         ulUespertti[8]  = 0;
         ulUespertti[9]  = 0;
         ulUespertti[10] = 0;
         ulUespertti[11] = 0;
         ulUespertti[12] = 0;
         ulUespertti[13] = 0;
         ulUespertti[14] = 0;
         ulUespertti[15] = 0;
         ulUespertti[16] = 0;
         ulUespertti[17] = 0;
      }
   }
   return;
}
#endif
/*
*
*       Fun:   ysMsUlmPrcRecpReq
*
*       Desc:  Process Reception request
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmPrcRecpReq
(
YsCellCb        *cellCb,
TfuRecpReqInfo  *recpReq
)

{
   PGENMSGDESC   pMsgDesc;
   PULSUBFRDESC  rxVector;
#ifndef TFU_UPGRADE
   YsSubFrInfo   *subFrInfo;
#endif /* TFU_UPGRADE */
   RACHCTRL      *rachCtrl;
#ifdef BATCH_PROCESSING_DL
   PMAC2PHY_QUEUE_EL    pElem = NULLP;
#endif
   CtfPrachCfgInfo                   *prachCfg;
#ifndef TFU_TDD
   YsPrachFddCfgInfo                 *ysPrachInfo;
#endif

/*Radisys*/

   TRC2(ysMsUlmPrcRecpReq)
/*
   RLOG2(L_INFO,"ysMsUlmPrcRecpReq (): (%d) (%d);",
            recpReq->timingInfo.sfn, recpReq->timingInfo.subframe);
*/
/*   RLOG0(L_DEBUG," Entering PrcRecpReq");*/

#ifndef TFU_UPGRADE
   /* Get Subframe Information */
   if(ysMsUlmGetSubFrInfo(cellCb, recpReq) != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"Failed to get SubFr Info");
      RETVALUE(RFAILED);
   }
#endif /* TFU_UPGRADE */

#ifdef CRAN_DEBUG_PRINT
   printUlPerTtiInfo(cellCb, recpReq);
#endif
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   /* Allocating Memory */
#ifdef BATCH_PROCESSING_DL 
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].rxVector;
   cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].addRxVecToLst = TRUE;
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      /* HARQ_DBG */
      RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
      RETVALUE(RFAILED);
   }
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   cmMemset((U8 *)pElem, 0, (sizeof(GENMSGDESC) + sizeof(ULSUBFRDESC) + sizeof(MAC2PHY_QUEUE_EL)));
#endif
   pMsgDesc = (PGENMSGDESC)(pElem + 1);
   pElem->AlignOffset = sizeof(ULSUBFRDESC) + sizeof(GENMSGDESC);
   pElem->NumMessageInBlock = 1;
   pElem->Next = NULLP;
#else
   /* Allocate a message towards Phy using sysCore */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pMsgDesc = cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].rxVector; 
   cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].addRxVecToLst = TRUE;
#else
   pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg (FALSE);
#endif
   if (pMsgDesc == NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"Unable to allocate memory for TxVector");
      MSPD_ERR("Unable to allocate memory for TxVector");
      RETVALUE (RFAILED);
   }
#endif

   rxVector = (PULSUBFRDESC)(pMsgDesc + 1);

   pMsgDesc->msgType     = PHY_RXSTART_REQ;
   pMsgDesc->phyEntityId = cellCb->phyInstId;
   pMsgDesc->msgSpecific = sizeof(ULSUBFRDESC);

#ifndef TFU_UPGRADE
   subFrInfo = &(cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].ysSubFrInfo);
#endif

   rxVector->numberofChannelDescriptors         = 0;
   rxVector->numberOfCtrlChannelDescriptors      = 0;
   rxVector->numberSrsinSf                        = 0;
   /* cmMemset((U8*)&(rxVector->ulSfrCtrl), 0, sizeof(ULSUBFRCMNCTRL)); */

#ifndef TFU_UPGRADE
   /* Map Reception Request to PHY API */
   if(ysMsUtlMapRxVector(cellCb, subFrInfo, (PULSUBFRDESC *)rxVector, recpReq->timingInfo) != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"Rx Vector Mapping failed");
      MSPD_ERR("Rx Vector Mapping failed");
#ifdef BATCH_PROCESSING_DL
      ysFreePhyMsg(pElem);
#else
#ifndef TENB_RTLIN_CHANGES
      SvsrFreeMsg(pMsgDesc);
#else
      ysFreePhyMsg(pMsgDesc);
#endif
#endif
      /* TODO free allocated rxvector memory */
      RETVALUE(RFAILED);
   }
#else
   if(ysMsUtlMapRxVector(cellCb, recpReq, (PULSUBFRDESC )rxVector, recpReq->timingInfo) != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"Rx Vector Mapping failed");
      MSPD_ERR("Rx Vector Mapping failed");
#ifdef BATCH_PROCESSING_DL
      ysFreePhyMsg(pElem);
#else
#ifndef TENB_RTLIN_CHANGES
      SvsrFreeMsg(pMsgDesc);
#else
      ysFreePhyMsg(pMsgDesc);
#endif
#endif
      /* TODO free allocated rxvector memory */
      RETVALUE(RFAILED);
   }
#endif /* TFU_UPGRADE */

    /* change */
#ifdef BIT_64
   rachCtrl = (RACHCTRL *)((U64)rxVector + rxVector->offsetRachCtrlStruct);
#else
   rachCtrl = (RACHCTRL *)((U32)rxVector + rxVector->offsetRachCtrlStruct);
#endif
   prachCfg            = &cellCb->cellCfg.prachCfg;
#ifndef TFU_TDD
   ysPrachInfo         = &ysPrachFddCfgDb[prachCfg->prachCfgIndex];
   rachCtrl->prachEnable               = 0;

   if(((ysPrachInfo->sfn == YS_EVEN_SFN) && (recpReq->timingInfo.sfn % 2 == 0)) || (ysPrachInfo->sfn == YS_ALL_SFN))
   {
      rachCtrl->prachEnable    = (cellCb->prachCb.ysPrachPres &
            (0x01 <<  recpReq->timingInfo.subframe))?1:0;

   }
#else
   U8 prachTime;
   prachTime = (recpReq->timingInfo.sfn & 0x1) * YS_NUM_SUB_FRAMES + recpReq->timingInfo.subframe;
   rachCtrl->prachEnable = FALSE;
   if((cellCb->cellId == CM_START_CELL_ID) && (cellCb->prachCb.ysPrachPresArr[prachTime] != YS_PRACH_NOT_PRSNT))
   {
      rachCtrl->prachEnable = TRUE;
   }
#endif
   if (ysOneRachCompleted)
   {
      rachCtrl->prachEnable               = 0;
   }
   /* Rach Predefine Control Information */
     /* rachCtrl    = &cellCb->preDefVal.rachCtrl;*/

   /*      prachCfg = &cellCb->cellCfg.prachCfg;*/
   rachCtrl->rootSequenceIndex         = prachCfg->rootSequenceIndex;
   rachCtrl->prachConfigIndex          = prachCfg->prachCfgIndex;

   rachCtrl->highSpeedFlag             = prachCfg->highSpeedFlag;
   rachCtrl->zeroCorrelationZoneConfig = prachCfg->zeroCorrelationZoneCfg;
   rachCtrl->prachFreqOffset           = prachCfg->prachFreqOffset;

   rxVector->offsetCustomFeatures					= 0;

   rxVector->frameNumber 								= recpReq->timingInfo.sfn;
   rxVector->subframeNumber 						   = recpReq->timingInfo.subframe;
   rxVector->subframeType 							 	= ULRX;
   rxVector->antennaPortcount							= 1;

   rxVector->frameNumber 								= recpReq->timingInfo.sfn;
   rxVector->subframeNumber 						   = recpReq->timingInfo.subframe;
   rxVector->subframeType 							 	= ULRX;
   rxVector->antennaPortcount							= 1;
#ifdef EMTC_ENABLE
   /* TODO:: This needs to be enhanced to support multiple ce levels and to 
    * have ctf prach config per CE level */
   rachCtrl->catmEnable                         = cellCb->cellInfo.catMenabled;
   rachCtrl->repetitionNumber                   = 0; /*no rep. only 1 attempt*/
   rachCtrl->repetitionIndex                    = 0; /*1st attempt*/
   rachCtrl->catmFrequencyOffset                = prachCfg->prachFreqOffset; 
   rachCtrl->pad                                = 0;
#endif
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
   /* there should not be any rxVector already present for this subframe */
   if(cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].rxVector != NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"Fatal error, RX vector is still there... exiting");
      MSPD_ERR("Fatal error, RX vector is still there... exiting (%u,%u)\n",
         recpReq->timingInfo.sfn, recpReq->timingInfo.subframe);
      MSPD_ERR("Losing Memory Need to cleanup\n");
   }

   /* Save rxVector */
#ifndef BATCH_PROCESSING_DL
   cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].rxVector = pMsgDesc;
#else
   cellCb->ulEncL1Msgs[recpReq->timingInfo.subframe].rxVector = pElem;
#endif
#endif
   /*Begin: add by luopeng for phy-l2 api send to wireshark 20171204*/
   if(gRgFapiWiresharkEnable && (rxVector->numberofChannelDescriptors||rxVector->numberOfCtrlChannelDescriptors||rxVector->numberSrsinSf))
   {	  
      sendFapiWiresharkToApp((U8*)pMsgDesc,4500, 3, indx);
   }
   /*End: add by luopeng for phy-l2 api send to wireshark 20171204*/

   RETVALUE(ROK);
} /* End of ysMsUlmPrcRecpReq */

//EXTERN U32 gSrCount;

PUBLIC S16 ysMsPrcUciInd
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		 rnti,
YsUeCb			*ueCb
)
{
   U32             pucchFormat =  rxSduInd->pucchType;
   CmLteTimingInfo timingInfo;
   U8              *hqBuf;
   U32 numHarqBits;
#ifdef YSMS_RLF_DETCT
   S32 pucchSnr;
#endif
   U8 cqiConfBitMask = 1;

   TRC2(ysMsPrcUciInd)

   if (rxSduInd->srdetected)
   {
#ifdef MSPD_TDD_DBG
      {
         rgStats.srDetCount++;
      }
#endif
      ysMsPrcSrInd(rxSduInd, cellCb, rnti);
   }
#ifdef YSMS_RLF_DETCT
   {
      pucchSnr = (rxSduInd->ul_CQI - 128);
      pucchSnr = pucchSnr /2;
      if ((pucchSnr <= -6) && (rxSduInd->pucchType != FORMAT1))
      {
         if (pucchFormat == FORMAT2 || pucchFormat == FORMAT2A || pucchFormat == FORMAT2B)
         {
            if (ueCb)
            {
               ueCb->cqiDropped ++;
               ueCb->contCqiDrops ++;
               if (ueCb->contCqiDrops > ueCb->maxContCqiDrops)
               {
                  ueCb->maxContCqiDrops = ueCb->contCqiDrops;
               }
            }
            //rgStats.cqiDropCount++;
            rgStats.contCqiDrops ++;
            if (rgStats.contCqiDrops > rgStats.maxContCqiDrops)
            {
               rgStats.maxContCqiDrops = rgStats.contCqiDrops;
            }
#ifdef CA_DBG
            {
               //rgStats.gCqiPucchLowSnrDropCount++;
            }
#endif
         }
         RLOG_ARG5(L_INFO, DBG_CRNTI, rnti, "PUCCH Drop (%d,%d) due to SNR at CL, format=%d snr=%ld ul_CQI=%d", 
               rxSduInd->frameNum, rxSduInd->subFrameNum, rxSduInd->pucchType,
               pucchSnr,rxSduInd->ul_CQI);
#ifdef XEON_SPECIFIC_CHANGES
         if(rxSduInd->pucchType != FORMAT1){ 
            /*printf("ANOOP_CL_DBG:: ysMsPrcUciInd() [%d] ul_CQI Dropped (%d,%d)"
                  "due to SNR at CL,pucchSnr=%d, ul_CQI=%d format %d\n",
                  rnti, rxSduInd->frameNum, rxSduInd->subFrameNum, pucchSnr,
                  rxSduInd->ul_CQI, rxSduInd->pucchType);*/
            {
               rgStats.gPucchDropCount++;
            }
         }
#endif

         RETVALUE(ROK);
      }
   }
#endif

   pucchFormat = rxSduInd->pucchType;
   timingInfo.sfn = rxSduInd->frameNum;
   timingInfo.subframe = rxSduInd->subFrameNum;
   if (pucchFormat == FORMAT1A || pucchFormat == FORMAT1B || pucchFormat == FORMAT2A || pucchFormat == FORMAT2B)
   {
      numHarqBits = 1;
      if (pucchFormat == FORMAT1B || pucchFormat == FORMAT2B)
      {
         numHarqBits = 2;
      }
      hqBuf = (U8 *)&rxSduInd->pRxSdu;
#ifndef MSPD_PHY_NEW 
      if (rxSduInd->pucchDetected)
#else
      if (rxSduInd->chanDetected)
#endif
      {
         Bool isSplBundling = 0;
#ifdef TFU_TDD
         if( (rxSduInd->srdetected ) || (pucchFormat >= FORMAT2A))
         {
            isSplBundling = 1;
         }
#else
#ifdef CA_PHY
         /* For CA:: F1BCS + SR, if Positive SR+ Harq collides
         * UE uses spatial bundling across TB with in a serving cell
         * section 7.3 of 36.213.*/
         if (rxSduInd->srdetected)
         {
            isSplBundling = 1;
         }
#endif
#endif

         ysMsPrcHarqInd(cellCb,&timingInfo,hqBuf,FALSE,rnti, numHarqBits, isSplBundling); 
      }
       /*add by luopeng for ue stk log to web*/
      else
      {
         if(rnti - g_MacRntiStart[cellCb->cellId - 1] >= 0 && rnti - g_MacRntiStart[cellCb->cellId - 1] < WEB_LOG_ARRAY_COUNT)
         {
             rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].rnti = rnti;
             rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].pucchDtxCnt++;
          }
      }
   }
   if (pucchFormat == FORMAT2 || pucchFormat == FORMAT2A || pucchFormat == FORMAT2B)
   {
#ifndef MSPD_PHY_NEW 
      if (!rxSduInd->pucchDetected)
#else
      if (!rxSduInd->chanDetected)
#endif
      {
         static U32 cqiDetectFailCnt = 0;
         ++cqiDetectFailCnt;
         /*RLOG4(L_DEBUG,"CQIDetectFail @(%u,%u) ueId(%u) cnt(%lu)",
               cellCb->timingInfo.sfn, cellCb->timingInfo.subframe, rnti,
               cqiDetectFailCnt);*/
         MSPD_DBG("CQIDetectFail @(%u,%u) ueId(%u) cnt(%lu)\n",
               cellCb->timingInfo.sfn, cellCb->timingInfo.subframe, rnti,
               cqiDetectFailCnt);
      }
      else
      {
         /* if ((ueCb) && ((ueCb->cqiDropped + ueCb->cqiSuccess)% 20 == 0))
            {
            MSPD_LOG("CQI Stats for UE(%d) cqiDropped=%lu, cqiSuccess=%lu, maxContCqiDrops=%lu\n",
            rnti, ueCb->cqiDropped, ueCb->cqiSuccess, ueCb->maxContCqiDrops);
            }
            */ 


         /* CCPU 129502 - if All CQI validation bits (bit 6 and bit 7) in "cqipmiconf" are set 
            * then only process CQI
            */
         if ( YS_CQIPMICONF_MSK != (rxSduInd->cqiPmiConf & YS_CQIPMICONF_MSK))
         {
            cqiConfBitMask = 0;
#ifdef CA_DBG                    
            rgStats.gCqiPucchConfMaskDropCount++;
#endif
#ifdef YSMS_RLF_DETCT
            RLOG_ARG5(L_INFO, DBG_CRNTI, rnti, "DL CQI Dropped (%d,%d) due to invalid cqiPmiConf at CL, pucchSnr=%lu, ul_CQI=%d CnfMask=%d", 
               rxSduInd->frameNum, rxSduInd->subFrameNum, pucchSnr, rxSduInd->ul_CQI,
               rxSduInd->cqiPmiConf);
#endif
         }
         if (ueCb)
         {
            ueCb->cqiSuccess++;
            ueCb->contCqiDrops = 0;
         }
         rgStats.cqiSuccess++;
         rgStats.contCqiDrops = 0;
         /* MSPD_DBG("[%d] DL CQI (%d,%d) SNR at CL, pucchSnr=%lu, ul_CQI=%d\n", 
            rnti, rxSduInd->frameNum, rxSduInd->subFrameNum, pucchSnr, rxSduInd->ul_CQI); */
         //ysMsPrcDlCqiInd(cellCb, rnti, timingInfo, 4, (U8*)&rxSduInd->pRxSdu);
         /* numBitsRx is in bits */
         ysMsPrcDlCqiInd(cellCb, rnti, timingInfo, (rxSduInd->numBitsRx)/8, (U8*)&rxSduInd->pRxSdu, NULLP,cqiConfBitMask);
      }
   }
   RETVALUE(ROK);
}

#ifdef RG_ULSCHED_AT_CRC
/*
*
*       Fun:   ysMsUlmSchSduInd
*
*       Desc:  Handles the ULSCH SDU Indication
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmSchSduInd
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb
)
{
   CmLteRnti     rnti;
   //YsUeCb        *ueCb;

   TRC2(ysMsUlmSchSduInd)

   /* Update the timing advance error average values in ueCb */
   ysMsGetRntiFrmChanId(cellCb, &rnti, rxSduInd->subFrameNum, rxSduInd->channelId);
   //ueCb = ysMsCfgGetUe(cellCb, rnti);
   if(rxSduInd->chanType == PUSCH)
   {
      if (!rxSduInd->status)
      {
         /* Process UL Sch Sdu Indication. add data to TfuDatIndication
            for the corresponding subframe  */
         if(ysMsPrcUlSchSduInd(rxSduInd, cellCb, rnti) != ROK)
         {
            RLOG_ARG0(L_ERROR,DBG_CRNTI,rnti,"ysMsUlmSchSduInd(): Processing of ysMsPrcUlSchSduInd failed");
            MSPD_ERR("Processing of ysMsPrcUlSchSduInd failed\n");
            RETVALUE(RFAILED);
         } /* end of if statement */
      }
   } /* end of (rxSduInd->chanType == UL_SCH) */
   RETVALUE(ROK);
} /* end of ysMsUlmSchSduInd */
#endif

/*
*
*       Fun:   ysMsUlmSduInd
*
*       Desc:  Handles the SDU Indication
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmSduInd
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb
)
{
   CmLteRnti     rnti;
   YsUeCb        *ueCb;
   Bool          isDummyRxSdu = FALSE; 

   TRC2(ysMsUlmSduInd)


   RLOG_NULL(L_UNUSED,"Received RX SDU from PHY : length=%d for TTI(%d, %d)",
            rxSduInd->numBitsRx,rxSduInd->frameNum, rxSduInd->subFrameNum); 
   RLOG_NULL(L_UNUSED,"Received RX SDU from PHY : type (%d) at cell(%d, %d) status (%d)",
            rxSduInd->chanType,
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe, rxSduInd->status);

   /* Update the timing advance error average values in ueCb */
   ysMsGetRntiFrmChanId(cellCb, &rnti, rxSduInd->subFrameNum, rxSduInd->channelId);
   ueCb = ysMsCfgGetUe(cellCb, rnti);
   if (ueCb)
   {
      ueCb->timingAdvErrInfo.mSetDefaults = 0;
      ueCb->timingAdvErrInfo.mErrAvgCh[0] = rxSduInd->mErrAvgCh[0];
      ueCb->timingAdvErrInfo.mErrAvgCh[1] = rxSduInd->mErrAvgCh[1];
      ueCb->timingAdvErrInfo.mErrExpo = rxSduInd->mErrExpo;
   }
   if ((rxSduInd->status == TIMEOUT_RXSTART_REQ) || (rxSduInd->status == INVALID_TX_VECTOR))
   {
      ++delayedApiCnt;
     isDummyRxSdu = TRUE;
      RLOG3(L_DEBUG,"Delayed API RXSDU chanType (%u) cnt(%lu) status(%u)", 
        rxSduInd->chanType, delayedApiCnt, rxSduInd->status);
      STKLOG(STK_MD_YS,STK_LOG_WARNING,"Delayed API RXSDU chanType (%u) cnt(%lu) status(%u)\n", 
         rxSduInd->chanType, delayedApiCnt, rxSduInd->status);
   }
   if(rxSduInd->chanType == PUSCH)
   {
      static U32 crcErrCnt = 0;
#ifdef HARQ_STATISTICS
   totl_ulTbs ++;
#endif
      if (rxSduInd->status)
      {
          /* ysMsGetRntiFrmChanId(cellCb, &rnti, rxSduInd->subFrameNum, rxSduInd->channelId);
          RLOG6(L_DEBUG,"Rcvd PUSCH RX SDU at PHY at (%d,%d) rnti %u ta %u status %d SNR %d",
          rxSduInd->frameNum, rxSduInd->subFrameNum, rnti, (U16)rxSduInd->timingAdv,
          rxSduInd->status, (rxSduInd->ul_CQI - 128)/2); */
          ++crcErrCnt;
      }


      /*RLOG7(L_DEBUG,"Received RX SDU from PHY : length=%d for TTI(%d, %d) type (%d) at cell(%d, %d) status (%d)",
         rxSduInd->numBitsRx,rxSduInd->frameNum, rxSduInd->subFrameNum, rxSduInd->chanType,
         cellCb->timingInfo.sfn, cellCb->timingInfo.subframe, rxSduInd->status);*/

#ifndef RG_ULSCHED_AT_CRC
      if (!rxSduInd->status)
      {
         /* Process UL Sch Sdu Indication. add data to TfuDatIndication
                     for the corresponding subframe  */
         if(ysMsPrcUlSchSduInd(rxSduInd, cellCb, rnti) != ROK)
         {
            RLOG_ARG0(L_ERROR,DBG_CRNTI,rnti,"ysMsUlmSduInd(): Processing of ysMsPrcUlSchSduInd failed");
            MSPD_ERR("Processing of ysMsPrcUlSchSduInd failed\n");
            RETVALUE(RFAILED);
         } /* end of if statement */
      }
#endif

      /* Update the CRC Indication structure */
      if (ysMsUpdCrcInd(rxSduInd, cellCb, rnti) != ROK)
      {
          RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"ysMsUlmSduInd(): Processing of ysMsUpdCrcInd failed");
          MSPD_ERR("Processing of ysMsUpdCrcInd failed\n");
          RETVALUE(RFAILED);
      } /* end of if statement */

#ifndef YS_MS_NO_TA
      if (!isDummyRxSdu)
      {
         /*ccpu00131191 and ccpu00131317 - Fix for RRC Reconfig failure issue
          * for VoLTE call */
         ysMsPrcTmAdvInd(rxSduInd, cellCb, rnti, ueCb);
      }
#endif
#ifndef YS_MS_NO_ULCQI
      if (!isDummyRxSdu)
      {
         ysMsPrcUlCqiInd(rxSduInd, cellCb, rnti, ueCb);
      }
#endif

#ifndef TFU_UPGRADE
      cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].ysSubFrInfo.numRxSduRcvd++;
#endif
   } /* end of (rxSduInd->chanType == UL_SCH) */
#ifndef DLHQ_RTT_OPT
   else if (rxSduInd->chanType == PUCCH)
   {
      if ((ysMsUlmPrcPucch(rxSduInd, cellCb)) != ROK)
      {
         RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"ysMsUlmPrcPucch(): Processing of PUCCH failed");
         MSPD_ERR("ysMsUlmPrcPucch(): Processing of PUCCH failed\n");
         RETVALUE(RFAILED);
      } /* end of if statement */
   }
#endif
   else
   {
      RLOG_ARG1(L_ERROR,DBG_CELLID,cellCb->cellId,"ysMsUlmSduInd(): Invalid channel type(%d) received"
               ,rxSduInd->chanType);
      RETVALUE(RFAILED);

   } /* end of else */

   RETVALUE(ROK);

} /* end of ysMsUlmSduInd */

/*
*
*       Fun:   ysMsUlmRxStartCnf
*
*       Desc:  Handles the Rx Start confirmation
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PUBLIC Void ysMsUlmRxStartCnf
(
PINITIND        rxStartCnf,
YsCellCb        *cellCb
)
{

   TRC2(ysMsUlmRxStartCnf)

   /* Check the Status. If the status is NOK then
      print the error else do nothing*/
   if(rxStartCnf->status != 0)
   {
      /* Print the SubFrame number and the error information */
      RLOG1(L_INFO,"ERROR SubFrame : %d",rxStartCnf->reserved);
      ysMsUtlPrntErrInfo(rxStartCnf->status);
   } /* end of if statement */

   RETVOID;

} /* end of ysMsUlmRxStartCnf */

/*
*
*       Fun:   ysMsUlmRxStartInd
*
*       Desc:  Handles the Rx Start Indication
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PUBLIC S16 ysMsUlmRxStartInd
(
PMSGIND        rxStartInd,
YsCellCb        *cellCb
)
{


   TRC2(ysMsUlmRxStartInd)

   /* Check the Status. If the status is NOK then
      print debug info and return */
   if(rxStartInd->status != 0)
   {
      /* Print the SubFrame number and the error information */
      RLOG1(L_INFO,"ERROR SubFrame : %d",rxStartInd->subFrameNum);
      ysMsUtlPrntErrInfo(rxStartInd->status);
   } /* end of if statement */

   YS_FREE_SDU(cellCb->ulEncL1Msgs[rxStartInd->subFrameNum].tfuCrcIndInfo);
   YS_FREE_SDU(cellCb->ulEncL1Msgs[rxStartInd->subFrameNum].tfuDatIndInfo);
   YS_FREE_SDU(cellCb->ulEncL1Msgs[rxStartInd->subFrameNum].rachIndInfo);
   YS_FREE_SDU(cellCb->ulEncL1Msgs[rxStartInd->subFrameNum].dlCqiIndInfo);
   YS_FREE_SDU(cellCb->ulEncL1Msgs[rxStartInd->subFrameNum].srsIndInfo);
   YS_FREE_SDU(cellCb->ulEncL1Msgs[rxStartInd->subFrameNum].ulCqiIndInfo);
   YS_FREE_SDU(cellCb->ulEncL1Msgs[rxStartInd->subFrameNum].harqIndInfo);
   YS_FREE_SDU(cellCb->ulEncL1Msgs[rxStartInd->subFrameNum].srIndInfo);
   YS_FREE_SDU(cellCb->ulEncL1Msgs[rxStartInd->subFrameNum].tmAdvIndInfo);

   /* HARQ */
   cellCb->isCrcExptd[rxStartInd->subFrameNum] = FALSE;
#ifdef RG_ULSCHED_AT_CRC
   cellCb->crcSent[rxStartInd->subFrameNum] = FALSE;
#endif

   RLOG_NULL(L_UNUSED,"RXSTART_IND at (%d) (%d) RXSTART_IND_time (%d) (%d) :", cellCb->timingInfo.sfn,
            cellCb->timingInfo.subframe, rxStartInd->frameNumber, rxStartInd->subFrameNum);
   /* Data is about to come. Initialize the data structure */

   /*Invoke the Simulator for the UL handling */

   RETVALUE(ROK);
} /* end of ysMsUlmRxStartInd */


#ifndef TFU_UPGRADE
PRIVATE Void ysMsResetUeLst
(
U16    *countRef,
YsUeCb *ueLst[],
U8     subframe
)
{
   U16  count = *countRef;
   while (count--)
   {
      YsUeCb         *ueCb      = ueLst[count];
      YsUeSubFrInfo  *subFrInfo = &ueCb->ueSubFrInfo[subframe];
      subFrInfo->schPres = 0;
      subFrInfo->onPucch = FALSE;
   }
   *countRef = 0;
}
#endif

/*
*
*       Fun:   ysMsUlmRxEndIndAtRxSdu
*
*       Desc:  Handles the Rx End Indication at CRC reception
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PUBLIC Void ysMsUlmRxEndIndAtRxSdu
(
CmLteTimingInfo rxEndTimingInfo,
YsCellCb        *cellCb
)
{
   TfuCrcIndInfo     *crcIndInfo;
#ifndef RG_ULSCHED_AT_CRC
   TfuDatIndInfo     *datIndInfo;
#endif
#ifndef TFU_UPGRADE
   TfuDlCqiIndInfo   *dlCqiIndInfo;
#else
   TfuRawCqiIndInfo  *dlCqiIndInfo;
   //TfuSrsIndInfo     *srsIndInfo;
#endif
   TfuUlCqiIndInfo   *ulCqiIndInfo;
#ifndef DLHQ_RTT_OPT
   TfuHqIndInfo      *harqIndInfo;
#endif
   TfuSrIndInfo      *srIndInfo;
   TfuTimingAdvIndInfo *tmAdvIndInfo;
   TfuPucchDeltaPwrIndInfo *pucchDeltaPwrIndInfo;

#ifndef TFU_UPGRADE
   YsSubFrInfo       *ysSubFrInfo;
   YsUeLst           *ueLst;
   YsUeLst          *ueLst;
#endif /* TFU_UPGRADE */
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC2(ysMsUlmRxEndIndAtRxSdu)

    /* HARQ_DBG: timing */
   RLOG_NULL(L_UNUSED,"RXEND_IND at (%d) (%d) RXEND_IND_time (%d) (%d) : ", cellCb->timingInfo.sfn,
            cellCb->timingInfo.subframe, rxEndTimingInfo.sfn, rxEndTimingInfo.subframe);


   crcIndInfo = cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].tfuCrcIndInfo;
   dlCqiIndInfo = cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].dlCqiIndInfo;
   //srsIndInfo = cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].srsIndInfo;
   ulCqiIndInfo = cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].ulCqiIndInfo;
#ifndef DLHQ_RTT_OPT
   harqIndInfo = cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].harqIndInfo;
#endif
   srIndInfo = cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].srIndInfo;
   tmAdvIndInfo = cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].tmAdvIndInfo;
   pucchDeltaPwrIndInfo = cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].pucchDeltaPwrIndInfo;
#ifndef TFU_UPGRADE
   ysSubFrInfo = &cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].ysSubFrInfo;
   /* - Ue Specific Sub Frame Info -*/
   ueLst = &ysSubFrInfo->ueLst;
   ysMsResetUeLst(&ueLst->numPusch, ueLst->puschLst, rxEndTimingInfo.subframe);
   ysMsResetUeLst(&ueLst->numPucch, ueLst->pucchLst, rxEndTimingInfo.subframe);
   ysMsResetUeLst(&ueLst->numSrs, ueLst->srsLst, rxEndTimingInfo.subframe);
   /* - Cell Specific Sub Frame Info -*/
   cmMemset((U8*)ysSubFrInfo, 0, sizeof(YsSubFrInfo));
#endif

   /* Send the CRC Indication to MAC for the corresponding subframe */
   if (crcIndInfo != NULLP)
   {
      if(crcIndInfo->crcLst.count > 0)
      {
         
         /*71827: If a second CRC Indication for the subframe is erroneously being generated to MAC, stop it*/
          if(cellCb->crcSent[cellCb->timingInfo.subframe] == TRUE)
          {
             MSPD_ERR("CRC already sent for this subframe\n");
         YS_FREE_SDU(crcIndInfo);
          }
         else
         {
             /*starting Task*/
             SStartTask(&startTime, PID_CRC_IND_REAL);
             ysSendCrcToMac(cellCb, crcIndInfo);
             cellCb->isCrcExptd[cellCb->timingInfo.subframe] = FALSE;
#ifdef RG_ULSCHED_AT_CRC
             cellCb->crcSent[cellCb->timingInfo.subframe] = TRUE;
#endif

             /*stopping Task*/
             SStopTask(startTime, PID_CRC_IND_REAL);
         }
      }
      else
      {
         YS_FREE_SDU(crcIndInfo);
      }/* end of else part */
   }

#ifndef RG_ULSCHED_AT_CRC
   /* Defer ULSCH Processing post SCH DL and UL TTI processing */
   datIndInfo = cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].tfuDatIndInfo;
   /* Send the Data Indication to MAC for the corresponding subframe */
   if (datIndInfo != NULLP)
   {
      if(datIndInfo->datIndLst.count > 0)
      {
         YsUiTfuDatInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, datIndInfo);
      } /* end of if statement */
      else
      {
         YS_FREE_SDU(datIndInfo);
      }/* end of else part */
   }
#endif


    /* Send the DL CQI Indication
     to MAC for the corresponding subframe */
   if (dlCqiIndInfo != NULLP)
   {
#ifndef TFU_UPGRADE
      if(dlCqiIndInfo->dlCqiRptsLst.count > 0 )
      {
         YsUiTfuDlCqiInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, dlCqiIndInfo);
      } /* end of if statement */
#else
      if(dlCqiIndInfo->rawCqiRpt.count > 0 )
      {
         YsUiTfuRawCqiInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, dlCqiIndInfo);
      } /* end of if statement */
#endif
      else
      {
         YS_FREE_SDU(dlCqiIndInfo);
      }/* end of else part */
   }

#ifdef TFU_UPGRADE
   /* 
    * Temporary patch for SRS
    * Need to handle case when we have more than one rs_status report for SRS
    * i.e, when we have more than one UE's SRS report in same subframe
    */
#endif
   /* Send the DL CQI Indication
     to MAC for the corresponding subframe */
   if (ulCqiIndInfo != NULLP)
   {
      if(ulCqiIndInfo->ulCqiRpt.count > 0 )
      {
         YsUiTfuUlCqiInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, ulCqiIndInfo);
      } /* end of if statement */
      else
      {
         YS_FREE_SDU(ulCqiIndInfo);
      }/* end of else part */
   }

#ifndef DLHQ_RTT_OPT
    /* Send the HARQ Indication
     to MAC for the corresponding subframe */
   if (harqIndInfo != NULLP)
   {
      if(harqIndInfo->hqIndLst.count > 0 )
      {
         YsUiTfuHqInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, harqIndInfo);
      }
      else
      {
         YS_FREE_SDU(harqIndInfo);
      }/* end of else part */
   }
#endif
    /* Send the SR Indication
     to MAC for the corresponding subframe */
   if (srIndInfo != NULLP)
   {
      if(srIndInfo->srLst.count > 0 )
      {
         YsUiTfuSrInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, srIndInfo);
         //RLOG0(L_DEBUG,"SR Ind processed by MAC");

      } /* end of if statement */
      else
      {
         YS_FREE_SDU(srIndInfo);
      }/* end of else part */
   }

   if (tmAdvIndInfo != NULLP)
   {
      if (tmAdvIndInfo->timingAdvLst.count > 0 )
      {
         YsUiTfuTimingAdvInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, tmAdvIndInfo);
      }
      else
      {
         YS_FREE_SDU(tmAdvIndInfo);
      }
   }

   if (pucchDeltaPwrIndInfo != NULLP)
   {
      if (pucchDeltaPwrIndInfo->pucchDeltaPwrLst.count > 0)
      {
         YsUiTfuPucchDeltaPwrInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId,
          pucchDeltaPwrIndInfo);
      }
      else
      {
         YS_FREE_SDU(pucchDeltaPwrIndInfo);
      }
   }
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].tfuCrcIndInfo = NULLP;
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].tfuDatIndInfo = NULLP;
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].dlCqiIndInfo = NULLP;
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].srsIndInfo = NULLP;
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].ulCqiIndInfo = NULLP;
#ifndef DLHQ_RTT_OPT
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].harqIndInfo = NULLP;
#endif
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].srIndInfo = NULLP;
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].tmAdvIndInfo = NULLP;
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].pucchDeltaPwrIndInfo = NULLP;
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].rxSduPres = FALSE;
#ifndef TFU_UPGRADE
   cellCb->ulEncL1Msgs[rxEndTimingInfo.subframe].ysSubFrInfo.numRxSduRcvd = 0;
#endif
   RETVOID;

} /* end of ysMsUlmRxEndIndAtRxSdu */

/*
*
*       Fun:   ysMsUlmRachRxEndInd
*
*       Desc:  Handles the Rx End Indication
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PUBLIC Void ysMsUlmRachRxEndInd
(
PMSGIND        rxEndInd,
YsCellCb        *cellCb
)
{

   TfuRaReqIndInfo   *rachIndInfo;

   RLOG_NULL(L_UNUSED,"RXEND_IND at (%d) (%d) RXEND_IND_time (%d) (%d) : ", cellCb->timingInfo.sfn,
            cellCb->timingInfo.subframe, rxEndInd->frameNumber, rxEndInd->subFrameNum);

   rachIndInfo = cellCb->ulEncL1Msgs[rxEndInd->subFrameNum].rachIndInfo;
   /* Send the RACH Indication
      to MAC for the corresponding subframe */
   if (rachIndInfo != NULLP)
   {
      if(!ysOneRachCompleted)
      {

         RLOG3(L_INFO,"Sending RA REQ to MAC at : (%d,%d) raRnti (%d)",
                  cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
                  rachIndInfo->rachInfo.raRnti);

         YsUiTfuRaReqInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, rachIndInfo);
         /* ysOneRachCompleted = 1;*/
      } /* end of if statement */
      else
      {
         RLOG2(L_INFO,"NO RA REQ to MAC freeup the memeory at : (%d) (%d) ",
                  cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
         YS_FREE_SDU(rachIndInfo);
      }
   }
   cellCb->ulEncL1Msgs[rxEndInd->subFrameNum].rachIndInfo = NULLP;

   RETVOID;
} /* end of ysMsUlmRachRxEndInd */

/*
*
*       Fun:   ysMsUlmRxEndInd
*
*       Desc:  Handles the Rx End Indication
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PUBLIC Void ysMsUlmRxEndInd
(
PMSGIND        rxEndInd,
YsCellCb        *cellCb
)
{

   CmLteTimingInfo rxEndTiming;
#ifndef TFU_UPGRADE
   U8              numPuschCh;
#endif


   rxEndTiming.sfn = rxEndInd->frameNumber;
   rxEndTiming.subframe = rxEndInd->subFrameNum;

#ifndef TFU_UPGRADE
   numPuschCh = cellCb->ulEncL1Msgs[rxEndTiming.subframe].ysSubFrInfo.numCh - cellCb->ulEncL1Msgs[rxEndTiming.subframe].ysSubFrInfo.numCtrl;
   if (numPuschCh != cellCb->ulEncL1Msgs[rxEndTiming.subframe].ysSubFrInfo.numRxSduRcvd)   {
     stop_printf("Missed some PUSCH SDU @ rxEndtime(%d,%d) @ celltime (%u,%u): exp(%u) rcvd(%u)\n",
         rxEndTiming.sfn, rxEndTiming.subframe,
         cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
         numPuschCh,cellCb->ulEncL1Msgs[rxEndTiming.subframe].ysSubFrInfo.numRxSduRcvd);
   }
#endif

   ysMsUlmRxEndIndAtRxSdu(rxEndTiming, cellCb);
   RETVOID;
} /* end of ysMsUlmRxEndInd */

/*
*
*       Fun:   ysMsGetUlSdu 
*
*       Desc:  Converts the uplink SDU passed from PHY into mBuf. 
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

#ifdef YS_MS_ULZBC
PRIVATE Void ysMsGetUlSdu
(
Buffer      **mBuf,
PRXSDUIND   rxSduInd,
U16         index
)
{
#if defined (TL_ALLOC_ICC_MEM) && !defined (INTEL_ALLOC_WLS_MEM)
   ZBC_LIST_ITEM pZbcListLocal[2];
   PZBC_LIST_ITEM pZbcApi;
   void* ysIccHandle;
#endif
   Data* ulPdu;
   U32 ulPduSize;

#ifdef T2K_MEM_LEAK_DBG
   char* file = __FILE__;
   U32 line = __LINE__;
#endif

#if defined (TL_ALLOC_ICC_MEM) && !defined (INTEL_ALLOC_WLS_MEM)

   /*getting PTR to ZBC APi array from RxSdu indication getting from linked
    * list*/
   pZbcApi = (PZBC_LIST_ITEM)((unsigned int)rxSduInd + sizeof(RXSDUIND));

   /*getting Rx Sdu data*/
   pZbcListLocal[0].pMsg = pZbcApi->pMsg;
   pZbcListLocal[0].MsgSize = pZbcApi->MsgSize;
   pZbcListLocal[1].pMsg = NULL;
   pZbcListLocal[1].MsgSize = 0;

   /*getting already opened ICC handle*/
   ysIccHandle = ssGetIccHdl(ysCb.ysInit[index].region); 

   /*TL_CacheInvalidate (ysIccHandle, pZbcListLocal);*/

   /*getting virtual address of Rx Sdu data for future processing*/
   ulPdu = (Data*) TL_PA2VA (ysIccHandle, (void*)pZbcApi->pMsg);
   ulPduSize = pZbcApi->MsgSize;
#ifdef T2K_MEM_LEAK_DBG
   if(ROK != SAttachPtrToBufNew(ysCb.ysInit[index].region,
            ysCb.ysInit[index].pool,
            ulPdu,
            ulPduSize,
            mBuf,
            __FILE__,
            __LINE__))
#else
    if(ROK != SAttachPtrToBuf(ysCb.ysInit[index].region,
            ysCb.ysInit[index].pool,
            ulPdu,
            ulPduSize,
            mBuf, TRUE))
#endif
   {
      RLOG0(L_FATAL, "Adding of Uplink data to Buffer failed\n");
   }
   CM_SAVE_MBUF_FILELINE(*mBuf);
#ifdef T2K_MEM_LEAK_DBG
   InsertToT2kMemLeakInfo(ulPdu - ((U32)ulPdu % 512),ulPduSize,__LINE__,__FILE__);
#endif
#else
   Data* readPtr;
   //U32   availMem = 0;

   ulPdu     = ((Data *)rxSduInd - sizeof(MAC2PHY_QUEUE_EL));
   readPtr   = (Data *) ((U64)rxSduInd + sizeof(RXSDUIND) - 4);
   ulPduSize = ((rxSduInd->numBitsRx + 7) >> 3);

   if(ROK != SAttachWlsPtrToMBuf(ysCb.ysInit[index].region,
            ysCb.ysInit[index].pool,
            ulPdu,
            YS_WLS_BFR_SZ,
            readPtr,
            ulPduSize,
            mBuf, TRUE))
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"Adding of Uplink data to Buffer failed \n");
   }
#endif

   RETVOID;


}
#endif
/*
*
*       Fun:   ysMsPrcUlSchSduInd
*
*       Desc:  Processes the UL_SCH SDU Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsPrcUlSchSduInd
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti	    rnti
)
{
   S16         ret;
   TfuDatInfo *datInfo;
#ifndef YS_MS_ULZBC
   U16         lenInBytes;
#endif
   //Data        incoming_lcid = 0;
#ifdef MSPD_MLOG
   VOLATILE U32     startTime = 0;
#endif
   TfuDatIndInfo   *datIndInfo = cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].tfuDatIndInfo;
   U16             indx = cellCb->cellId - CM_START_CELL_ID;
   TRC2(ysMsPrcUlSchSduInd)
   /*starting Task*/
#ifdef MSPD_MLOG
   SStartTask(&startTime, PID_ysMsPrcUlSchSduInd);
#endif

#if 0
#ifndef YS_MS_ULZBC 
   EXTERN S16 rgTOMDatIndOpt
   (
   PRXSDUIND	   rxSduInd,
   YsCellCb 	   *ysCellCb,
   CmLteRnti	   rnti
   );

   if (rgTOMDatIndOpt(rxSduInd, cellCb, rnti) == ROK)
   {
      RETVALUE(ROK);
   }
#endif
#endif

   ret = ROK;
   datInfo = NULLP;

   RLOG_NULL(L_UNUSED, "R PUSCH SDU(%d)", rxSduInd->numBitsRx);
   if(datIndInfo == NULLP)
   {
      /*This is a normal scenario, we are not going to allocate the structure
         * unless we need it.We are here means that this is the first SDU
         * recieved for this SF. Time to allocate the structure */

      /* Allocate memory for Data Indication Info */
       ret = ysUtlAllocEventMem((Ptr *)&datIndInfo,
               sizeof(TfuDatIndInfo), indx,  __FUNCTION__, __LINE__);
       if(ret != ROK)
       {
          RLOG0(L_FATAL,"ysMsPrcUlSchSduInd(): Memory allocation failed for DatInd");
          RETVALUE(RFAILED);
       } /* end of if statement */
       cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].tfuDatIndInfo = datIndInfo;

       /* Initialize the Data Indication List */
       cmLListInit(&(datIndInfo->datIndLst));

       datIndInfo->cellId = cellCb->cellId;
       datIndInfo->timingInfo.hfn = cellCb->timingInfo.hfn;
       datIndInfo->timingInfo.sfn = rxSduInd->frameNum;
       datIndInfo->timingInfo.subframe = rxSduInd->subFrameNum;
   } /* end of datIndInfo == NULLP */
   {
#ifndef YS_MS_ULZBC
      lenInBytes = (U16)(rxSduInd->numBitsRx >> 3);
#endif
      if (ysUtlGetEventMem(&datIndInfo->memCp, sizeof(TfuDatInfo),
            (Ptr *)&datInfo) != ROK)
      {
         RLOG0(L_ERROR,"ysMsPrcUlSchSduInd(): ysUtlGetEventMem returned failure");
         MSPD_ERR("ysUtlGetEventMem returned failure\n");
         RETVALUE (RFAILED);
      } /* end of if statement */



      datInfo->rnti = rnti;
#ifndef YS_MS_ULZBC 
#ifndef TENB_RTLIN_CHANGES
      SGetMsg(CL_REGION, 2, &datInfo->mBuf);
#else
      YS_MS_ALLOC_BUF(datInfo->mBuf, indx);
#if 0	/* comment by lichangwu, 2017-10-31 */
      {
         extern U32 ulIccAlocCnt;
         extern U32 gMemoryAlarm;
         extern U32 totalUlPkts;
         totalUlPkts++;
         if(gMemoryAlarm)
            ulIccAlocCnt++;

      }
#endif
#endif
#endif
#ifdef YS_MS_ULZBC
      ysMsGetUlSdu(&datInfo->mBuf, rxSduInd, indx);
#endif
      if(NULLP == datInfo->mBuf)
      {
         RLOG_ARG0(L_ERROR,DBG_CRNTI,rnti,"SGetMsg returned failure");
         MSPD_ERR("SGetMsg returned failure\n");
         RETVALUE (RFAILED);
      }

#ifndef YS_MS_ULZBC 
      ret = SAddPstMsgMult((Data*)&(rxSduInd->pRxSdu), lenInBytes, datInfo->mBuf);
      if(ret != ROK)
      {
         RLOG_ARG0(L_ERROR,DBG_CRNTI,rnti,"SAddPstMsgMult returned failure");
         YS_MS_FREE_BUF(datInfo->mBuf);
         RETVALUE (RFAILED);
      } /* end of if statement */
#endif
      /*RLOG1(L_DEBUG,"Received PUSCH SDU (%x)", ((U8)rxSduInd->pRxSdu));*/

      /* SExamMsg (&incoming_lcid, datInfo->mBuf, 1);*/
#if 0
      /*Right now UL RRC are being sent from RRC layer.
         * So commenting it here*/
#ifdef RSYS_WIRESHARK
      ysSendMsgToWireShark(datInfo->mBuf,datInfo->rnti,datIndInfo->timingInfo.subframe);
#endif
#endif
#ifdef XXX_TRC_MBUF
      PRIVATE U32 trcCount = 0;
      if (++trcCount > 1000)
      {
         trcCount = 0;
      }
      if (trcCount == 10)
      {
         PRIVATE U32  gDLTrcID = 1;    /* unused for alignment, add by lichangwu */
         gDLTrcID+=2;
         SET_TRC_MBUF(datInfo->mBuf, gDLTrcID);
      }
#endif
      datInfo->lnk.node = (PTR)datInfo;

      cmLListAdd2Tail(&(datIndInfo->datIndLst), &(datInfo->lnk));

   } /* end of else statement */
   /*stopping Task*/
#ifdef MSPD_MLOG
   SStopTask(startTime, PID_ysMsPrcUlSchSduInd);
#endif
   RETVALUE(ret);
} /* end of ysMsPrcUlSchSduInd */

/*
*
*       Fun:   ysMsUpdCrcInd
*
*       Desc:  Update Crc Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsUpdCrcInd
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		rnti
)
{
   S16         ret;
   TfuCrcInfo  *crcInfo;
   TfuCrcIndInfo   *crcIndInfo = cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].tfuCrcIndInfo;
   U16         indx = cellCb->cellId - CM_START_CELL_ID;
   TRC2(ysMsUpdCrcInd)

   ret = ROK;
   crcInfo = NULLP;

   if(NULLP == crcIndInfo)
   {
      /* Allocate memory for the structures corresponding to the sub frame.
         rxStartInd->reserved has the subframe number */
      /* Allocate memory for CRC Indication Info */
       ret = ysUtlAllocEventMem((Ptr *)&crcIndInfo,
               sizeof(TfuCrcIndInfo), indx, __FUNCTION__,__LINE__);
       if(ret != ROK)
       {
          RLOG0(L_FATAL,"ysMsUpdCrcInd(): Memory allocation failed for CrcInd");
          RETVALUE(RFAILED);
       } /* end of if statement */

       cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].tfuCrcIndInfo = crcIndInfo;
       cmLListInit(&(crcIndInfo->crcLst));

       crcIndInfo->cellId = cellCb->cellId;
       crcIndInfo->timingInfo.sfn = rxSduInd->frameNum;
       crcIndInfo->timingInfo.subframe = rxSduInd->subFrameNum;
   }
   {
      if (ysUtlGetEventMem(&crcIndInfo->memCp, sizeof(TfuCrcInfo),
            (Ptr *)&crcInfo) != ROK)
      {
         RLOG_ARG0(L_FATAL,DBG_CRNTI,rnti,"ysMsUpdCrcInd(): ysUtlGetEventMem returned failure");
         MSPD_ERR("ysUtlGetEventMem returned failure\n");
         RETVALUE (RFAILED);
      } /* end of if statement */



     crcInfo->rnti = rnti;
#ifdef TFU_ALLOC_EVENT_NO_INIT     
     crcInfo->rv.pres = 0;
     crcInfo->isDtx = 0;
#endif   
      if(rxSduInd->status)
      {
          crcInfo->isFailure = TRUE;
#ifdef HARQ_STATISTICS
     ulNacks++;
#endif
#ifdef MSPD_TDD_DBG
          rgStats.ulNackCount++;
#endif
          /* begin: add by luopeng for ue stk log to web */ 
          if(crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1] >= 0 && crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1] < WEB_LOG_ARRAY_COUNT)
          {
             rgStats.webUeLog[cellCb->cellId - 1][crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1]].rnti = crcInfo->rnti;
             rgStats.webUeLog[cellCb->cellId - 1][crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1]].ulNackCnt ++;
           }
           /* end: add by luopeng for ue stk log to web */ 

      } /* end of if statement */
      else
      {
          crcInfo->isFailure = FALSE;
#ifdef HARQ_STATISTICS
     ulAcks++;
#endif
#ifdef MSPD_TDD_DBG
          rgStats.ulAckCount++;
#endif
      } /* end of else part */
      /* begin: add by luopeng for ue stk log to web */ 
	  if(crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1] >= 0 && crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1] < WEB_LOG_ARRAY_COUNT)
	  {
		 rgStats.webUeLog[cellCb->cellId - 1][crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1]].rnti = crcInfo->rnti;
		 rgStats.webUeLog[cellCb->cellId - 1][crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1]].ulAckCnt++;
	  }
	  /* end: add by luopeng for ue stk log to web */ 

      crcInfo->lnk.node = (PTR)crcInfo;

      cmLListAdd2Tail(&(crcIndInfo->crcLst), &(crcInfo->lnk));

   } /* end of else statement */


   RETVALUE(ret);
} /* end of ysMsUpdCrcInd*/

#ifdef LTE_ADV
#ifndef TFU_TDD
/*
*
*       Fun:   ysMsPrcHarq1bCsInd
*
*       Desc:  Processes the 1B with CS HARQ Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsPrcHarq1bCsInd
(
U8                *hqBuf,
TfuHqFdbk         *is1bCsAck
)
{
   /* The convention used for the harq-ack data is as follows:
    * 0000 = dtx
    * 0001 = Ack
    * 0010 = Nack
    * 0100 = dtx
    * 0110 = dtx/nack[36.213][36.213][36.213][36.213]
    */
   /*typedef enum
    * {
    *    TFU_HQ_ACK=1,
    *    TFU_HQ_NACK,
    *    TFU_HQ_ACK_OR_NACK,
    *    TFU_HQ_DTX,
    *    TFU_HQ_ACK_OR_DTX,
    *    TFU_HQ_NACK_OR_DTX,
    *    TFU_HQ_ACK_OR_NACK_OR_DTX
    *    } TfuHqFdbk;
    */                     
   U8       temp[4];/*Max4 nibbles*/
   U8       i = 0;
   TRC2(ysMsPrcHarq1bCsInd)
   //if (count == 10)
   {
//      MSPD_DBG("hqBuf[0] = %x   hqBuf[1] = %x \n", hqBuf[0], hqBuf[1]);
   }
   /*Data is in the form of little endian. MSB is Primary and LSB is Secondary*/
   temp[0] = hqBuf[1]   >> 4; 
   temp[1] = hqBuf[1] & 0x0F ; 
   temp[2] = hqBuf[0]   >> 4; 
   temp[3] = hqBuf[0] & 0x0F ; 
  
   for(i = 0; i < 4; i++)
   {
      switch(temp[i])
      {
         case 0x00:
         case 0x04:
            {
               is1bCsAck[i] = TFU_HQ_DTX;
            }
            break;
         case 0x01:
            {
               is1bCsAck[i] = TFU_HQ_ACK;
            }
            break;
         case 0x02:
            {
               is1bCsAck[i] = TFU_HQ_NACK;
            }
            break;
         case 0x06:
            {
               is1bCsAck[i] = TFU_HQ_NACK_OR_DTX;
            }
            break;
         default:
            {
               is1bCsAck[i] = TFU_HQ_ACK_OR_NACK_OR_DTX;
            }
      } 
   }
   RETVALUE(ROK);
}

/*
*
*       Fun:   ysMsPrcHarq1bCsSplBundInd
*
*       Desc:  Processes the 1B with CS HARQ Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsPrcHarq1bCsSplBundInd
(
U8                *hqBuf,
TfuHqFdbk         *is1bCsAck
)
{


   TRC2(ysMsPrcHarq1bCsSplBundInd)
   /* harq + Sr */
   /*As per disc with Intel
    * mix ack0+ack1 and ack2+ack3
    * 0x6 means ack on both cell
    * 0x4 means ack on 1st cell
    * 0x2 means ack on 2nd cell
    * 0x0 meana nack on both cell*/


   switch(hqBuf[1])
   {
      case 0x06:
         {/* ACK on both the cell */
            is1bCsAck[0] = TFU_HQ_ACK;
            is1bCsAck[1] = TFU_HQ_ACK;
            is1bCsAck[2] = TFU_HQ_ACK;
            is1bCsAck[3] = TFU_HQ_ACK;
         }
         break;
      case 0x04:
         { /* ACK on first cell */
            is1bCsAck[0] = TFU_HQ_ACK;
            is1bCsAck[1] = TFU_HQ_ACK;
            is1bCsAck[2] = TFU_HQ_NACK;
            is1bCsAck[3] = TFU_HQ_NACK;
         }
         break;
      case 0x02:
         {/* Ack on second cell */
            is1bCsAck[0] = TFU_HQ_NACK;
            is1bCsAck[1] = TFU_HQ_NACK;
            is1bCsAck[2] = TFU_HQ_ACK;
            is1bCsAck[3] = TFU_HQ_ACK;
         }
         break;
      case 0x00:
         {/* NACK on both the cells */
            is1bCsAck[0] = TFU_HQ_NACK;
            is1bCsAck[1] = TFU_HQ_NACK;
            is1bCsAck[2] = TFU_HQ_NACK;
            is1bCsAck[3] = TFU_HQ_NACK;
         }
         break;
      default:
         {
         
            MSPD_LOG("\n Invalid Feedback received on Positive SR + F1BCS .Rcvd Value %d\n",hqBuf[1]);
         }
         break;
   }

   RETVALUE(ROK);
}

#endif
#endif /* LTE_ADV */
/*
*
*       Fun:   ysMsPrcHarqInd
*
*       Desc:  Processes the HARQ Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsPrcHarqInd
(
YsCellCb        *cellCb,
CmLteTimingInfo *timingInfo,
U8              *hqBuf,
Bool            isPusch,
CmLteRnti       rnti,
U32             numHarqBits,
Bool            isSplBundling
)
{
   S16               ret = ROK;
   TfuHqInfo        *harqInfo = NULLP;
   U8                isAck = 0;
   U8                isAckCw2 = 0;
#ifndef TFU_TDD
#ifdef LTE_ADV
   U8                isAckCw3 = 0;
   U8                isAckCw4 = 0;
#endif
   TfuAckNackMode    ackNackMode = 0;
#endif
#ifdef LTE_ADV
#ifdef TFU_TDD
   TfuAckNackMode    ackNackMode = 0;
   U8                a;
#else
   TfuHqFdbk         is1bCsAck[TFU_MAX_HARQ_FDBKS];
#endif
#endif
   YsUeCb           *ueCb;
#ifndef TFU_UPGRADE
   CmLteTimingInfo   txsubframe;
#endif
#ifdef DLHQ_RTT_OPT
   CmLteTimingInfo   rxtime;
#endif
#ifdef TFU_TDD
   U8                pucchMVal = YsTddPucchMTable[cellCb->ulDlCfgIdx][timingInfo->subframe];
   U8                mIdx;
#ifdef CA_PHY
   U8                puschMVal;
#endif
#endif
   TfuHqIndInfo    *harqIndInfo;

   TRC2(ysMsPrcHarqInd)

   ueCb = ysMsCfgGetUe(cellCb, rnti);
   if (ueCb == NULLP)
   {
      RLOG_NULL(L_ERROR,DBG_CRNTI,rnti,"ysMsPrcHarqInd: UE doesnt exist");
      MSPD_ERR("UE[%d] noexist\n", rnti);
      RETVALUE (RFAILED);
   }

#ifdef DLHQ_RTT_OPT
   rxtime = (*timingInfo);
   YS_INCR_TIMING_INFO(rxtime, 1);
   if (!YS_TIMING_INFO_SAME(rxtime, cellCb->timingInfo))
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"Harq feedback for PHY time (%d, %d) received at CL at current time (%d, %d)\n", (*timingInfo).sfn, (*timingInfo).subframe, 
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
   }
#endif /* DLHQ_RTT_OPT */

   U16 indx = cellCb->cellId - CM_START_CELL_ID;

   harqIndInfo = cellCb->ulEncL1Msgs[timingInfo->subframe].harqIndInfo;
   if(harqIndInfo == NULLP)
   {
      ret = ysUtlAllocEventMem((Ptr *)&harqIndInfo, sizeof(TfuHqIndInfo), indx, __FILE__, __LINE__);
      if(ret != ROK)
      {
         RLOG_ARG0(L_FATAL,DBG_CRNTI,rnti,"ysMsPrcHarqInd(): Memory allocation failed for HqInd");
         RETVALUE(RFAILED);
      }
      cellCb->ulEncL1Msgs[timingInfo->subframe].harqIndInfo = harqIndInfo;

      cmLListInit(&(harqIndInfo->hqIndLst));

      harqIndInfo->cellId = cellCb->cellId;
      harqIndInfo->timingInfo = *timingInfo;
   }
   {
#ifndef TFU_TDD
   static unsigned int ackCw2Cnt = 0;
   static unsigned int nackCw2Cnt = 0;
   static unsigned int ackCnt = 0;
   static unsigned int nackCnt = 0;
#ifndef LTE_ADV
   if (!isPusch)
   {
      isAck = (hqBuf[1] & 0x04)? TRUE: FALSE;
      if (numHarqBits == 2)
         isAckCw2 = (hqBuf[1] & 0x02)? TRUE: FALSE;
      else
         isAckCw2 = isAck;
   }
   else
   {
      isAck = (*hqBuf & 0x80) ? TRUE:FALSE;
      if (numHarqBits == 2)
         isAckCw2 = (*hqBuf & 0x40) ? TRUE:FALSE;
      else
         isAckCw2 = isAck;
   }

#else      
       ackNackMode = ueCb->harqRecpReqInfo[timingInfo->subframe].ackNackMode;

#ifdef CA_DBG    
      MSPD_DBG("AckNackMode = %d, isPusch = %d , timingInfo->subframe = %d \n", ackNackMode, isPusch, 
            timingInfo->subframe);
#endif 
      if(isPusch)
      {/* Harq on PUSCH */
         isAck    = (*hqBuf & 0x80) ? TRUE:FALSE;
         isAckCw2 = (*hqBuf & 0x40) ? TRUE:FALSE;
         isAckCw3 = (*hqBuf & 0x20) ? TRUE:FALSE;
         isAckCw4 = (*hqBuf & 0x10) ? TRUE:FALSE;
      }
      else/* Only Harq on PUCCH */
      {     
         switch(ackNackMode)
         {
            case TFU_UCI_FORMAT_1A_1B:
               {
                  isAck = (hqBuf[1] & 0x04)? TRUE: FALSE;
                  if (numHarqBits == 2)
                  {
                     isAckCw2 = (hqBuf[1] & 0x02)? TRUE: FALSE;
                  }
                  else
                  {
                     isAckCw2 = isAck;
                  }
               }
               break;
            case TFU_UCI_FORMAT_1B_CS:
               {
                  if(isSplBundling)
                  {
                     ysMsPrcHarq1bCsSplBundInd(hqBuf, is1bCsAck);
                  }
                  else
                  {
                     ysMsPrcHarq1bCsInd(hqBuf, is1bCsAck);
                  }
                  isAck    = is1bCsAck[0];
                  isAckCw2 = is1bCsAck[1];
                  isAckCw3 = is1bCsAck[2];
                  isAckCw4 = is1bCsAck[3];
                  /* Reset the fdd Ack nack Feedback Mode */
                  ueCb->harqRecpReqInfo[timingInfo->subframe].ackNackMode = TFU_UCI_FORMAT_1A_1B;
               }
               break;
            case TFU_UCI_FORMAT_3:
               {
                  /* TODO */
               }
               break;
            default:
               {
                  YS_DBG_ERR((_ysp, "ysMsPrcHarqInd WRONG Format Seleted \n"));
               }
         }
      }
#endif/*CA_PHY*/
#else
#if 0 //def MSPD_TDD
      MSPD_DBG("\nHarq Ind in CL , hqBuf %d harqTime %d %d cell time %d %d rnti %d",
            *hqBuf, timingInfo->sfn, timingInfo->subframe,
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,rnti );
      printf("\nPucch Harq Ind in CL , hqBuf %d harqTime %d %d cell time %d %d rnti %d",
            *hqBuf, timingInfo->sfn, timingInfo->subframe, 
            ellCb->timingInfo.sfn, cellCb->timingInfo.subframe,rnti );
#endif

#ifdef CA_PHY
      ackNackMode = ueCb->harqRecpReqInfo[timingInfo->subframe].ackNackMode;
#endif
      if (ysUtlGetEventMem(&harqIndInfo->memCp, sizeof(TfuHqInfo),
               (Ptr *)&harqInfo) != ROK)
      {
         RLOG_ARG0(L_ERROR,DBG_CRNTI,rnti,"ysMsPrcHarqInd(): ysUtlGetEventMem returned failure");
         
         RETVALUE (RFAILED);
      } /* end of if statement */

      cmMemset ((U8 *)harqInfo, 0, sizeof(TfuHqInfo));

      harqInfo->M = pucchMVal;
      harqInfo->rnti = rnti;

      if (!isPusch)
      {
         if(isSplBundling)
         {
            U8 numOfAcks;
            harqInfo->hqFdbkMode = TFU_ACK_NACK_SPECIAL_BUNDLING;
            harqInfo->isPusch = FALSE;
            numOfAcks = mapTblFrmHarqToNumbrOfAcks[(hqBuf[1] & 0x06) >> 1]; 
            harqInfo->isAck[0] = numOfAcks;
#ifdef DLHQ_STATS
         if (statsCntCl >= MAX_STATS_CNT) statsCntCl = 0;
         dlHqStatsCl[statsCntCl].sfn = harqIndInfo->timingInfo.sfn; 
         dlHqStatsCl[statsCntCl].sf = harqIndInfo->timingInfo.subframe; 
         dlHqStatsCl[statsCntCl].mode = 3;//Special
         dlHqStatsCl[statsCntCl].M = 0;
         dlHqStatsCl[statsCntCl].o0 = ((hqBuf[1] & 0x06) >> 1); 
         dlHqStatsCl[statsCntCl].o1 = 0; 
         dlHqStatsCl[statsCntCl].o2 = 0; 
         dlHqStatsCl[statsCntCl].o3 = 0; 
         dlHqStatsCl[statsCntCl].ack0 = harqInfo->isAck[0]; 
         dlHqStatsCl[statsCntCl].ack1 = harqInfo->isAck[1]; 
         dlHqStatsCl[statsCntCl].ack2 = harqInfo->isAck[2]; 
         dlHqStatsCl[statsCntCl].ack3 = harqInfo->isAck[3]; 
         dlHqStatsCl[statsCntCl].ack4 = harqInfo->isAck[4]; 
         dlHqStatsCl[statsCntCl].ack5 = harqInfo->isAck[5]; 
         dlHqStatsCl[statsCntCl].ack6 = harqInfo->isAck[6]; 
         dlHqStatsCl[statsCntCl].ack7 = harqInfo->isAck[7];
         statsCntCl++; 
#endif
         }
#ifdef CA_PHY
         /* For CA PHY*/
         else if (ackNackMode == TFU_ACK_NACK_CHANNEL_SELECTION)
         {
            /* byte0 XXXX XXR1R2 ?R1R2 resource
               byte1 XXXX XA1A2X  A1A2 ACK Bits*/
            U8 n1pucch = ((*hqBuf) & 0x3);
            U8 b0 = (hqBuf[1] >> 2) & 0x01;  
            U8 b1 = (hqBuf[1] >> 1) & 0x01;
            U32 idx;
            YsDlFdbkInfo fdbkInfo;
            a = ueCb->harqRecpReqInfo[timingInfo->subframe].a;
            harqInfo->isPusch = FALSE;
#ifdef CHAN
STKLOG(STK_MD_YS,STK_LOG_INFO,"\n DEBUG: [%d:%d] hqBuf:%d%d n1pucch:%d b0:%d b1:%d pucchMVal:%d A:%d",timingInfo->sfn,timingInfo->subframe
		,(U8)hqBuf[0],(U8)hqBuf[1],n1pucch,b0,b1,pucchMVal,a);
#endif
            if (pucchMVal == 1)
            {
               /* For a = 4 fetch from table with M=2 */
               if (a == 4)
               {
                  fdbkInfo = ysDlFdbkForM234[0][n1pucch][b0][b1];
               }
               else
               {
                  fdbkInfo = ysDlFdbkForM1[a-2][n1pucch][b0][b1];
               }
            }
            else
            {
               fdbkInfo = ysDlFdbkForM234[pucchMVal-2][n1pucch][b0][b1];
            }
            harqInfo->isAck[0] = fdbkInfo.fdbk0;  
            harqInfo->isAck[1] = fdbkInfo.fdbk1;  
            harqInfo->isAck[2] = fdbkInfo.fdbk2;  
            harqInfo->isAck[3] = fdbkInfo.fdbk3;  
            harqInfo->isAck[4] = fdbkInfo.fdbk4;  
            harqInfo->isAck[5] = fdbkInfo.fdbk5;  
            harqInfo->isAck[6] = fdbkInfo.fdbk6;  
            harqInfo->isAck[7] = fdbkInfo.fdbk7;
            //Chandan
            /* Making ACK_OR_DTX as ACK */
            for (idx=0;idx < 8;idx++)
            {
               if(harqInfo->isAck[idx] == TFU_HQ_ACK_OR_DTX)
               {
                  harqInfo->isAck[idx] = TFU_HQ_ACK;
               }
            } 
#ifdef DLHQ_STATS
         if (statsCntCl >= MAX_STATS_CNT) statsCntCl = 0;
         dlHqStatsCl[statsCntCl].sfn = harqIndInfo->timingInfo.sfn; 
         dlHqStatsCl[statsCntCl].sf = harqIndInfo->timingInfo.subframe; 
         dlHqStatsCl[statsCntCl].mode = 1;//PUCCH
         dlHqStatsCl[statsCntCl].M = pucchMVal;
         dlHqStatsCl[statsCntCl].o0 = n1pucch; 
         dlHqStatsCl[statsCntCl].o1 = 0; 
         dlHqStatsCl[statsCntCl].o2 = b0; 
         dlHqStatsCl[statsCntCl].o3 = b1; 
         dlHqStatsCl[statsCntCl].ack0 = harqInfo->isAck[0]; 
         dlHqStatsCl[statsCntCl].ack1 = harqInfo->isAck[1]; 
         dlHqStatsCl[statsCntCl].ack2 = harqInfo->isAck[2]; 
         dlHqStatsCl[statsCntCl].ack3 = harqInfo->isAck[3]; 
         dlHqStatsCl[statsCntCl].ack4 = harqInfo->isAck[4]; 
         dlHqStatsCl[statsCntCl].ack5 = harqInfo->isAck[5]; 
         dlHqStatsCl[statsCntCl].ack6 = harqInfo->isAck[6]; 
         dlHqStatsCl[statsCntCl].ack7 = harqInfo->isAck[7];
         statsCntCl++; 
#endif
         }
#endif
         else if((ueCb->ackNackMode == TFU_ACK_NACK_BUNDLING) || (pucchMVal == 1))
         {
            harqInfo->isAck[0] = (hqBuf[1] & 0x04)? TRUE: FALSE;
            isAck =   harqInfo->isAck[0];
            if (numHarqBits == 2)
            {
               harqInfo->isAck[1] = (hqBuf[1] & 0x02)? TRUE: FALSE;
               isAckCw2 =  harqInfo->isAck[1];
#if 1
               if(!isAck || !isAckCw2)
               {
                  //rgStats.harqNackCnt++;
               }
               else
               {
                  //rgStats.harqAckCnt++;
               }
#endif
            }
            else
            {
               isAckCw2 = isAck;
            }

         }
         else
         {
            /* TDD_TODO: Need to add support for M>1 multiplexing */ 
            for(mIdx = 0; mIdx < pucchMVal;mIdx++)
            {
               harqInfo->isAck[mIdx] = (*hqBuf & (0x80 >> mIdx)) ? TRUE:FALSE;
            }
         }
      }
      else
      {
#ifdef CA_PHY
         /* For CA PHY*/
         if (ackNackMode == TFU_ACK_NACK_CHANNEL_SELECTION)
         {
            U8 ulDai = ueCb->harqRecpReqInfo[timingInfo->subframe].ulDai;
            U8 o0 = (*hqBuf & 0x80) ? TRUE:FALSE; 
            U8 o1 = (*hqBuf & 0x40) ? TRUE:FALSE; 
            U8 o2 = (*hqBuf & 0x20) ? TRUE:FALSE;
            U8 o3 = (*hqBuf & 0x10) ? TRUE:FALSE;
            U32 idx;
            YsDlFdbkInfo puschHqFdbk;

            harqInfo->isPusch = TRUE;

            if (ulDai >= 3)
            {
               puschMVal = ulDai;
            }
            else
            {
               puschMVal = pucchMVal;
            }
            if (pucchMVal <= 2)
            {
               harqInfo->isAck[0] = o0;
               harqInfo->isAck[1] = o1;
               harqInfo->isAck[2] = o2;
               harqInfo->isAck[3] = o3;
            }
            else
            {
               puschHqFdbk = ysDlHqFdbkOnPusch[puschMVal-3][o0][o1][o2][o3];
               harqInfo->isAck[0] = puschHqFdbk.fdbk0;  
               harqInfo->isAck[1] = puschHqFdbk.fdbk1;  
               harqInfo->isAck[2] = puschHqFdbk.fdbk2;  
               harqInfo->isAck[3] = puschHqFdbk.fdbk3;  
               harqInfo->isAck[4] = puschHqFdbk.fdbk4;  
               harqInfo->isAck[5] = puschHqFdbk.fdbk5;  
               harqInfo->isAck[6] = puschHqFdbk.fdbk6;  
               harqInfo->isAck[7] = puschHqFdbk.fdbk7;  
            }
            for (idx = 0; idx<8;idx++)
            {
               if (harqInfo->isAck[idx] == TFU_HQ_ACK_OR_DTX)
               {
                  harqInfo->isAck[idx] = TFU_HQ_ACK;
               }
               if ((idx > 5) && (harqInfo->isAck[idx] == TFU_HQ_INVALID))
               {
                  harqInfo->isAck[idx] = TFU_HQ_ACK_OR_NACK_OR_DTX;
               }
            }
#ifdef DLHQ_STATS
         if (statsCntCl >= MAX_STATS_CNT) statsCntCl = 0;
         dlHqStatsCl[statsCntCl].sfn = harqIndInfo->timingInfo.sfn; 
         dlHqStatsCl[statsCntCl].sf = harqIndInfo->timingInfo.subframe; 
         dlHqStatsCl[statsCntCl].mode = 2;//PUSCH
         dlHqStatsCl[statsCntCl].M = puschMVal;
         dlHqStatsCl[statsCntCl].o0 = o0; 
         dlHqStatsCl[statsCntCl].o1 = o1; 
         dlHqStatsCl[statsCntCl].o2 = o2; 
         dlHqStatsCl[statsCntCl].o3 = o3; 
         dlHqStatsCl[statsCntCl].ack0 = harqInfo->isAck[0]; 
         dlHqStatsCl[statsCntCl].ack1 = harqInfo->isAck[1]; 
         dlHqStatsCl[statsCntCl].ack2 = harqInfo->isAck[2]; 
         dlHqStatsCl[statsCntCl].ack3 = harqInfo->isAck[3]; 
         dlHqStatsCl[statsCntCl].ack4 = harqInfo->isAck[4]; 
         dlHqStatsCl[statsCntCl].ack5 = harqInfo->isAck[5]; 
         dlHqStatsCl[statsCntCl].ack6 = harqInfo->isAck[6]; 
         dlHqStatsCl[statsCntCl].ack7 = harqInfo->isAck[7];
         statsCntCl++; 
#endif
         }
         else
#endif
         {
            if(ueCb->ackNackMode == TFU_ACK_NACK_BUNDLING)
            {
               harqInfo->isAck[0] = (*hqBuf & 0x80) ? TRUE:FALSE;
               if (numHarqBits == 2)
               {
                  harqInfo->isAck[1] = (*hqBuf & 0x40) ? TRUE:FALSE;
               }
               if(harqInfo->isAck[0] == TRUE)
               {
                  rgStats.bundlingAck[0]++;
               }
               if(harqInfo->isAck[1] == TRUE)
               {
                  rgStats.bundlingAck[1]++;
               }
               if(harqInfo->isAck[0] == FALSE)
               {
                  rgStats.bundlingNack[0]++;
               }
               if(harqInfo->isAck[1] == FALSE)
               {
                  rgStats.bundlingNack[1]++;
               }
            }
            else
            {
               /* TDD_TODO: Need to add support for M>1 multiplexing */ 
               for(mIdx = 0; mIdx < pucchMVal;mIdx++)
               {
                  harqInfo->isAck[mIdx] = (*hqBuf & (0x80 >> mIdx)) ? TRUE:FALSE;
               }
            }
         }
      }

#endif /* TFU_TDD */

#ifdef HARQ_STATISTICS
      if (isAck)
         dlAcks++;
      else
         dlNacks++;
#else
#ifndef TFU_TDD
      {
         if (isAck)
         {
            ++ackCnt;
         }
         else
         {
            ++nackCnt;
#if 0
            if ((cellCb->timingInfo.sfn % 1000 ==0) && (cellCb->timingInfo.subframe == 0)){
               RLOG_NULL(L_UNUSED,"CW1: Nacks/acks %u/%u",
                           nackCnt, ackCnt);
              //Sunil 
               printf("\n################### CW1:Nacks/acks %u/%u phytime(%u,%u) cltime(%u,%u)\n",nackCnt,                                  ackCnt,timingInfo->sfn, timingInfo->subframe, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
            }
#endif
         }
      }
      if (numHarqBits == 2)
      {
         if (isAckCw2)
         {
            ++ackCw2Cnt;
         }
	 else
	 {
	    ++nackCw2Cnt;
#if 0
            if ((cellCb->timingInfo.sfn % 1000 ==0) && (cellCb->timingInfo.subframe == 0))
            {
               MSPD_DBG("CW2: Nacks/acks %u/%u, nack at phytime(%u,%u) cltime(%u,%u)\n",
                     nackCw2Cnt, ackCw2Cnt, timingInfo->sfn, timingInfo->subframe,
                     cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
               //Sunil
               printf("\n############ CW2: Nacks/acks %u/%u, phytime(%u,%u) cltime(%u,%u)\n",
                     nackCw2Cnt, ackCw2Cnt, timingInfo->sfn, timingInfo->subframe,
                     cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
            }
#endif
         }
      }

      if (ysUtlGetEventMem(&harqIndInfo->memCp, sizeof(TfuHqInfo),
               (Ptr *)&harqInfo) != ROK)
      {
         RLOG_ARG0(L_ERROR,DBG_CRNTI,rnti,"ysMsPrcHarqInd(): ysUtlGetEventMem returned failure");
         MSPD_ERR("ysUtlGetEventMem returned failure\n");
         RETVALUE (RFAILED);
      } /* end of if statement */

#ifdef TFU_ALLOC_EVENT_NO_INIT
      harqInfo->noOfTbs = 0;
      harqInfo->isAck[0] = harqInfo->isAck[1] = 0;
#else
      cmMemset ((U8 *)harqInfo, 0, sizeof(TfuHqInfo));
#endif
      
#else
      /*TDD_TODO need to fill ackCw and ackCw2*/
#endif /* TFU_TDD */

      harqInfo->rnti = rnti;
      /* harqInfo->noOfTbs = YS_NUM_OF_TBS; MAC currently does not care about it */
#endif /* HARQ_STATISTICS */

#ifndef TFU_UPGRADE
      YS_MS_DECR_TIME((*timingInfo), txsubframe, 4);
      if (TRUE == ueCb->cwSwpflg[txsubframe.subframe])
      {
         RLOG_NULL(L_UNUSED," Swapping the feedbacks rcvd at (%d,%d)"
            "as tbtocwflag was set at (%d,%d) transmission",
            timingInfo->sfn,timingInfo->subframe,
            txsubframe.sfn,txsubframe.subframe);
         harqInfo->isAck[0] = (TfuHqFdbk)isAckCw2;
         harqInfo->isAck[1] = (TfuHqFdbk)isAck;
         ueCb->cwSwpflg[txsubframe.subframe] = FALSE;
      }
      else
#endif
      {
#ifndef TFU_TDD
         if ((TFU_UCI_FORMAT_1A_1B == ackNackMode) 
               || (TFU_UCI_FORMAT_1B_CS == ackNackMode))
         {
            harqInfo->isAck[0] = (TfuHqFdbk)isAck;
            harqInfo->isAck[1] = (TfuHqFdbk)isAckCw2;
#ifdef LTE_ADV
            harqInfo->isAck[2] = (TfuHqFdbk)isAckCw3;
            harqInfo->isAck[3] = (TfuHqFdbk)isAckCw4;
#endif
         }
#endif
      }
      harqInfo->lnk.node = (PTR)harqInfo;

      cmLListAdd2Tail(&(harqIndInfo->hqIndLst), &(harqInfo->lnk));
#ifndef TFU_UPGRADE
#ifdef HARQ_STATISTICS
      if(ueCb->cwCount[txsubframe.subframe] > 1)
      {
         if (isAckCw2)
            dlAcks++;
         else
            dlNacks++;
      }
      /* resetting the count */
      ueCb->cwCount[txsubframe.subframe] = 0;
#endif /* HARQ_STATISTICS */
#endif /* TFU_UPGRADE */

   } /* end of else statement */

   RETVALUE(ret);
} /* end of ysMsPrcHarqInd*/

/*
*
*       Fun:   ysMsPrcSrInd
*
*       Desc:  Processes the SR Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsPrcSrInd
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		 rnti
)
{
   S16           ret;
   TfuSrInfo     *srInfo;
   TfuSrIndInfo  *srIndInfo;
   U16 indx = cellCb->cellId - CM_START_CELL_ID;

   TRC2(ysMsPrcSrInd)

   /* begin: add by luopeng for ue stk log to web */ 
   if(rnti - g_MacRntiStart[cellCb->cellId - 1] >= 0 && rnti - g_MacRntiStart[cellCb->cellId - 1] < WEB_LOG_ARRAY_COUNT)
   {
	  rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].rnti = rnti;
	  rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].srDetectCnt++;
   }
   /* end: add by luopeng for ue stk log to web */ 

   ret = ROK;
   srInfo = NULLP;

   srIndInfo = cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].srIndInfo;
   if(srIndInfo == NULLP)
   {
      ret = ysUtlAllocEventMem((Ptr *)&srIndInfo, sizeof(TfuSrIndInfo), indx, __FUNCTION__, __LINE__);
      if(ret != ROK)
      {
         RLOG0(L_FATAL,"ysMsPrcSrInd(): Memory allocation failed for SrInd");
         RETVALUE(RFAILED);
      }
      cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].srIndInfo = srIndInfo;

      cmLListInit(&(srIndInfo->srLst));

      srIndInfo->cellId = cellCb->cellId;
      srIndInfo->timingInfo.sfn = rxSduInd->frameNum;
      srIndInfo->timingInfo.subframe = rxSduInd->subFrameNum;
   }
   {
      if (ysUtlGetEventMem(&srIndInfo->memCp, sizeof(TfuSrInfo),
            (Ptr *)&srInfo) != ROK)
      {
         RLOG0(L_ERROR,"ysMsPrcSrInd(): ysUtlGetEventMem returned failure");
         MSPD_ERR("ysUtlGetEventMem returned failure\n");
         RETVALUE (RFAILED);
      } /* end of if statement */

      srInfo->rnti = rnti;
      srInfo->lnk.node = (PTR)srInfo;

      cmLListAdd2Tail(&(srIndInfo->srLst), &(srInfo->lnk));

   } /* end of else statement */

   RETVALUE(ret);
} /* end of ysMsPrcSrInd*/


/*
*
*       Fun:   ysMsPrcRachInd
*
*       Desc:  Process RACH Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PUBLIC S16 ysMsPrcRachInd
(
PRXSTATUSIND       pRxStatusInd,
YsCellCb            *cellCb
)
{
   U8 preamble;
#ifdef TFU_TDD
   U8 freqIdx;
   //U8 prachCfgIdx;
#endif
   TfuRaReqIndInfo	   *rachIndInfo = cellCb->ulEncL1Msgs[pRxStatusInd->subFrameNum].rachIndInfo;
   PRX_PRACH_STATUS_EVENT pPrachEvents;

   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   TRC2(ysMsPrcRachInd)
   RASSERT_COREDUMP(rachIndInfo == NULLP);
   if(rachIndInfo == NULLP)
   {
      S16 ret;

      /* Allocate memory for the structures corresponding to the sub frame.
         rxStartInd->reserved has the subframe number */
      /* Allocate memory for Rach Indication Info */
      ret = ysUtlAllocEventMem((Ptr *)&rachIndInfo,
            sizeof(TfuRaReqIndInfo), indx, __FUNCTION__, __LINE__);
      if(ret != ROK)
      {
         RLOG1(L_FATAL,"ysMsPrcRachInd(): Memory allocation failed for RaReq %d", ret);
         RETVALUE(RFAILED);
      } /* end of if statement */

      cellCb->ulEncL1Msgs[pRxStatusInd->subFrameNum].rachIndInfo = rachIndInfo;

      rachIndInfo->cellId 		= cellCb->cellId;
      rachIndInfo->timingInfo.hfn 	= cellCb->timingInfo.hfn;
      rachIndInfo->timingInfo.sfn 	= pRxStatusInd->frameNum;
      rachIndInfo->timingInfo.subframe  = pRxStatusInd->subFrameNum;
   }

   pPrachEvents = (PRX_PRACH_STATUS_EVENT)&pRxStatusInd->pEventList;

   /* CL_CLEANUP: Removed the hard coding of values */
   preamble = pPrachEvents->prachPreambleId;
   /* 3GPP 36.321 5.1.4 */
   /* - RA RNTI as defined in MAC Spec */
   /*- rarnti = 1 + t_id + 10 * f_id */
   /* t_id ==> index of first sbframe of the prach */
   /* f_id ==> index of specified PRACH with that subframe */
#ifndef TFU_TDD
   /* for FDD there is only on Resource and configured on first
    * subframe, hence f_id=0 !!!!
    * hence
      ra_rnti = 1 + t_id */
   rachIndInfo->rachInfo.raRnti = 1 + pRxStatusInd->subFrameNum;
#else
   /* TDD_TODO currently MSPD phy doesn't support multiple RACH region on single
    *  subframe. When the Phy supports following calculation needs to use the 
    * freqIdx sent by L1 
    * As freqIdx is present in L1API. it is used in RA-RNTI calculation*/
    
   //prachCfgIdx = cellCb->prachCb.rachCfgInfo->prachCfgIndex;
   //freqIdx = pPrachEvents->frequencyIdx;
   freqIdx = 0;//manjappa
//   freqIdx = ysPrachTddMapLstDb[cellCb->ulDlCfgIdx][prachCfgIdx].prachTddMapLst[0].fRA;
   rachIndInfo->rachInfo.raRnti = 1 + pRxStatusInd->subFrameNum + (10 * freqIdx);
#endif

   /* Get the preamble Id  and other parameters */
   /* CL_CLEANUP: Removed the hard coding of values */
   rachIndInfo->rachInfo.raReqInfo.rapId = preamble;
   if (cellCb->vendorParams.period == 5)
   {
      rachIndInfo->rachInfo.raReqInfo.ta = 0;
   }
   else
   {
      rachIndInfo->rachInfo.raReqInfo.ta = pPrachEvents->timingOffset;
   }
   rachIndInfo->rachInfo.raReqInfo.cqiPres = FALSE;
#ifdef TFU_ALLOC_EVENT_NO_INIT
   rachIndInfo->rachInfo.raReqInfo.tpc = 0;
#endif   
   RLOG5(L_DEBUG,"Filling up RA REQ for  MAC at : (%d,%d) raRnti (%d) preamble (%d) ta (%d)",
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
            rachIndInfo->rachInfo.raRnti, preamble, pPrachEvents->timingOffset); 

   RETVALUE(ROK);
} /* end of  ysMsPrcRachInd */


#ifndef YS_MS_NO_ULCQI
/*
*
*       Fun:   ysMsPrcUlCqiInd
*
*       Desc:  Process UL CQI
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PRIVATE S16 ysMsPrcUlCqiInd
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		 rnti,
YsUeCb          *ueCb
)
{
   TfuUlCqiIndInfo   *ulCqiInd = cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].ulCqiIndInfo;
   TfuUlCqiRpt       *ulCqiRpt;
   U8                wideCqi;
   U32               currentTti, ttiDiff;
   U8                ulCqiAlphaFactor;
   U8                ulCqiBeltaFactor;
   U16               indx = cellCb->cellId - CM_START_CELL_ID;
   TRC2(ysMsPrcUlCqiInd)

   if (ueCb == NULLP)
   {
      RLOG_NULL(L_DEBUG,DBG_CRNTI,rnti,"ysMsPrcUlCqiInd(): UE doesnt exist");
      MSPD_ERR("UE[%d] noexist\n", rnti);
      RETVALUE (RFAILED);
   }
   /* Smooting algorithm weighs the last report and all the previous */
   /* reports equally.                                               */
   wideCqi             = ysCb.sinrToCqi[rxSduInd->ul_CQI];
   /* KINGTA: UL Cqi filter can be set from CLI
      * Here the ulCqiFactorAlpha must from 0 - 10
      * Because the OAM has already limit the value to be 0 - 10
      * Here may not need to check the value.
      */
   ulCqiAlphaFactor = cellCb->cellCfg.ulCqiFactorAlpha;
   ulCqiBeltaFactor = 10 - ulCqiAlphaFactor;
   
   /* lastRptdUlCqi is used for UL LA, lastRptUlSINR is used for UL power ctrl */
   ueCb->lastRptdUlCqi  = (ueCb->lastRptdUlCqi * ulCqiAlphaFactor)/10;
   ueCb->lastRptdUlCqi += (wideCqi *  ulCqiBeltaFactor);

   currentTti = ((rxSduInd->frameNum * 10) + rxSduInd->subFrameNum);
   if (currentTti < ueCb->ulCqiLastTti)
      ttiDiff = ((currentTti + 10240) - ueCb->ulCqiLastTti);
   else
      ttiDiff = (currentTti - ueCb->ulCqiLastTti);

    /*begin: add by luopeng for ue stk log to web*/
   if(rnti - g_MacRntiStart[cellCb->cellId - 1] >= 0 && rnti - g_MacRntiStart[cellCb->cellId - 1] < WEB_LOG_ARRAY_COUNT )
   {
      rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].rnti = rnti;
      rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].sinrCnt++;
      rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].ulSinr += (ueCb->lastRptUlSINR + 5)/10; 
   }
   /*end: add by luopeng for ue stk log to web*/
   /* Send UL CQI once every 20ms */
   if ((ueCb->numCqiSmps < 10) || (ttiDiff < 80))
   {
      ueCb->numCqiSmps++;
      RETVALUE(ROK);
   }
   ueCb->numCqiSmps = 0;	   
   ueCb->ulCqiLastTti = currentTti;


#ifdef YS_ALLOC_ON_NEED
   if(NULLP == ulCqiInd)
   {
      S16 ret;

      /* Allocate memory for the structures corresponding to the sub frame.*/
      ret = ysUtlAllocEventMem((Ptr *)&ulCqiInd, sizeof(TfuUlCqiIndInfo), indx, __FUNCTION__,__LINE__);
      if(ret != ROK)
      {
         RLOG_ARG0(L_ERROR,DBG_CRNTI,rnti,"ysMsPrcUlCqiInd(): Mem alloc failed for UlCqi");
         MSPD_ERR("Mem alloc failed for UlCqi\n");
         RETVALUE(RFAILED);
      }

      cmLListInit(&(ulCqiInd->ulCqiRpt));
      ulCqiInd->cellId = cellCb->cellId;
      ulCqiInd->timingInfo.sfn = rxSduInd->frameNum;
      ulCqiInd->timingInfo.subframe = rxSduInd->subFrameNum;
      cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].ulCqiIndInfo = ulCqiInd;
   }
#endif
   if (ysUtlGetEventMem(&ulCqiInd->memCp, sizeof(TfuUlCqiRpt), (Ptr *)&ulCqiRpt) != ROK)
   {
      ysUtlFreeEventMem(ulCqiInd);
      cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].ulCqiIndInfo = NULLP;
      RLOG_ARG0(L_FATAL,DBG_CRNTI,rnti,"ysUtlGetEventMem returned failure");
      MSPD_ERR("ysUtlGetEventMem returned failure\n");
      RETVALUE (RFAILED);
   }


   /* Added for Limiting the CQI for stability Check*/
#ifdef LIMIT_DL_UL_CQI
   if (ueCb->lastRptdUlCqi >= 10)
   {
      ueCb->lastRptdUlCqi = 10;
   }
#endif
   /* Fill the report with the values */

   ulCqiRpt->isTxPort0  = TRUE;
#if 1
   ulCqiRpt->wideCqi    = (ueCb->lastRptdUlCqi + 5)/10;
#else
   /* Removing the filter at CL as there is one at PHY */
   ulCqiRpt->wideCqi    = wideCqi;
   if (wideCqi == 0)
   {
      ulCqiRpt->wideCqi = 1;
   }

#endif
#ifdef TFU_TDD
   //ulCqiRpt->wideCqi    = 7;
#endif


   ulCqiRpt->rnti       = rnti;
   ulCqiRptCnt[ulCqiRpt->wideCqi]++;
   totUlCqiRpt++;
   ulCqiRpt->numSubband = 0;
   ulCqiRpt->lnk.node   = (PTR)ulCqiRpt;
   cmLListAdd2Tail(&(ulCqiInd->ulCqiRpt), &(ulCqiRpt->lnk));
   /* RLOG2(L_DEBUG,"Feeding MAC UL CQI %d for RNTI %d", ueCb->lastRptdUlCqi,
                                                   ueCb->ueId); */
   RETVALUE(ROK);
} /* end of  ysMsPrcUlCqiInd */
#endif

#ifdef TFU_UPGRADE
#if !defined(LTE_ADV) || !defined(TFU_TDD)
/*
*
*       Fun:   ysMsPrcDlRiInd
*
*       Desc:  Process DL RI indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PRIVATE S16 ysMsPrcDlRiInd
(
YsCellCb         *cellCb,
CmLteRnti        rnti,
CmLteTimingInfo  timingInfo,
U8               riByte
)
{
   TfuRawCqiIndInfo  *dlCqiIndInfo;
   TfuRawCqiRpt      *dlCqiRpt;
   S16         ret;
   YsUeCb      *ueCb;
   U8          numRiBits;    
   U16         indx = cellCb->cellId - CM_START_CELL_ID;
   TRC2(ysMsPrcDlRiInd)

   ret = ROK;

   ueCb = ysMsCfgGetUe(cellCb, rnti);
   if (ueCb == NULLP)
   {
      RLOG_NULL(L_ERROR,DBG_CRNTI,rnti,"ysMsPrcDlRiInd(): UE doesnt exist");
      MSPD_ERR("UE[%d] noexist\n", rnti);
      RETVALUE (RFAILED);
   }

   dlCqiIndInfo = cellCb->ulEncL1Msgs[timingInfo.subframe].dlCqiIndInfo;
#ifdef YS_ALLOC_ON_NEED
   if(NULLP == dlCqiIndInfo)
   {
      /* Allocate memory for the structures corresponding to the sub frame.*/
      ret = ysUtlAllocEventMem((Ptr *)&dlCqiIndInfo,
                           sizeof(TfuRawCqiIndInfo), indx, __FUNCTION__,__LINE__);
      if(ret != ROK)
      {
         RLOG_ARG0(L_FATAL,DBG_CRNTI,rnti,"ysMsPrcDlRiInd(): Memory allocation failed for DlCqi");
         RETVALUE(RFAILED);
      }

      cellCb->ulEncL1Msgs[timingInfo.subframe].dlCqiIndInfo = dlCqiIndInfo;
      cmLListInit(&(dlCqiIndInfo->rawCqiRpt));

      dlCqiIndInfo->cellId = cellCb->cellId;
      dlCqiIndInfo->timingInfo = timingInfo;
   }
#endif

   if (ysUtlGetEventMem(&dlCqiIndInfo->memCp, sizeof(TfuRawCqiRpt),
            (Ptr *)&dlCqiRpt) != ROK)
   {
      RLOG_ARG0(L_FATAL,DBG_CRNTI,rnti,"ysMsPrcDlRiInd(): ysUtlGetEventMem returned failure");
      MSPD_ERR("ysUtlGetEventMem returned failure\n");
      RETVALUE (RFAILED);
   }

  if(4 == cellCb->cellInfo.numAntPorts)
   {
      numRiBits = 2; 
   }
   else if(2 == cellCb->cellInfo.numAntPorts)
   {
      numRiBits = 1; 
   } 
   else
   {
      numRiBits = 1; // Not Supported yet
   } 
  /* Only periodic CQI is expected currently as the configuration from RRC
     is intended for periodic. 36.213 Section 7.2.2 */
   dlCqiRpt->crnti = rnti;
   dlCqiRpt->numBits = numRiBits;

#ifdef XEON_SPECIFIC_CHANGES
   //vz
#ifdef FOUR_TX_ANTENNA
   dlCqiRpt->ri[0] = (riByte >> (8 - numRiBits));
#else
   dlCqiRpt->ri[0] = 1; //(riByte >> (8 - numRiBits));
#endif
#else
   dlCqiRpt->ri[0] = (riByte >> (8 - numRiBits));
#endif

   /* MAC expects information from LSB startting from the cqiBits[0]*/
   dlCqiRpt->ri[0] = (riByte >> (8 - numRiBits));
   /* MSPD_LOG("\n At CL RI numBits, riByte are [%d, %d]\n", dlCqiRpt->numBits, dlCqiRpt->ri); */

   dlCqiRpt->lnk.node = (PTR)dlCqiRpt;

   cmLListAdd2Tail(&(dlCqiIndInfo->rawCqiRpt), &(dlCqiRpt->lnk));

   RETVALUE(ret);
} /* end of ysMsPrcDlRiInd */
#endif
#endif
/*
*
*       Fun:   ysMsPrcDlCqiInd
*
*       Desc:  Process DL CQI indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PRIVATE S16 ysMsPrcDlCqiInd
(
YsCellCb         *cellCb,
CmLteRnti        rnti,
CmLteTimingInfo  timingInfo,
U8               numCqiBits,
U8               *cqiBits,
U8               *riPtr,
U8               cqiConfBitMask
)
{
#ifndef TFU_UPGRADE
   TfuDlCqiIndInfo  *dlCqiIndInfo;
   TfuDlCqiRpt *dlCqiRpt;
#endif
#ifdef TFU_UPGRADE
   TfuRawCqiIndInfo  *dlCqiIndInfo;
   TfuRawCqiRpt      *dlCqiRpt;
   U8                numRiBits;
#endif
   S16         ret;
   YsUeCb      *ueCb;
#ifndef TFU_UPGRADE
   U8          cqi;
#endif
   U8 cnt;

   TRC2(ysMsPrcDlCqiInd)

   ret = ROK;

   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   
   ueCb = ysMsCfgGetUe(cellCb, rnti);
   if (ueCb == NULLP)
   {
      RLOG_NULL(L_ERROR,DBG_CRNTI,rnti,"ysMsPrcDlCqiInd(): UE doesnt exist");
      MSPD_ERR("UE[%d] noexist\n", rnti);
      RETVALUE (RFAILED);
   }

   dlCqiIndInfo = cellCb->ulEncL1Msgs[timingInfo.subframe].dlCqiIndInfo;
#ifdef YS_ALLOC_ON_NEED
   if(NULLP == dlCqiIndInfo)
   {
      /* Allocate memory for the structures corresponding to the sub frame.*/
#ifndef TFU_UPGRADE
      ret = ysUtlAllocEventMem((Ptr *)&dlCqiIndInfo,
                           sizeof(TfuDlCqiIndInfo), indx, __FUNCTION__,__LINE__);
#else
      ret = ysUtlAllocEventMem((Ptr *)&dlCqiIndInfo,
                           sizeof(TfuRawCqiIndInfo), indx, __FUNCTION__,__LINE__);
#endif
      if(ret != ROK)
      {
         RLOG_ARG0(L_FATAL,DBG_CRNTI,rnti,"ysMsPrcDlCqiInd(): Memory allocation failed for DlCqi");
         RETVALUE(RFAILED);
      }

      cellCb->ulEncL1Msgs[timingInfo.subframe].dlCqiIndInfo = dlCqiIndInfo;
#ifndef TFU_UPGRADE
      cmLListInit(&(dlCqiIndInfo->dlCqiRptsLst));
#else
      cmLListInit(&(dlCqiIndInfo->rawCqiRpt));
#endif

      dlCqiIndInfo->cellId = cellCb->cellId;
      dlCqiIndInfo->timingInfo = timingInfo;
   }
#endif

#ifndef TFU_UPGRADE
   if (ysUtlGetEventMem(&dlCqiIndInfo->memCp, sizeof(TfuDlCqiRpt),
            (Ptr *)&dlCqiRpt) != ROK)
#else
   if (ysUtlGetEventMem(&dlCqiIndInfo->memCp, sizeof(TfuRawCqiRpt),
            (Ptr *)&dlCqiRpt) != ROK)
#endif
   {
      RLOG_ARG0(L_FATAL,DBG_CRNTI,rnti,"ysMsPrcDlCqiInd(): ysUtlGetEventMem returned failure");
      ysUtlFreeEventMem(dlCqiIndInfo);
      /*ccpu00129690 -Avoiding a possible Double dealloc */
      cellCb->ulEncL1Msgs[timingInfo.subframe].dlCqiIndInfo = NULLP;
      RETVALUE (RFAILED);
   }

  /* Only periodic CQI is expected currently as the configuration from RRC
     is intended for periodic. 36.213 Section 7.2.2 */
#ifndef TFU_UPGRADE
   dlCqiRpt->rnti = rnti;
   dlCqiRpt->isPucchInfo = TRUE;
   dlCqiRpt->dlCqiInfo.pucchCqi.mode =  TFU_PUCCH_CQI_MODE10;

   if(!cqi)	uninitialised here!!!
   {
      /* MS_WORAKAROUND: Considering CQI 0 as invalid CQI and using last reported valid CQI */
      cqi = ueCb->lastRptdDlCqi;
   }
   else
   {
      ueCb->lastRptdDlCqi = cqi;
   }

   dlCqiRpt->dlCqiInfo.pucchCqi.u.mode10Info.type = TFU_RPT_CQI;
   dlCqiRpt->dlCqiInfo.pucchCqi.u.mode10Info.u.cqi = cqi;


   /* RLOG6(L_DEBUG,"DL CQI(%u) @ cellTime(%u,%u) for PHY time(%u,%u) ueId(%u)",
      cqi, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
      timingInfo.sfn, timingInfo.subframe, rnti); */

#endif
#ifdef TFU_UPGRADE
#ifdef FOUR_TX_ANTENNA
      if(4 == cellCb->cellInfo.numAntPorts)
      {
          numRiBits = 2; 
      }
      else if(2 == cellCb->cellInfo.numAntPorts)
      {
          numRiBits = 1; 
      } 
      else
      {
	 // Not Supported yet
          //initialized to 1 to avoid compiler warning
          numRiBits = 1; 
      }
#else
   numRiBits = 1; /* TODO: Assuming 2x2 MIMO */
#endif
   dlCqiRpt->crnti = rnti;
   dlCqiRpt->numBits = numCqiBits;
/* skumar workaround added */
   dlCqiRpt->cqiConfBitMask = cqiConfBitMask;
   /* Filling the CQI bits */
   for(cnt = 0 ; cnt < numCqiBits; cnt++)
   {
      dlCqiRpt->cqiBits[cnt] = cqiBits[cnt];
   }
#ifdef XEON_SPECIFIC_CHANGES   /* Hardcoding DLCqi */
   //vz   
   //dlCqiRpt->cqiBits[0] = 0xF0; 
#endif

   if(riPtr != NULLP)
   {   
      U8 idx = 0;
      U8 start = 0;
#ifndef XEON_SPECIFIC_CHANGES
      U8 mask = 0;
#endif
      YsRiInfo *riInfo = &ueCb->riInfo[timingInfo.subframe];
      /* Filling the RI bits for Multiple Cells*/
      for (idx = 0;idx < riInfo->numCell; idx++)
      {
#ifndef XEON_SPECIFIC_CHANGES
	 mask = (0xFF) >> (8 - riInfo->riSize[idx]);
#endif
#ifdef XEON_SPECIFIC_CHANGES
	 //vz
#ifdef FOUR_TX_ANTENNA
	 dlCqiRpt->ri[idx] = (*riPtr >> (8 - numRiBits));
#else
	 dlCqiRpt->ri[idx] = 1; //(*riPtr >> (8 - numRiBits));  
#endif
#else
	 dlCqiRpt->ri[idx] = (mask) & (*riPtr >> (8 - (start + riInfo->riSize[idx])));  
#endif
	 start += riInfo->riSize[idx];
      }
   }
   else
   {   
      /* Filling the RI bits */
#ifdef XEON_SPECIFIC_CHANGES
      //vz
#ifdef FOUR_TX_ANTENNA
        /*Need to take care for MCell */
         dlCqiRpt->ri[0] = (cqiBits[0] >> (8 - numRiBits));
	 //dlCqiRpt->ri[0] = 3; //(riByte >> (8 - numRiBits));
#else
      dlCqiRpt->ri[0] = 1; //(*riPtr >> (8 - numRiBits));  
#endif
#else
      dlCqiRpt->ri[0] = (cqiBits[0] >> (8 - numRiBits));
#endif

   }
#endif
   
   dlCqiRpt->lnk.node = (PTR)dlCqiRpt;

#ifndef TFU_UPGRADE
   cmLListAdd2Tail(&(dlCqiIndInfo->dlCqiRptsLst), &(dlCqiRpt->lnk));
#else
   cmLListAdd2Tail(&(dlCqiIndInfo->rawCqiRpt), &(dlCqiRpt->lnk));
#endif

#ifdef CA_DBG
   {
      //rgStats.gCqiRcvdCount++;
   }

#endif

   RETVALUE(ret);
} /* end of ysMsPrcDlCqiInd */

#ifndef YS_MS_NO_TA
/*
*
*       Fun:   ysMsPrcTmAdvInd
*
*       Desc:  Process Timing Advance indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsPrcTmAdvInd
(
PRXSDUIND       rxSduInd,
YsCellCb         *cellCb,
CmLteRnti		 rnti,
YsUeCb			*ueCb
)
{
   TfuTimingAdvIndInfo *tmAdvIndInfo = cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].tmAdvIndInfo;
   TfuTimingAdvInfo *tmAdvInfo;
#ifndef PHY_3829
   U16         ta = (U16)(rxSduInd->timingAdv);
#else
   U16         currTa = (U16)(rxSduInd->timingAdv);
   U8          currCqi = (U8)(rxSduInd->ul_CQI);
   U16         ta = 0;
#endif
   S16         ret; 

   TRC2(ysMsPrcTmAdvInd)
   U16         indx = cellCb->cellId - CM_START_CELL_ID;
   
   ret = ROK;

#ifndef PHY_3829
   if(!(ta <=63))
   {
      RLOG_ARG1(L_ERROR,DBG_CELLID,cellCb->cellId,"ysMsPrcTmAdvInd(): ta=%u not in range [0,63]", ta);
      MSPD_ERR("ta=%u not in range [0,63]\n", ta);
      RETVALUE(ROK);
   }
#endif

   if (ueCb == NULLP)
   {
      RLOG_NULL(L_DEBUG,DBG_CRNTI,rnti,"ysMsPrcTmAdvInd(): UE doesnt exist");
      MSPD_ERR("UE[%d] noexist\n", rnti);
      RETVALUE(ROK);
   }

#ifdef PHY_3829
   if(currCqi > YS_MS_TA_AVG_MIN_CQI)
   {
      if((currTa < 0) || (currTa > 63))
      {
         currTa = 31;
      }

      ueCb->avgTa += (currTa & 0x3f);
      ueCb->avgTaCnt++;
   }

   if(ueCb->avgTaCnt == YA_MS_TA_AVG_TIME)
   {
      ta = (S8)((ueCb->avgTa >> YA_MS_TA_AVG_TIMElog2) +
            ((ueCb->avgTa >> (YA_MS_TA_AVG_TIMElog2 - 1))&1));

      ueCb->avgTaCnt = 0;
      ueCb->avgTa = 0;
#endif
      if (ta == 31)//YS_MS_TA_THROTTLED(ueCb))
      {
         //RLOG0(L_DEBUG,"[TA] Not reporting");
         /* For now don't report TA to MAC when there is no drift,
          * OR, when TA reporting is throttled at this time */
         RETVALUE(ROK);
      }

      ueCb->ulTaLastTti = ta;

      /*RLOG3(L_DEBUG,"[TA] Reporting TA to MAC prev TA %d crnt TA %d rnti %u",
        ueCb->tarptInfo.ta, ta, ueId); */
      ueCb->tarptInfo.ta = ta;

      if (tmAdvIndInfo == NULLP)
      {
         ret = ysUtlAllocEventMem((Ptr *)&tmAdvIndInfo,
               sizeof(*tmAdvIndInfo), indx, __FUNCTION__, __LINE__);
         if(ret != ROK)
         {
            RLOG_ARG0(L_FATAL, DBG_CRNTI,rnti,"Memory allocation failed for DatInd");
            MSPD_ERR("Memory allocation failed for DatInd\n");
            RETVALUE(ret);
         }

         /* Initialize the Data Indication List */
         cmLListInit(&tmAdvIndInfo->timingAdvLst);

         tmAdvIndInfo->cellId = cellCb->cellId;
         tmAdvIndInfo->timingInfo.sfn = rxSduInd->frameNum;
         tmAdvIndInfo->timingInfo.subframe = rxSduInd->subFrameNum;

         cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].tmAdvIndInfo = tmAdvIndInfo;
         RLOG2(L_DEBUG,"*********** TA feeding to schduler: %u rnti %u ", ta, rnti);
      }

      if (ysUtlGetEventMem(&tmAdvIndInfo->memCp, sizeof(TfuTimingAdvInfo),
               (Ptr *)&tmAdvInfo) != ROK)
      {
         YS_DBG_ERR((_ysp, "ysMsPrcTmAdvInd(): ysUtlGetEventMem returned failure\n"));
         MSPD_ERR("ysUtlGetEventMem returned failure\n");
         RETVALUE (RFAILED);
      }

      tmAdvInfo->rnti      = rnti;
      tmAdvInfo->timingAdv = ta;
      tmAdvInfo->lnk.node = (PTR)tmAdvInfo;
      cmLListAdd2Tail(&tmAdvIndInfo->timingAdvLst, &tmAdvInfo->lnk);
#ifdef PHY_3829
   }
#endif

   RETVALUE(ret);
} /* end of ysMsPrcTmAdvInd */
#endif

/*
*
*       Fun:   ysMsPrcRxStatusInd
*
*       Desc:  Process RX_STATUS_IND message from PHY
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PUBLIC S16 ysMsPrcRxStatusInd
(
PRXSTATUSIND       pRxStatusInd,
YsCellCb           *cellCb
)
{
   TRC2(ysMsPrcRxStatusInd);
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   
   RLOG_NULL(L_UNUSED,"Received PHY_RXSTATUS_IND subframe (%d) statustype (%d) eventNumber (%d) ",
            pRxStatusInd->subFrameNum, pRxStatusInd->statusType, pRxStatusInd->eventNumber);

   if (pRxStatusInd->eventNumber != 0)
   {
      if (pRxStatusInd->statusType == PRACH_RESULT)
      {
         MSPD_DBG("R PRACH(%d,%d)\n", pRxStatusInd->frameNum , pRxStatusInd->subFrameNum);

         //printf("\n\nReceived PRACH from UE : celltime (%d,%d) PRACH(%d,%d) ",
         //cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
         // pRxStatusInd->frameNum , pRxStatusInd->subFrameNum);

         RLOG4(L_DEBUG, "Received PRACH from UE subframe cell(%d, %d) at(%d,%d)",
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
            pRxStatusInd->frameNum , pRxStatusInd->subFrameNum);
         cellCb->gotRACH++;
         ysMsPrcRachInd(pRxStatusInd, cellCb);
      }
      else if (pRxStatusInd->statusType == CQIRIHI_RESULT)
      {
         if ((pRxStatusInd->status == TIMEOUT_RXSTART_REQ) || (pRxStatusInd->status == INVALID_TX_VECTOR))
         {
            ++delayedApiCnt;/*SRIKY MMM */
            RLOG2(L_DEBUG,"Delayed API RXSTATUS cnt(%lu) status(%u)", delayedApiCnt, pRxStatusInd->status);
         }
         ysMsPrcCqiPmiRiHqInd(pRxStatusInd, cellCb);
      }
      else if (pRxStatusInd->statusType == SRS_RESULT)
      {
         if ((pRxStatusInd->status == TIMEOUT_RXSTART_REQ) || (pRxStatusInd->status == INVALID_TX_VECTOR))
         {
            ++delayedApiCnt;
            MSPD_DBG("Delayed API RXSTATUS cnt(%lu) status(%u)\n", delayedApiCnt, pRxStatusInd->status);
         }
         ysMsPrcSrsInd(pRxStatusInd, cellCb);
      }
      else
      {
         uart_printf("Unhandled status Type %d in ysMsPrcRxStatusInd()\n",
            pRxStatusInd->statusType);
      }
      /*Begin: add by luopeng for phy-l2 api send to wireshark 20171204*/
      if(gRgFapiWiresharkEnable)
      {
         sendFapiWiresharkToApp((U8*)pRxStatusInd, 100, 2, indx);
      }
      /*End: add by luopeng for phy-l2 api send to wireshark 20171204*/

   }

   RETVALUE(ROK);
} /* end of  ysMsPrcRxStatusInd */
/*
 *    Fun : ysMsPrcSrsInd
 *
 *    Desc: Process SRS indication on PUSCH
 *
 *    Ret: S16
 *
 *    Notes: None
 *
 *    File: ys_ms_ul.c
 *
 */
PRIVATE S16 ysMsPrcSrsInd
(
 PRXSTATUSIND       pRxStatusInd,
 YsCellCb            *cellCb
 )
{
   PRX_SRS_STATUS_EVENT pRxSrsStatusEvent;
   TfuSrsIndInfo           *srsIndInfo = NULLP;
   TfuSrsRpt            *srsRpt = NULLP; 
   S16                    ret;
   YsUeCb                *ueCb = NULLP;
   CmLteTimingInfo          timingInfo;
   CmLteRnti                rnti;

   TRC2(ysMsPrcSrsInd)
   U16                   indx = cellCb->cellId - CM_START_CELL_ID;
   ret = ROK;
   //MSPD_LOG("\n\n[SRS] Recevied SRS Report, Num of Events [%d]\n", pRxStatusInd->eventNumber);

   pRxSrsStatusEvent = (PRX_SRS_STATUS_EVENT)&pRxStatusInd->pEventList;

#ifdef MSPD_TDD_LTE
#ifndef XEON_SPECIFIC_CHANGES
   rnti = pRxSrsStatusEvent->rnti;
#endif
#else
   rnti = pRxSrsStatusEvent->srsIndex;
#endif
   //MSPD_LOG("\n\nRecevied SRS report for UEId [%d]\n", rnti);

   ueCb = ysMsCfgGetUe(cellCb, rnti);
   if (ueCb == NULLP)
   {
      YS_DBG_ERR((_ysp, "ysMsPrcSrsInd(): UE doesnt exist\n"));
      MSPD_ERR("UE[%d] noexist\n", rnti);
      RETVALUE (RFAILED);
   }

   timingInfo.sfn = pRxStatusInd->frameNum;
   timingInfo.subframe = pRxStatusInd->subFrameNum;

   
   srsIndInfo = cellCb->ulEncL1Msgs[timingInfo.subframe].srsIndInfo;
   if (NULLP == srsIndInfo)
   {
      /* Allocate memory for the structures corresponding to the sub frame.*/
      ret = ysUtlAllocEventMem((Ptr *)&srsIndInfo, 
                        sizeof(TfuSrsIndInfo), indx, __FUNCTION__,__LINE__);
      if(ret == RFAILED)
      {
         YS_DBG_ERR((_ysp, "ysMsPrcSrsInd(): Memory allocation failed for DlCqi\n"));
         MSPD_ERR("Memory allocation failed for DlCQI\n");
         RETVALUE(ret);
      }
      cellCb->ulEncL1Msgs[timingInfo.subframe].srsIndInfo = srsIndInfo;

      srsIndInfo->cellId = cellCb->cellId;
      srsIndInfo->timingInfo = timingInfo;
      cmLListInit(&(srsIndInfo->srsRpt));
   }
   //MSPD_LOG("\n[SRS] adding srsIndInfo to timingInfo.subframe[%d]\n", timingInfo.subframe);

   /* Update the SRS Rpt from RXInd */

   if (ysUtlGetEventMem(&srsIndInfo->memCp, sizeof(TfuSrsRpt),
            (Ptr *)&srsRpt) != ROK)
   {
      RLOG_ARG0(L_FATAL,DBG_CRNTI,rnti,"ysMsPrcSrsInd(): ysUtlGetEventMem returned failure");
      ysUtlFreeEventMem(srsIndInfo);
      /*ccpu00129690 -Avoiding a possible Double dealloc */
      cellCb->ulEncL1Msgs[timingInfo.subframe].srsIndInfo = NULLP;
      ret = RFAILED;
      RETVALUE (ret);
   }
   /* Update the SRS info */
   srsRpt->ueId = rnti; 
   srsRpt->ta = pRxSrsStatusEvent->timingAdvance;
   srsRpt->numRbs = pRxSrsStatusEvent->numberRb;
   srsRpt->rbStart = pRxSrsStatusEvent->rbStart;

   /* Need to Check
      srsRpt->dopEst = 
   */
   /* Updating wideCqi */
   srsRpt->wideCqiPres = TRUE;
#ifdef MSPD_TDD_LTE
#ifndef XEON_SPECIFIC_CHANGES
   RASSERT_COREDUMP(pRxSrsStatusEvent->widebandSnr < 256);
   srsRpt->wideCqi = ysCb.sinrToCqi[pRxSrsStatusEvent->widebandSnr]; 
#endif
#endif
   //MSPD_LOG("\n\n Received SRS report UeId[%d], ta[%d], numRb[%d], rbSt[%d], wideCqi[%d], wideBandSnr[%d]\n", srsRpt->ueId, srsRpt->ta, srsRpt->numRbs, srsRpt->rbStart, srsRpt->wideCqi, pRxSrsStatusEvent->widebandSnr);
   cmMemcpy(&srsRpt->snr[srsRpt->rbStart], (const U8 *)&pRxSrsStatusEvent->psnr, srsRpt->numRbs);
   /* add SRS Report to list */
   srsRpt->lnk.node = (PTR)srsRpt;
   cmLListAdd2Tail( &(srsIndInfo->srsRpt), &(srsRpt->lnk));

   /*
    * Need to handle TDB, SRS upgrade, Temporary patch
    * We need to accumulate srs reports in the same subframe and send it to mac
    */
   YsUiTfuSrsInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, srsIndInfo);

   RETVALUE(ret);
}

/*
*
*       Fun:   ysMsPrcCqiPmiRiHqInd
*
*       Desc:  Process CQI/PMI/RI/HARQ indication on PUSCH
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/

PRIVATE S16 ysMsPrcCqiPmiRiHqInd
(
PRXSTATUSIND       pRxStatusInd,
YsCellCb            *cellCb
)
{
   PRX_CQIRIHI_STATUS_EVENT pCqiPmiRiHqEvents;
   U8                       numCqiPmiBytes = 0;
   U8                       numHqBytes = 0;
   U8                       numRiBytes = 0;
   U8                       *msgPtr;
   U8                       cqiPmiMsg[32];
   U8                       hqByte;
#ifdef TFU_UPGRADE
   //U8                       riByte;
#endif
   CmLteTimingInfo          timingInfo;
   CmLteRnti                rnti;
   U8                       cqiConfBitMask = 1;


   TRC2(ysMsPrcCqiPmiRiHqInd)

   pCqiPmiRiHqEvents = (PRX_CQIRIHI_STATUS_EVENT)&pRxStatusInd->pEventList;

   timingInfo.sfn = pRxStatusInd->frameNum;
   timingInfo.subframe = pRxStatusInd->subFrameNum;

   ysMsGetRntiFrmChanId(cellCb, &rnti, timingInfo.subframe, pCqiPmiRiHqEvents->chanId);

   if (pCqiPmiRiHqEvents->harq_pt)
   {
      numHqBytes   = 1;
   }

   if (pCqiPmiRiHqEvents->ri_pt)
   {
      numRiBytes   = 1;
   }
   if (pCqiPmiRiHqEvents->cqi_pmi_pt)
   {
      numCqiPmiBytes = pCqiPmiRiHqEvents->status_len - numHqBytes - numRiBytes;
   }
#ifdef CA_PHY
   msgPtr = (U8 *) (pCqiPmiRiHqEvents + 1);
   //msgPtr = (U8 *) ((U8 *)pCqiPmiRiHqEvents + sizeof(PRX_CQIRIHI_STATUS_EVENT));
   //ANOOP :: Added this to fix Nack issue
   //msgPtr = (U8 *) ((U8 *)pCqiPmiRiHqEvents + sizeof(RX_CQIRIHI_STATUS_EVENT));
#else
#ifdef XEON_SPECIFIC_CHANGES
   msgPtr = (U8 *) (pCqiPmiRiHqEvents + 1);
#else
   msgPtr = (U8 *) ((U8 *)pCqiPmiRiHqEvents + sizeof(RX_CQIRIHI_STATUS_EVENT));
#endif
#endif

#if 1 //Sunil
    if (numHqBytes)
    {
       hqByte = *msgPtr;
       msgPtr = msgPtr + 1;
 
 #ifndef CA_PHY 
          /*This is for checking The harq CF bit in case on non ca. 
           * so this is guarded and avoided for CA
           */
       if (hqByte & 0x20)
 #endif/* CA_PHY */
       {
#ifndef TFU_TDD
#if 0//def LTE_ADV
         if(YS_HARQ_ACKNACK_CONF_MSK == 
               (pCqiPmiRiHqEvents->ackConf & YS_HARQ_ACKNACK_CONF_MSK))
         {
            ysMsPrcHarqInd(cellCb, &timingInfo, 
                  &hqByte, TRUE, rnti, pCqiPmiRiHqEvents->harq_pt,FALSE);
         }
         else
         {
            MSPD_DBG("\n Dropping harq on PUSCH due to conf mask at(%d %d)\n",
               pRxStatusInd->frameNum,pRxStatusInd->subFrameNum);
         }

#else
         ysMsPrcHarqInd(cellCb, &timingInfo, 
               &hqByte, TRUE, rnti, pCqiPmiRiHqEvents->harq_pt,FALSE);
#endif /* LTE_ADV */

#else /* ifndef TFU_TDD */

         ysMsPrcHarqInd(cellCb, &timingInfo, 
              &hqByte, TRUE, rnti, pCqiPmiRiHqEvents->harq_pt, FALSE);
#endif
      }
   }


   if (numCqiPmiBytes)
   {
#if ((defined LTE_TDD) || (!defined LTE_ADV_ACQI_SUPP))
      cmMemcpy(cqiPmiMsg,msgPtr,numCqiPmiBytes);
      msgPtr = msgPtr + numCqiPmiBytes;
#else
      /* nawas:: to test and verify with intel team
       * RI is observed to be the first byte
       * followed by CQI. But as per the doc
       * CQI will come first followed by RI
       * Needs confirmation from intel fdd team*/
      if(numRiBytes)
      {
         cmMemcpy(cqiPmiMsg,(msgPtr + numRiBytes),numCqiPmiBytes);
      }else
      {
         cmMemcpy(cqiPmiMsg,msgPtr,numCqiPmiBytes);
      }
#endif

      /* CCPU 129502 - if All CQI validation bits (bit 6 and bit 7) in "cqipmiconf" are set 
       * then only process CQI
       */
       if (YS_CQIPMICONF_MSK != 
            (pCqiPmiRiHqEvents->cqiPmiConf & YS_CQIPMICONF_MSK))
            {
#ifdef CA_DBG                    
                        rgStats.gCqiPuschConfMaskDropCount++;
#endif
                        cqiConfBitMask = 0;
            }
      if (1)
      {
         if(numRiBytes)
         {
            /* In CA there can be more than 4 bytes of CQI , when the CQI reported
             * is for multiple serving cells*/
            ysMsPrcDlCqiInd(cellCb, rnti, timingInfo, numCqiPmiBytes, cqiPmiMsg, msgPtr,cqiConfBitMask);
         }
         else
         {
           ysMsPrcDlCqiInd(cellCb, rnti, timingInfo, numCqiPmiBytes, cqiPmiMsg, NULLP,cqiConfBitMask);
         }    
      }else
      {
#ifdef CA_DBG
         {
            //rgStats.gPuschCqiDropCount++;
         }
#endif
         MSPD_DBG("\n Dropping CQI on PUSCH due to conf mask at(%d %d)\n",
               pRxStatusInd->frameNum,pRxStatusInd->subFrameNum);
      }
#if ((!defined LTE_TDD) || (defined LTE_ADV_ACQI_SUPP))
      msgPtr = msgPtr + numCqiPmiBytes+numRiBytes;
#endif
   }
   else if (numRiBytes)
   {
      //riByte = *msgPtr;
#ifdef TFU_UPGRADE
#ifdef LTE_ADV 
#if 0//ndef TFU_TDD 
         if(YS_RI_CONF_MSK == 
               (pCqiPmiRiHqEvents->riConf & YS_RI_CONF_MSK))
         {
            /* TODO: Assuming 2 TX antenna, hence a RI bitwidth of 1 */
            ysMsPrcDlRiInd(cellCb, rnti, timingInfo, riByte);
         }else
         {
            MSPD_DBG("\n Dropping RI on PUSCH due to conf mask at(%d %d)\n",
               pRxStatusInd->frameNum,pRxStatusInd->subFrameNum);

         }
   msgPtr = (U8 *) (pCqiPmiRiHqEvents + 1);
#endif
#else
          ysMsPrcDlRiInd(cellCb, rnti, timingInfo, riByte);
#endif /* LTE_ADV */

#endif
      msgPtr = msgPtr + 1;
   }
#endif //Sunil  
#if 0
   if ((numCqiPmiBytes + numRiBytes + numHqBytes) == 0)
   {
      static U32 muxDtxCnt = 0;
      muxDtxCnt++;
      if ((cellCb->timingInfo.sfn % 10 == 0) && 
            (cellCb->timingInfo.subframe == 0))
      {
         /*RLOG4(L_DEBUG,"MUX DTX Received @ (%d,%d) ueId(%u) Cnt(%lu)",
          cellCb->timingInfo.sfn, cellCb->timingInfo.subframe, rnti, muxDtxCnt);*/
      }
   }
#endif


   RETVALUE(ROK);
} /* end of  ysMsPrcCqiPmiRiHqInd */


/*
*
*       Fun:   ysMsPrcPucchDeltaPwrInd
*
*       Desc:  Processes the PUCCH delta power indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PRIVATE S16 ysMsPrcPucchDeltaPwrInd
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		 rnti,
YsUeCb          *ue
)
{
   S16               ret;
   TfuPucchDeltaPwr  *pucchDeltaPwrInfo;
   S32               pucchSnr;
   TfuPucchDeltaPwrIndInfo *pucchDeltaPwrIndInfo = cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].pucchDeltaPwrIndInfo;

   TRC2(ysMsPrcPucchDeltaPwrInd)
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   ret = ROK;
   pucchDeltaPwrInfo = NULLP;

   if(pucchDeltaPwrIndInfo == NULLP)
   {
      ret = ysUtlAllocEventMem((Ptr *)&pucchDeltaPwrIndInfo, sizeof(TfuPucchDeltaPwrIndInfo), indx, __FUNCTION__, __LINE__);
      if(ret != ROK)
      {
         RLOG0(L_FATAL,"ysMsPrcPucchDeltaPwrInd(): Memory allocation failed for SrInd");
         RETVALUE(RFAILED);
      }
      cellCb->ulEncL1Msgs[rxSduInd->subFrameNum].pucchDeltaPwrIndInfo = pucchDeltaPwrIndInfo;

      cmLListInit(&(pucchDeltaPwrIndInfo->pucchDeltaPwrLst));

      pucchDeltaPwrIndInfo->cellId = cellCb->cellId;
      pucchDeltaPwrIndInfo->timingInfo.sfn = rxSduInd->frameNum;
      pucchDeltaPwrIndInfo->timingInfo.subframe = rxSduInd->subFrameNum;
   }
   {
      if (ysUtlGetEventMem(&pucchDeltaPwrIndInfo->memCp, sizeof(TfuPucchDeltaPwr),
            (Ptr *)&pucchDeltaPwrInfo) != ROK)
      {
         RLOG0(L_ERROR,"ysMsPrcPucchDeltaPwrInd(): ysUtlGetEventMem returned failure");
         MSPD_ERR("ysUtlGetEventMem returned failure\n");
         RETVALUE (RFAILED);
      } /* end of if statement */


     ysMsGetRntiFrmChanId(cellCb, &(pucchDeltaPwrInfo->rnti),
        rxSduInd->subFrameNum, rxSduInd->channelId);

      pucchSnr = ue->lastRptdPucchSnr;
      /*RLOG2(L_DEBUG,"PUCCH SNR (%d) UE (%u)", pucchSnr, ue->ueId);*/

      /* Do not feed a large power command. It can interfere with other UEs */
      /* The power increase should be done slowly                           */
#ifndef TFU_TDD
      if (pucchSnr < 10)
      {
         pucchDeltaPwrInfo->pucchDeltaPwr = 1;
      }
      else if (pucchSnr > 15)
      {
         pucchDeltaPwrInfo->pucchDeltaPwr = -1;
      }
      else
      {
         pucchDeltaPwrInfo->pucchDeltaPwr =  0;
      }
#else
      if (ue->contCqiDrops > 6)
      {
         pucchDeltaPwrInfo->pucchDeltaPwr = 1;
      }
      else if (pucchSnr > 15 && ue->contCqiDrops <=2) 
      {
         pucchDeltaPwrInfo->pucchDeltaPwr = -1;
      }
      else
      {
         pucchDeltaPwrInfo->pucchDeltaPwr = 0;
      }

#endif
     // pucchDeltaPwrInfo->lnk.node = (PTR)pucchDeltaPwrInfo;

      //cmLListAdd2Tail(&(pucchDeltaPwrIndInfo->pucchDeltaPwrLst), &(pucchDeltaPwrInfo->lnk));

   } /* end of else statement */

   RETVALUE(ret);
} /* end of ysMsPrcPucchDeltaPwrInd */
/*
*
*       Fun:   ysMsPrcPucchPwrInd
*
*       Desc:  Process PUCCH power indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsPrcPucchPwrInd
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb,
CmLteRnti		 rnti,
YsUeCb			*ueCb
)
{
   S32              currSnr = 0;
   U32             currentTti, ttiDiff;

   TRC2(ysMsPrcPucchPwrInd)

   if (ueCb == NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CRNTI,rnti,"ysMsPrcPucchPwrInd(): UE doesnt exist");
      MSPD_ERR("UE[%d] noexist\n", rnti);
      RETVALUE (RFAILED);
   }
   /* Smooting algorithm weighs the last report and all the previous */
   /* reports equally.                                               */
   currSnr = (rxSduInd->ul_CQI - 128)/2;
   /* RLOG3(L_DEBUG,"SNR from PHY %u lastRptdSnr %u ue %u",
      currSnr, ueCb->lastRptdPucchSnr, ueCb->ueId); */
   ueCb->lastRptdPucchSnr *= 8;
   ueCb->lastRptdPucchSnr += (currSnr *  2);
   ueCb->lastRptdPucchSnr += 5;        // Rounded
   ueCb->lastRptdPucchSnr /= 10;

   currentTti = ((rxSduInd->frameNum * YS_NUM_SUB_FRAMES) + rxSduInd->subFrameNum);
   if (currentTti < ueCb->pucchSnrLastTti)
      ttiDiff = ((currentTti + YS_TOTL_SUB_FRAMES_IN_SFN) - ueCb->pucchSnrLastTti);
   else
      ttiDiff = (currentTti - ueCb->pucchSnrLastTti);

   /* Send SNR report once every 64ms or greater since the values from PHY are averaged over 64 subframes */
   if (ttiDiff < 64)
   {
      RETVALUE(ROK);
   }
   ueCb->pucchSnrLastTti = currentTti;


   ysMsPrcPucchDeltaPwrInd(rxSduInd, cellCb, rnti, ueCb);

   RETVALUE(ROK);
}

/*
*
*       Fun:   ysMsUlmPrcPucch
*
*       Desc:  Handles PUCCH SDUs
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmPrcPucch
(
PRXSDUIND       rxSduInd,
YsCellCb        *cellCb
)
{
   CmLteRnti		rnti;
   YsUeCb           *ueCb;

   TRC2(ysMsUlmPrcPucch)

   ysMsGetRntiFrmChanId(cellCb, &rnti,rxSduInd->subFrameNum, rxSduInd->channelId);
   ueCb = ysMsCfgGetUe(cellCb, rnti);

   if (ysMsPrcUciInd(rxSduInd, cellCb, rnti, ueCb) != ROK)
   {
      RLOG0(L_ERROR,"ysMsUlmPrcPucch(): Processing of ysMsPrcUci failed");
      MSPD_ERR("Processing of ysMsPrcUci failed\n");
      RETVALUE(RFAILED);
   } /* end of if statement */
#ifndef YS_MS_NO_TA
      /* This is blocked as PHY sends 0 always for ta on PUCCH */
#ifdef TFU_TDD

   ysMsPrcTmAdvInd(rxSduInd, cellCb, rnti, ueCb); 
#endif

#endif
      /* SNR for SR is not to be considered for PUCCH power control */
   if ((rxSduInd->pucchType != FORMAT1) &&
         !((rxSduInd->status == TIMEOUT_RXSTART_REQ) ||
            (rxSduInd->status == INVALID_TX_VECTOR)))
   {
      ysMsPrcPucchPwrInd(rxSduInd, cellCb, rnti, ueCb);
   }

   RETVALUE(ROK);
} /* end of ysMsUlmPrcPucch */


#ifdef DLHQ_RTT_OPT
/*
*
*       Fun:   ysMsUlmPrcUlCntrl
*
*       Desc:  Sends UL control information to SCH
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysMsUlmPrcUlCntrl
(
CmLteTimingInfo *ulCntrlTiming,
YsCellCb        *cellCb
)
{
   TfuHqIndInfo    *harqIndInfo;
#ifndef TENB_RTLIN_CHANGES
   CmLteTimingInfo rxSduSf;
   Bool            sndTtiOnHq = FALSE;
#endif

   harqIndInfo = cellCb->ulEncL1Msgs[ulCntrlTiming->subframe].harqIndInfo;

#ifndef TENB_RTLIN_CHANGES
   rxSduSf = *ulCntrlTiming;
   YS_INCR_TIMING_INFO(rxSduSf,1);

   if (!YS_TIMING_INFO_SAME(rxSduSf, cellCb->timingInfo))
   {
      delayedHarq++;
     RLOG2(L_DEBUG," DL HARQ IND (%u,%u) is received late/early",
           ulCntrlTiming->sfn, ulCntrlTiming->subframe);
     /*RLOG4(L_DEBUG,"PHY Exptime(%d,%d) rcvdtime(%d,%d)",
          rxSduSf.sfn, rxSduSf.subframe,
          cellCb->timingInfo.sfn, cellCb->timingInfo.subframe); */
   }
   else
   {
      sndTtiOnHq = TRUE;
   }
#endif
   /* sending the DL HARQ feedbacks to SCH as and when it is received */
   if (harqIndInfo != NULLP)
   {
      if(harqIndInfo->hqIndLst.count > 0 )
      {
         YsUiTfuHqInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, harqIndInfo);
#ifndef TENB_RTLIN_CHANGES
         if (sndTtiOnHq)
         {
            /* ccpu00128524 - Checking for a ongoing DatReq processing by CL
             * and avoiding a TtiIndOnHqReceipt momentarily so that CL gets
             * the time slice to complete DatReq and thus avoid dropping it. 
             * A flag is set to TRUE if DatReq processing is on-going */
            if(!(cellCb->dlEncL1Msgs[expDatReqTiming.subframe].isdatReqPres)) 
            {
               //RLOG0(L_DEBUG,"Sending TTI on HARQ");
               ysMsDlmPrcTtiIndOnHqReceipt(cellCb, FALSE);
            }
            else
            {
               cellCb->sndTtiIndOnHqRecptLater = TRUE;
            }
         }
#endif
      }
      else
      {
         YS_FREE_SDU(harqIndInfo);
      }/* end of else part */
   }
#ifndef TENB_RTLIN_CHANGES
        if (sndTtiOnHq)
        {
           //RLOG0(L_DEBUG,"Sending TTI on HARQ");
          ysMsDlmPrcTtiIndOnHqReceipt(cellCb, FALSE);
        }
#endif

   cellCb->ulEncL1Msgs[ulCntrlTiming->subframe].harqIndInfo = NULLP;
   RETVALUE(ROK);
}
#endif
#ifdef RSYS_WIRESHARK
/**
 *  *    @brief   This function checks the MAC PDU for the presence of
 *  ccch/srb1/srb2 data.
 *   *     If any of these data present then it will return TRUE else it will
 *   return FALSE. 
 *    *    @param[in]  mBuf  MAC PDU.
 *     */
PUBLIC Bool ysCheckSrbOrCcch(Buffer *mBuf)
{
   MsgLen idx;
   U32 isExtBit;

   idx = 0;
   isExtBit = 1;

   while(isExtBit)
   {
      Data firstByte;
      Data secondByte;
      U32 lcId = 0;
      U32 formatBit = 0;

      SExamMsg(&firstByte,mBuf,idx);
      idx += 1; /* for traversing second byte */
      YS_EXT_LCID(lcId, firstByte);

      /* check * the * data * presence * for * ccch/srb1/srb2 * */
      if(lcId < 2)
      {
         RETVALUE(TRUE);
      }

      /* get * the * extention * bit * */
      /* To * check * is * there * any * further * MAC * subheader * follows * in * the * MAC * PDU * */
      YS_EXT_EXTN_BIT(isExtBit,firstByte);
      if(!isExtBit)
      {
         /* This * is * the * last * subheader * in * the * MAC * PDU * */
         RETVALUE(FALSE);
      }

      /* check * for * MAC * control * element * LCID * */
      /* If * it * is * for * MAC * CE * LCID * then * it * contains * only * R/R/E/LCID * */
      /* so * don't * increment * idx * for * decoding * second * byte * */
      if(ysValidateLcid(lcId))
      {
         SExamMsg(&secondByte,mBuf,idx);
         YS_EXT_F_BIT(formatBit, secondByte);
         if(formatBit)
         {
            idx += 2; /*  2 bytes = F - 1 bit, L - 15 bits */
         }
         else
         {
            idx += 1;/* 1 byte = F - 1 bit, L - 7 bits */
         }
      }
   }
   RETVALUE(FALSE);
}

#if 0
/**
 *  *    @brief   This function posts the logs to wireshark application 
 *   *          for the ccch/srb1/srb2 
 *    *    @param[in]  srcBuf    MAC PDU.
 *     *    @param[in]  rnti      UE C-RNTI.
 *      *    @param[in]  subFrame  sub frmae information.
 *       *    @param[in]  direction  UL/DL information.
 *        */
PRIVATE Void ysSendMsgToWireShark(Buffer *srcBuf,U16 rnti,U16 subFrame)
{
   Bool isSrbOrCcch;
   isSrbOrCcch = ysCheckSrbOrCcch(srcBuf);
   if(isSrbOrCcch)
   {
      Buffer *dstBuf;
      /* copy the MAC PDU Info into mBuf */
      if(ROK != SAddMsgRef(srcBuf, ysCb.ysInit.region, ysCb.ysInit.pool, &dstBuf))
      {
         /* error print */
         YS_DBG_ERR((_ysp, "ysSendMsgToWireShark:: SAddMsgRef failed \n"));
         RETVOID;
      }
#ifdef TFU_TDD
      postToApp(dstBuf,
            2,  /* TDD */
            0,  /*UL direction*/
            3, /* C-RNTI Type */
            rnti,
            rnti,
            subFrame,
            0 /* Predefined FALSE */,
            0 /* retx FALSE */,
            1 /* crcStatus TRUE*/
            );
#else
      postToApp(dstBuf,
            1,  /* FDD */
            0,  /* UL dirction*/
            3, /* C-RNTI Type*/
            rnti,
            rnti,
            subFrame,
            0 /* Predefined FALSE */,
            0 /* retx FALSE */,
            1 /* crcStatus TRUE*/
            );
#endif
   }
   RETVOID;
}
#endif

/**
 *  *    @brief   This function checks lcId value.
 *   *       return FALSE if lcid is for MAC Control element
 *         else it returns TRUE
 *          *    @param[in]  lcId LCID value for MAC PDU subheader.
 *           */
PRIVATE Bool ysValidateLcid(U32 lcId)
{
   RETVALUE(lcId < YS_MIN_MAC_CE_LCID);
}

#endif
/*
*
*       Fun:   ysUlHdlEnbStopInd
*
*       Desc:  Handler function for Received ENODEB STOP INDICATION
*              messages from Phy
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ysUlHdlEnbStopInd
(
U32        cellId
)
{
   CtfCfgTransId        transId;
   TRC2(ysUlHdlEnbStopInd);
   /*Fill the transId as cell Id*/

   transId.trans[7] = cellId & 0x000000ff; cellId >>= 8;
   transId.trans[6] = cellId & 0x000000ff; cellId >>= 8;
   transId.trans[5] = cellId & 0x000000ff; cellId >>= 8;
   transId.trans[4] = cellId & 0x000000ff; cellId >>= 8;
   YsUiCtfEnbStopInd(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId, transId);
   RETVALUE(ROK);
}


/********************************************************************30**

         End of file:     yw_ms_ul.c@@/main/TeNB_Main_BR/11 - Mon Aug 11 16:42:39 2014

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      mraj   1. initial release.
/main/1    ys004.102  vr     1. Merged MSPD code with phy 1.7
*********************************************************************91*/

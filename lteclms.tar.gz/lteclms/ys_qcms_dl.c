/*
                 IMPORTANT LIMITATION(S) ON USE
                    
This files include the QC platform DL handle
     

    
 
**********************************************************************/


#include "envopt.h"             /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "fapiApiInternal.h"
#include "ac_ltePhyL2Api.h"
#include "ssi.h"           /* system services */
#include "gen.h"                /* general layer */
#include "tfu.h"
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "lys.h"
#include "resultcodes.h"
#include "ctf.h"
#include "ys_ms.h"
#include "ys_ms_err.h"

#include "gen.x"                /* general layer */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"

#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#include "ctf.x"

#include "ys_ms.x"
#include "ys_qcms.h"

#include <assert.h> 


static void ys_qcBuildHiPdu(FAPI_T_PDU *pdu_p, TfuPhichInfo *ulpdu);
static void ys_qcBuildDci0Pdu(FAPI_T_PDU *pdu_p, TfuPdcchInfo *pdcchInfo, CmLteCellId cellId);
void* ys_qcBuildDlMsg(TfuCntrlReqInfo *tfuCntrlReq,TfuDatReqInfo *datReq,FAPI_T_TX_REQ** fapiTxReq, U16 *LenTxReq, CmLteCellId cellId);
void* ys_NxpBuildDlMsg(TfuCntrlReqInfo *tfuCntrlReq,TfuDatReqInfo *datReq,ltePhyL2ApiTxReq_t** fapiTxReq, U16 *LenTxReq, CmLteCellId cellId);

void* ys_qcBuildDlConfigMsgOnlyBch(TfuDatReqInfo   *datReq,YsCellCb *cellCb,U16* bachPduId);
void ys_qcSendNullCrcInd(U16 sfn, U8 subframe, U8 flag, CmLteCellId cellId);
void ys_qcBuildDciDlPdu(FAPI_T_PDU *pdu_p,TfuPdcchInfo *pdcchInfo, CmLteCellId cellId);
void ys_qcUpdateDatInfo(TfuDatReqInfo *DatReq, U8 phyInstId);


extern PUBLIC Void cmLListCatLList
(
 CmLListCp *list1,              /*-- list control point --*/
 CmLListCp *list2               /*-- node to be added --*/
);


YsQcPhyLstCp   YsQcPhyDlMsgLstCp[YS_LTE_MAX_CELLS][YS_NUM_SUB_FRAMES];
QcDlMsgInfoS   ysQcPhyDlMsgInfo[YS_LTE_MAX_CELLS][YS_NUM_SUB_FRAMES]; 


#define SUBSFNPP(x)  ((x+1)%YS_NUM_SUB_FRAMES)

#define  YSQC_DLCTR_RDY(phyInstId, SFN)    ysQcPhyDlMsgInfo[phyInstId][SFN].ctrInfoRdy
#define  YSQC_DLDAT_RDY(phyInstId, SFN)    ysQcPhyDlMsgInfo[phyInstId][SFN].datInfoRdy
#define  YSQC_SETDLCTR_RDY(phyInstId, SFN) (ysQcPhyDlMsgInfo[phyInstId][SFN].ctrInfoRdy = 1)
#define  YSQC_SETDLDAT_RDY(phyInstId, SFN) (ysQcPhyDlMsgInfo[phyInstId][SFN].datInfoRdy = 1)

#define  YSQC_DLCTR_ARRVD(phyInstId, SFN)    ysQcPhyDlMsgInfo[phyInstId][SFN].ctrArrved
#define  YSQC_SETDLCTR_ARRVD(phyInstId, SFN) (ysQcPhyDlMsgInfo[phyInstId][SFN].ctrArrved = 1)
#define  YSQC_DLDAT_ARRVD(phyInstId, SFN)    ysQcPhyDlMsgInfo[phyInstId][SFN].datArrved
#define  YSQC_SETDLDAT_ARRVD(phyInstId, SFN) (ysQcPhyDlMsgInfo[phyInstId][SFN].datArrved = 1)



void ys_qcInitPhyDlMsgLstCp()
{
    U8 subSfn = 0;	
    U8 i = 0, phyInstId=0;
    while(phyInstId<YS_LTE_MAX_CELLS)
    {
        while(subSfn < YS_NUM_SUB_FRAMES)
        {
            YsQcPhyDlMsgLstCp[phyInstId][subSfn].count = 0;
            for(i = 0; i < YS_MAX_TX_PERSF; i ++)
            {
                YsQcPhyDlMsgLstCp[phyInstId][subSfn].msg[i] = NULLP;
            }
            ysQcPhyDlMsgInfo[phyInstId][subSfn].ctrInfoRdy = 0;
            ysQcPhyDlMsgInfo[phyInstId][subSfn].datInfoRdy = 0;
            ysQcPhyDlMsgInfo[phyInstId][subSfn].ctrArrved = 0;
            ysQcPhyDlMsgInfo[phyInstId][subSfn].datArrved = 0;
            subSfn ++;
        }
        phyInstId++;
    }
    return;
}
void ys_qcCleanDlInfo(U8 subSfn, U8 phyInstId)
{
    if(YSQC_DLDAT_RDY(phyInstId, subSfn))
    {
        ysUtlFreeDatReq(ysQcPhyDlMsgInfo[phyInstId][subSfn].pDatReqInfo);
        ysQcPhyDlMsgInfo[phyInstId][subSfn].pDatReqInfo = NULLP;
    }
    if(YSQC_DLCTR_RDY(phyInstId, subSfn))
    {
        YS_FREE_SDU(ysQcPhyDlMsgInfo[phyInstId][subSfn].pCntrlReqInfo);        
    }
    ysQcPhyDlMsgInfo[phyInstId][subSfn].ctrInfoRdy = 0;
    ysQcPhyDlMsgInfo[phyInstId][subSfn].datInfoRdy = 0;
    ysQcPhyDlMsgInfo[phyInstId][subSfn].ctrArrved = 0;
    ysQcPhyDlMsgInfo[phyInstId][subSfn].datArrved = 0;

    return;
}

#define IS_BIT_SET(_a, _i)  ((_a) & (1<<(_i)))
U32 ys_qcsetRbforRaType0_1( U8 *resAllocMap )
{
   U32 RbCoding = 0;

   U32 i, j;
   for (i = 0; i < TFU_MAX_ALLOC_BYTES; ++i)
   {
      U8  base = i * 8;
      if (!resAllocMap[i])
         continue;
      for (j = 0; j < 8; ++j)
      {
         if (IS_BIT_SET(resAllocMap[i], 7-j))
         {
            RbCoding |=  1 << (24- (base + j));
         }
      }
   }

   return RbCoding;
}

U32 ys_qcsetRbforRaType0( U8 *resAllocMap, CtfBandwidth bandWidth)
{
    U32 RbCoding = 0;
    U32 i, j=0;
    U32 numOfRbgs=0;
    U32 newResAllocMap=0;
    switch(bandWidth)
    {
        case CTF_BW_RB_6:
            numOfRbgs =6;
            break;
        case CTF_BW_RB_15:
            numOfRbgs =8;
            break;
        case CTF_BW_RB_25:
            numOfRbgs=13;
            break;
            case CTF_BW_RB_50:
            numOfRbgs=17;
            break;
        case CTF_BW_RB_75:
            numOfRbgs=19;
            break;
        case CTF_BW_RB_100:
            numOfRbgs=25;
            break;
        default:
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcsetRbforRaType0 ERROR: invalid bandWith!\n");
            return 0;
    }
    for(i = 0; i < TFU_MAX_ALLOC_BYTES; ++i)
    {
        RbCoding |=((resAllocMap[i])<<((TFU_MAX_ALLOC_BYTES-i-1)*8));
    }

    return RbCoding;
}

U8 ys_qcMcstoModulation (U32 mcs, Bool dl_ul)
{
    U32 endQPSK = 0, end16QAM = 0;
    const U32 end64QAM = 28;

    if(mcs == 29)
    {
        return 2;
    }

    if(mcs == 30)
    {
        return 4;
    }

    if(mcs == 31)
    {
        return 6;
    }

    if(dl_ul)
    {
        endQPSK     = 9;
        end16QAM = 16;
    }
    else
    {
        endQPSK     = 10;
        end16QAM = 20;
    }

    if(mcs <= endQPSK)
        return FAPI_E_MOD_QPSK;
    else if(mcs <= end16QAM)
        return FAPI_E_MOD_16QAM;
    else if(mcs <= end64QAM)
        return FAPI_E_MOD_64QAM;
    else
        return 0;
}

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_calc_dl_config_msg_size
 * Description:     Calculate the DL_CONFIG_REQ messages size
 *
 * Input:       nsf - the SF number for which the request is
 *                being built
 *
 * Output:      N/A
 *
 * ----------------------------------------------------------------------
 */
U32 ys_qcCalcDlConfigMsgSize(TfuCntrlReqInfo *tfuCntrlReq, TfuDatReqInfo *datReq , U16 *pdu_count, U16 *tx_req_szie)
{

    U32          pdu_data_size = 0;
    U32          dl_config_msg_size = 0;
    U8           p_rntiCount = 0;
    CmLList      *cmLstEnt;
    TfuDatReqPduInfo *pduInfo;
    MsgLen	   bufLen;

    *tx_req_szie = sizeof(FAPI_T_TX_REQ);
    cmLstEnt = tfuCntrlReq->dlPdcchLst.first;
    dl_config_msg_size = sizeof(FAPI_T_DL_CONFIG_REQ) +
                         tfuCntrlReq->dlPdcchLst.count* (sizeof(FAPI_T_PDU) +
                         sizeof(FAPI_T_DCI_DL_PDU_A)+sizeof(FAPI_T_DCI_DL_PDU_B)) +
                         p_rntiCount * (sizeof(FAPI_T_PDU) +
                         sizeof(FAPI_T_PCH_PDU));

    cmLstEnt = datReq->pdus.first;

    for(cmLstEnt = datReq->pdus.first;cmLstEnt != NULLP;)
    {
        pdu_data_size = 0;
        pduInfo = (TfuDatReqPduInfo*)cmLstEnt->node;
        cmLstEnt = cmLstEnt->next;
        pdu_data_size +=  sizeof(U8); /* size of codebook indices (only 1 codebook index is supported) */

        pdu_data_size += (sizeof(FAPI_T_PDU) +
                         sizeof(FAPI_T_DLSCH_PDU_A) +
                         sizeof(FAPI_T_DLSCH_PDU_B) +
                         sizeof(FAPI_T_DLSCH_PDU_C) +
                         sizeof(FAPI_T_DLSCH_PDU_D));
        (*pdu_count)++;

        if((1 == pduInfo->nmbOfTBs)&&((pduInfo->dciInfo.format ==TFU_DCI_FORMAT_2A)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].rv == 1)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].mcs== 0)))
        {
            if(pduInfo->mBuf[1])
            {
                SFndLenMsg(pduInfo->mBuf[1], &bufLen);
            }
            else
            {
                STKLOG(STK_MD_YS,STK_LOG_ERR,"pduInfo->mBuf[01] error --------------------------------------------------------------------------\n");
            }
        }
        else
        {
            if(pduInfo->mBuf[0])
            {
                SFndLenMsg(pduInfo->mBuf[0], &bufLen);
            }
            else
            {
                STKLOG(STK_MD_YS,STK_LOG_ERR,"pduInfo->mBuf[0] error --------------------------------------------------------------------------\n");
            }
        }

        if((sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen)%4)
        {
            *tx_req_szie += sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen + (4-bufLen%4);
        }
        else
        {
            *tx_req_szie += sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen;
        }

        if(pduInfo->nmbOfTBs == 2)
        {
            (*pdu_count)++;
            if(pduInfo->mBuf[1])
            {
                SFndLenMsg(pduInfo->mBuf[1], &bufLen);
            }
            else
            {
                STKLOG(STK_MD_YS,STK_LOG_ERR,"pduInfo->mBuf[1] error --------------------------------------------------------------------------\n");
            }
            if((sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen)%4)
            {
                *tx_req_szie += sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen + (4-bufLen%4);
            }
            else
            {
                *tx_req_szie += sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen;
            }
            pdu_data_size *= 2;
        }
        dl_config_msg_size += pdu_data_size;

    }
    if(datReq->bchDat.pres)
    {
        (*pdu_count)++;
        SFndLenMsg(datReq->bchDat.val, &bufLen);
        if((sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen)%4)
        {
            *tx_req_szie += sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen + (4-bufLen%4);
        }
        else
        {
            *tx_req_szie += sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen;
        }
        dl_config_msg_size += (sizeof(FAPI_T_BCH_PDU) + sizeof(FAPI_T_PDU));
    }

    return dl_config_msg_size;
}
/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_calc_dl_config_msg_size
 * Description:     Calculate the DL_CONFIG_REQ messages size
 *
 * Input:       nsf - the SF number for which the request is
 *                being built
 *
 * Output:      N/A
 *
 * ----------------------------------------------------------------------
 */
U32 ys_NxpCalcDlConfigMsgSize(TfuCntrlReqInfo *tfuCntrlReq, TfuDatReqInfo *datReq , U16 *pdu_count, U16 *tx_req_szie,U32 *totalBufLen)
{

    U32          pdu_data_size = 0;
    U32          dl_config_msg_size = 0;
    U8           p_rntiCount = 0;
    CmLList      *cmLstEnt;
    TfuDatReqPduInfo *pduInfo;
    MsgLen	   bufLen;

    *tx_req_szie = sizeof(ltePhyL2ApiTxReq_t);
    cmLstEnt = tfuCntrlReq->dlPdcchLst.first;
    dl_config_msg_size = sizeof(ltePhyL2ApiDlConfigReq_t) +
                         tfuCntrlReq->dlPdcchLst.count* (2 +
                         sizeof(apiDlCfgPduDCI_t)) +
                         p_rntiCount * (sizeof(FAPI_T_PDU) +
                         sizeof(FAPI_T_PCH_PDU));

    cmLstEnt = datReq->pdus.first;

    for(cmLstEnt = datReq->pdus.first;cmLstEnt != NULLP;)
    {
        pdu_data_size = 0;
        pduInfo = (TfuDatReqPduInfo*)cmLstEnt->node;
        cmLstEnt = cmLstEnt->next;
    //pdu_data_size +=  sizeof(U8); /* size of codebook indices (only 1 codebook index is supported) */

        pdu_data_size += (2 +
                         sizeof(apiDlCfgPduDlSCH_t));
        (*pdu_count)++;

        if((1 == pduInfo->nmbOfTBs)&&((pduInfo->dciInfo.format ==TFU_DCI_FORMAT_2A)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].rv == 1)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].mcs== 0)))
        {
            if(pduInfo->mBuf[1])
            {
                SFndLenMsg(pduInfo->mBuf[1], &bufLen);
                *totalBufLen+=bufLen;
            }
            else
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"pduInfo->mBuf[01] error --------------------------------------------------------------------------\n");
            }
        }
        else
        {
            if(pduInfo->mBuf[0])
            {
                SFndLenMsg(pduInfo->mBuf[0], &bufLen);
                *totalBufLen+=bufLen;
            }
            else
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"pduInfo->mBuf[0] error --------------------------------------------------------------------------\n");
            }
        }

 
        *tx_req_szie += sizeof(apiTxDataPdu_t) + sizeof(apiDlDataTlv_t);

        if(pduInfo->nmbOfTBs == 2)
        {
            (*pdu_count)++;
            if(pduInfo->mBuf[1])
            {
                SFndLenMsg(pduInfo->mBuf[1], &bufLen);
                *totalBufLen+=bufLen;
            }
            else
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"pduInfo->mBuf[1] error --------------------------------------------------------------------------\n");
            }
            *tx_req_szie += sizeof(apiTxDataPdu_t) + sizeof(apiDlDataTlv_t);
            pdu_data_size *= 2;
        }
        dl_config_msg_size += pdu_data_size;

    }
    if(datReq->bchDat.pres)
    {
        (*pdu_count)++;
        SFndLenMsg(datReq->bchDat.val, &bufLen);
        *totalBufLen+=bufLen;
         *tx_req_szie += sizeof(apiTxDataPdu_t) + sizeof(apiDlDataTlv_t);
        dl_config_msg_size += sizeof(apiDlCfgPduBCH_t)+ sizeof(apiDlCfgPdu_t);
    }

    return dl_config_msg_size;
}

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_dlsch_pdu
 * Description:     Init PDSCH request message with configured before
 *                      parameters for DL
 *
 * Input:       N/A
 *
 * Output:      N/A
 *
 * ----------------------------------------------------------------------
 */
U32 ys_qcBuildDlschPdu(FAPI_T_PDU *pdu_p, 
                       Bool second_tb,
                       U32 pdu_idx,
                       TfuDatReqPduInfo *pduInfo,
                       TfuCntrlReqInfo  *tfuCntrlReq, 
                       U16 Pdulen,
                       CmLteCellId cellId)
{
    FAPI_T_DLSCH_PDU_A          *dlsch_pdu_a;
    FAPI_T_DLSCH_PDU_B          *dlsch_pdu_b;
    FAPI_T_DLSCH_PDU_C          *dlsch_pdu_c;
    FAPI_T_DLSCH_PDU_D          *dlsch_pdu_d;
    U8 prbMap[CTF_BW_RB_100+1]={6,15,25,50,75,100};

    TfuPdcchInfo *pdcchInfo = NULL;
    CmLList 	 *cmLstEnt;
    YsCellCb	*cellCb = (YsCellCb*)ysMsCfgGetCellCfg(cellId);
    U32 pdu_data_size = 0;
    U8 mcs = 0;

    dlsch_pdu_a = (FAPI_T_DLSCH_PDU_A *)&(pdu_p->pdu[0]);
    dlsch_pdu_a->rel8_A.pdu_idx = pdu_idx;
    dlsch_pdu_a->rel8_A.rnti = pduInfo->rnti;
    if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)
    {
        if(pduInfo->dciInfo.u.format1aAllocInfo.isLocal)
        {
            dlsch_pdu_a->rel8_A.vir_rb_flag = 0;
        }
        else
        {
            dlsch_pdu_a->rel8_A.vir_rb_flag = 1;
        }
    }

    if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1)
    {
        dlsch_pdu_a->rel8_A.ra_type = ~(pduInfo->dciInfo.u.format1AllocInfo.isAllocType0);
    }
    else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"TFU_DCI_FORMAT_2 to be debuged \n");
    }
    else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A)
    {
        dlsch_pdu_a->rel8_A.vir_rb_flag = 0;
        dlsch_pdu_a->rel8_A.ra_type = 1- (pduInfo->dciInfo.u.format2AAllocInfo.isAllocType0);
        dlsch_pdu_a->rel8_A.rb_coding = ys_qcsetRbforRaType0(pduInfo->dciInfo.u.format2AAllocInfo.resAllocMap, cellCb->cellCfg.bwCfg.dlBw);

    }
    else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)
    {
        dlsch_pdu_a->rel8_A.ra_type = 2;
        dlsch_pdu_a->rel8_A.rb_coding = pduInfo->dciInfo.u.format1aAllocInfo.alloc.u.riv;
    }

    if(second_tb)
    {
        if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2)
        {
            mcs = pduInfo->dciInfo.u.format2AllocInfo.tbInfo[1].mcs;
            dlsch_pdu_a->rel8_A.rv = pduInfo->dciInfo.u.format2AllocInfo.tbInfo[1].rv;
        }
        else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A)
        {
            mcs = pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[1].mcs;
            dlsch_pdu_a->rel8_A.rv = pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[1].rv;
        }
        if((1 == pduInfo->nmbOfTBs)&&((pduInfo->dciInfo.format ==TFU_DCI_FORMAT_2A)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].rv == 1)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].mcs== 0)))
        {
            dlsch_pdu_a->rel8_A.tb= 1;
        }
        else
        {
            dlsch_pdu_a->rel8_A.tb = 2;
        }
    }
    else
    {
        if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1)
        {
            mcs = pduInfo->dciInfo.u.format1AllocInfo.mcs;
            dlsch_pdu_a->rel8_A.rv = pduInfo->dciInfo.u.format1AllocInfo.rv;
        }
        else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)
        {
            mcs = pduInfo->dciInfo.u.format1aAllocInfo.mcs;
            dlsch_pdu_a->rel8_A.rv = pduInfo->dciInfo.u.format1aAllocInfo.rv;
        }
        else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2)
        {
            mcs = pduInfo->dciInfo.u.format2AllocInfo.tbInfo[0].mcs;
            dlsch_pdu_a->rel8_A.rv = pduInfo->dciInfo.u.format2AllocInfo.tbInfo[0].rv;
        }
        else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A)
        {
            mcs = pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].mcs;
            dlsch_pdu_a->rel8_A.rv = pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].rv;
        }
        dlsch_pdu_a->rel8_A.tb = 1;
    }

    dlsch_pdu_a->rel8_A.modulation =  ys_qcMcstoModulation(mcs, TRUE);
    if(YS_SI_RNTI == pduInfo->rnti)//#23035, 2019/3/19, fix the modulation to QPSK for SI-RNTI
    {
        dlsch_pdu_a->rel8_A.modulation = 2;
    }
    dlsch_pdu_a->rel8_A.length = Pdulen;//MAC_SIM_fapi_get_dlsch_data_length(dlpdu, second_tb, tb_size_reduc);
    dlsch_pdu_a->rel8_A.tb_2_code_swap = 0;
    if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A)
    {
        dlsch_pdu_a->rel8_A.trans_scheme = 2;
    }
    else
    {
        dlsch_pdu_a->rel8_A.trans_scheme = 1;
    }
    dlsch_pdu_a->rel8_A.n_layers = pduInfo->nmbOfTBs;//pduInfo->numLayers;
    dlsch_pdu_a->rel8_A.n_subbands = 1;
    dlsch_pdu_a->rel8_A.codebook_idx[0] = 0;

    pdu_data_size +=  sizeof(U8);
    dlsch_pdu_b = (FAPI_T_DLSCH_PDU_B *)((U8 *)dlsch_pdu_a +sizeof(FAPI_T_DLSCH_PDU_A)+( sizeof(U8)));
    dlsch_pdu_b->rel8_B.ue_cat_cap = 5;//dlpdu->DLSCH_ue_cat_cap;
    dlsch_pdu_b->rel8_B.pa = pduInfo->pa;
    dlsch_pdu_b->rel8_B.del_pwr_off_idx = 0;//pduInfo->deltaPowOffIdx;//dlpdu->DLSCH_del_pwr_off_idx;

    if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)
    {
        dlsch_pdu_b->rel8_B.n_gap = pduInfo->dciInfo.u.format1aAllocInfo.nGap2.val;
    }
    else
    {
        dlsch_pdu_b->rel8_B.n_gap = 0;
    }

    if((pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)&&((YS_SI_RNTI == pduInfo->rnti)||(YS_P_RNTI == pduInfo->rnti)||(pduInfo->rnti <= YS_MAX_RARNTI)))
    {
        cmLstEnt = tfuCntrlReq->dlPdcchLst.first;
        while(cmLstEnt != NULLP)
        {
            pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
            if(pdcchInfo->rnti == pduInfo->rnti)
            {
                break;
            }
            cmLstEnt = cmLstEnt->next;
        }
        dlsch_pdu_b->rel8_B.n_prb = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        dlsch_pdu_b->rel8_B.trans_mode = cellCb->cellInfo.cmnTransMode;
        dlsch_pdu_b->rel8_B.n_bf_prb = prbMap[cellCb->cellCfg.bwCfg.dlBw];
        dlsch_pdu_b->rel8_B.n_bf_vector = 0;
    }
    else
    {
        dlsch_pdu_b->rel8_B.n_prb = 0;
        dlsch_pdu_b->rel8_B.trans_mode = 3;//pduInfo->transMode;
        dlsch_pdu_b->rel8_B.n_bf_prb = prbMap[cellCb->cellCfg.bwCfg.dlBw];//pduInfo->numBfPrbPerSb;
        dlsch_pdu_b->rel8_B.n_bf_vector = 0;//pduInfo->numBfVectors;
    }
    dlsch_pdu_c = (FAPI_T_DLSCH_PDU_C *)((U8 *)dlsch_pdu_b +sizeof(FAPI_T_DLSCH_PDU_B));
    dlsch_pdu_c->rel9.nscid = 0;
    dlsch_pdu_c->rel10_A.csi_rs_flag = 0;
    dlsch_pdu_c->rel10_A.csi_res_conf_r10 = 0;
    dlsch_pdu_c->rel10_A.csi_rs_cnf_bmap_r10 = 0;
    dlsch_pdu_c->rel10_A.csi_rs_num_nzp_cfg= 0;

    dlsch_pdu_d = (FAPI_T_DLSCH_PDU_D *)((U8 *)dlsch_pdu_c +sizeof(FAPI_T_DLSCH_PDU_C));
    dlsch_pdu_d->rel10_B.pdsch_start = 0xFF;

    dlsch_pdu_d->rel11.dmrs_config_flag= 0;
    dlsch_pdu_d->rel11.dmrs_scrambling= 0;
    dlsch_pdu_d->rel11.csi_config_flag= 0;
    dlsch_pdu_d->rel11.csi_scrambling= 36; //for temp test
    dlsch_pdu_d->rel11.pdsch_re_map_flag= 0;
    dlsch_pdu_d->rel11.pdsch_re_map_ant_ports= 0;
    dlsch_pdu_d->rel11.pdsch_re_map_freq_shift= 0;

    dlsch_pdu_d->rel12.altCQI_table_r12= 0;
    dlsch_pdu_d->rel12.max_layers= 0;
    dlsch_pdu_d->rel12.n_dl_harq= 0;
    dlsch_pdu_d->rel13.DwPTS_symbols= 0;
    dlsch_pdu_d->rel13.init_lbt_sf= 0;
    dlsch_pdu_d->rel13.ue_type= 0;
    dlsch_pdu_d->rel13.payload_type= 0;
    dlsch_pdu_d->rel13.initial_transmission_sf= 0xFFFF;
    dlsch_pdu_d->rel13.r13_dmrs_table_flag= 0;

    return pdu_data_size;
} // end of MAC_SIM_fapi_build_dlsch_pdu

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_dlsch_pdu
 * Description:     Init PDSCH request message with configured before
 *                      parameters for DL
 *
 * Input:       N/A
 *
 * Output:      N/A
 *
 * ----------------------------------------------------------------------
 */
U32 ys_NxpBuildDlschPdu(apiDlCfgPdu_t *pdu_p, 
                       Bool second_tb,
                       U32 pdu_idx,
                       TfuDatReqPduInfo *pduInfo,
                       TfuCntrlReqInfo  *tfuCntrlReq, 
                       U16 Pdulen,
                       CmLteCellId cellId)
{
    apiDlCfgPduDlSCH_t *dlsch_pdu;
    U8 prbMap[CTF_BW_RB_100+1]={6,15,25,50,75,100};

    TfuPdcchInfo *pdcchInfo = NULL;
    CmLList 	 *cmLstEnt;
    YsCellCb	*cellCb = (YsCellCb*)ysMsCfgGetCellCfg(cellId);
    U32 pdu_data_size = 0;
    U8 mcs = 0;

    dlsch_pdu = (apiDlCfgPduDlSCH_t *)&(pdu_p->pdu[0]);
    dlsch_pdu->pduIdx = pdu_idx;
    dlsch_pdu->rnti = pduInfo->rnti;
    if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)
    {
        if(pduInfo->dciInfo.u.format1aAllocInfo.isLocal)
        {
            dlsch_pdu->virtRbFlag= 0;
        }
        else
        {
            dlsch_pdu->virtRbFlag= 1;
        }
    }

    if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1)
    {
        dlsch_pdu->resAllocType= ~(pduInfo->dciInfo.u.format1AllocInfo.isAllocType0);
    }
    else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"TFU_DCI_FORMAT_2 to be debuged \n");
    }
    else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A)
    {
        dlsch_pdu->virtRbFlag= 0;
        dlsch_pdu->resAllocType= 1- (pduInfo->dciInfo.u.format2AAllocInfo.isAllocType0);
       // printf("rbcoding %x %x %x %x \n",pduInfo->dciInfo.u.format2AAllocInfo.resAllocMap[0],pduInfo->dciInfo.u.format2AAllocInfo.resAllocMap[1],pduInfo->dciInfo.u.format2AAllocInfo.resAllocMap[2],pduInfo->dciInfo.u.format2AAllocInfo.resAllocMap[3]);
        dlsch_pdu->rbCoding= ys_qcsetRbforRaType0(pduInfo->dciInfo.u.format2AAllocInfo.resAllocMap, cellCb->cellCfg.bwCfg.dlBw);

    }
    else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)
    {
        dlsch_pdu->resAllocType= 2;
        dlsch_pdu->rbCoding = pduInfo->dciInfo.u.format1aAllocInfo.alloc.u.riv;
    }

    if(second_tb)
    {
        if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2)
        {
            mcs = pduInfo->dciInfo.u.format2AllocInfo.tbInfo[1].mcs;
            dlsch_pdu->rv = pduInfo->dciInfo.u.format2AllocInfo.tbInfo[1].rv;
        }
        else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A)
        {
            mcs = pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[1].mcs;
            dlsch_pdu->rv = pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[1].rv;
        }
        if((1 == pduInfo->nmbOfTBs)&&((pduInfo->dciInfo.format ==TFU_DCI_FORMAT_2A)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].rv == 1)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].mcs== 0)))
        {
            dlsch_pdu->tbIdx= 1;
        }
        else
        {
            dlsch_pdu->tbIdx= 2;
        }
    }
    else
    {
        if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1)
        {
            mcs = pduInfo->dciInfo.u.format1AllocInfo.mcs;
            dlsch_pdu->rv = pduInfo->dciInfo.u.format1AllocInfo.rv;
        }
        else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)
        {
            mcs = pduInfo->dciInfo.u.format1aAllocInfo.mcs;
            dlsch_pdu->rv = pduInfo->dciInfo.u.format1aAllocInfo.rv;
        }
        else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2)
        {
            mcs = pduInfo->dciInfo.u.format2AllocInfo.tbInfo[0].mcs;
            dlsch_pdu->rv = pduInfo->dciInfo.u.format2AllocInfo.tbInfo[0].rv;
        }
        else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A)
        {
            mcs = pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].mcs;
            dlsch_pdu->rv = pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].rv;
        }
        dlsch_pdu->tbIdx= 1;
    }

    dlsch_pdu->modulation =  ys_qcMcstoModulation(mcs, TRUE);
    if(YS_SI_RNTI == pduInfo->rnti)//#23035, 2019/3/19, fix the modulation to QPSK for SI-RNTI
    {
        dlsch_pdu->modulation = 2;
    }
    dlsch_pdu->length = Pdulen;//MAC_SIM_fapi_get_dlsch_data_length(dlpdu, second_tb, tb_size_reduc);
    dlsch_pdu->tbCwSwapFlag = 0;
    if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A)
    {
        if(pduInfo->nmbOfTBs == 2)
        {
            dlsch_pdu->transScheme= 2;
        }
        else
        {
            dlsch_pdu->transScheme= 1;
        }
    }
    else
    {
        dlsch_pdu->transScheme= 1;
    }
    dlsch_pdu->numLayers= 2;//pduInfo->nmbOfTBs;//pduInfo->numLayers;
    dlsch_pdu->numSubbands= 0;
   // dlsch_pdu->codeBookIdx[0] = 0;

   // pdu_data_size +=  sizeof(U8);
    
    dlsch_pdu->ueCategory= 5;//dlpdu->DLSCH_ue_cat_cap;
    dlsch_pdu->PA = pduInfo->pa;
    dlsch_pdu->deltaPowerOffs= 0;//pduInfo->deltaPowOffIdx;//dlpdu->DLSCH_del_pwr_off_idx;

    if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)
    {
        dlsch_pdu->N_GAP=0;// pduInfo->dciInfo.u.format1aAllocInfo.nGap2.val;
    }
    else
    {
        dlsch_pdu->N_GAP= 0;
    }

    if((pduInfo->dciInfo.format == TFU_DCI_FORMAT_1A)&&((YS_SI_RNTI == pduInfo->rnti)||(YS_P_RNTI == pduInfo->rnti)||(pduInfo->rnti <= YS_MAX_RARNTI)))
    {
        cmLstEnt = tfuCntrlReq->dlPdcchLst.first;
        while(cmLstEnt != NULLP)
        {
            pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
            if(pdcchInfo->rnti == pduInfo->rnti)
            {
                break;
            }
            cmLstEnt = cmLstEnt->next;
        }
        dlsch_pdu->N_PRB = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        dlsch_pdu->TransMode= cellCb->cellInfo.cmnTransMode;
        dlsch_pdu->numPrbPerSubband=0;// prbMap[cellCb->cellCfg.bwCfg.dlBw];
        dlsch_pdu->numBfVector = 0;
    }
    else
    {
        dlsch_pdu->N_PRB = 0;
        dlsch_pdu->TransMode= 3;//pduInfo->transMode;
        dlsch_pdu->numPrbPerSubband= 0;//prbMap[cellCb->cellCfg.bwCfg.dlBw];//pduInfo->numBfPrbPerSb;
        dlsch_pdu->numBfVector= 0;//pduInfo->numBfVectors;
    }
    #if 0
    dlsch_pdu_c = (FAPI_T_DLSCH_PDU_C *)((U8 *)dlsch_pdu_b +sizeof(FAPI_T_DLSCH_PDU_B));
    dlsch_pdu_c->rel9.nscid = 0;
    dlsch_pdu_c->rel10_A.csi_rs_flag = 0;
    dlsch_pdu_c->rel10_A.csi_res_conf_r10 = 0;
    dlsch_pdu_c->rel10_A.csi_rs_cnf_bmap_r10 = 0;
    dlsch_pdu_c->rel10_A.csi_rs_num_nzp_cfg= 0;

    dlsch_pdu_d = (FAPI_T_DLSCH_PDU_D *)((U8 *)dlsch_pdu_c +sizeof(FAPI_T_DLSCH_PDU_C));
    dlsch_pdu_d->rel10_B.pdsch_start = 0xFF;

    dlsch_pdu_d->rel11.dmrs_config_flag= 0;
    dlsch_pdu_d->rel11.dmrs_scrambling= 0;
    dlsch_pdu_d->rel11.csi_config_flag= 0;
    dlsch_pdu_d->rel11.csi_scrambling= 36; //for temp test
    dlsch_pdu_d->rel11.pdsch_re_map_flag= 0;
    dlsch_pdu_d->rel11.pdsch_re_map_ant_ports= 0;
    dlsch_pdu_d->rel11.pdsch_re_map_freq_shift= 0;

    dlsch_pdu_d->rel12.altCQI_table_r12= 0;
    dlsch_pdu_d->rel12.max_layers= 0;
    dlsch_pdu_d->rel12.n_dl_harq= 0;
    dlsch_pdu_d->rel13.DwPTS_symbols= 0;
    dlsch_pdu_d->rel13.init_lbt_sf= 0;
    dlsch_pdu_d->rel13.ue_type= 0;
    dlsch_pdu_d->rel13.payload_type= 0;
    dlsch_pdu_d->rel13.initial_transmission_sf= 0xFFFF;
    dlsch_pdu_d->rel13.r13_dmrs_table_flag= 0;
#endif
    return pdu_data_size;
} // end of MAC_SIM_fapi_build_dlsch_pdu

PUBLIC S16 ys_qcBuildTxReqPdu(FAPI_T_TX_REQ_PDU *tx_pdu,TfuDatReqPduInfo *datReq,U16  pdu_idx,U8  tbIndex, U16 sfn,U8 subsfn, CmLteCellId cellId)
{

    MsgLen     bufLen;
    MsgLen     malloclen = 0;
    MsgLen     cLen;
    FAPI_T_TLV *TxTlv = NULLP;
    U8* pTlv;

    if (!datReq->mBuf[tbIndex])
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcBuildTxReqPdu mBuf null sfn %d subsfn%d  tb idx %d\n",sfn,subsfn,tbIndex);
        //return 0;
    }

    SFndLenMsg(datReq->mBuf[tbIndex], &bufLen);
    rgStats.dlrate_tfu[cellId - CM_START_CELL_ID] += bufLen;
    tx_pdu->n_tlv = 1;
    tx_pdu->pdu_idx = pdu_idx;
    tx_pdu->pdu_length = sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32 *)+ bufLen;
    TxTlv = (FAPI_T_TLV *)&tx_pdu->tlv[0];
    TxTlv->tag = 0;
    TxTlv->length = bufLen;

    pTlv = (U8*)&TxTlv->length;
    pTlv += sizeof(TxTlv->length);

    if (SCpyMsgFix(datReq->mBuf[tbIndex], (MsgLen)0, (MsgLen)bufLen,
        (Data*)pTlv, (MsgLen*)&cLen) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcBuildTxReqPdu copy failed \n");
        //YS_MS_FREE(TxTlv->value, malloclen, (cellId - CM_START_CELL_ID));
        return 0;
    }

    if(cLen != 28)
    {
        //assert(0);
    }

    return bufLen;
} /* end of ysMsUtlFillTxSduForPDSCH */
PUBLIC S16 ys_NxpBuildTxReqPdu(apiTxDataPdu_t *tx_pdu,TfuDatReqPduInfo *datReq,U16  pdu_idx,U8  tbIndex, U16 sfn,U8 subsfn, CmLteCellId cellId,U32 *offset)
{

    MsgLen     bufLen;
    MsgLen     malloclen = 0;
    MsgLen     cLen;
    apiDlDataTlv_t *TxTlv = NULLP;
    U8* pTlv;
    U8* dataBuf_p;

    if (!datReq->mBuf[tbIndex])
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcBuildTxReqPdu mBuf null sfn %d subsfn%d  tb idx %d\n",sfn,subsfn,tbIndex);
        //return 0;
    }

    SFndLenMsg(datReq->mBuf[tbIndex], &bufLen);
    rgStats.dlrate_tfu[cellId - CM_START_CELL_ID] += bufLen;
    tx_pdu->numTlvs= 1;
    tx_pdu->pduIdx = pdu_idx;
    tx_pdu->pduSize = sizeof(apiTxDataPdu_t) + sizeof(apiDlDataTlv_t);
    TxTlv = (apiDlDataTlv_t *)&tx_pdu->TLV[0];
    TxTlv->tag = 1;
    TxTlv->length = bufLen;
    TxTlv->value =  *offset;
  
   
    dataBuf_p = ac_shmAlloc(bufLen);
    if (SCpyMsgFix(datReq->mBuf[tbIndex], (MsgLen)0, (MsgLen)bufLen,
        dataBuf_p, (MsgLen*)&cLen) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcBuildTxReqPdu copy failed \n");
        //YS_MS_FREE(TxTlv->value, malloclen, (cellId - CM_START_CELL_ID));
        return 0;
    }
    
    *offset+=bufLen;

    if(cLen != 28)
    {
        //assert(0);
    }

    return bufLen;
} /* end of ysMsUtlFillTxSduForPDSCH */

#define PACK_STRUCT __attribute__((packed))

typedef struct PACK_STRUCT FAPI_S_TX_REQS{
    U16                 pdu_length; //The total length (in bytes) of the PDU description and PDU data, without the padding bytes.
    U16                 pdu_idx; //This is a count value which starts from 0. It is incremented for each BCH, MCH, PCH or DLSCH PDU. This value was included in TX.request and associates the data to the control information. It is reset to 0 for every subframe. Range 0...65535
    U32                 n_tlv; //The number of TLVs describing the data of the transport block.
    //FAPI_T_TLV          tlv[]; //Always a multiple of 32-bits.
 } FAPI_T_TX_REQS;
void* ys_NxpBuildTxReqOnlyBch(TfuCntrlReqInfo* cntrlReq,TfuDatReqInfo* pDatReqInfo,YsCellCb* cellCb,U16 bchPduId)
{
    ltePhyL2ApiTxReq_t *  fapiTxReq;
    apiTxDataPdu_t* txReqPdu;
    U8* pTlv;
    MsgLen     bufLen,outPut;
    U32 size;
    U32 bchPduSize;
    U16 indx = cellCb->cellId - CM_START_CELL_ID;
    U8* dataBuf_p;
    U32 firstPduPAddr;
    SFndLenMsg(pDatReqInfo->bchDat.val, &bufLen);
    

    size = sizeof(ltePhyL2ApiTxReq_t) + sizeof(apiTxDataPdu_t) + sizeof(apiDlDataTlv_t);
    bchPduSize = sizeof(apiTxDataPdu_t) + sizeof(apiDlDataTlv_t);
    
    if(ysUtlAllocQCIPCSBuf((Data **)&fapiTxReq, 1024,indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"hidci0 SGetSBuf failed.\n");
        return NULLP;
    }
    
    /* build msg body */
    fapiTxReq->msg_hdr.msgBodyLength = size - sizeof(FAPI_T_MSG_HDR);

    fapiTxReq->msg_hdr.msgVdrSpecFlag = 0;

    fapiTxReq->msg_hdr.msgTypeId = FAPI_E_TX_REQ;
    fapiTxReq->numPDUs = 1;
    fapiTxReq->SFN_SF = (pDatReqInfo->timingInfo.sfn << 4) + (pDatReqInfo->timingInfo.subframe & 0xF);

    firstPduPAddr = ac_shmV2P(ac_getAvaiShmAddr());
    memcpy((void *)((U8*)(fapiTxReq) + 1020), &firstPduPAddr, 4);
    /* build bach pdu */
    txReqPdu = (apiTxDataPdu_t*)&fapiTxReq->PDU[0];
    txReqPdu->pduSize= bchPduSize;
    txReqPdu->pduIdx= bchPduId;
    txReqPdu->numTlvs = 1;
    apiDlDataTlv_t* txBchTlv = (apiDlDataTlv_t*)&(txReqPdu->TLV[0]);
    txBchTlv->length     = bufLen;
    txBchTlv->tag        = 1; //value model on krait
    txBchTlv->value     = 0;

    dataBuf_p = ac_shmAlloc(bufLen);  
    SCpyMsgFix(pDatReqInfo->bchDat.val,0,bufLen,dataBuf_p,&outPut);

    return (void*)fapiTxReq;
}

void* ys_qcBuildTxReqOnlyBch(TfuCntrlReqInfo* cntrlReq,TfuDatReqInfo* pDatReqInfo,YsCellCb* cellCb,U16 bchPduId)
{
    FAPI_T_TX_REQ*  fapiTxReq;
    FAPI_T_TX_REQ_PDU* txReqPdu;
    U8* pTlv;
    MsgLen     bufLen,outPut;
    U32 size;
    U32 bchPduSize;
    U16 indx = cellCb->cellId - CM_START_CELL_ID;
    SFndLenMsg(pDatReqInfo->bchDat.val, &bufLen);

    size = sizeof(FAPI_T_TX_REQ) + sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*)+  bufLen + (4-bufLen%4);
    bchPduSize = sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*) + bufLen;
    
    if(ysUtlAllocQCIPCSBuf((Data **)&fapiTxReq, size,indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"hidci0 SGetSBuf failed.\n");
        return NULLP;
    }
    
    /* build msg body */
    fapiTxReq->msg_hdr.len = size - sizeof(FAPI_T_MSG_HDR);
    #ifdef NXP_PLATFORM
    fapiTxReq->msg_hdr.msgVdrSpecFlag = 0;
    #else
    fapiTxReq->msg_hdr.len_ven = 0;
    #endif
    fapiTxReq->msg_hdr.type = FAPI_E_TX_REQ;
    fapiTxReq->n_pdu = 1;
    fapiTxReq->sf_sfn = (pDatReqInfo->timingInfo.sfn << 4) + (pDatReqInfo->timingInfo.subframe & 0xF);

    /* build bach pdu */
    txReqPdu = (FAPI_T_TX_REQ_PDU*)&fapiTxReq->pdu[0];
    txReqPdu->pdu_length  = bchPduSize;
    txReqPdu->pdu_idx = bchPduId;
    txReqPdu->n_tlv = 1;
    FAPI_T_TLV* txBchTlv = (FAPI_T_TLV*)&(txReqPdu->tlv[0]);
    txBchTlv->length     = bufLen;
    txBchTlv->tag        = 0; //value model on krait
    pTlv = (U8*)&txBchTlv->length;
    pTlv += sizeof(txBchTlv->length);

    SCpyMsgFix(pDatReqInfo->bchDat.val,0,bufLen,pTlv,&outPut);

    return (void*)fapiTxReq;
}
void ys_NxpBuildTxReqBch(apiTxDataPdu_t *tx_pdu,TfuDatReqInfo* pDatReqInfo,U16 bchPduId,U32 *offset)
{
    U8* pTlv;
    MsgLen     bufLen,outPut;
    U32 bchPduSize;
    U8* dataBuf_p;

    SFndLenMsg(pDatReqInfo->bchDat.val, &bufLen);

    bchPduSize = sizeof(apiTxDataPdu_t) + sizeof(apiDlDataTlv_t);

    tx_pdu->pduSize= bchPduSize;
    tx_pdu->pduIdx= bchPduId;
    tx_pdu->numTlvs = 1;

    apiDlDataTlv_t* txBchTlv = (apiDlDataTlv_t*)&(tx_pdu->TLV[0]);
    txBchTlv->length     = bufLen;
    txBchTlv->tag        = 1; //value model on krait
    txBchTlv->value     = *offset;
 
    dataBuf_p = ac_shmAlloc(bufLen);
    SCpyMsgFix(pDatReqInfo->bchDat.val,0,bufLen,dataBuf_p,&outPut);

    return;
}
void ys_qcBuildTxReqBch(FAPI_T_TX_REQ_PDU *tx_pdu,TfuDatReqInfo* pDatReqInfo,U16 bchPduId)
{
    U8* pTlv;
    MsgLen     bufLen,outPut;
    U32 bchPduSize;

    SFndLenMsg(pDatReqInfo->bchDat.val, &bufLen);

    bchPduSize = sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32*) + bufLen;

    tx_pdu->pdu_length  = bchPduSize;
    tx_pdu->pdu_idx = bchPduId;
    tx_pdu->n_tlv = 1;

    FAPI_T_TLV* txBchTlv = (FAPI_T_TLV*)&(tx_pdu->tlv[0]);
    txBchTlv->length     = bufLen;
    txBchTlv->tag        = 0; //value model on krait
    pTlv = (U8*)&txBchTlv->length;
    pTlv += sizeof(txBchTlv->length);

    SCpyMsgFix(pDatReqInfo->bchDat.val,0,bufLen,pTlv,&outPut);

    return;
}

void ys_qcBchDatOnlyHndl(TfuDatReqInfo* pDatReqInfo,YsCellCb *cellCb)
{
    TRC2(ys_qcBchDatOnlyHndl)
    #ifdef NXP_PLATFORM
    ltePhyL2ApiTxReq_t *fapiTxReq = NULLP;
    #else
    FAPI_T_TX_REQ*	fapiTxReq = NULLP;
    #endif
    U32 len;
    U16 bachPduId;
    FAPI_T_DL_CONFIG_REQ* fapiDlConfigReq = NULLP;
    U16 indx = cellCb->cellId - CM_START_CELL_ID;
    if(!pDatReqInfo->bchDat.pres)
    {
        RETVOID;
    }

    fapiDlConfigReq = (FAPI_T_DL_CONFIG_REQ*)ys_qcBuildDlConfigMsgOnlyBch(pDatReqInfo,cellCb,&bachPduId);
    #ifdef NXP_PLATFORM
    fapiTxReq = (ltePhyL2ApiTxReq_t*)ys_NxpBuildTxReqOnlyBch(NULLP,pDatReqInfo,cellCb,0);
    #else
    fapiTxReq = (FAPI_T_TX_REQ*)ys_qcBuildTxReqOnlyBch(NULLP,pDatReqInfo,cellCb,0);
    #endif
    #ifdef NXP_PLATFORM
    len = fapiDlConfigReq->msg_hdr.len + sizeof(FAPI_T_MSG_HDR);
    #else

    len = fapiDlConfigReq->msg_hdr.len + fapiDlConfigReq->msg_hdr.len_ven +sizeof(FAPI_T_MSG_HDR);
    #endif
    ys_qcSendtoPhy((char*)fapiDlConfigReq,len, (int)(cellCb->phyInstId));
    ysUtlFreeQCIPCSBuf((Data *)fapiDlConfigReq, len, indx);
	 #ifdef NXP_PLATFORM
	 len = 1024;
    #else
    len = fapiTxReq->msg_hdr.len + fapiTxReq->msg_hdr.len_ven +sizeof(FAPI_T_MSG_HDR);
    #endif
    ys_qcSendtoPhy((char*)fapiTxReq,len, (int)(cellCb->phyInstId));
    ysUtlFreeQCIPCSBuf((Data *)fapiTxReq, len, indx);

    RETVOID;
}
void ys_NxpBchDatOnlyHndl(TfuDatReqInfo* pDatReqInfo,YsCellCb *cellCb)
{
    TRC2(ys_qcBchDatOnlyHndl)
    FAPI_T_TX_REQ*	fapiTxReq = NULLP;
    U32 len;
    U16 bachPduId;
    FAPI_T_DL_CONFIG_REQ* fapiDlConfigReq = NULLP;
    U16 indx = cellCb->cellId - CM_START_CELL_ID;
    if(!pDatReqInfo->bchDat.pres)
    {
        RETVOID;
    }

    fapiDlConfigReq = (FAPI_T_DL_CONFIG_REQ*)ys_qcBuildDlConfigMsgOnlyBch(pDatReqInfo,cellCb,&bachPduId);
    fapiTxReq = (FAPI_T_TX_REQ*)ys_qcBuildTxReqOnlyBch(NULLP,pDatReqInfo,cellCb,0);
    #ifdef NXP_PLATFORM
    len = fapiDlConfigReq->msg_hdr.len + sizeof(FAPI_T_MSG_HDR);

    #else

    len = fapiDlConfigReq->msg_hdr.len + fapiDlConfigReq->msg_hdr.len_ven +sizeof(FAPI_T_MSG_HDR);
    #endif
    ys_qcSendtoPhy((char*)fapiDlConfigReq,len, (int)(cellCb->phyInstId));
    ysUtlFreeQCIPCSBuf((Data *)fapiDlConfigReq, len, indx);
    #ifdef NXP_PLATFORM
    len = fapiTxReq->msg_hdr.len +sizeof(FAPI_T_MSG_HDR);
    #else
    len = fapiTxReq->msg_hdr.len + fapiTxReq->msg_hdr.len_ven +sizeof(FAPI_T_MSG_HDR);
    #endif
    ys_qcSendtoPhy((char*)fapiTxReq,len, (int)(cellCb->phyInstId));
    ysUtlFreeQCIPCSBuf((Data *)fapiTxReq, len, indx);

    RETVOID;
}

S16 ys_qcPrcDataReq(YsCellCb *cellCb,TfuDatReqInfo* datReq)
{

    //ysUtlFreeDatReq(datReq);
    //return;

#ifdef NXP_PLATFORM
    ltePhyL2ApiDlConfigReq_t *fapiDlConfigReq;
#else
    FAPI_T_DL_CONFIG_REQ *fapiDlConfigReq;
#endif
    U16 len, lenTxReq;
    TfuCntrlReqInfo* pTfuCntrlReq;
    U8  subSfn;
    #ifdef NXP_PLATFORM
    apiTxDataPdu_t*	fapiTxReq = NULLP;
    #else
    FAPI_T_TX_REQ*	fapiTxReq = NULLP;
    #endif
    
    U8     phyInstId = cellCb->phyInstId;
    
    TRC2(ys_qcPrcDataReq)
    U16 indx = cellCb->cellId - CM_START_CELL_ID;

    subSfn = datReq->timingInfo.subframe;

    if(YSQC_DLCTR_RDY(phyInstId, subSfn))
    {
        pTfuCntrlReq = ysQcPhyDlMsgInfo[phyInstId][subSfn].pCntrlReqInfo;
        #ifdef NXP_PLATFORM
        fapiDlConfigReq = (ltePhyL2ApiDlConfigReq_t*)ys_NxpBuildDlMsg(pTfuCntrlReq,datReq,&fapiTxReq,&lenTxReq, cellCb->cellId);
        len = fapiDlConfigReq->msg_hdr.msgBodyLength + fapiDlConfigReq->msg_hdr.msgVdrSpecFlag + sizeof(ltePhyL2ApiMsgHdr_t);
        #else
        fapiDlConfigReq = (FAPI_T_DL_CONFIG_REQ*)ys_qcBuildDlMsg(pTfuCntrlReq,datReq,&fapiTxReq,&lenTxReq, cellCb->cellId);
        len = fapiDlConfigReq->msg_hdr.len + fapiDlConfigReq->msg_hdr.len_ven + sizeof(FAPI_T_MSG_HDR);
        #endif
        ys_qcSendtoPhy((char*)fapiDlConfigReq,len, (int)(phyInstId));
        ysUtlFreeQCIPCSBuf((Data *)fapiDlConfigReq, len, indx);        
        if(fapiTxReq)
        {
            ys_qcSendtoPhy((char*)fapiTxReq,lenTxReq, (int)(phyInstId));
            ysUtlFreeQCIPCSBuf((Data *)fapiTxReq, lenTxReq, indx);            
        }
        else
        {
            //printf("pTxReq failed %d %d\n", datReq->timingInfo.sfn, datReq->timingInfo.subframe);
        }
        ys_qcCleanDlInfo(subSfn, phyInstId);
        ysUtlFreeDatReq(datReq);
    }
    else
    {
        if(YSQC_DLDAT_RDY(phyInstId, subSfn))
        {            
            ys_qcCleanDlInfo(subSfn, phyInstId);
        }
        ys_qcUpdateDatInfo(datReq, phyInstId);
        YSQC_SETDLDAT_RDY(phyInstId, subSfn);
    }

    RETVALUE(ROK);
}

void ys_qcUpdateCntrlInfo(TfuCntrlReqInfo *cntrlReq, U8 phyInstId)
{
    U8 sfNum =0;

    sfNum = cntrlReq->dlTiming.subframe;
    ysQcPhyDlMsgInfo[phyInstId][sfNum].pCntrlReqInfo = cntrlReq;

    return;
}

void ys_qcUpdateDatInfo(TfuDatReqInfo *DatReq, U8 phyInstId)
{
    U8 sfNum =0;

    sfNum = DatReq->timingInfo.subframe;
    ysQcPhyDlMsgInfo[phyInstId][sfNum].pDatReqInfo = DatReq;

    return;
}

void ys_qcFillHiDci0Info
(
YsCellCb        *cellCb,
TfuCntrlReqInfo *cntrlReq
)
{
    TRC2(ys_qcFillHiDci0Info)

    U8                 pdu_size;
    Data	           *buff;
    FAPI_T_PDU         *pdu_p;
    FAPI_T_HI_DCI0_REQ *fapiHiDci0Req;
    U32                fapiHiDci0ReqMsgSize;
    CmLList 	       *cmLstEnt;
    TfuPhichInfo       *phichInfo;
    TfuPdcchInfo       *pdcchInfo;
    U16 indx = cellCb->cellId - CM_START_CELL_ID;

    fapiHiDci0ReqMsgSize = sizeof(FAPI_T_HI_DCI0_REQ) +
                           cntrlReq->ulPdcchLst.count*(sizeof(FAPI_T_PDU) +
                           sizeof(FAPI_T_DCI_UL_PDU)) +
                           cntrlReq->phichLst.count*(sizeof(FAPI_T_PDU) +
                           sizeof(FAPI_T_HI_PDU)) ;
    
    if(ysUtlAllocQCIPCSBuf(&buff,fapiHiDci0ReqMsgSize, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"hidci0 SGetSBuf failed.\n");
        RETVOID;
    }

    fapiHiDci0Req = (FAPI_T_HI_DCI0_REQ*)buff;


    fapiHiDci0Req->msg_hdr.type     = FAPI_E_HI_DCI0_REQ;
    #ifdef NXP_PLATFORM
    fapiHiDci0Req->msg_hdr.msgVdrSpecFlag= 0;
    #else
    fapiHiDci0Req->msg_hdr.len_ven  = 0;
    #endif
    fapiHiDci0Req->msg_hdr.len      = fapiHiDci0ReqMsgSize - sizeof(FAPI_T_MSG_HDR);

    fapiHiDci0Req->sf_sfn           = ((cntrlReq->ulTiming.sfn<< 4) + (cntrlReq->ulTiming.subframe & 0xF));;
    fapiHiDci0Req->n_dci            = cntrlReq->ulPdcchLst.count;
    fapiHiDci0Req->n_hi             = cntrlReq->phichLst.count;

    pdu_p = &(fapiHiDci0Req->pdu[0]);

    for (cmLstEnt = cntrlReq->phichLst.first;cmLstEnt;cmLstEnt = cmLstEnt->next)
    {
        phichInfo = (TfuPhichInfo*)(cmLstEnt->node);
        pdu_p->pdu_type = 0;
        pdu_size = sizeof(FAPI_T_HI_PDU) + sizeof(FAPI_T_PDU);
        pdu_p->pdu_size = pdu_size;
        ys_qcBuildHiPdu(pdu_p,phichInfo);
        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);
    }

    for (cmLstEnt = cntrlReq->ulPdcchLst.first; cmLstEnt; cmLstEnt = cmLstEnt->next)
    {
        pdu_p->pdu_type = 1;
        pdu_size = sizeof(FAPI_T_DCI_UL_PDU) + sizeof(FAPI_T_PDU);
        pdu_p->pdu_size = pdu_size;
        pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
        if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3) || ((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3A)))
        {
            STKLOG(STK_MD_YS,STK_LOG_INFO,"dci 3/3a\n");
        }
        else
        {
            ys_qcBuildDci0Pdu(pdu_p,pdcchInfo, cellCb->cellId);
        }
        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);
    }


    ys_qcSendtoPhy((char*)fapiHiDci0Req,fapiHiDci0ReqMsgSize, (int)(cellCb->phyInstId));    
    ysUtlFreeQCIPCSBuf(buff,fapiHiDci0ReqMsgSize, indx);

    RETVOID;
}

void ys_NxpFillHiDci0Info
(
YsCellCb        *cellCb,
TfuCntrlReqInfo *cntrlReq
)
{
    TRC2(ys_qcFillHiDci0Info)

    U8                 pdu_size;
    Data	           *buff;
    apiHIDCI0Pdu_t         *pdu_p;
    ltePhyL2ApiHIDCI0Req_t *fapiHiDci0Req;
    U32                fapiHiDci0ReqMsgSize;
    CmLList 	       *cmLstEnt;
    TfuPhichInfo       *phichInfo;
    TfuPdcchInfo       *pdcchInfo;
    U16 indx = cellCb->cellId - CM_START_CELL_ID;

    fapiHiDci0ReqMsgSize = sizeof(ltePhyL2ApiHIDCI0Req_t) +
                           cntrlReq->ulPdcchLst.count*(sizeof(apiHIDCI0Pdu_t) +
                           sizeof(apiHIDCI0PduUlDCI_t)) +
                           cntrlReq->phichLst.count*(sizeof(apiHIDCI0Pdu_t) +
                           sizeof(apiHIDCI0PduHI_t)) ;
    
    if(ysUtlAllocQCIPCSBuf(&buff,fapiHiDci0ReqMsgSize, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"hidci0 SGetSBuf failed.\n");
        RETVOID;
    }

    fapiHiDci0Req = (ltePhyL2ApiHIDCI0Req_t*)buff;

    fapiHiDci0Req->msg_hdr.msgTypeId= API_MSG_TYPE_HI_DCI0_REQ;
    fapiHiDci0Req->msg_hdr.msgVdrSpecFlag  = 0;
    fapiHiDci0Req->msg_hdr.msgBodyLength      = fapiHiDci0ReqMsgSize - sizeof(ltePhyL2ApiMsgHdr_t);
    fapiHiDci0Req->SFN_SF = ((cntrlReq->ulTiming.sfn<< 4) + (cntrlReq->ulTiming.subframe & 0xF));;
    fapiHiDci0Req->numDCIs = cntrlReq->ulPdcchLst.count;
    fapiHiDci0Req->numHIs = cntrlReq->phichLst.count;

    pdu_p = &(fapiHiDci0Req->PDU[0]);
  
    for (cmLstEnt = cntrlReq->phichLst.first;cmLstEnt;cmLstEnt = cmLstEnt->next)
    {
        phichInfo = (TfuPhichInfo*)(cmLstEnt->node);
        pdu_p->pduType = apiHIDCI0PduType_eHI;
        pdu_size = sizeof(apiHIDCI0PduHI_t) + sizeof(apiHIDCI0Pdu_t);
        pdu_p->pduSize = pdu_size;
        ys_NxpBuildHiPdu(pdu_p,phichInfo);
        pdu_p = (apiHIDCI0Pdu_t*)((U8 *)pdu_p + pdu_size);
    }

    for (cmLstEnt = cntrlReq->ulPdcchLst.first; cmLstEnt; cmLstEnt = cmLstEnt->next)
    {
        pdu_p->pduType = apiHIDCI0PduType_eDciUl;
        pdu_size = sizeof(apiHIDCI0PduUlDCI_t) + sizeof(apiHIDCI0Pdu_t);
        pdu_p->pduSize = pdu_size;
        pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
        if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3) || ((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3A)))
        {
            STKLOG(STK_MD_YS,STK_LOG_INFO,"dci 3/3a\n");
        }
        else
        {
            ys_NxpBuildDci0Pdu(pdu_p,pdcchInfo, cellCb->cellId);
        }
        pdu_p = (apiHIDCI0Pdu_t*)((U8 *)pdu_p + pdu_size);
    }


    ys_qcSendtoPhy((char*)fapiHiDci0Req,fapiHiDci0ReqMsgSize, (int)(cellCb->phyInstId));    
    ysUtlFreeQCIPCSBuf(buff,fapiHiDci0ReqMsgSize, indx);

    RETVOID;
}

U8 ys_qcCehckSib1(
TfuCntrlReqInfo *cntrlReq,
TfuDatReqInfo   *datReq)
{
    return 0;
}

S16 ys_qcPrcCntrlReq
(
YsCellCb        *cellCb,
TfuCntrlReqInfo *cntrlReq
)
{

    //YS_FREE_SDU(cntrlReq);
    //return;

    U8                     subSfNum;
    U16                    len, lenTxReq;
    TfuDatReqInfo          *pDatReqInfo =NULLP;
 #ifdef NXP_PLATFORM
    ltePhyL2ApiDlConfigReq_t *pDlCnfMsg= NULLP;
    apiTxDataPdu_t*	pTxReq = NULLP;
#else
    FAPI_T_DL_CONFIG_REQ *pDlCnfMsg= NULLP;
    FAPI_T_TX_REQ*	pTxReq = NULLP;

#endif

    U8  phyInstId = cellCb->phyInstId;

    TRC2(ys_qcPrcCntrlReq)
    U16 indx = cellCb->cellId - CM_START_CELL_ID;
    subSfNum = cntrlReq->dlTiming.subframe;
    YSQC_SETDLCTR_ARRVD(phyInstId, subSfNum);
#ifdef LTE_TDD
    if(ysqcTddUlDlSubfrmTbl[cellCb->ulDlCfgIdx][cntrlReq->dlTiming.subframe] == YS_TDD_UL_SUBFRAME)
    {
        ys_qcCleanDlInfo(subSfNum, phyInstId);
        YS_FREE_SDU(cntrlReq);
        RETVALUE(ROK);
    }
    else if(ysqcTddUlDlSubfrmTbl[cellCb->ulDlCfgIdx][cntrlReq->dlTiming.subframe] == YS_TDD_DL_SUBFRAME)
    {
        ys_qcSendNullCrcInd(cntrlReq->dlTiming.sfn,cntrlReq->dlTiming.subframe,cntrlReq->ulPdcchLst.count,cellCb->cellId);
    }
#endif

    if((cntrlReq->ulPdcchLst.count != 0)||(cntrlReq->phichLst.count != 0))
    {
    #ifdef NXP_PLATFORM
        ys_NxpFillHiDci0Info(cellCb,cntrlReq);
    #else
        ys_qcFillHiDci0Info(cellCb,cntrlReq);
    #endif
    }

    if(cntrlReq->dlPdcchLst.count == 0)
    {
        if(!((cntrlReq->dlTiming.subframe == 0) &&((cntrlReq->dlTiming.sfn %4) == 0) ))
        {
            ys_qcsendEmptyDlConfigReq(cntrlReq->dlTiming.sfn,cntrlReq->dlTiming.subframe, (int)(phyInstId));
            ys_qcCleanDlInfo(subSfNum, phyInstId);
            rgStats.uespertti[0]++; /* No UE is scheduled in this TTI */
        }
        else if(YSQC_DLDAT_RDY(phyInstId, subSfNum))
        {
            pDatReqInfo = ysQcPhyDlMsgInfo[phyInstId][subSfNum].pDatReqInfo;
            ys_qcBchDatOnlyHndl(pDatReqInfo,cellCb);
            ys_qcCleanDlInfo(subSfNum, phyInstId);
        }
        else
        {
            //printf("ys_qcBchDatOnlyHndl data not ready %d %d\n", cntrlReq->dlTiming.sfn, cntrlReq->dlTiming.subframe);
        }
        YS_FREE_SDU(cntrlReq);
        RETVALUE(ROK);
    }

    if(YSQC_DLDAT_RDY(phyInstId, subSfNum))
    {
        pDatReqInfo = ysQcPhyDlMsgInfo[phyInstId][subSfNum].pDatReqInfo;
        #ifdef NXP_PLATFORM
        pDlCnfMsg = (ltePhyL2ApiDlConfigReq_t*)ys_NxpBuildDlMsg(cntrlReq,pDatReqInfo,&pTxReq,&lenTxReq, cellCb->cellId);
        len = pDlCnfMsg->msg_hdr.msgBodyLength + pDlCnfMsg->msg_hdr.msgVdrSpecFlag + sizeof(ltePhyL2ApiMsgHdr_t);
        #else
        pDlCnfMsg = (FAPI_T_DL_CONFIG_REQ*)ys_qcBuildDlMsg(cntrlReq,pDatReqInfo,&pTxReq,&lenTxReq, cellCb->cellId);
        len = pDlCnfMsg->msg_hdr.len + pDlCnfMsg->msg_hdr.len_ven + sizeof(FAPI_T_MSG_HDR);
        #endif
        ys_qcSendtoPhy((char*)pDlCnfMsg,len, (int)(phyInstId));
        ysUtlFreeQCIPCSBuf((Data *)pDlCnfMsg, len, indx);
        if(pTxReq)
        {
            ys_qcSendtoPhy((char*)pTxReq,lenTxReq, (int)(phyInstId));
            ysUtlFreeQCIPCSBuf((Data *)pTxReq, lenTxReq, indx);
        }
        else
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"pTxReq failed %d %d\n", cntrlReq->dlTiming.sfn, cntrlReq->dlTiming.subframe);
        }

        ys_qcCleanDlInfo(subSfNum, phyInstId);
        YS_FREE_SDU(cntrlReq);	
    }
    else
    {
        if(YSQC_DLCTR_RDY(phyInstId, subSfNum))
        {
            ys_qcCleanDlInfo(subSfNum, phyInstId);         
            STKLOG(STK_MD_YS,STK_LOG_INFO,"YSQC_DLCTR_RDY free %d %d\n", cntrlReq->dlTiming.sfn, cntrlReq->dlTiming.subframe);
        }

        ys_qcUpdateCntrlInfo(cntrlReq, phyInstId);
        YSQC_SETDLCTR_RDY(phyInstId, subSfNum);

    }

    RETVALUE(ROK);
}

S16 ys_qcFillDlConfigReq
(
YsCellCb        *cellCb,
TfuCntrlReqInfo *cntrlReq
)
{
    return 0;
}
S16 ys_qcFillUlConfigReq
(
YsCellCb        *cellCb,
TfuCntrlReqInfo *cntrlReq
)
{
    return 0;
}

void* ys_qcBuildDlConfigMsgOnlyBch(TfuDatReqInfo   *datReq,YsCellCb *cellCb,U16* bachPduId)
{
    FAPI_T_DL_CONFIG_REQ *fapiDlConfigReq;
    U8   size;
    FAPI_T_PDU            *pdu_p;
    FAPI_T_BCH_PDU        *dlBchPdu;
    U16    bchPduSize = sizeof(FAPI_T_BCH_PDU) + sizeof(FAPI_T_PDU);
    MsgLen     bufLen;
    U16 indx = cellCb->cellId - CM_START_CELL_ID;
    SFndLenMsg(datReq->bchDat.val, &bufLen);

    size = sizeof(FAPI_T_DL_CONFIG_REQ) + bchPduSize;
    
    if(ysUtlAllocQCIPCSBuf((Data **)&fapiDlConfigReq, size, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"DlConfigReq SGetSBuf failed.\n");
        return NULLP;
    }
    fapiDlConfigReq->msg_hdr.len = size-sizeof(FAPI_T_MSG_HDR);
    #ifndef NXP_PLATFORM
    fapiDlConfigReq->msg_hdr.len_ven = 0;
    #else
    fapiDlConfigReq->msg_hdr.msgVdrSpecFlag= 0;
    #endif
    fapiDlConfigReq->msg_hdr.type = FAPI_E_DL_CONFIG_REQ;

    fapiDlConfigReq->sf_sfn              = (datReq->timingInfo.sfn << 4) + (datReq->timingInfo.subframe & 0xF);
    fapiDlConfigReq->length              = size-sizeof(FAPI_T_MSG_HDR);
    fapiDlConfigReq->n_pdcch_symb        = 1; //??
    fapiDlConfigReq->n_dci               = 0;
    fapiDlConfigReq->n_pdu               = 1;
    fapiDlConfigReq->n_pdsch_rnti        = 0;
    fapiDlConfigReq->trans_power_pcfich  = 6000;

    pdu_p = &fapiDlConfigReq->dl_pdu[0];
    pdu_p->pdu_type = FAPI_E_DL_BCH_PDU;
    pdu_p->pdu_size = bchPduSize;

    dlBchPdu = (FAPI_T_BCH_PDU*)(&pdu_p->pdu[0]);
    dlBchPdu->rel8.length  = bufLen;
    dlBchPdu->rel8.pdu_idx = 0;
    dlBchPdu->rel8.tp = 6000;  //0..10000 for -6 ..+4db

    *bachPduId = 0;

    return (void*)fapiDlConfigReq;
}

/*
 * ----------------------------------------------------------------------
 * Function:        ys_qcBuildDlConfigMsg
 * Description:     Init DL CONFIG request message with configured before
 *                   parameters for DL
 *
 * Input:           N/A
 *
 * Output:          N/A
 *
 * ----------------------------------------------------------------------
 */
void* ys_qcBuildDlMsg(TfuCntrlReqInfo *tfuCntrlReq,TfuDatReqInfo *datReq,FAPI_T_TX_REQ** fapiTxReq, U16 *LenTxReq, CmLteCellId cellId)
{
   TRC2(ys_qcBuildDlMsg)
    U32      i;
    U8       pdu_size = 0;
    FAPI_T_PDU  *pdu_p;
    Data    *buff;
    U32 dlConfigReqMsgSize;
    FAPI_T_DL_CONFIG_REQ* dlConfigReqMsg;
    CmLList      *cmLstEnt;
    TfuPdcchInfo *pdcchInfo;
    TfuDatReqPduInfo *pduInfo;
    U8 TbIdx = 0,dlsch_pdu_count = 0;
    U8 num_pdsch_rnti=0;
    U8* pTmp;
    U16  pdu_count = 0;
    U16   fapiTxReqSize;
    U16   tx_req_len = 0;
    FAPI_T_TX_REQ_PDU *TxReqPdu = NULLP;
    U32 ueCnt = 0;
    U16 indx = cellId - CM_START_CELL_ID;

    dlConfigReqMsgSize = ys_qcCalcDlConfigMsgSize(tfuCntrlReq,datReq,&pdu_count,&fapiTxReqSize);    
  
    if(ysUtlAllocQCIPCSBuf(&buff, dlConfigReqMsgSize, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"DlConfigReq SGetSBuf failed. dlConfigReqMsgSize %lu \n",dlConfigReqMsgSize);
        RETVALUE(NULLP);
    }

    dlConfigReqMsg = (FAPI_T_DL_CONFIG_REQ*) buff;

    dlConfigReqMsg->msg_hdr.type        = FAPI_E_DL_CONFIG_REQ;
    #ifdef NXP_PLATFORM
    dlConfigReqMsg->msg_hdr.msgVdrSpecFlag= 0;
    #else
    dlConfigReqMsg->msg_hdr.len_ven     = 0;
    #endif
    dlConfigReqMsg->msg_hdr.len         = dlConfigReqMsgSize - sizeof(FAPI_T_MSG_HDR);

    dlConfigReqMsg->sf_sfn              = (tfuCntrlReq->dlTiming.sfn << 4) + (tfuCntrlReq->dlTiming.subframe & 0xF);
    dlConfigReqMsg->length              = dlConfigReqMsgSize - sizeof(FAPI_T_MSG_HDR);
    dlConfigReqMsg->n_pdcch_symb        = tfuCntrlReq->cfi;
    dlConfigReqMsg->n_dci               = tfuCntrlReq->dlPdcchLst.count;
    dlConfigReqMsg->trans_power_pcfich  = 6000;

    if(ysUtlAllocQCIPCSBuf(&buff, fapiTxReqSize, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"DlConfigReq SGetSBuf failed.fapiTxReqSize %d\n",fapiTxReqSize);
        ysUtlFreeQCIPCSBuf((Data *)dlConfigReqMsg, dlConfigReqMsgSize, indx);
        RETVALUE(NULLP);
    }

    (*fapiTxReq) = (FAPI_T_TX_REQ*)buff;

    (*fapiTxReq)->msg_hdr.type      = FAPI_E_TX_REQ;
    #ifdef NXP_PLATFORM
    (*fapiTxReq)->msg_hdr.msgVdrSpecFlag   = 0;
    #else
    (*fapiTxReq)->msg_hdr.len_ven   = 0;
    #endif
    (*fapiTxReq)->msg_hdr.len       = fapiTxReqSize - sizeof(FAPI_T_MSG_HDR);
    (*fapiTxReq)->sf_sfn            = (tfuCntrlReq->dlTiming.sfn << 4) + (tfuCntrlReq->dlTiming.subframe & 0xF);
    (*fapiTxReq)->n_pdu             = pdu_count;
    *LenTxReq = fapiTxReqSize;

    pdu_p = &(dlConfigReqMsg->dl_pdu[0]);
    cmLstEnt = tfuCntrlReq->dlPdcchLst.first;
    while(cmLstEnt != NULLP)
    {
        pdu_p->pdu_type = FAPI_E_DL_DCI_DL_PDU;
        pdu_size = sizeof(FAPI_T_DCI_DL_PDU_A) + sizeof(FAPI_T_PDU)+sizeof(FAPI_T_DCI_DL_PDU_B);
        pdu_p->pdu_size = pdu_size;
        pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
        ys_qcBuildDciDlPdu(pdu_p,pdcchInfo,cellId);
        pTmp = (U8*)pdu_p;
        pdu_p = (FAPI_T_PDU*)(pTmp + pdu_size);
        cmLstEnt = cmLstEnt->next;
    }

    TxReqPdu = &((*fapiTxReq)->pdu[0]);

    for(cmLstEnt = datReq->pdus.first;cmLstEnt != NULLP; i++)
    {
        pduInfo = (TfuDatReqPduInfo*)cmLstEnt->node;
        cmLstEnt = cmLstEnt->next;
        num_pdsch_rnti++;

        if (pduInfo->rnti != YS_SI_RNTI)
        {
            ueCnt++;
        }

        for(TbIdx = 0; TbIdx <pduInfo->nmbOfTBs;TbIdx++)
        {
            pdu_p->pdu_type = FAPI_E_DL_DLSCH_PDU;
            pdu_size  = sizeof(FAPI_T_DLSCH_PDU_A) + sizeof(FAPI_T_DLSCH_PDU_B) +sizeof(FAPI_T_DLSCH_PDU_C)+sizeof(FAPI_T_DLSCH_PDU_D)+sizeof(FAPI_T_PDU);
            if(((1 == pduInfo->nmbOfTBs)&&(TbIdx == 0))&&((pduInfo->dciInfo.format ==TFU_DCI_FORMAT_2A)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].rv == 1)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].mcs== 0)))
            {
                tx_req_len = ys_qcBuildTxReqPdu(TxReqPdu,pduInfo,dlsch_pdu_count,1,tfuCntrlReq->dlTiming.sfn,tfuCntrlReq->dlTiming.subframe,cellId);
                TbIdx =1;
            }
            else
            {
                tx_req_len = ys_qcBuildTxReqPdu(TxReqPdu,pduInfo,dlsch_pdu_count,TbIdx,tfuCntrlReq->dlTiming.sfn,tfuCntrlReq->dlTiming.subframe,cellId);
            }
            pdu_size += ys_qcBuildDlschPdu(pdu_p,TbIdx,dlsch_pdu_count, pduInfo,tfuCntrlReq,tx_req_len,cellId);
            dlsch_pdu_count++;
            pdu_p->pdu_size = pdu_size;
            pTmp = (U8*)pdu_p;
            pdu_p = (FAPI_T_PDU*)(pTmp + pdu_size);
            pTmp = (U8*)TxReqPdu;

            if(tx_req_len %4)
            {
                TxReqPdu = (FAPI_T_TX_REQ_PDU *)(pTmp +tx_req_len +sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32 *) +4 -tx_req_len %4 );
            }
            else
            {
                TxReqPdu = (FAPI_T_TX_REQ_PDU *)(pTmp +tx_req_len +sizeof(FAPI_T_TX_REQ_PDU) + sizeof(FAPI_T_TLV) - sizeof(U32 *) );
            }
        }
    }

    if (ueCnt < 17)
    {
        rgStats.uespertti[ueCnt]++;
    }
    else
    {
        rgStats.uespertti[17]++;
    }

    dlConfigReqMsg->n_pdu               = dlsch_pdu_count+ tfuCntrlReq->dlPdcchLst.count;
    dlConfigReqMsg->n_pdsch_rnti        = num_pdsch_rnti;
    if(datReq->bchDat.pres) //bch data handle
    {
        U32 bchPduSize = sizeof(FAPI_T_BCH_PDU) + sizeof(FAPI_T_PDU);
        FAPI_T_BCH_PDU* dlBchPdu;

        pdu_p->pdu_type = FAPI_E_DL_BCH_PDU;
        pdu_p->pdu_size = bchPduSize;

        dlBchPdu = (FAPI_T_BCH_PDU*)(&pdu_p->pdu[0]);
        dlBchPdu->rel8.length  = (BCH_PAYLOAD_SIZE_BYTES);
        dlBchPdu->rel8.pdu_idx = dlsch_pdu_count;
        dlBchPdu->rel8.tp = 6000;

        ys_qcBuildTxReqBch(TxReqPdu,datReq,dlsch_pdu_count);
        dlConfigReqMsg->n_pdu ++;
    }

    RETVALUE(dlConfigReqMsg);
}// end of MAC_SIM_fapi_build_dl_config_msg

/*
 * ----------------------------------------------------------------------
 * Function:        ys_qcBuildDlConfigMsg
 * Description:     Init DL CONFIG request message with configured before
 *                   parameters for DL
 *
 * Input:           N/A
 *
 * Output:          N/A
 *
 * ----------------------------------------------------------------------
 */
void* ys_NxpBuildDlMsg(TfuCntrlReqInfo *tfuCntrlReq,TfuDatReqInfo *datReq,ltePhyL2ApiTxReq_t** fapiTxReq, U16 *LenTxReq, CmLteCellId cellId)
{
   TRC2(ys_qcBuildDlMsg)
    U32      i;
    U8       pdu_size = 0;
    apiDlCfgPdu_t  *pdu_p;
    Data    *buff;
    U32 dlConfigReqMsgSize;
    ltePhyL2ApiDlConfigReq_t* dlConfigReqMsg;
    CmLList      *cmLstEnt;
    TfuPdcchInfo *pdcchInfo;
    TfuDatReqPduInfo *pduInfo;
    U8 TbIdx = 0,dlsch_pdu_count = 0;
    U8 num_pdsch_rnti=0;
    U8* pTmp;
    U16  pdu_count = 0;
    U16   fapiTxReqSize;
    U16   tx_req_len = 0;
    U32   totalBufLen = 0;
    U32   txReqBaseOffset = 0;
    apiTxDataPdu_t *TxReqPdu = NULLP;
    U32 ueCnt = 0;
    U16 indx = cellId - CM_START_CELL_ID;
    U32 firstPduPAddr;

    dlConfigReqMsgSize = ys_NxpCalcDlConfigMsgSize(tfuCntrlReq,datReq,&pdu_count,&fapiTxReqSize,&totalBufLen);    
    //fapiTxReqSize =1024;
    if(ysUtlAllocQCIPCSBuf(&buff, dlConfigReqMsgSize, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"DlConfigReq SGetSBuf failed. dlConfigReqMsgSize %lu \n",dlConfigReqMsgSize);
        RETVALUE(NULLP);
    }

    dlConfigReqMsg = (ltePhyL2ApiDlConfigReq_t*) buff;

    dlConfigReqMsg->msg_hdr.msgTypeId        = API_MSG_TYPE_DLCFG_REQ;
    dlConfigReqMsg->msg_hdr.msgVdrSpecFlag     = 0;
    dlConfigReqMsg->msg_hdr.msgBodyLength         = dlConfigReqMsgSize - sizeof(ltePhyL2ApiMsgHdr_t);

    dlConfigReqMsg->SFN_SF              = (tfuCntrlReq->dlTiming.sfn << 4) + (tfuCntrlReq->dlTiming.subframe & 0xF);
    dlConfigReqMsg->length              = dlConfigReqMsgSize - sizeof(ltePhyL2ApiMsgHdr_t);
    dlConfigReqMsg->numPdcchSyms        = tfuCntrlReq->cfi;
    dlConfigReqMsg->numDCIs               = tfuCntrlReq->dlPdcchLst.count;
    dlConfigReqMsg->pcfichPower  = 6000;

    if(ysUtlAllocQCIPCSBuf(&buff, 1024, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_INFO,"DlConfigReq SGetSBuf failed.fapiTxReqSize %d\n",fapiTxReqSize);
        ysUtlFreeQCIPCSBuf((Data *)dlConfigReqMsg, dlConfigReqMsgSize, indx);
        RETVALUE(NULLP);
    }

    (*fapiTxReq) = (ltePhyL2ApiTxReq_t*)buff;

    (*fapiTxReq)->msg_hdr.msgTypeId      = API_MSG_TYPE_TX_REQ;
    (*fapiTxReq)->msg_hdr.msgVdrSpecFlag   = 0;
    (*fapiTxReq)->msg_hdr.msgBodyLength       = fapiTxReqSize - sizeof(ltePhyL2ApiMsgHdr_t);
    (*fapiTxReq)->SFN_SF            = (tfuCntrlReq->dlTiming.sfn << 4) + (tfuCntrlReq->dlTiming.subframe & 0xF);
    (*fapiTxReq)->numPDUs             = pdu_count;
    *LenTxReq = 1024;//fapiTxReqSize;
    firstPduPAddr = ac_shmV2P(ac_getAvaiShmAddr());
    memcpy((void *)((U8*)(*fapiTxReq) + 1020), &firstPduPAddr, 4);


    pdu_p = &(dlConfigReqMsg->PDU[0]);
    cmLstEnt = tfuCntrlReq->dlPdcchLst.first;
    while(cmLstEnt != NULLP)
    {
        pdu_p->pduType = apiDlCfgPduType_eDciDl;
        pdu_size = sizeof(apiDlCfgPdu_t)+sizeof(apiDlCfgPduDCI_t);
        pdu_p->pduSize = pdu_size;
        pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
        ys_NxpBuildDciDlPduTemp(pdu_p,pdcchInfo,cellId);
        pTmp = (U8*)pdu_p;
        pdu_p = (apiDlCfgPdu_t*)(pTmp + pdu_size);
        cmLstEnt = cmLstEnt->next;
    }

    TxReqPdu = &((*fapiTxReq)->PDU[0]);

    for(cmLstEnt = datReq->pdus.first;cmLstEnt != NULLP; i++)
    {
        pduInfo = (TfuDatReqPduInfo*)cmLstEnt->node;
        cmLstEnt = cmLstEnt->next;
        num_pdsch_rnti++;

        if (pduInfo->rnti != YS_SI_RNTI)
        {
            ueCnt++;
        }

        for(TbIdx = 0; TbIdx <pduInfo->nmbOfTBs;TbIdx++)
        {
            pdu_p->pduType = apiDlCfgPduType_eDlSch;
            pdu_size  = sizeof(apiDlCfgPduDlSCH_t)+sizeof(apiDlCfgPdu_t);
            if(((1 == pduInfo->nmbOfTBs)&&(TbIdx == 0))&&((pduInfo->dciInfo.format ==TFU_DCI_FORMAT_2A)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].rv == 1)&&(pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].mcs== 0)))
            {
                tx_req_len = ys_NxpBuildTxReqPdu(TxReqPdu,pduInfo,dlsch_pdu_count,1,tfuCntrlReq->dlTiming.sfn,tfuCntrlReq->dlTiming.subframe,cellId,&txReqBaseOffset);
                TbIdx =1;
            }
            else
            {
                tx_req_len = ys_NxpBuildTxReqPdu(TxReqPdu,pduInfo,dlsch_pdu_count,TbIdx,tfuCntrlReq->dlTiming.sfn,tfuCntrlReq->dlTiming.subframe,cellId,&txReqBaseOffset);
            }
            pdu_size += ys_NxpBuildDlschPdu(pdu_p,TbIdx,dlsch_pdu_count, pduInfo,tfuCntrlReq,tx_req_len,cellId);
            dlsch_pdu_count++;
            pdu_p->pduSize= pdu_size;
            pTmp = (U8*)pdu_p;
            pdu_p = (apiDlCfgPdu_t*)(pTmp + pdu_size);
            pTmp = (U8*)TxReqPdu;
             #if 1

            TxReqPdu = (apiTxDataPdu_t *)(pTmp  +sizeof(apiTxDataPdu_t)+sizeof(apiDlDataTlv_t));

            #endif
        }
    }

    if (ueCnt < 17)
    {
        rgStats.uespertti[ueCnt]++;
    }
    else
    {
        rgStats.uespertti[17]++;
    }

    dlConfigReqMsg->numPDUs= dlsch_pdu_count+ tfuCntrlReq->dlPdcchLst.count;
    dlConfigReqMsg->numPdschRntis= num_pdsch_rnti;
    if(datReq->bchDat.pres) //bch data handle
    {
        U32 bchPduSize = sizeof(apiDlCfgPduBCH_t) + sizeof(apiDlCfgPdu_t);
        apiDlCfgPduBCH_t* dlBchPdu;

        pdu_p->pduType = apiDlCfgPduType_eBCH;
        pdu_p->pduSize = bchPduSize;

        dlBchPdu = (apiDlCfgPduBCH_t*)(&pdu_p->pdu[0]);
        dlBchPdu->length  = (BCH_PAYLOAD_SIZE_BYTES);
        dlBchPdu->pduIdx = dlsch_pdu_count;
        dlBchPdu->transPower= 6000;
        ys_NxpBuildTxReqBch(TxReqPdu,datReq,dlsch_pdu_count,&txReqBaseOffset);
        dlConfigReqMsg->numPDUs++;
    }

    RETVALUE(dlConfigReqMsg);
}// end of MAC_SIM_fapi_build_dl_config_msg

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_dci_dl_pdu
 * Description:     Init PDCCH request message with configured before
 *                      parameters for DL
 *
 * Input:       dlpdu - DL PDU config parameters
 *              advance_imp - implicit step size
 *
 * Output:      pdu_p - pointer to the newly created DL DCI PDU
 *
 * ----------------------------------------------------------------------
 */
void ys_NxpBuildDciDlPdu(apiDlCfgPdu_t *pdu_p,TfuPdcchInfo *pdcchInfo, CmLteCellId cellId)
{
    apiDlCfgPduDCI_t  *dciPdu;
    YsCellCb	*cellCb = (YsCellCb*)ysMsCfgGetCellCfg(cellId);
    dciPdu  = (apiDlCfgPduDCI_t *)&(pdu_p->pdu[0]);
       
    dciPdu->dciFormat      = pdcchInfo->dci.dciFormat-1; //difference  between QC and Intel
    dciPdu->cceIndx       = pdcchInfo->nCce;
    if(pdcchInfo->aggrLvl == CM_LTE_AGGR_LVL4)  //difference  between QC and Intel
    {
        dciPdu->aggreLevel = 4;
    }
    else if(pdcchInfo->aggrLvl == CM_LTE_AGGR_LVL8)
    {
        dciPdu->aggreLevel = 8;
    }
    else
    {
        dciPdu->aggreLevel = pdcchInfo->aggrLvl;
    }
    dciPdu->rnti            = pdcchInfo->rnti;

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1)
    {
        dciPdu->resAllocType = ~(pdcchInfo->dci.u.format1Info.allocInfo.isAllocType0);
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2)
    {
        dciPdu->resAllocType = ~(pdcchInfo->dci.u.format2Info.allocInfo.isAllocType0);
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2A)
    {
        dciPdu->resAllocType = 1 - (pdcchInfo->dci.u.format2AInfo.allocInfo.isAllocType0);
        if(pdcchInfo->dci.u.format2AInfo.allocInfo.isAllocType0 == 1)
        {
            dciPdu->resAllocType = ys_qcsetRbforRaType0(pdcchInfo->dci.u.format2AInfo.allocInfo.resAllocMap, cellCb->cellCfg.bwCfg.dlBw);
        }
        else
        {
            STKLOG(STK_MD_YS,STK_LOG_INFO,"allocat type error \n");
        }
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
    {
        dciPdu->resAllocType = 2;
        dciPdu->rbCoding   = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.alloc.u.riv;
    }

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
    {
        dciPdu->virtRbFlag = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.isLocal ? 0:1;
    }
    else
    {
        dciPdu->virtRbFlag = 0;
    }

    dciPdu->newDataInd_2               = 0;
    dciPdu->TPMI                = 0;
    dciPdu->PMI                 = 0;
    dciPdu->precodeInfo        = 0;

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1)
    {
#ifdef LTE_TDD
        dciPdu->dlAssignIdx = pdcchInfo->dci.u.format1Info.dai;
#else
        dciPdu->dlAssignIdx = 0;

#endif
        dciPdu->TPC = pdcchInfo->dci.u.format1Info.tpcCmd;
        dciPdu->mcs_1               = pdcchInfo->dci.u.format1Info.allocInfo.mcs;
        dciPdu->rv_1                = pdcchInfo->dci.u.format1Info.allocInfo.rv;
        dciPdu->newDataInd_1              = pdcchInfo->dci.u.format1Info.allocInfo.ndi;
        dciPdu->tb2CwSwapFlag      = 0;
        dciPdu->mcs_2               = 0;
        dciPdu->rv_2                = 0;
        dciPdu->newDataInd_2             = 0;
        dciPdu->harqProcess           = pdcchInfo->dci.u.format1Info.allocInfo.harqProcId;
    }
    else if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)&&(!pdcchInfo->dci.u.format1aInfo.isPdcchOrder)) 
    {
#ifdef LTE_TDD
        dciPdu->dlAssignIdx  = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.dai.val;
#else
        dciPdu->dlAssignIdx = 0;
#endif
        dciPdu->TPC = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        if((YS_SI_RNTI == pdcchInfo->rnti)||(YS_P_RNTI == pdcchInfo->rnti)||(pdcchInfo->rnti <= YS_MAX_RARNTI))
        {
            dciPdu->TPC = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        }
        else
        {
            dciPdu->TPC = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        }
        dciPdu->mcs_1              = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.mcs;
        if(pdcchInfo->rnti <200)
        {
            //printf("mcs %d  pid %d\n",pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.mcs, pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.harqProcId.val);
        }
        dciPdu->rv_1                = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.rv;
        dciPdu->newDataInd_1               = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.ndi;
        dciPdu->tb2CwSwapFlag      = 0;
        dciPdu->mcs_2               = 0;
        dciPdu->rv_2                = 0;
        dciPdu->newDataInd_2               = 0;
        dciPdu->harqProcess           = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.harqProcId.val;
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2)
    {
#ifdef LTE_TDD
        dciPdu->dlAssignIdx = pdcchInfo->dci.u.format2Info.dai;
#else
        dciPdu->dlAssignIdx = 0;

#endif
        dciPdu->TPC = pdcchInfo->dci.u.format2Info.tpcCmd;
        dciPdu->mcs_1              = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].mcs;
        dciPdu->rv_1                = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].rv;
        dciPdu->newDataInd_1               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].ndi;
        dciPdu->tb2CwSwapFlag      = pdcchInfo->dci.u.format2Info.allocInfo.transSwap;
        dciPdu->mcs_2               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[1].mcs;
        dciPdu->rv_2                = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[1].rv;
        dciPdu->newDataInd_2               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].ndi;
        dciPdu->harqProcess           = pdcchInfo->dci.u.format2Info.allocInfo.harqProcId;

    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2A)
    {
#ifdef LTE_TDD
        dciPdu->dlAssignIdx  = pdcchInfo->dci.u.format2AInfo.dai;
#else
        dciPdu->dlAssignIdx = 0;
#endif
        dciPdu->TPC = pdcchInfo->dci.u.format2AInfo.tpcCmd;
        dciPdu->mcs_1              = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[0].mcs;
        dciPdu->rv_1                = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[0].rv;
        dciPdu->newDataInd_1               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[0].ndi;
        dciPdu->tb2CwSwapFlag     = pdcchInfo->dci.u.format2AInfo.allocInfo.transSwap;
        dciPdu->mcs_2               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[1].mcs;
        dciPdu->rv_2                = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[1].rv;
        dciPdu->newDataInd_2               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[1].ndi;
        dciPdu->harqProcess           = pdcchInfo->dci.u.format2AInfo.allocInfo.harqProcId;
    }
    else
    {
        dciPdu->dlAssignIdx  = 1;
        dciPdu->TPC = 1;
    }

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
    {
        dciPdu->N_GAP               =0;// pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.nGap2.val;
    }
    else
    {
        dciPdu->N_GAP = 0;
    }

    dciPdu->tbsIdx = 0;
    dciPdu->dlPowerOffs        = 0;
    if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)&&(pdcchInfo->dci.u.format1aInfo.isPdcchOrder))
    {
        dciPdu->prachFlag    = 1;
        dciPdu->preambleIdx        = pdcchInfo->dci.u.format1aInfo.t.pdcchOrder.preambleIdx;
        dciPdu->prachMskIdx     = pdcchInfo->dci.u.format1aInfo.t.pdcchOrder.prachMaskIdx;
    }
    else
    {
        dciPdu->prachFlag    = 0;
        dciPdu->preambleIdx        = 0;
        dciPdu->prachMskIdx      = 0;
    }

    if(YS_SI_RNTI == dciPdu->rnti)
    {
        dciPdu->rntiType = 2;
    }
    else if(YS_P_RNTI == dciPdu->rnti)
    {
        dciPdu->rntiType = 2;
    }
    else if(dciPdu->rnti <= YS_MAX_RARNTI)
    {
        dciPdu->rntiType = 2;
    }
    else
    {
        dciPdu->rntiType = 1;
    }

    dciPdu->transPower                  = 6000;
    #if 0
    dciPdu->rel9.mcch_flag           = 0;
    dciPdu->rel9.mcch_change_notif   = 0;
    dciPdu->rel9.scramb_id           = 0;
    dciPdu->rel10.cross_car_schd_flag = 0;
    dciPdu->rel10.car_indicator       = 0;
    dciPdu->rel10.srs_flag            = 0;
    dciPdu->rel10.srs_request         = 0;
    dciPdu->rel10.ant_p_scr_lrs       = 0;
    //dciPduA->rel10.payload_length      = ys_qcGetDciSize(0,DAN_E_ANT_BW20MHz,dciPduA->rel8.dci_format,0,0,0,0,0,0,1);//macsimMod_get_dci_size(fapi_carrier_params_ptr->init_config.duplexing_mode, MAC_SIM_fapi_get_dl_bw(fapi_carrier_params_ptr->init_config.RF_CONFIG_dl_bw),  dciPdu->dci_format,  dlpdu->DCI_associated_UL ,  dciPdu->cross_car_schd_flag ,  dlpdu->DCI_cqi_csi_size, dciPdu->srs_flag, max_rx_rb_num<=max_tx_rb_num  ,  0 /*trans_mode is relevant for dci format 4- uplink*/, TRUE );
#ifdef LTE_TDD
    dciPdu->rel10.payload_length      = ys_qcGetDciSize(0,cellCb->cellCfg.bwCfg.dlBw,dciPduA->rel8.dci_format,0,0,0,0,0,0,1);
#else
    dciPdu->rel10.payload_length      = ys_qcGetDciSize(1,cellCb->cellCfg.bwCfg.dlBw,dciPduA->rel8.dci_format,0,0,0,0,0,0,1);
#endif
    dciPdu->rel10.n_dl_rb= 0;
    dciPdu->rel11.harq_ack_res_offset = 0;
    dciPdu->rel11.qcl= 0;
    dciPdu->rel12.primary_cell_type= 0;
    dciPdu->rel12.ul_dl_config_flag= 0;
    dciPdu->rel12.num_ul_dl_config= 0;
    dciPduB->rel13.laa_end_partial_sf_flag=0;	
    dciPduB->rel13.laa_end_partial_sf_config=0;
    dciPduB->rel13.initial_lbt_sf=0;
    dciPduB->rel13.codebook_size_determination_r13=0;
    dciPduB->rel13.r13_dmrs_table_flag=0;
    #endif
} // end of MAC_SIM_fapi_build_dci_dl_pdu
/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_dci_dl_pdu
 * Description:     Init PDCCH request message with configured before
 *                      parameters for DL
 *
 * Input:       dlpdu - DL PDU config parameters
 *              advance_imp - implicit step size
 *
 * Output:      pdu_p - pointer to the newly created DL DCI PDU
 *
 * ----------------------------------------------------------------------
 */
void ys_NxpBuildDciDlPduTemp(FAPI_T_PDU *pdu_p,TfuPdcchInfo *pdcchInfo, CmLteCellId cellId)
{
    FAPI_T_DCI_DL_PDU_A           *dciPduA;

    YsCellCb	*cellCb = (YsCellCb*)ysMsCfgGetCellCfg(cellId);
    dciPduA  = (FAPI_T_DCI_DL_PDU_A *)&(pdu_p->pdu[0]);
  

    dciPduA->rel8.dci_format      = pdcchInfo->dci.dciFormat-1; //difference  between QC and Intel
    dciPduA->rel8.cce_index       = pdcchInfo->nCce;
    if(pdcchInfo->aggrLvl == CM_LTE_AGGR_LVL4)  //difference  between QC and Intel
    {
        dciPduA->rel8.agg_level = 4;
    }
    else if(pdcchInfo->aggrLvl == CM_LTE_AGGR_LVL8)
    {
        dciPduA->rel8.agg_level = 8;
    }
    else
    {
        dciPduA->rel8.agg_level = pdcchInfo->aggrLvl;
    }
    dciPduA->rel8.rnti            = pdcchInfo->rnti;

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1)
    {
        dciPduA->rel8.ra_type = ~(pdcchInfo->dci.u.format1Info.allocInfo.isAllocType0);
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2)
    {
        dciPduA->rel8.ra_type = ~(pdcchInfo->dci.u.format2Info.allocInfo.isAllocType0);
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2A)
    {
        dciPduA->rel8.ra_type = 1 - (pdcchInfo->dci.u.format2AInfo.allocInfo.isAllocType0);
        if(pdcchInfo->dci.u.format2AInfo.allocInfo.isAllocType0 == 1)
        {
            dciPduA->rel8.rb_coding = ys_qcsetRbforRaType0(pdcchInfo->dci.u.format2AInfo.allocInfo.resAllocMap, cellCb->cellCfg.bwCfg.dlBw);
        }
        else
        {
            STKLOG(STK_MD_YS,STK_LOG_INFO,"allocat type error \n");
        }
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
    {
        dciPduA->rel8.ra_type = 2;
        dciPduA->rel8.rb_coding   = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.alloc.u.riv;
    }

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
    {
        dciPduA->rel8.vir_rb_flag = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.isLocal ? 0:1;
    }
    else
    {
        dciPduA->rel8.vir_rb_flag = 0;
    }

    dciPduA->rel8.ndi_2               = 0;
    dciPduA->rel8.tpmi                = 0;
    dciPduA->rel8.pmi                 = 0;
    dciPduA->rel8.precode_info        = 0;

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1)
    {
#ifdef LTE_TDD
        dciPduA->rel8.dl_assign_idx = pdcchInfo->dci.u.format1Info.dai;
#endif
        dciPduA->rel8.tpc = pdcchInfo->dci.u.format1Info.tpcCmd;
        dciPduA->rel8.mcs_1               = pdcchInfo->dci.u.format1Info.allocInfo.mcs;
        dciPduA->rel8.rv_1                = pdcchInfo->dci.u.format1Info.allocInfo.rv;
        dciPduA->rel8.ndi_1               = pdcchInfo->dci.u.format1Info.allocInfo.ndi;
        dciPduA->rel8.tb_2_code_swap      = 0;
        dciPduA->rel8.mcs_2               = 0;
        dciPduA->rel8.rv_2                = 0;
        dciPduA->rel8.ndi_2               = 0;
        dciPduA->rel8.harq_proc           = pdcchInfo->dci.u.format1Info.allocInfo.harqProcId;
    }
    else if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)&&(!pdcchInfo->dci.u.format1aInfo.isPdcchOrder)) 
    {
#ifdef LTE_TDD
        dciPduA->rel8.dl_assign_idx = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.dai.val;
#else
        dciPduA->rel8.dl_assign_idx = 0;
#endif
        dciPduA->rel8.tpc = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        if((YS_SI_RNTI == pdcchInfo->rnti)||(YS_P_RNTI == pdcchInfo->rnti)||(pdcchInfo->rnti <= YS_MAX_RARNTI))
        {
            dciPduA->rel8.tpc = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        }
        else
        {
            dciPduA->rel8.tpc = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        }
        dciPduA->rel8.mcs_1               = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.mcs;
        if(pdcchInfo->rnti <200)
        {
            //printf("mcs %d  pid %d\n",pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.mcs, pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.harqProcId.val);
        }
        dciPduA->rel8.rv_1                = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.rv;
        dciPduA->rel8.ndi_1               = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.ndi;
        dciPduA->rel8.tb_2_code_swap      = 0;
        dciPduA->rel8.mcs_2               = 0;
        dciPduA->rel8.rv_2                = 0;
        dciPduA->rel8.ndi_2               = 0;
        dciPduA->rel8.harq_proc           = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.harqProcId.val;
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2)
    {
#ifdef LTE_TDD
        dciPduA->rel8.dl_assign_idx = pdcchInfo->dci.u.format2Info.dai;
#endif
        dciPduA->rel8.tpc = pdcchInfo->dci.u.format2Info.tpcCmd;
        dciPduA->rel8.mcs_1               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].mcs;
        dciPduA->rel8.rv_1                = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].rv;
        dciPduA->rel8.ndi_1               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].ndi;
        dciPduA->rel8.tb_2_code_swap      = pdcchInfo->dci.u.format2Info.allocInfo.transSwap;
        dciPduA->rel8.mcs_2               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[1].mcs;
        dciPduA->rel8.rv_2                = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[1].rv;
        dciPduA->rel8.ndi_2               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].ndi;
        dciPduA->rel8.harq_proc           = pdcchInfo->dci.u.format2Info.allocInfo.harqProcId;

    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2A)
    {
#ifdef LTE_TDD
        dciPduA->rel8.dl_assign_idx = pdcchInfo->dci.u.format2AInfo.dai;
#else
        dciPduA->rel8.dl_assign_idx = 0;

#endif
        dciPduA->rel8.tpc = pdcchInfo->dci.u.format2AInfo.tpcCmd;
        dciPduA->rel8.mcs_1               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[0].mcs;
        dciPduA->rel8.rv_1                = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[0].rv;
        dciPduA->rel8.ndi_1               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[0].ndi;
        dciPduA->rel8.tb_2_code_swap      = pdcchInfo->dci.u.format2AInfo.allocInfo.transSwap;
        dciPduA->rel8.mcs_2               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[1].mcs;
        dciPduA->rel8.rv_2                = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[1].rv;
        dciPduA->rel8.ndi_2               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[1].ndi;
        dciPduA->rel8.harq_proc           = pdcchInfo->dci.u.format2AInfo.allocInfo.harqProcId;
    }
    else
    {
        dciPduA->rel8.dl_assign_idx = 1;
        dciPduA->rel8.tpc = 1;
    }

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
    {
        dciPduA->rel8.n_gap               =0;// pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.nGap2.val;
    }
    else
    {
        dciPduA->rel8.n_gap = 0;
    }

    dciPduA->rel8.tb_size_idx = 0;
    dciPduA->rel8.dl_power_off        = 0;
    if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)&&(pdcchInfo->dci.u.format1aInfo.isPdcchOrder))
    {
        dciPduA->rel8.alloc_prach_flag    = 1;
        dciPduA->rel8.preamble_idx        = pdcchInfo->dci.u.format1aInfo.t.pdcchOrder.preambleIdx;
        dciPduA->rel8.prach_mask_idx      = pdcchInfo->dci.u.format1aInfo.t.pdcchOrder.prachMaskIdx;
    }
    else
    {
        dciPduA->rel8.alloc_prach_flag    = 0;
        dciPduA->rel8.preamble_idx        = 0;
        dciPduA->rel8.prach_mask_idx      = 0;
    }

    if(YS_SI_RNTI == dciPduA->rel8.rnti)
    {
        dciPduA->rel8.rnti_type = 2;
    }
    else if(YS_P_RNTI == dciPduA->rel8.rnti)
    {
        dciPduA->rel8.rnti_type = 2;
    }
    else if(dciPduA->rel8.rnti <= YS_MAX_RARNTI)
    {
        dciPduA->rel8.rnti_type = 2;
    }
    else
    {
        dciPduA->rel8.rnti_type = 1;
    }

    dciPduA->rel8.tp                  = 6000;
 
} // end of MAC_SIM_fapi_build_dci_dl_pdu
void ys_qcBuildDciDlPdu(FAPI_T_PDU *pdu_p,TfuPdcchInfo *pdcchInfo, CmLteCellId cellId)
{
    FAPI_T_DCI_DL_PDU_A           *dciPduA;
    FAPI_T_DCI_DL_PDU_B           *dciPduB;
    YsCellCb	*cellCb = (YsCellCb*)ysMsCfgGetCellCfg(cellId);
    dciPduA  = (FAPI_T_DCI_DL_PDU_A *)&(pdu_p->pdu[0]);
    dciPduB  = (FAPI_T_DCI_DL_PDU_B *)((U8*)dciPduA+sizeof(FAPI_T_DCI_DL_PDU_A));    

    dciPduA->rel8.dci_format      = pdcchInfo->dci.dciFormat-1; //difference  between QC and Intel
    dciPduA->rel8.cce_index       = pdcchInfo->nCce;
    if(pdcchInfo->aggrLvl == CM_LTE_AGGR_LVL4)  //difference  between QC and Intel
    {
        dciPduA->rel8.agg_level = 4;
    }
    else if(pdcchInfo->aggrLvl == CM_LTE_AGGR_LVL8)
    {
        dciPduA->rel8.agg_level = 8;
    }
    else
    {
        dciPduA->rel8.agg_level = pdcchInfo->aggrLvl;
    }
    dciPduA->rel8.rnti            = pdcchInfo->rnti;

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1)
    {
        dciPduA->rel8.ra_type = ~(pdcchInfo->dci.u.format1Info.allocInfo.isAllocType0);
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2)
    {
        dciPduA->rel8.ra_type = ~(pdcchInfo->dci.u.format2Info.allocInfo.isAllocType0);
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2A)
    {
        dciPduA->rel8.ra_type = 1 - (pdcchInfo->dci.u.format2AInfo.allocInfo.isAllocType0);
        if(pdcchInfo->dci.u.format2AInfo.allocInfo.isAllocType0 == 1)
        {
            dciPduA->rel8.rb_coding = ys_qcsetRbforRaType0(pdcchInfo->dci.u.format2AInfo.allocInfo.resAllocMap, cellCb->cellCfg.bwCfg.dlBw);
        }
        else
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"allocat type error \n");
        }
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
    {
        dciPduA->rel8.ra_type = 2;
        dciPduA->rel8.rb_coding   = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.alloc.u.riv;
    }

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
    {
        dciPduA->rel8.vir_rb_flag = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.isLocal ? 0:1;
    }
    else
    {
        dciPduA->rel8.vir_rb_flag = 0;
    }

    dciPduA->rel8.ndi_2               = 0;
    dciPduA->rel8.tpmi                = 0;
    dciPduA->rel8.pmi                 = 0;
    dciPduA->rel8.precode_info        = 0;

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1)
    {
#ifdef LTE_TDD
        dciPduA->rel8.dl_assign_idx = pdcchInfo->dci.u.format1Info.dai;
#endif
        dciPduA->rel8.tpc = pdcchInfo->dci.u.format1Info.tpcCmd;
        dciPduA->rel8.mcs_1               = pdcchInfo->dci.u.format1Info.allocInfo.mcs;
        dciPduA->rel8.rv_1                = pdcchInfo->dci.u.format1Info.allocInfo.rv;
        dciPduA->rel8.ndi_1               = pdcchInfo->dci.u.format1Info.allocInfo.ndi;
        dciPduA->rel8.tb_2_code_swap      = 0;
        dciPduA->rel8.mcs_2               = 0;
        dciPduA->rel8.rv_2                = 0;
        dciPduA->rel8.ndi_2               = 0;
        dciPduA->rel8.harq_proc           = pdcchInfo->dci.u.format1Info.allocInfo.harqProcId;
    }
    else if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)&&(!pdcchInfo->dci.u.format1aInfo.isPdcchOrder)) 
    {
#ifdef LTE_TDD
        dciPduA->rel8.dl_assign_idx = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.dai.val;
#endif
        dciPduA->rel8.tpc = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        if((YS_SI_RNTI == pdcchInfo->rnti)||(YS_P_RNTI == pdcchInfo->rnti)||(pdcchInfo->rnti <= YS_MAX_RARNTI))
        {
            dciPduA->rel8.tpc = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        }
        else
        {
            dciPduA->rel8.tpc = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.tpcCmd;
        }
        dciPduA->rel8.mcs_1               = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.mcs;
        if(pdcchInfo->rnti <200)
        {
            //printf("mcs %d  pid %d\n",pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.mcs, pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.harqProcId.val);
        }
        dciPduA->rel8.rv_1                = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.rv;
        dciPduA->rel8.ndi_1               = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.ndi;
        dciPduA->rel8.tb_2_code_swap      = 0;
        dciPduA->rel8.mcs_2               = 0;
        dciPduA->rel8.rv_2                = 0;
        dciPduA->rel8.ndi_2               = 0;
        dciPduA->rel8.harq_proc           = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.harqProcId.val;
    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2)
    {
#ifdef LTE_TDD
        dciPduA->rel8.dl_assign_idx = pdcchInfo->dci.u.format2Info.dai;
#endif
        dciPduA->rel8.tpc = pdcchInfo->dci.u.format2Info.tpcCmd;
        dciPduA->rel8.mcs_1               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].mcs;
        dciPduA->rel8.rv_1                = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].rv;
        dciPduA->rel8.ndi_1               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].ndi;
        dciPduA->rel8.tb_2_code_swap      = pdcchInfo->dci.u.format2Info.allocInfo.transSwap;
        dciPduA->rel8.mcs_2               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[1].mcs;
        dciPduA->rel8.rv_2                = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[1].rv;
        dciPduA->rel8.ndi_2               = pdcchInfo->dci.u.format2Info.allocInfo.tbInfo[0].ndi;
        dciPduA->rel8.harq_proc           = pdcchInfo->dci.u.format2Info.allocInfo.harqProcId;

    }
    else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_2A)
    {
#ifdef LTE_TDD
        dciPduA->rel8.dl_assign_idx = pdcchInfo->dci.u.format2AInfo.dai;
#endif
        dciPduA->rel8.tpc = pdcchInfo->dci.u.format2AInfo.tpcCmd;
        dciPduA->rel8.mcs_1               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[0].mcs;
        dciPduA->rel8.rv_1                = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[0].rv;
        dciPduA->rel8.ndi_1               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[0].ndi;
        dciPduA->rel8.tb_2_code_swap      = pdcchInfo->dci.u.format2AInfo.allocInfo.transSwap;
        dciPduA->rel8.mcs_2               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[1].mcs;
        dciPduA->rel8.rv_2                = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[1].rv;
        dciPduA->rel8.ndi_2               = pdcchInfo->dci.u.format2AInfo.allocInfo.tbInfo[1].ndi;
        dciPduA->rel8.harq_proc           = pdcchInfo->dci.u.format2AInfo.allocInfo.harqProcId;
    }
    else
    {
        dciPduA->rel8.dl_assign_idx = 1;
        dciPduA->rel8.tpc = 1;
    }

    if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
    {
        dciPduA->rel8.n_gap               = pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.nGap2.val;
    }

        dciPduA->rel8.tb_size_idx = 0;
        dciPduA->rel8.dl_power_off        = 0;
    if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)&&(pdcchInfo->dci.u.format1aInfo.isPdcchOrder))
    {
        dciPduA->rel8.alloc_prach_flag    = 1;
        dciPduA->rel8.preamble_idx        = pdcchInfo->dci.u.format1aInfo.t.pdcchOrder.preambleIdx;
        dciPduA->rel8.prach_mask_idx      = pdcchInfo->dci.u.format1aInfo.t.pdcchOrder.prachMaskIdx;
    }
    else
    {
        dciPduA->rel8.alloc_prach_flag    = 0;
        dciPduA->rel8.preamble_idx        = 0;
        dciPduA->rel8.prach_mask_idx      = 0;
    }

    if(YS_SI_RNTI == dciPduA->rel8.rnti)
    {
        dciPduA->rel8.rnti_type = 2;
    }
    else if(YS_P_RNTI == dciPduA->rel8.rnti)
    {
        dciPduA->rel8.rnti_type = 2;
    }
    else if(dciPduA->rel8.rnti <= YS_MAX_RARNTI)
    {
        dciPduA->rel8.rnti_type = 2;
    }
    else
    {
        dciPduA->rel8.rnti_type = 1;
    }

    dciPduA->rel8.tp                  = 6000;
    dciPduA->rel9.mcch_flag           = 0;
    dciPduA->rel9.mcch_change_notif   = 0;
    dciPduA->rel9.scramb_id           = 0;
    dciPduA->rel10.cross_car_schd_flag = 0;
    dciPduA->rel10.car_indicator       = 0;
    dciPduA->rel10.srs_flag            = 0;
    dciPduA->rel10.srs_request         = 0;
    dciPduA->rel10.ant_p_scr_lrs       = 0;
    //dciPduA->rel10.payload_length      = ys_qcGetDciSize(0,DAN_E_ANT_BW20MHz,dciPduA->rel8.dci_format,0,0,0,0,0,0,1);//macsimMod_get_dci_size(fapi_carrier_params_ptr->init_config.duplexing_mode, MAC_SIM_fapi_get_dl_bw(fapi_carrier_params_ptr->init_config.RF_CONFIG_dl_bw),  dciPdu->dci_format,  dlpdu->DCI_associated_UL ,  dciPdu->cross_car_schd_flag ,  dlpdu->DCI_cqi_csi_size, dciPdu->srs_flag, max_rx_rb_num<=max_tx_rb_num  ,  0 /*trans_mode is relevant for dci format 4- uplink*/, TRUE );
#ifdef LTE_TDD
    dciPduA->rel10.payload_length      = ys_qcGetDciSize(0,cellCb->cellCfg.bwCfg.dlBw,dciPduA->rel8.dci_format,0,0,0,0,0,0,1);
#else
    dciPduA->rel10.payload_length      = ys_qcGetDciSize(1,cellCb->cellCfg.bwCfg.dlBw,dciPduA->rel8.dci_format,0,0,0,0,0,0,1);
#endif
    dciPduA->rel10.n_dl_rb= 0;
    dciPduA->rel11.harq_ack_res_offset = 0;
    dciPduA->rel11.qcl= 0;
    dciPduA->rel12.primary_cell_type= 0;
    dciPduA->rel12.ul_dl_config_flag= 0;
    dciPduA->rel12.num_ul_dl_config= 0;
    dciPduB->rel13.laa_end_partial_sf_flag=0;	
    dciPduB->rel13.laa_end_partial_sf_config=0;
    dciPduB->rel13.initial_lbt_sf=0;
    dciPduB->rel13.codebook_size_determination_r13=0;
    dciPduB->rel13.r13_dmrs_table_flag=0;
} // end of MAC_SIM_fapi_build_dci_dl_pdu

static void ys_qcBuildHiPdu(FAPI_T_PDU *pdu_p, TfuPhichInfo *ulpdu)
{
    FAPI_T_HI_PDU   *hiPdu  = (FAPI_T_HI_PDU *)&(pdu_p->pdu[0]);

    hiPdu->rel8.rb_start         = ulpdu->rbStart;
    hiPdu->rel8.cyc_shift_2_dmrs = ulpdu->nDmrs;
    hiPdu->rel8.hi_value         = ulpdu->isAck;
#ifdef TFU_TDD
    hiPdu->rel8.i_phich          = ulpdu->iPhich;
#else
    hiPdu->rel8.i_phich = 0;
#endif

    hiPdu->rel8.trans_power      = 6000;//ulpdu->txPower;
    hiPdu->rel10.flag_tb2         = 0;
    hiPdu->rel10.hi_value2        = 0;
} // end of MAC_SIM_fapi_build_hi_pdu
void ys_NxpBuildHiPdu(apiHIDCI0Pdu_t *pdu_p, TfuPhichInfo *ulpdu)
{
    apiHIDCI0PduHI_t   *hiPdu  = (apiHIDCI0PduHI_t *)&(pdu_p->pdu[0]);

    hiPdu->rbStart         = ulpdu->rbStart;
    hiPdu->cs2DMRS         = ulpdu->nDmrs;
    hiPdu->hiVal           = ulpdu->isAck;
#ifdef TFU_TDD
    hiPdu->I_PHICH         = ulpdu->iPhich;
#else
    hiPdu->I_PHICH         = 0;
#endif

    hiPdu->transPower      = 6000;//ulpdu->txPower;
    #if 0
    hiPdu->rel10.flag_tb2         = 0;
    hiPdu->rel10.hi_value2        = 0;
    #endif
} // end of MAC_SIM_fapi_build_hi_pdu

static void ys_qcBuildDci0Pdu(FAPI_T_PDU *pdu_p, TfuPdcchInfo *pdcchInfo, CmLteCellId cellId)
{
    FAPI_T_DCI_UL_PDU *dciPdu   = (FAPI_T_DCI_UL_PDU *)&(pdu_p->pdu[0]);
    YsCellCb	*cellCb = (YsCellCb*)ysMsCfgGetCellCfg(cellId);

    dciPdu->rel8.dci_format          = pdcchInfo->dci.dciFormat;
    dciPdu->rel8.cce_idx             = pdcchInfo->nCce;
    switch(pdcchInfo->aggrLvl)
    {
        case 1:
            dciPdu->rel8.agg_level = 1;
        break;
        case 2:
            dciPdu->rel8.agg_level = 2;
        break;
        case 3:
            dciPdu->rel8.agg_level = 4;
        break;
        case 4:
            dciPdu->rel8.agg_level = 8;
        break;
        default:
            STKLOG(STK_MD_YS,STK_LOG_ERR,"Invalid aggrLvl\n");
        break;
    }

    dciPdu->rel8.rnti                = pdcchInfo->rnti;
    dciPdu->rel8.rb_start            = pdcchInfo->dci.u.format0Info.rbStart;
    dciPdu->rel8.n_rb                = pdcchInfo->dci.u.format0Info.numRb;
    dciPdu->rel8.mcs_1               = pdcchInfo->dci.u.format0Info.mcs;//ulpdu->UL_mcs1;

    //dciPdu->rel8.mcs_2               = 0;//ulpdu->UL_mcs2;
    dciPdu->rel8.cyc_shift_2_dmrs    = pdcchInfo->dci.u.format0Info.nDmrs;
#ifdef TFU_TDD
    dciPdu->rel8.freq_enable         = pdcchInfo->dci.u.format0Info.hoppingEnbld;
    dciPdu->rel8.freq_hop_bits       = pdcchInfo->dci.u.format0Info.hoppingBits;
#else
    dciPdu->rel8.freq_enable         = 0;
    dciPdu->rel8.freq_hop_bits       = 0;
#endif
    dciPdu->rel8.ndi_1               = pdcchInfo->dci.u.format0Info.ndi;//ulpdu->UL_ndi1;
    //dciPdu->rel8.ndi_2               = 0;//ulpdu->UL_ndi2;
    dciPdu->rel8.ue_tx_ant_select    = 0;//ulpdu->DCI_ant_sel;
    dciPdu->rel8.tpc                 = pdcchInfo->dci.u.format0Info.tpcCmd;
    dciPdu->rel8.cqi_csi_req         = pdcchInfo->dci.u.format0Info.cqiReq;
#ifdef TFU_TDD
    dciPdu->rel8.ul_idx              = pdcchInfo->dci.u.format0Info.ulIdx;//ulpdu->DCI_ul_idx;
    dciPdu->rel8.dl_assign_idx       = pdcchInfo->dci.u.format0Info.dai;//ulpdu->DCI_dl_assign_idx;
#else
    dciPdu->rel8.ul_idx              = 0;
    dciPdu->rel8.dl_assign_idx       = 0;
#endif
    dciPdu->rel8.tpc_bitmap          = 0;//ulpdu->DCI_tpc_bitmap;
    dciPdu->rel8.tp                  = 6000;//ulpdu->DCI_tp;
    dciPdu->rel10.cros_car_sch_flag   = 0;//ulpdu->DCI_cross_car_flag;
    dciPdu->rel10.car_ind             = 0;//ulpdu->DCI_car_ind;
#ifdef TFU_TDD
    dciPdu->rel10.cqi_csi_size        = pdcchInfo->dci.u.format0Info.numCqiBit -1; //ulpdu->DCI_cqi_csi_size;
#else
    dciPdu->rel10.cqi_csi_size        = 0;
#endif
    dciPdu->rel10.srs_flag            = 0;//ulpdu->DCI_srs_flag;
    dciPdu->rel10.srs_req             = 0;//ulpdu->DCI_srs_req;
    dciPdu->rel10.res_alloc_flag      = 0;//ulpdu->DCI_ra_flag;
    dciPdu->rel10.res_alloc_type      = 0;//ulpdu->UL_ra_type;
    dciPdu->rel10.rb_coding           = 0;//ulpdu->UL_rb_coding;
    dciPdu->rel10.mcs_2               = 0;//ulpdu->UL_mcs2;
    dciPdu->rel10.nd_ind2               = 0;//ulpdu->UL_ndi2;
    dciPdu->rel10.n_ant_ports         = 0;//ulpdu->DCI_n_ant;
    dciPdu->rel10.tpmi                = 0;//ulpdu->DCI_tpmi;
#ifdef TFU_TDD
    dciPdu->rel10.payload_length      = ys_qcGetDciSize(0,cellCb->cellCfg.bwCfg.dlBw,dciPdu->rel8.dci_format,0,0,0,0,0,0,0);//macsimMod_get_dci_size(fapi_carrier_params_ptr->init_config.duplexing_mode, MAC_SIM_fapi_get_dl_bw(fapi_carrier_params_ptr->init_config.RF_CONFIG_ul_bw),  dciPdu->dci_format,  1 ,  dciPdu->cros_car_sch_flag ,  dciPdu->cqi_csi_size, dciPdu->srs_flag, max_rx_rb_num<=max_tx_rb_num  , ulpdu->DCI_trans_mode, FALSE );
#else
    dciPdu->rel10.payload_length      = ys_qcGetDciSize(1,cellCb->cellCfg.bwCfg.dlBw,dciPdu->rel8.dci_format,0,0,0,0,0,0,0);//macsimMod_get_dci_size(fapi_carrier_params_ptr->init_config.duplexing_mode, MAC_SIM_fapi_get_dl_bw(fapi_carrier_params_ptr->init_config.RF_CONFIG_ul_bw),  dciPdu->dci_format,  1 ,  dciPdu->cros_car_sch_flag ,  dciPdu->cqi_csi_size, dciPdu->srs_flag, max_rx_rb_num<=max_tx_rb_num  , ulpdu->DCI_trans_mode, FALSE );
#endif
    dciPdu->rel10.n_ul_rb= 0;
    dciPdu->rel12.pscch_resource = 0;
    dciPdu->rel12.time_resource_pattern = 0;
} // end of MAC_SIM_fapi_build_dci_ul_pdu
void ys_NxpBuildDci0Pdu(apiHIDCI0Pdu_t *pdu_p, TfuPdcchInfo *pdcchInfo, CmLteCellId cellId)
{
    apiHIDCI0PduUlDCI_t *dciPdu   = (apiHIDCI0PduUlDCI_t *)&(pdu_p->pdu[0]);
    YsCellCb	*cellCb = (YsCellCb*)ysMsCfgGetCellCfg(cellId);

    dciPdu->dciFormat          = pdcchInfo->dci.dciFormat;
    dciPdu->cceIdx             = pdcchInfo->nCce;
    switch(pdcchInfo->aggrLvl)
    {
        case 1:
            dciPdu->aggreLevel= 1;
        break;
        case 2:
            dciPdu->aggreLevel = 2;
        break;
        case 3:
            dciPdu->aggreLevel = 4;
        break;
        case 4:
            dciPdu->aggreLevel = 8;
        break;
        default:
            STKLOG(STK_MD_YS,STK_LOG_INFO,"Invalid aggrLvl\n");
        break;
    }

    dciPdu->rnti                     = pdcchInfo->rnti;
    dciPdu->rbStart                  = pdcchInfo->dci.u.format0Info.rbStart;
    dciPdu->numRbs                   = pdcchInfo->dci.u.format0Info.numRb;
    dciPdu->mcs                      = pdcchInfo->dci.u.format0Info.mcs;//ulpdu->UL_mcs1;

    //dciPdu->rel8.mcs_2               = 0;//ulpdu->UL_mcs2;
    dciPdu->cs2DMRS                  = pdcchInfo->dci.u.format0Info.nDmrs;
#ifdef TFU_TDD
    dciPdu->freqHopFlag              = pdcchInfo->dci.u.format0Info.hoppingEnbld;
    dciPdu->freqHopBits              = pdcchInfo->dci.u.format0Info.hoppingBits;
#else
    dciPdu->freqHopFlag              = 0;
    dciPdu->freqHopBits              = 0;
#endif
    dciPdu->newDataInd               = pdcchInfo->dci.u.format0Info.ndi;//ulpdu->UL_ndi1;
    //dciPdu->rel8.ndi_2               = 0;//ulpdu->UL_ndi2;
    dciPdu->ueTxAntSelec             = 0;//ulpdu->DCI_ant_sel;
    dciPdu->TPC                      = pdcchInfo->dci.u.format0Info.tpcCmd;
    dciPdu->cqiReq                   = pdcchInfo->dci.u.format0Info.cqiReq;
#ifdef TFU_TDD
    dciPdu->ulIdx                    = pdcchInfo->dci.u.format0Info.ulIdx;//ulpdu->DCI_ul_idx;
    dciPdu->dlAssignIdx              = pdcchInfo->dci.u.format0Info.dai;//ulpdu->DCI_dl_assign_idx;
#else
    dciPdu->ulIdx                    = 0;
    dciPdu->dlAssignIdx              = 0;
#endif
    dciPdu->tpcBitmap                = 0;//ulpdu->DCI_tpc_bitmap;
    dciPdu->transPower               = 6000;//ulpdu->DCI_tp;
#if 0
    dciPdu->rel10.cros_car_sch_flag   = 0;//ulpdu->DCI_cross_car_flag;
    dciPdu->rel10.car_ind             = 0;//ulpdu->DCI_car_ind;
#ifdef TFU_TDD
    dciPdu->rel10.cqi_csi_size        = pdcchInfo->dci.u.format0Info.numCqiBit -1; //ulpdu->DCI_cqi_csi_size;
#else
    dciPdu->rel10.cqi_csi_size        = 0;
#endif
    dciPdu->rel10.srs_flag            = 0;//ulpdu->DCI_srs_flag;
    dciPdu->rel10.srs_req             = 0;//ulpdu->DCI_srs_req;
    dciPdu->rel10.res_alloc_flag      = 0;//ulpdu->DCI_ra_flag;
    dciPdu->rel10.res_alloc_type      = 0;//ulpdu->UL_ra_type;
    dciPdu->rel10.rb_coding           = 0;//ulpdu->UL_rb_coding;
    dciPdu->rel10.mcs_2               = 0;//ulpdu->UL_mcs2;
    dciPdu->rel10.nd_ind2               = 0;//ulpdu->UL_ndi2;
    dciPdu->rel10.n_ant_ports         = 0;//ulpdu->DCI_n_ant;
    dciPdu->rel10.tpmi                = 0;//ulpdu->DCI_tpmi;
#ifdef TFU_TDD
    dciPdu->rel10.payload_length      = ys_qcGetDciSize(0,cellCb->cellCfg.bwCfg.dlBw,dciPdu->rel8.dci_format,0,0,0,0,0,0,0);//macsimMod_get_dci_size(fapi_carrier_params_ptr->init_config.duplexing_mode, MAC_SIM_fapi_get_dl_bw(fapi_carrier_params_ptr->init_config.RF_CONFIG_ul_bw),  dciPdu->dci_format,  1 ,  dciPdu->cros_car_sch_flag ,  dciPdu->cqi_csi_size, dciPdu->srs_flag, max_rx_rb_num<=max_tx_rb_num  , ulpdu->DCI_trans_mode, FALSE );
#else
    dciPdu->rel10.payload_length      = ys_qcGetDciSize(1,cellCb->cellCfg.bwCfg.dlBw,dciPdu->rel8.dci_format,0,0,0,0,0,0,0);//macsimMod_get_dci_size(fapi_carrier_params_ptr->init_config.duplexing_mode, MAC_SIM_fapi_get_dl_bw(fapi_carrier_params_ptr->init_config.RF_CONFIG_ul_bw),  dciPdu->dci_format,  1 ,  dciPdu->cros_car_sch_flag ,  dciPdu->cqi_csi_size, dciPdu->srs_flag, max_rx_rb_num<=max_tx_rb_num  , ulpdu->DCI_trans_mode, FALSE );
#endif
    dciPdu->rel10.n_ul_rb= 0;
    dciPdu->rel12.pscch_resource = 0;
    dciPdu->rel12.time_resource_pattern = 0;
    #endif
} // end of MAC_SIM_fapi_build_dci_ul_pdu

void ys_qcSendNullCrcInd(U16 sfn, U8 subframe, U8 flag, CmLteCellId cellId)
{
    TfuCrcIndInfo     *crcIndInfo = NULLP;
    S16 ret = 0;
    YsCellCb    *cellCb;

    TRC2(ys_qcSendNullCrcInd)
    U16 indx = cellId - CM_START_CELL_ID;
    cellCb = (YsCellCb*)ysMsCfgGetCellCfg(cellId);
    if(NULLP != cellCb->ulEncL1Msgs[(subframe+3)%10].tfuCrcIndInfo)
    {
        return;
    }
    if(flag != 0)
    {
        //printf("%d\n",sizeof(TfuCrcIndInfo));
    }
    ret = ysUtlAllocEventMem((Ptr *)&crcIndInfo,sizeof(TfuCrcIndInfo), indx, __FUNCTION__,__LINE__);
    if(ret == RFAILED)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"malloc failed for fake crc ind\n");
        return;
    } /* end of if statement */
    cmLListInit(&(crcIndInfo->crcLst));

    crcIndInfo->cellId = cellId;
    crcIndInfo->timingInfo.sfn = sfn;
    crcIndInfo->timingInfo.subframe =subframe;
    //YsUiTfuCrcInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId,crcIndInfo);
    cellCb->ulEncL1Msgs[(subframe+3)%10].tfuCrcIndInfo = crcIndInfo;
    RETVOID;
}

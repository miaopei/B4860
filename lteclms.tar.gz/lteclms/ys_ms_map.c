/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/



/**********************************************************************

     Name:     LTE-SCL Layer 
  
     Type:     C souce file
  
     Desc:     SCL for Trillium to Silicon Rx Mapping. 

     File:     ys_rxmap.c 

     Sid:      yw_ms_map.c@@/main/TeNB_Main_BR/5 - Wed Jun 11 13:19:53 2014

     Prg:      mraj 

**********************************************************************/

#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_FILE_ID=281;
static int RLOG_MODULE_ID=1;

/* Trillium Includes */
#include "envopt.h"        /* Environment options */
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */
  
#include "gen.h"           /* General */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common timer defines */
#include "cm_tkns.h"       /* Common tokens defines */
#include "cm_mblk.h"       /* Common memory allocation library defines */
#include "cm_llist.h"      /* Common link list defines  */
#include "cm_hash.h"       /* Common hashlist defines */
#include "cm_lte.h"        /* Common LTEE defines */
#include "tfu.h"
#include "ctf.h"
#include "lys.h"

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "spaccdrv.h" /*sumanth*/
#endif
#endif

#include "gen.x"           /* General */
#include "ssi.x"           /* System services */

#include "cm5.x"           /* Common timer library */
#include "cm_tkns.x"       /* Common tokens */
#include "cm_mblk.x"       /* Common memory allocation */
#include "cm_llist.x"      /* Common link list */
#include "cm_hash.x"       /* Common hashlist */
#include "cm_lte.x"        /* Common LTE includes */
#include "cm_lib.x"
#include "tfu.x"
#include "ctf.x"
#include "lys.x"

/* Silicon Includes */
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "resultcodes.h"
#endif

#include "ys_ms_err.h"        /* CL error header file */
#include "ys_ms.h"
#include "ys_ms.x"

/*ys004.102 :  Merged MSPD code with phy 1.7 */

U8 ysUeModulation[YS_NUM_MODULATION]={0, BPSK, QPSK, QPSK, QPSK, QPSK};


/**
 *     @brief This function is used to 
 *            
 *            
 *     @param[in] ulSubFrDesc  [PHY]Sub Frame Descriptor
 *     @param[in] l2Msg        [MAC]Message from MAC
 *     @param[in] cellCb       [CL] Convergence Layer
 *     @param[in] event        [CL] Event triggered
 *
 *  @return  S16
 *      -# ROK 
 *      -# RFAILED 
 *
 *
 **********************************************************/


#define TODO 0x01;

/* Maps from TFU values to PHY values */
enum ModulationOptions ModulationMap[3] = 
{
   QPSK, QAM16, QAM64
};

#ifdef TFU_UPGRADE
PRIVATE Void ysMsMapUeCtrlOnPusch ARGS((
YsCellCb           *ysCellCb,
YsUeCb             *ysUeCb,
TfuUePuschRecpReq  *puschRecpReq,
PULCHANDESC        pPuschChan,
U8                 recpsf
));
#endif
#ifndef TFU_UPGRADE
PRIVATE S16 ysMsResetUeSfInfo ARGS((YsUeSubFrInfo *ueSubFrInfo));
PRIVATE Void ysMsMapUeCtrlOnPusch ARGS((YsCellCb *ysCellCb,YsUeCb *ysUeCb,PULCHANDESC pPuschChan, U8 recpsf));



/* 
*
*       Fun:   ysMsMapSrsDedInfo 
*  
*       Desc:  Mapping of UE specific SR
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapSrsDedInfo
(
YsUeCb           *ysUeCb,
CtfCellCfgInfo   *cellCfg,
SRSDED           *srsDed
)
{
   CtfDedSrsUlCfgInfo           *srsDedCfg;

   TRC2(ysMsMapSrsDedInfo)

   if (srsDed->enableDisable = ysUeCb->ueCfg.srsUlCfg.pres)
   {
      srsDedCfg = &ysUeCb->ueCfg.srsUlCfg;
      srsDed->srsBandwidth        = srsDedCfg->dedSrsSetup.srsBw;
      srsDed->srsHoppingBandwidth = srsDedCfg->dedSrsSetup.srsHopngBw;
      srsDed->transmissionComb    = srsDedCfg->dedSrsSetup.txComb;
      srsDed->cyclicShift         = srsDedCfg->dedSrsSetup.cyclicShift;
      srsDed->freqDomainPosition  = srsDedCfg->dedSrsSetup.freqDmnPos;
      srsDed->duration            = srsDedCfg->dedSrsSetup.duration;
      srsDed->srsConfigIndex      = srsDedCfg->dedSrsSetup.srsCfgIdx;
   }

   RETVOID;
} /* ysMsMapSrsDedInfo */

/*
*       Fun:  ysMsGetAndResetCwCount
*  
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:
*/
PRIVATE U8 ysMsGetAndResetCwCount
(
YsUeCb           *ysUeCb,
U8                recpSubframe
)
{
   U8  cwCount;
   U8  dataSubframe = recpSubframe + YS_NUM_SUB_FRAMES - 4;
   if (dataSubframe >= YS_NUM_SUB_FRAMES)
      dataSubframe -= YS_NUM_SUB_FRAMES;
   cwCount = ysUeCb->cwCount[dataSubframe];
#ifndef HARQ_STATISTICS
   ysUeCb->cwCount[dataSubframe] = 0;
#endif
   return cwCount;
}

/*
*
*       Fun:  ysMsSetPucchParams
*  
*       Desc:  Calculate Pucch Format type
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE S16 ysMsSetPucchParams
(
YsUeSubFrInfo    *ueSubFrInfo,
Bool              simultAckNack,
PUCCHDEDCTL      *pucchDedCtlInfo,
YsUeCb           *ysUeCb,
U8                recpSubFrameNo
)
{
   /* 36.211 Table 5.4-1 */

   TRC2(ysMsSetPucchParams)

   pucchDedCtlInfo->simSRHarq = 0;
   if (ueSubFrInfo->harqReqInfo)
   {
      U8 cwCount = ysMsGetAndResetCwCount(ysUeCb, recpSubFrameNo);
      if (ueSubFrInfo->cqiPres && simultAckNack)
      {

         if (cwCount > 1)
         {
            ueSubFrInfo->pucchFormat = FORMAT2B;
            pucchDedCtlInfo->formatType = FORMAT2B;
         }
         else
         {
            ueSubFrInfo->pucchFormat = FORMAT2A;
            pucchDedCtlInfo->formatType = FORMAT2A;
         }
      } /* harq + cqi */
      else 
      {
         if (cwCount > 1)
         {
            ueSubFrInfo->pucchFormat = FORMAT1B;
            pucchDedCtlInfo->formatType = FORMAT1B;
         }
         else
         {
            ueSubFrInfo->pucchFormat = FORMAT1A;
            pucchDedCtlInfo->formatType = FORMAT1A;
         }
      }/* only Harq */
     if (ueSubFrInfo->srPres)
     {
        pucchDedCtlInfo->simSRHarq = 1;
     }
     RETVALUE(ROK);
   }
   if (ueSubFrInfo->cqiPres)
   {  
      ueSubFrInfo->pucchFormat = FORMAT2;
      pucchDedCtlInfo->formatType = FORMAT2;
     RETVALUE(ROK);
   } /* Only Cqi */
   if(ueSubFrInfo->srPres)
   {
      ueSubFrInfo->pucchFormat = FORMAT1;
      pucchDedCtlInfo->formatType = FORMAT1;
     RETVALUE(ROK);
   } /* Only Sr */

   /* Negative SR Case + Format 2b case unhandled */
   /* Format 1b unsupported */
   ueSubFrInfo->pucchFormat = FORMAT1;
   pucchDedCtlInfo->formatType = FORMAT1;
   RETVALUE(ROK);

} /* ysMsSetPucchParams */

/* 
*
*       Fun:  ysMsMapPucchDedCtl
*  
*       Desc:  Map Ue Specific Pucch Control
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/

PRIVATE void ysMsMapPucchDedCtl
(
YsUeCb           *ysUeCb,
CtfCellCfgInfo   *cellCfg,
PUCCHDEDCTL      *pucchDedCtl,
U8                recpSubframeNo
)
{
   CtfDedPucchCfgInfo        *pucchDedCfg;
   CtfCqiRptModePeriodic     *periodicRpt = NULLP;
   YsUeSubFrInfo             *ueSubFrInfo;
   Bool                       simultAckNack = FALSE;

   TRC2(ysMsMapPucchDedCtl)

   ueSubFrInfo = &ysUeCb->subFrInfo;

   if (ysUeCb->ueCfg.cqiRptCfg.pres && ysUeCb->ueCfg.cqiRptCfg.reportingMode == \
                  CTF_CQI_RPTMODE_PRDIOC && ueSubFrInfo->cqiPres )
   {
      periodicRpt = &ysUeCb->ueCfg.cqiRptCfg.reportMode.periodicRpt;
      simultAckNack = periodicRpt->cqiSetup.simultaneousAckNack;
   }
   if (ysUeCb->ueCfg.pucchCfg.pres)
   {
      pucchDedCfg =  &ysUeCb->ueCfg.pucchCfg;

      /* Tobe runtime */
      ysMsSetPucchParams(ueSubFrInfo, simultAckNack, pucchDedCtl,ysUeCb,recpSubframeNo);

      /* RepFact E {2,4,6} */ 
      pucchDedCtl->ackNackRepetition     = pucchDedCfg->pucchSetup.repFact?1:0; 
      pucchDedCtl->repetitionFactor      = pucchDedCfg->pucchSetup.repFact;
      /* TODO get from recep req */
      pucchDedCtl->n1PucchANRep          = pucchDedCfg->pucchSetup.n1PUCCHRep;
     pucchDedCtl->msPucchSrSel          = 0;
   }/* if pucch pres */
   if (periodicRpt)
   {
      pucchDedCtl->cqiPUCCHResourceIndex = \
                                     periodicRpt->cqiSetup.cqiPUCCHRsrcIndx;
      pucchDedCtl->dlCqiPmiSizeBits = 4; /* currently for wideband CQI */
   }/* Cqi Pres */
   if (ysUeCb->ueCfg.dedSRCfg.pres && ueSubFrInfo->srPres)
   {
      pucchDedCtl->srPUCCHResourceIndex  = \
                                     ysUeCb->ueCfg.dedSRCfg.dedSrSetup.srPUCCHRi;
   } /* Sr pres */

   RETVOID;
} /* ysMsMapPucchDedCtl */


/*
*       Fun:  ysMsMapPucchDedRb
*  
*       Desc:  Determine PUCCH RB for the UE
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapPucchDedRb
(
YsCellCb         *ysCellCb,
YsUeCb           *ysUeCb,
ULCTRLCHDESC     *ulCtlChDesc
)
{
  
   YsUeSubFrInfo  *ysSubFrInfo;
   U8             c = ysCellCb->cellCfg.txCfg.cycPfx == CTF_CP_NORMAL ? 3:2;
   U32            n1Pucch = 0; 
   U32            n2Pucch = 0;
   Bool           isFormat1 =FALSE;
   U8             nScPerRb = 12;
   U8             n2Rb = ysCellCb->preDefVal.ulSubFrCmnCtrl.nRBCQI;
   U8             n1Cs = ysCellCb->preDefVal.ulSubFrCmnCtrl.nCSAn;
   U8             deltaShiftPucch = ysCellCb->preDefVal.ulSubFrCmnCtrl.deltaPUCCHShift;
   U8             ulBw = ysCellCb->cellInfo.ulBw;
   U8             mVal;

   TRC2(ysMsMapPucchDedRb)

   ysSubFrInfo = &ysUeCb->subFrInfo;

   switch(ysSubFrInfo->pucchFormat)
   {
      case FORMAT1: 
      {
         n1Pucch = ysUeCb->ueCfg.dedSRCfg.dedSrSetup.srPUCCHRi;
       ulCtlChDesc->pucchDedCtl.harqPucchIndex = n1Pucch;
         isFormat1 = TRUE;  
         break;
      }
      case FORMAT1A:
      {
         n1Pucch = ysSubFrInfo->harqReqInfo->t.pucchRecpReq.t.nCce + 
            ysCellCb->preDefVal.ulSubFrCmnCtrl.n1PucchAN;
       ulCtlChDesc->pucchDedCtl.harqPucchIndex = n1Pucch;
       ulCtlChDesc->pucchDedCtl.harqSizebits = 1;
         isFormat1 = TRUE;
         break;
      }
      case FORMAT1B:
      {
         n1Pucch = ysSubFrInfo->harqReqInfo->t.pucchRecpReq.t.nCce + 
            ysCellCb->preDefVal.ulSubFrCmnCtrl.n1PucchAN;
       ulCtlChDesc->pucchDedCtl.harqPucchIndex = n1Pucch;
       ulCtlChDesc->pucchDedCtl.harqSizebits = 2;
         isFormat1 = TRUE;
         break;
      }
      case FORMAT2:
      case FORMAT2A:
      case FORMAT2B:
      { 
         n2Pucch = ysUeCb->ueCfg.cqiRptCfg.reportMode.periodicRpt.cqiSetup.cqiPUCCHRsrcIndx;
         break;   
      }   
   }

   if (isFormat1)
   {
      U8 shift = (c * n1Cs/deltaShiftPucch);
     mVal = n1Pucch < shift ? n2Rb : ((n1Pucch - shift)/(c * nScPerRb/deltaShiftPucch) + n2Rb + (n1Cs + 7)/8);
     ulCtlChDesc->pucchDedCtl.n1PUCCHResourceIndex = n1Pucch;
     if (mVal != 1)
          RLOG2(L_DEBUG,"mVal %u n1pucch %u", mVal, n1Pucch);
   }
   else
   {
       mVal = n2Pucch/nScPerRb;
   }

   if (mVal % 2 == 0)
   {
      ulCtlChDesc->startRes = mVal/2;
   }
   else
   {
      ulCtlChDesc->startRes = ulBw - 1 - (mVal/2);
   }
   
   RETVOID;
} /* ysMsMapPucchDedRb*/

/* 
*
*       Fun:  ysMsMapCqiPmiRpt 
*  
*       Desc:  Map Ue Specific Pucch Control
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapCqiPmiRpt
(
YsUeCb           *ysUeCb,
CQIPMIRIRPT      *cqiPmiRpt
)
{

   TRC2(ysMsMapCqiPmiRpt)

   RETVOID;
} /* ysMsMapCqiPmiRpt */

/* 
*
*       Fun:  ysMsMapCtlChanDesc
*  
*       Desc:  Map Control Channel Descriptor
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapCtlChanDesc
(
YsCellCb         *ysCellCb,
YsUeCb           *ysUeCb,
ULCTRLCHDESC     *ulCtlChDesc,
U8                recpSubfameNo
)
{
   TRC2(ysMsMapCtlChanDesc)

   ulCtlChDesc->txpowerControl         = YS_TX_PWR_CNTRL;
   ulCtlChDesc->crcLength              = YS_PUCCH_CRC_LEN;
   ulCtlChDesc->channelType            = PUCCH;
#ifndef EMTC_ENABLE
#ifndef BATCH_PROCESSING_UL
   ulCtlChDesc->reserved               = PAD;
#endif
#endif
   /* 36.211 Section 5.4 */

   /*Changing it to C-RNTI for UE using ueId, replacing ysCellCb->cellId */
   ulCtlChDesc->scrmblerInitValue      = ysUeCb->ueId;
   ulCtlChDesc->codingDescriptor       = YS_PUCCH_COD_DES;
   ulCtlChDesc->blockCodeConcatenation = YS_PUCCH_BLK_CAT;
   ulCtlChDesc->mcsType                = YS_PUCCH_MCS_TYP;
   /* MS_WORKAROUND: Pass recpSubfameNo to figure out number of harq bits, not needed once using TFU_UPGRADE */
   ysMsMapPucchDedCtl(ysUeCb, &ysCellCb->cellCfg, &ulCtlChDesc->pucchDedCtl,recpSubfameNo);
   ulCtlChDesc->modulationType 
      = ysUeModulation[ysUeCb->subFrInfo.pucchFormat];

   /* The entire structure ulCtlChDesc->cqiPmiRiRpt is unused, so don't
    * care about it */

   ulCtlChDesc->numberofEntries = YS_SINGLE_MAPPING;

   ysMsMapPucchDedRb(ysCellCb, ysUeCb, ulCtlChDesc);
  
   ulCtlChDesc->numRes          = 0;
   cmMemcpy((U8 *)&ulCtlChDesc->timAdvErrInfo, (U8 *)&ysUeCb->timingAdvErrInfo, sizeof(TIMADVERRINF));
   
   RETVOID;
} /*ysMsMapCtlChanDesc*/

/* 
*
*       Fun:  ysMsMapMapInfo
*  
*       Desc:  Map  Rb Start numRb
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapMapInfo
(
TfuUePuschRecpReq *puschRecpReq,
MAPPINGINFO       *mapInfo
)
{

   TRC2(ysMsMapMapInfo)

   mapInfo->numberofEntries = YS_SINGLE_MAPPING;

   mapInfo->reselmInfo[0].startRes = puschRecpReq->rbStart;
   mapInfo->reselmInfo[0].numRes   = puschRecpReq->numRb;
   RASSERT_COREDUMP(puschRecpReq->numRb != 0);

   RETVOID;
} /*ysMsMapMapInfo*/

/* 
*
*       Fun:  ysMsMapMsg3MapInfo
*  
*       Desc:  Map  Rb Start numRb
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapMsg3MapInfo
(
TfuUeMsg3RecpReq  *msg3RecpReq,
MAPPINGINFO       *mapInfo
)
{

   TRC2(ysMsMapMsg3MapInfo)

   mapInfo->numberofEntries = YS_SINGLE_MAPPING;

   mapInfo->reselmInfo[0].startRes = msg3RecpReq->rbStart;
   mapInfo->reselmInfo[0].numRes   = msg3RecpReq->numRb;
   RASSERT_COREDUMP(msg3RecpReq->numRb != 0);

   RETVOID;
} /*ysMsMapMsg3MapInfo*/


/* 
*
*       Fun:  ysMsMapPuschDed
*  
*       Desc:  Map  Ue specific Pusch Details
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapPuschDed
(
YsUeCb           *ysUeCb,
TfuUeRecpReqInfo *recpReqInfo,
PUSCHDED         *puschDed
)
{
   CtfDedPuschCfgInfo     *puschDedCfg;
   U8                     n2DmrsArr[8] = {0,6,3,4,2,8,10,9};
   TRC2(ysMsMapPuschDed)

   puschDedCfg = &ysUeCb->ueCfg.puschCfg;
   puschDed->betaOffsetACKIndex = puschDedCfg->betaOffsetAckIdx;
   puschDed->betaOffsetCQIIndex = puschDedCfg->betaOffsetCqiIdx;
   puschDed->betaOffsetRIIndex  = puschDedCfg->betaOffsetRiIdx;

   switch (recpReqInfo->type)
   {
      case TFU_RECP_REQ_PUSCH:
        puschDed->nDMRS2 = n2DmrsArr[recpReqInfo->t.puschRecpReq.nDmrs];
      break;
      case TFU_RECP_REQ_MSG3:
        puschDed->nDMRS2 = 0;
      break;
   }
   RETVOID;
} /* ysMsMapPuschDed */

/* 
*
*       Fun:  ysMsMapCrcInfo
*  
*       Desc:  Map  Ue specific CRC Info
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapCrcInfo
(
YsUeCb           *ysUeCb,
CRCINFO          *crcInfo
)
{
   TRC2(ysMsMapCrcInfo)

   crcInfo->crcLength         = TWTYFOUR; /*LtePhyApi.h*/
   crcInfo->crcScrambling     = YS_CRC_SCRAMBLING;

   RETVOID;
} /* ysMsMapCrcInfo */


/* 
*
*       Fun:  ysMsMapHarqInfo
*  
*       Desc:  Map  Ue specific Harq Info
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapHarqInfo
(
TfuUePuschRecpReq  *puschRecpReq,
HARQINFO           *harqInfo
)
{
   TRC2(ysMsMapHarqInfo)

   harqInfo->reserved = PAD;
   harqInfo->rV       = puschRecpReq->rv;
   harqInfo->nDi      = puschRecpReq->ndi;
   /*hardcoding to 1 for now due to a bug in PHY*/
   /* HARQ_UL: Removing hard coding of NDI below */
   /* HARQ_UL: NDI = 1 implies transmission while 0 means re-transmission */
   harqInfo->nDi      = !puschRecpReq->isRtx;
   
   harqInfo->flushReq = !puschRecpReq->isRtx;

   RETVOID;
} /* ysMsMapHarqInfo */

/* 
*
*       Fun:  ysMsMapMsg3HarqInfo
*  
*       Desc:  Map  Ue specific Harq Info
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapMsg3HarqInfo
(
TfuUeMsg3RecpReq   *msg3RecpReq,
HARQINFO           *harqInfo
)
{
   TRC2(ysMsMapHarqInfo)

   harqInfo->reserved = PAD;

   /* Invalid */
   harqInfo->rV       = 0;
   harqInfo->nDi      = 1;

   /* Flush Request mapping to Retransmission */
   harqInfo->flushReq = !msg3RecpReq->isRtx;

   RETVOID;
} /* ysMsMapHarqInfo */




/* 
 *
 *       Fun:  ysMsMapSubChInfoMsg3
 *  
 *       Desc:  Map  Ue specific SubChannel Info
 *
 *       Ret:   void 
 *
 *       Notes: None
 *
 *       File:  ys_ms_map.c
 *
 */
PRIVATE void ysMsMapSubChInfoMsg3
(
YsCellCb         *cellCb,
YsSubFrInfo      *ysSubFrInfo,
ULSUBCHINFO      *ulChanDesc,
U8               chIdx
)
{
   TfuUeRecpReqInfo    *recpReqInfo;
   TfuUeMsg3RecpReq    *msg3RecpReq;
   MCINFO              *mcInfo;

   TRC2(ysMsMapSubChInfoMsg3)

   recpReqInfo      = &(ysSubFrInfo->msg3Lst.msg3RecpLst[chIdx]);

   mcInfo           =  &ulChanDesc->mcinfo;
   msg3RecpReq      =  &(recpReqInfo->t.msg3RecpReq);

   cmMemset((U8*)&(ulChanDesc->puschDed), 0, sizeof(PUSCHDED));
   cmMemset((U8*)&(ulChanDesc->cqiPmiRiRpt), 0, sizeof(CQIPMIRIRPT));

   mcInfo->codingDescriptor       = TURBOCDR;
   mcInfo->blockCodeConcatenation = YS_BLK_CODE_CAT;

   mcInfo->modulationType         = ModulationMap[(msg3RecpReq->modType/2) - 1];

   mcInfo->mcsType                = msg3RecpReq->mcs;
   RASSERT_COREDUMP(mcInfo->mcsType < 32);

   ysMsMapMsg3HarqInfo(msg3RecpReq, &ulChanDesc->harqInfo);
   ysMsMapMsg3MapInfo(msg3RecpReq, &(ulChanDesc->mapInfo));


   ulChanDesc->crcInfo.crcLength         = TWTYFOUR; /*LtePhyApi.h*/
   ulChanDesc->crcInfo.crcScrambling     = YS_CRC_SCRAMBLING;

   ulChanDesc->scrInfo.scramblerType     = 0; /*LtePhyApi.h*/
   ulChanDesc->scrInfo.scrinitValueinput = recpReqInfo->rnti;

   ulChanDesc->reserved = PAD;

   //uart_printf("\n ysMsMapMsg3MapInfo sending MSG3 RX Vector (%d) (%d) \n", 
    //     cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);

} /* End of ysMsMapSubChInfoMsg3 */


/* 
 *
 *       Fun:  ysMsMapSubChInfo
 *  
 *       Desc:  Map  Ue specific SubChannel Info
 *
 *       Ret:   void 
 *
 *       Notes: None
 *
 *       File:  ys_ms_map.c
 *
 */
PRIVATE void ysMsMapSubChInfo
(
YsCellCb         *cellCb,
YsUeCb           *ysUeCb,
ULSUBCHINFO      *ulChanDesc
)
{
   TfuUeRecpReqInfo    *recpReqInfo;
   TfuUeMsg3RecpReq    *msg3RecpReq;
   TfuUePuschRecpReq   *puschRecpReq;
   MCINFO              *mcInfo;

   TRC2(ysMsMapSubChInfo)

   recpReqInfo      = ysUeCb->subFrInfo.schReqInfo;

   mcInfo           =  &ulChanDesc->mcinfo;
   puschRecpReq     =  &(recpReqInfo->t.puschRecpReq);
   msg3RecpReq      =  &(recpReqInfo->t.msg3RecpReq);

   cmMemset((U8*)&(ulChanDesc->puschDed), 0, sizeof(PUSCHDED));
   cmMemset((U8*)&(ulChanDesc->cqiPmiRiRpt), 0, sizeof(CQIPMIRIRPT));

   switch (recpReqInfo->type)
   {
      case TFU_RECP_REQ_PUSCH:
         mcInfo->codingDescriptor       = TURBOCDR;
         mcInfo->blockCodeConcatenation = YS_BLK_CODE_CAT;

         mcInfo->modulationType         = ModulationMap[(puschRecpReq->modType/2) - 1];

         mcInfo->mcsType                = puschRecpReq->mcs;
         ysMsMapHarqInfo(&recpReqInfo->t.puschRecpReq, &ulChanDesc->harqInfo);
       if (ulChanDesc->harqInfo.rV)
         {
#if 0  /* Not needed as of now*/
#ifndef HARQ_STATISTICS
            RLOG_ARG4(L_DEBUG,DBG_CRNTI,recpReqInfo->rnti,"UL Re-transmission @ (%d,%d)"
                  "hqPId(%d) rv(%d)",
                  cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
                  recpReqInfo->t.puschRecpReq.harqProcId, 
                  ulChanDesc->harqInfo.rV);
#endif
#endif
         } 
         ysMsMapMapInfo(&(recpReqInfo->t.puschRecpReq), &(ulChanDesc->mapInfo));
      break;
      case TFU_RECP_REQ_MSG3:
         mcInfo->codingDescriptor       = TURBOCDR;
         mcInfo->blockCodeConcatenation = YS_BLK_CODE_CAT;
         mcInfo->modulationType         = msg3RecpReq->modType;
         mcInfo->mcsType                = msg3RecpReq->mcs;
         ysMsMapMsg3HarqInfo(msg3RecpReq, &ulChanDesc->harqInfo);
         ysMsMapMsg3MapInfo(msg3RecpReq, &(ulChanDesc->mapInfo));
      break;
      default:
         RLOG1(L_FATAL, "recpReqInfo->type = %u", recpReqInfo->type);
      break;
   }
   RASSERT_COREDUMP(mcInfo->mcsType < 32);
   ysMsMapCrcInfo(ysUeCb, &ulChanDesc->crcInfo);

   ulChanDesc->scrInfo.scramblerType     = 0; /*LtePhyApi.h*/
   ulChanDesc->scrInfo.scrinitValueinput = recpReqInfo->rnti;

   ulChanDesc->reserved = PAD;

   ysMsMapPuschDed(ysUeCb, recpReqInfo, &ulChanDesc->puschDed);

   if (ysUeCb->subFrInfo.cqiPres)
   {
      ysMsMapCqiPmiRpt(ysUeCb, &ulChanDesc->cqiPmiRiRpt);
   }
} /* End of ysMsMapSubChInfo */

/* 
 *
 *       Fun:  ysMsMapChanDesc
 *  
 *       Desc:  Map  Ue specific Dedicated Channel Descriptor
 *
 *       Ret:   void 
 *
 *       Notes: None
 *
 *       File:  ys_ms_map.c
 *
 */
PRIVATE void ysMsMapChanDesc
(
YsCellCb         *cellCb,
YsUeCb           *ysUeCb,
ULCHANDESC       *ulChanDesc,
U8               numCh
)
{
   TRC2(ysMsMapChanDesc)

   ulChanDesc->txpowerControl  = YS_TX_PWR_CNTRL;

   /* Warning: Hardcoding values */
   ulChanDesc->persistEnable   = 1;
   ulChanDesc->repeatCycle     = 0x01;
   ulChanDesc->channelType     = PUSCH;
   ulChanDesc->halfIterations  = 0x10;
   cmMemcpy((U8 *)&ulChanDesc->timAdvErrInfo, (U8 *)&ysUeCb->timingAdvErrInfo, sizeof(TIMADVERRINF));
   
   ysMsMapSubChInfo(cellCb, ysUeCb, &ulChanDesc->ulSubChInfo);

   RETVOID;
} /*ysMsMapChanDesc*/

/* 
 *
 *       Fun:  ysMsMapChanDescMsg3
 *  
 *       Desc:  Map  Ue specific Dedicated Channel Descriptor
 *
 *       Ret:   void 
 *
 *       Notes: None
 *
 *       File:  ys_ms_map.c
 *
 */
PRIVATE void ysMsMapChanDescMsg3
(
YsCellCb         *cellCb,
YsSubFrInfo      *ysSubFrInfo,
ULCHANDESC       *ulChanDesc,
U8               chIdx
)
{
   TRC2(ysMsMapChanDescMsg3)

   ulChanDesc->txpowerControl  = YS_TX_PWR_CNTRL;

   /* Warning: Hardcoding values */
   ulChanDesc->persistEnable   = 1;
   ulChanDesc->repeatCycle     = 0x01;
   ulChanDesc->channelType     = PUSCH;
   ulChanDesc->halfIterations  = 0x10;
   ulChanDesc->timAdvErrInfo.mSetDefaults = 1;

   ysMsMapSubChInfoMsg3(cellCb, ysSubFrInfo, &ulChanDesc->ulSubChInfo,chIdx);

   RETVOID;
} /*ysMsMapChanDescMsg3*/

/* HARQ_UL: Added timing information for UL HARQ handling */
/* 
 *
 *       Fun:   ysMsMapUlSubFrDesc
 *  
 *       Desc:  Fill UL SubFrame Descriptor
 *
 *       Ret:   void 
 *
 *       Notes: None
 *
 *       File:  ys_ms_map.c
 *
 */
PUBLIC S16 ysMsMapUlSubFrDesc
(
YsCellCb         *cellCb,
YsSubFrInfo      *ysSubFrInfo,
ULSUBFRDESC      *ulSubFrDesc, 
MsgLen           *msgLen, 
CmLteTimingInfo  timingInfo
)
{
   CtfCellCfgInfo              *cellCfg;
   YsUeLst                     *ueLst;
   YsUeCb                      *ueCb;
   U8                           idx;
   U8                          rxSduSf;
   U32                         numPuschCh = 0;
   U32                         numPucchCh = 0;
   U32                         numCh = 0;
   ULCHANDESC                  *ulCh;
   ULCTRLCHDESC                *ulCtlCh;
   SRSDED                      *srsInfo;
   RACHCTRL                    *rachCtrl;
  
   
   TRC2(ysMsMapUlSubFrDesc)

   ueLst                       = &ysSubFrInfo->ueLst;
   cellCfg                     = &cellCb->cellCfg;
   ulSubFrDesc->frameNumber    = timingInfo.sfn;
   ulSubFrDesc->subframeNumber = timingInfo.subframe;
   ulSubFrDesc->subframeType   = ULRX;

   RLOG2(L_INFO,"ysMsMapUlSubFrDesc(): (%d) (%d);", 
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe));

   ulSubFrDesc->antennaPortcount = YS_MS_GET_NUM_TX_ANT(cellCfg->antennaCfg); 

   /* Getting values from stored predefined configuration */
   cmMemcpy((U8*) &ulSubFrDesc->ulSfrCtrl,
            (U8*) &cellCb->preDefVal.ulSubFrCmnCtrl,
            sizeof(ULSUBFRCMNCTRL));
   
   ulCh    = ulSubFrDesc->ulCh;
   ulCtlCh = (ULCTRLCHDESC *)&ulSubFrDesc->ulCh[ysSubFrInfo->msg3Lst.numMsg3 + ueLst->numPusch];
   srsInfo = (SRSDED *)&ulCtlCh[ueLst->numPucch];

   /* HARQ_TODO: Remove hardcoding */
   rxSduSf = (timingInfo.subframe + 2) % YS_NUM_SUB_FRAMES;
    for (idx = 0; idx < ysSubFrInfo->msg3Lst.numMsg3; idx++)
   {
      RLOG1(L_INFO,"Received reception request for Msg3 gotRACH = (%d)", cellCb->gotRACH);
      ysMsMapChanDescMsg3(cellCb, ysSubFrInfo, 
            &ulCh[numPuschCh], idx);
      ysMsMapRntiToChan(cellCb,ysSubFrInfo->msg3Lst.msg3RecpLst[idx].rnti, timingInfo.subframe, numCh);
      ulCh[numPuschCh].channelId       = numCh;
      numPuschCh++;
      numCh++;
      cellCb->isCrcExptd[rxSduSf] = TRUE;
    }

   for (idx=0; idx<ueLst->numPusch; idx++)
   {
      ueCb = ueLst->puschLst[idx];

      /* HARQ_UL: If PUSCH/Msg3 reception request, mark CRC information */
#ifndef TFU_TDD
      ysMsMapChanDesc(cellCb, ueCb, &ulCh[numPuschCh], numPuschCh);
#else
      ysMsMapChanDesc(cellCb, ueCb, &ulCh[numPuschCh], numPuschCh, timingInfo.subframe);
#endif

      if (ueCb->subFrInfo.harqReqInfo || ueCb->subFrInfo.cqiPres)
      {
         ysMsMapUeCtrlOnPusch(cellCb, ueCb, &ulCh[numPuschCh], timingInfo.subframe);
      }
      cellCb->isCrcExptd[rxSduSf] = TRUE;
    
      ysMsMapRntiToChan(cellCb, ueCb->ueId, timingInfo.subframe, numCh);
      ulCh[numPuschCh].channelId = numCh;
      numPuschCh++;
      numCh++;
      
      cmMemcpy((U8*)&ueCb->ueSubFrInfo[cellCb->timingInfo.subframe], 
                           (U8*)&ueCb->subFrInfo, sizeof(YsUeSubFrInfo));
      ysMsResetUeSfInfo(&ueCb->subFrInfo);
   }

   for (idx=0; idx<ueLst->numPucch; idx++)
   {
      ueCb = ueLst->pucchLst[idx];

      /* MS_WORKAROUND: Pass recpSubfameNo to figure out number of harq bits, not needed once using TFU_UPGRADE */
      ysMsMapCtlChanDesc(cellCb, ueCb, &ulCtlCh[numPucchCh], timingInfo.subframe);
      ulCtlCh[numPucchCh].channelId = numCh;
      ysMsMapRntiToChan(cellCb, ueCb->ueId, timingInfo.subframe, numCh);
      numPucchCh++;
      numCh++;

      cmMemcpy((U8*)&ueCb->ueSubFrInfo[cellCb->timingInfo.subframe], 
                           (U8*)&ueCb->subFrInfo, sizeof(YsUeSubFrInfo));
      ysMsResetUeSfInfo(&ueCb->subFrInfo);
   }

   RASSERT_COREDUMP(ysSubFrInfo->numSrs == 0);
   RASSERT_COREDUMP(ueLst->numSrs == 0);
   for (idx=0; idx<ueLst->numSrs; idx++)
   {
      ueCb = ueLst->srsLst[idx];

      ysMsMapSrsDedInfo(ueCb, cellCfg, &srsInfo[ysSubFrInfo->numSrs]);
      ysSubFrInfo->numSrs++;

      cmMemcpy((U8*)&ueCb->ueSubFrInfo[cellCb->timingInfo.subframe], 
                           (U8*)&ueCb->subFrInfo, sizeof(YsUeSubFrInfo));
      ysMsResetUeSfInfo(&ueCb->subFrInfo);
   }

   rachCtrl = (RACHCTRL *)&srsInfo[ysSubFrInfo->numSrs];
   if (rachCtrl->prachEnable)
   {
      RLOG_ARG4(L_ALWAYS, DBG_CELLID, cellCb->cellId, "rachCtrl = %p, rootSequenceIndex = %u, prachConfigIndex = %u highSpeedFlag = %u",
            (void *)rachCtrl, rachCtrl->rootSequenceIndex, rachCtrl->prachConfigIndex, rachCtrl->highSpeedFlag);
      RLOG_ARG3(L_ALWAYS, DBG_CELLID, cellCb->cellId, "zeroCorrelationZoneConfig = %u, prachFreqOffset = %u prachPreambleNumber = %u",
            rachCtrl->zeroCorrelationZoneConfig, rachCtrl->prachFreqOffset, rachCtrl->prachPreambleNumber);
   }

   if ((cellCb->cellId > CM_START_CELL_ID) && ((numPucchCh > 0) || (ysSubFrInfo->numSrs > 0)))
   {
      RLOG_ARG2(L_ALWAYS, DBG_CELLID, cellCb->cellId, "numPucchCh = %u, numSrs = %u", numPucchCh, ysSubFrInfo->numSrs);
   }

   ysSubFrInfo->numCh = numCh;
   ysSubFrInfo->numCtrl = numPucchCh;
   ulSubFrDesc->numberofChannelDescriptors =  ysSubFrInfo->numCh;
   ulSubFrDesc->numberOfCtrlChannelDescriptors  = ysSubFrInfo->numCtrl;
   ulSubFrDesc->numberSrsinSf                   = ysSubFrInfo->numSrs;

#ifdef BIT_64
   ulSubFrDesc->offsetULCtrlChannels            = (U64)ulCtlCh - (U64)ulSubFrDesc;
   ulSubFrDesc->offsetsrsInfo                   = (U64)srsInfo - (U64)ulSubFrDesc;
   ulSubFrDesc->offsetRachCtrlStruct            = (U64)rachCtrl - (U64)ulSubFrDesc;
#else
   ulSubFrDesc->offsetULCtrlChannels            = (U32)ulCtlCh - (U32)ulSubFrDesc;
   ulSubFrDesc->offsetsrsInfo                   = (U32)srsInfo - (U32)ulSubFrDesc;
   ulSubFrDesc->offsetRachCtrlStruct            = (U32)rachCtrl - (U32)ulSubFrDesc;
#endif
   ulSubFrDesc->offsetCustomFeatures            = 0;

   RETVALUE(ROK);
} /* ysMsMapUlSubFrDesc */


/* HARQ_UL: Added timing information for UL HARQ handling */
/* 
*
*       Fun:   ysMsMapRxVector
*  
*       Desc:  Create Rx Vector
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PUBLIC S16 ysMsUtlMapRxVector
(
YsCellCb         *cellCb,
YsSubFrInfo      *subFrInfo,
PULSUBFRDESC     *ulSubFrDesc,
CmLteTimingInfo  timingInfo
)
{
   MsgLen                    len;

   TRC2(ysMsUtlMapRxVector)

   ysMsMapUlSubFrDesc(cellCb, subFrInfo, (ULSUBFRDESC *)ulSubFrDesc, &len, timingInfo);

   RETVALUE(ROK);
} /* ysMsUtlMapRxVector */


/* 
*
*       Fun:   ysMsResetUeSfInfo
*  
*       Desc:  Reset subframe inforamtion per UE
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE S16 ysMsResetUeSfInfo
(
YsUeSubFrInfo      *ueSubFrInfo
)
{
   cmMemset((U8*)ueSubFrInfo, 0, sizeof(*ueSubFrInfo));
   RETVALUE(ROK);
} /* ysMsResetUeSfInfo */

/* 
*
*       Fun:  ysMsMapUeCtrlOnPusch
*  
*       Desc:  Maps control information of the UE on PUSCH
*
*       Ret:  Void
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE Void ysMsMapUeCtrlOnPusch
(
YsCellCb         *ysCellCb,
YsUeCb           *ysUeCb,
PULCHANDESC      pPuschChan,
U8               recpsf
)
{
   TRC2(ysMsMapUeCtrlOnPusch)

   pPuschChan->ulSubChInfo.puschDed.nsymi = 12;
   pPuschChan->ulSubChInfo.puschDed.nrbi = pPuschChan->ulSubChInfo.mapInfo.reselmInfo[0].numRes;
   if (ysUeCb->subFrInfo.harqReqInfo)
   {
      U8 cwCount = ysMsGetAndResetCwCount(ysUeCb, recpsf);
      cwCount = cwCount > 1 ? 2 : 1;
      pPuschChan->ulSubChInfo.puschDed.nACK = cwCount;
   }
   if (ysUeCb->subFrInfo.cqiPres)
   {
      /* pPuschChan->ulSubChInfo.puschDed.betaOffsetCQIIndex already updated */
      pPuschChan->ulSubChInfo.puschDed.nr1CQI = 4; /* '4' for wideband cqi */
   }
   
   RETVOID;
} /*ysMsMapUeCtrlOnPusch*/

#else /* TFU_UPGRADE*/


/* 
*
*       Fun:  ysMsMapUeCtrlOnPusch
*  
*       Desc:  Maps control information of the UE on PUSCH
*
*       Ret:  Void
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE Void ysMsMapUeCtrlOnPusch
(
YsCellCb           *ysCellCb,
YsUeCb             *ysUeCb,
TfuUePuschRecpReq  *puschRecpReq,
PULCHANDESC        pPuschChan,
U8                 recpSf
)
{
   PPUSCHDED pPuschDed = &pPuschChan->ulSubChInfo.puschDed;

   TRC2(ysMsMapUeCtrlOnPusch)   
      
   pPuschDed->nsymi = 12;
   pPuschDed->nrbi = pPuschChan->ulSubChInfo.mapInfo.reselmInfo[0].numRes;
#if (!defined(TFU_TDD) && !defined (BATCH_PROCESSING_UL))
#ifndef CA_PHY
   pPuschDed->reserved = PAD;
#endif 
#endif 
   
   if (puschRecpReq->rcpInfo == TFU_PUSCH_DATA)
   {
      RETVOID;
   }

   /* Handle multiplexed Data and HARQ */
   if (puschRecpReq->rcpInfo == TFU_PUSCH_DATA_HARQ || 
         puschRecpReq->rcpInfo == TFU_PUSCH_DATA_HARQ_SRS ||
         puschRecpReq->rcpInfo == TFU_PUSCH_DATA_CQI_HARQ ||
         puschRecpReq->rcpInfo == TFU_PUSCH_DATA_CQI_HARQ_SRS
         )
   {
      TfuUePuschHqRecpInfo   *hqInfo = &puschRecpReq->hqInfo;
      pPuschDed->nACK = hqInfo->hqSz;      
     pPuschDed->betaOffsetACKIndex = hqInfo->hqBetaOff;   
#ifdef TFU_TDD
#ifdef CA_PHY
     if (hqInfo->hqFdbkMode == TFU_ACK_NACK_CHANNEL_SELECTION)
     {
#ifdef XEON_SPECIFIC_CHANGES
         pPuschDed->tddAckNackFeedbackMode = TFU_ACK_NACK_MULTIPLEXING;//CRAN: New Phy
#else
        pPuschDed->ackNackReportMode = TFU_ACK_NACK_MULTIPLEXING;
#endif
        ysUeCb->harqRecpReqInfo[recpSf].ackNackMode =
                      hqInfo->hqFdbkMode;
        /* Keep UL Dai in UE, Will be used while HARQ Processing*/
        ysUeCb->harqRecpReqInfo[recpSf].ulDai =
                      hqInfo->ulDai;
     }
     else
#endif
     {     
#ifdef XEON_SPECIFIC_CHANGES
        pPuschDed->tddAckNackFeedbackMode = hqInfo->hqFdbkMode;//CRAN: New Phy
#else
        pPuschDed->ackNackReportMode = hqInfo->hqFdbkMode;
#endif
     }
     /*KWORK_FIX*/
     if(ysUeCb)
     {
#ifdef CA_PHY
        if (hqInfo->hqFdbkMode == TFU_ACK_NACK_CHANNEL_SELECTION)
        {
           pPuschDed->Nbundled = 0;
           pPuschDed->nACK = 4;
        }
        else
#endif
        {
           pPuschDed->Nbundled = hqInfo->nBundled;
        }
     }
     else
     {
        pPuschDed->Nbundled = 1;
     }
#endif
   }
   /* Handle multiplexed Data and CQI */
   if (puschRecpReq->rcpInfo == TFU_PUSCH_DATA_CQI ||
         puschRecpReq->rcpInfo == TFU_PUSCH_DATA_CQI_SRS ||
         puschRecpReq->rcpInfo == TFU_PUSCH_DATA_CQI_HARQ ||
         puschRecpReq->rcpInfo == TFU_PUSCH_DATA_CQI_HARQ_SRS
         )           
   {
     U8 cqiPmiSzR1   = 0;
     U8 cqiPmiSzRn1  = 0;
     U8 nRI          = 0;
     U8 idx          = 0;

     TfuUePuschCqiRecpInfo  *cqiRiInfo = &puschRecpReq->cqiRiInfo;
     YsRiInfo *riInfo = &ysUeCb->riInfo[recpSf];   
     for (idx = 0;idx < cqiRiInfo->cCNum ;idx++)
     {
         cqiPmiSzR1 += cqiRiInfo->cqiPmiSzR1[idx];
         cqiPmiSzRn1 += cqiRiInfo->cqiPmiSzRn1[idx];
         if (cqiRiInfo->riSz[idx].pres)
         {
            riInfo->numCell = cqiRiInfo->cCNum;
            nRI += cqiRiInfo->riSz[idx].val;
            riInfo->riSize[idx] = cqiRiInfo->riSz[idx].val;
         }

     }
     /* nawas*/

     pPuschDed->nr1CQI  = cqiPmiSzR1; 
     pPuschDed->nrg1CQI = cqiPmiSzRn1;
     pPuschDed->nRI     = nRI;

     pPuschDed->betaOffsetCQIIndex = cqiRiInfo->cqiBetaOff;
     pPuschDed->betaOffsetRIIndex = cqiRiInfo->riBetaOff;
     pPuschChan->ulSubChInfo.cqiPmiRiRpt.cqiPUCCHResourceIndex = 0;
     pPuschChan->ulSubChInfo.cqiPmiRiRpt.cqiFormatIndicatorPeriodic = 0;
     pPuschChan->ulSubChInfo.cqiPmiRiRpt.cqiReportPeriodicEnable = 1;
     /* TFU_UPGRADE_TODO */
     #if 0
     pPuschChan->ulSubChInfo.ulSubChInfo.cqiPmiRiRpt.cqiReportModeAperiodic = 0;
      pPuschChan->ulSubChInfo.cqiPmiRiRpt.nomPDSCHRSEPREOffset = 0;           
      pPuschChan->ulSubChInfo.cqiPmiRiRpt.cqipmiConfigIndex = 0;
      pPuschChan->ulSubChInfo.cqiPmiRiRpt.K = 0;
      pPuschChan->ulSubChInfo.cqiPmiRiRpt.riConfigIndex = 0;
      pPuschChan->ulSubChInfo.cqiPmiRiRpt.simultaneousAckNackAndCQI = 0;
      pPuschChan->ulSubChInfo.cqiPmiRiRpt.padding = PAD;
     #endif

#ifdef CA_DBG
      {
         //rgStats.gCqiRecpPuschCount++;
      }
#endif
   }
#ifdef PHY_3828
      /* API change for 3.8.2.8 */
     /* cqiOnlyFlag = TRUE if PUSCH is scheduled only for CQI on PUSCH
      * else FALSE
      * TODO:: As of now MAC doesnt support only CQI on PUSCH.
      * THis needs to be enhance once this feature is available */
#ifndef XEON_SPECIFIC_CHANGES
     pPuschChan->ulSubChInfo.cqiOnlyFlag = 0;
#endif
#endif
     /* Nawas:: Resetting hopping enabled flag
      * This needs to be removed and taken from
      * TFU interface once the hopping support
      * is added*/
     pPuschDed->puschHoppingEn= 0;
   
   RETVOID;
} /*ysMsMapUeCtrlOnPusch*/

/* 
 *
 *       Fun:  ysMsMapSubChInfo
 *  
 *       Desc:  Map  Ue specific SubChannel Info
 *
 *       Ret:   void 
 *
 *       Notes: None
 *
 *       File:  ys_ms_map.c
 *
 */
PRIVATE void ysMsMapSubChInfo
(
YsCellCb             *cellCb,
YsUeCb               *ysUeCb,
TfuUePuschRecpReq    *puschRecpReq,
ULSUBCHINFO          *ulChanDesc
)
{
   U8                     n2DmrsArr[8] = {0,6,3,4,2,8,10,9};
   S8                     indx = 0;


   TRC2(ysMsMapSubChInfo)

   cmMemset((U8*)&(ulChanDesc->puschDed), 0, sizeof(PUSCHDED));
   cmMemset((U8*)&(ulChanDesc->cqiPmiRiRpt), 0, sizeof(CQIPMIRIRPT));

   ulChanDesc->mcinfo.codingDescriptor       = TURBOCDR;
   ulChanDesc->mcinfo.blockCodeConcatenation = YS_BLK_CODE_CAT;
   indx = (puschRecpReq->ulSchInfo.modType/2) - 1;  
   if(indx > 0) 
   {
      ulChanDesc->mcinfo.modulationType = ModulationMap[(U8)indx];  /*KW_FIXX*/ 
   }
   else
   {
      ulChanDesc->mcinfo.modulationType = ModulationMap[0];  /*KW_FIXX*/ 
   }

   ulChanDesc->mcinfo.mcsType = puschRecpReq->ulSchInfo.mcs;
   RASSERT_COREDUMP(ulChanDesc->mcinfo.mcsType < 32);

#ifndef PHY_3828
   ulChanDesc->harqInfo.reserved = PAD;
#endif
   ulChanDesc->harqInfo.rV       = puschRecpReq->ulSchInfo.rv;
   if (ulChanDesc->harqInfo.rV)
   {
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
      RLOG_ARG4(L_DEBUG,DBG_CRNTI,ysUeCb->ueId,"UL Re-transmission @ (%d,%d)"
            "hqPId(%d) rv(%d)",
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
            puschRecpReq->ulSchInfo.harqProcId, 
            ulChanDesc->harqInfo.rV);
#endif
   } 

   /* NDI = 1 implies transmission while 0 means re-transmission */
   ulChanDesc->harqInfo.nDi      = !puschRecpReq->ulSchInfo.isRtx;
   ulChanDesc->harqInfo.flushReq = !puschRecpReq->ulSchInfo.isRtx;

   ulChanDesc->crcInfo.crcLength         = TWTYFOUR; /*LtePhyApi.h*/
   ulChanDesc->crcInfo.crcScrambling     = YS_CRC_SCRAMBLING;

   ulChanDesc->scrInfo.scramblerType     = 0; /*LtePhyApi.h*/
#if (!defined(PHY_3828) && defined(TFU_TDD))
   ulChanDesc->reserved = PAD;
#endif

   ulChanDesc->puschDed.nDMRS2 = n2DmrsArr[puschRecpReq->ulSchInfo.nDmrs];


/* TFU_UPGRADE_TODO:
   ulChanDesc->cqiPmiRiRpt.cqiReportModeAperiodic = 0;
   ulChanDesc->cqiPmiRiRpt.nomPDSCHRSEPREOffset = 0;
   ulChanDesc->cqiPmiRiRpt.cqiReportPeriodicEnable = 0;
   ulChanDesc->cqiPmiRiRpt.cqiPUCCHResourceIndex = 0;
   ulChanDesc->cqiPmiRiRpt.cqipmiConfigIndex = 0;
   ulChanDesc->cqiPmiRiRpt.cqiFormatIndicatorPeriodic = 0;
   ulChanDesc->cqiPmiRiRpt.K = 0;
   ulChanDesc->cqiPmiRiRpt.riConfigIndex = 0;
   ulChanDesc->cqiPmiRiRpt.simultaneousAckNackAndCQI = 0;
   ulChanDesc->cqiPmiRiRpt.padding = PAD;
   */

   ulChanDesc->mapInfo.numberofEntries = YS_SINGLE_MAPPING;
   ulChanDesc->mapInfo.reselmInfo[0].startRes = puschRecpReq->ulSchInfo.rbStart;
   ulChanDesc->mapInfo.reselmInfo[0].numRes   = puschRecpReq->ulSchInfo.numRb;
   RASSERT_COREDUMP(puschRecpReq->ulSchInfo.numRb != 0);

} /* End of ysMsMapSubChInfo */


/* 
 *
 *       Fun:  ysMsMapChanDesc
 *  
 *       Desc:  Map  Ue specific Dedicated Channel Descriptor
 *
 *       Ret:   void 
 *
 *       Notes: None
 *
 *       File:  ys_ms_map.c
 *
 */
#ifndef TFU_TDD
PRIVATE void ysMsMapChanDesc
(
YsCellCb             *cellCb,
YsUeCb               *ysUeCb,
TfuUePuschRecpReq    *puschRecpReq,  /*!< Reception request for PUSCH */
ULCHANDESC           *ulChanDesc,
U8                   subframe,
Bool                 isEmtcEnable
)
#else
PRIVATE void ysMsMapChanDesc
(
YsCellCb             *cellCb,
YsUeCb               *ysUeCb,
CmLteRnti             rnti,
TfuUePuschRecpReq    *puschRecpReq,  /*!< Reception request for PUSCH */
ULCHANDESC           *ulChanDesc,
U8                   subframe,
Bool                 isEmtcEnable
)
#endif
{
   TRC2(ysMsMapChanDesc)

   ulChanDesc->txpowerControl  = YS_TX_PWR_CNTRL;

   /* Warning: Hardcoding values */
   ulChanDesc->persistEnable   = 1;
   ulChanDesc->repeatCycle     = 0x01;
   ulChanDesc->channelType     = PUSCH;
   ulChanDesc->halfIterations  = 0x10;

#ifdef CA_PHY
#if 0//ndef TFU_TDD
   /* Nawas:: This hardcoding needs to be
    * removed while adding support for 
    * UL mimo..UL Crc errors was happening
    * if it is not reset*/
   ulChanDesc->ulRelease10     = 0; /* UL MIMO*/
#endif
#endif

   /* TFU_UPGRADE_TODO */
   if (!ysUeCb)
   {
      ulChanDesc->timAdvErrInfo.mSetDefaults = 1;
   }
   else
   {
      cmMemcpy((U8 *)&ulChanDesc->timAdvErrInfo, (U8 *)&ysUeCb->timingAdvErrInfo, sizeof(TIMADVERRINF));
#ifdef PHY_3829
      ulChanDesc->timAdvErrInfo.mSetDefaults = 1;
#endif
   }
#ifdef EMTC_ENABLE
   if(TRUE == isEmtcEnable)
   {
      ulChanDesc->ulCatmEn = isEmtcEnable;
#if 0
      ulChanDesc->ulSubChCatmInfo.repetitionNumber = 
         puschRecpReq->ulSchInfo.repetitionNumber;
#else
      ulChanDesc->ulSubChCatmInfo.puschCEmode = 0;/* Only CE Mode A is supported.Need 
                                                     to enhance this when cemodeb supports is 
                                                     added */
      ulChanDesc->ulSubChCatmInfo.puschRepetitionIndex = 0;/* change this during pusch rep user story*/
      ulChanDesc->ulSubChCatmInfo.puschRftuningSymbols = 0;/* Not reqd during attach..need to fill it from mac */
      ulChanDesc->ulSubChCatmInfo.puschMaxNumRepetitions = 0;
      ulChanDesc->ulSubChCatmInfo.puschrepSetSelection = 0;
      ulChanDesc->ulSubChCatmInfo.harqProcessNumber   = puschRecpReq->ulSchInfo.harqProcId;


#endif
      ulChanDesc->ulSubChCatmInfo.scramblerInitValue = 
         puschRecpReq->ulSchInfo.scramblerInitValue;
   }
#endif /*END of EMTC_ENABLE*/
   ysMsMapSubChInfo(cellCb, ysUeCb, puschRecpReq, &ulChanDesc->ulSubChInfo);
   ysMsMapUeCtrlOnPusch(cellCb, ysUeCb, puschRecpReq, ulChanDesc, subframe);
   RETVOID;
} /*ysMsMapChanDesc*/

#ifdef CA_PHY
#ifndef TFU_TDD 
/* 
*
*       Fun:  ysMsMapHarqAckNackMode
*  
*       Desc:  Map Ue Specific Pucch HarqAckNackMode
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/

PRIVATE U32 ysMsMapHarqAckNackMode
(
TfuAckNackMode        hqFdbkMode
)
{
   TRC2(ysMsMapHarqAckNackMode)
#ifdef LTE_TDD
      U32 harqAckFeedbackMethod;
      /* For FDD the values are interpreted as 
       * 0 Format 1a/1b 
       * 1 Don.t Care 
       * 2 F1b with Channel Selection 
       * 3 Format 3 
       */
      switch(hqFdbkMode)
      {
         case TFU_UCI_FORMAT_1A_1B:
            {
               harqAckFeedbackMethod = FORMAT_1A_1B;
            }
            break;
         case TFU_UCI_FORMAT_1B_CS:
            {
               harqAckFeedbackMethod = CHANNEL_SELECTION;
            }
            break;
         case TFU_UCI_FORMAT_3:
            {
               harqAckFeedbackMethod = UCI_FORMAT_3;
            }
            break;
         default:
            {
               harqAckFeedbackMethod = DONT_CARE;
            }
      }
   RETVALUE(harqAckFeedbackMethod);
#else
   RETVALUE(0);
#endif
}
#endif
#endif

/* 
*
*       Fun:  ysMsMapPucchDedCtl
*  
*       Desc:  Map Ue Specific Pucch Control
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/

PRIVATE void ysMsMapPucchDedCtl
(
YsUeCb               *ueCb,
TfuUePucchRecpReq    *pucchRecpReq,  /*!< Reception request for PUCCH */
PUCCHDEDCTL          *pucchDedCtl,
CmLteTimingInfo       timingInfo
)
{
#ifdef TFU_TDD
   U8    pucchMVal = YsTddPucchMTable[ueCb->cellCb->ulDlCfgIdx][timingInfo.subframe];
#endif
   TRC2(ysMsMapPucchDedCtl)

      pucchDedCtl->simSRHarq = 0;

   switch (pucchRecpReq->uciInfo)
   {
      case TFU_PUCCH_HARQ:
         {
            pucchDedCtl->formatType = FORMAT1A;
            if (pucchRecpReq->hqInfo.hqSz >= 2)
            {
               pucchDedCtl->formatType = FORMAT1B;
            }
         }
         break;
      case TFU_PUCCH_SR:
         {
            pucchDedCtl->formatType = FORMAT1;
         }
         break;
      case TFU_PUCCH_SRS:
         {
            pucchDedCtl->formatType = FORMAT1;
         }
         break;
      case TFU_PUCCH_CQI:
         {
            pucchDedCtl->formatType = FORMAT2;
         }
         break;
      case  TFU_PUCCH_HARQ_SR:
         {
#ifndef TFU_TDD
            pucchDedCtl->formatType = FORMAT1A;
            if (pucchRecpReq->hqInfo.hqSz >= 2)
            {
               pucchDedCtl->formatType = FORMAT1B;
            }
#else
            pucchDedCtl->formatType = FORMAT1B;
#endif
            pucchDedCtl->simSRHarq = 1;
         }
         break;
      case TFU_PUCCH_HARQ_SRS:
         {
            pucchDedCtl->formatType = FORMAT1A;
            if (pucchRecpReq->hqInfo.hqSz >= 2)
            {
               pucchDedCtl->formatType = FORMAT1B;
            }
         }
         break;
      case TFU_PUCCH_HARQ_CQI:
         {
#ifndef TFU_TDD
            pucchDedCtl->formatType = FORMAT2A;
            if (pucchRecpReq->hqInfo.hqSz >= 2)
            {
               pucchDedCtl->formatType = FORMAT2B;
            }
#else
            pucchDedCtl->formatType = FORMAT2B;
#endif
         }
         break;
      case TFU_PUCCH_HARQ_SR_SRS:
         {
#ifndef TFU_TDD
            pucchDedCtl->formatType = FORMAT1A;
            if (pucchRecpReq->hqInfo.hqSz >= 2)
            {
               pucchDedCtl->formatType = FORMAT1B;
            }
#else
            pucchDedCtl->formatType = FORMAT1B;
#endif
            pucchDedCtl->simSRHarq = 1;
         }
         break;
      case TFU_PUCCH_HARQ_SR_CQI:
         {
#ifndef TFU_TDD
            pucchDedCtl->formatType = FORMAT2A;
            if (pucchRecpReq->hqInfo.hqSz >= 2)
               pucchDedCtl->formatType = FORMAT2B;
#else
            pucchDedCtl->formatType = FORMAT2B;
#endif
            pucchDedCtl->simSRHarq = 1;
         }
         break;
      case TFU_PUCCH_SR_SRS:
         {
            pucchDedCtl->formatType = FORMAT1;
         }
         break;
      case TFU_PUCCH_SR_CQI:
         {
            pucchDedCtl->formatType = FORMAT2;
            pucchDedCtl->simSRHarq = 1;
         }
         break;
      case TFU_PUCCH_HARQ_SR_CQI_SRS:
         {
#ifndef TFU_TDD
            pucchDedCtl->formatType = FORMAT2A;
            if (pucchRecpReq->hqInfo.hqSz >= 2)
            {
               pucchDedCtl->formatType = FORMAT2B;
            }
#else
            pucchDedCtl->formatType = FORMAT2B;
#endif
            pucchDedCtl->simSRHarq = 1;
         }
         break;
      case TFU_PUCCH_SR_CQI_SRS:
         {
            pucchDedCtl->formatType = FORMAT2;
            pucchDedCtl->simSRHarq = 1;
         }
   }/* end of Switch */

   /* Check if HArqAckNackMode is FORMAT 3 then update FormatType */
#ifndef TFU_TDD 
#ifdef CA_PHY
   if((pucchDedCtl->formatType == FORMAT1B) &&
         (UCI_FORMAT_3 == ysMsMapHarqAckNackMode(pucchRecpReq->hqInfo.hqFdbkMode)) )
   {
      pucchDedCtl->formatType = UCI_FORMAT_3;/*TODO Fill from LTEPHY API when Intel provide supp*/;
   }
#endif
#endif

#ifdef CA_DBG
   {
      if(pucchDedCtl->formatType > FORMAT1B)
      {
         //rgStats.gCqiRecpCount++;
      }
   
   }

#endif
#ifdef TFU_ALLOC_EVENT_NO_INIT
   /* initialize */
   pucchDedCtl->srPUCCHResourceIndex = 0;
   pucchDedCtl->cqiPUCCHResourceIndex = 0;
   pucchDedCtl->dlCqiPmiSizeBits = 0;
#ifndef CA_PHY
#ifndef TFU_TDD
   pucchDedCtl->harqPucchIndex = 0;
   pucchDedCtl->harqSizebits = 0;
   pucchDedCtl->n1PUCCHResourceIndex = 0;
#endif
#else
#ifndef CA_PHY
   pucchDedCtl->ackNackReportMode = 0;
#endif
   /*TDD_TODO: check for fdbkMode required
 *  *      For bundling cross check in MAC whteh M is populated crrectly*/
   pucchDedCtl->subframeMultiplexNum = 0;
   pucchDedCtl->ackPUCCHResourceIndex0 = 0;
   pucchDedCtl->ackPUCCHResourceIndex1 = 0;
   pucchDedCtl->ackPUCCHResourceIndex2 = 0;
   pucchDedCtl->ackPUCCHResourceIndex3 = 0;
   //Added the number of control bit and initial symbol according to MSPD's API update for TDD 2012-08-08
   pucchDedCtl->harqSizebits = 0;
#endif
   
   if (pucchRecpReq->uciInfo == TFU_PUCCH_HARQ ||
         pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR ||
         pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SRS ||
         pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_CQI ||
         pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR_SRS ||
         pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR_CQI ||
         pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR_CQI_SRS)
   {
#ifndef TFU_TDD
#ifdef CA_PHY
      /*For bundling cross check in MAC whteh M is populated crrectly*/
      pucchDedCtl->ackPUCCHResourceIndex0 = pucchRecpReq->hqInfo.hqRes[0];
      pucchDedCtl->ackPUCCHResourceIndex1 = pucchRecpReq->hqInfo.hqRes[1];
      pucchDedCtl->ackPUCCHResourceIndex2 = pucchRecpReq->hqInfo.hqRes[2];
      pucchDedCtl->ackPUCCHResourceIndex3 = pucchRecpReq->hqInfo.hqRes[3];
      pucchDedCtl->harqSizebits = pucchRecpReq->hqInfo.hqSz;
      pucchDedCtl->harqAckFeedbackMethod = ysMsMapHarqAckNackMode(pucchRecpReq->hqInfo.hqFdbkMode);
      /* * Number of configured serving cells 
       * 0 corresponds to one  
       * 1 corresponds to two or more
       */ 
      if(ueCb->noOfCfgSCells <= 0)
      {
         pucchDedCtl->numConfiguredServingCells = 0; 
      }
      else
      {
         pucchDedCtl->numConfiguredServingCells = 1; 
      }
      pucchDedCtl->cqiPucchResourceIndexP1 = 0;
      pucchDedCtl->srPucchResourceIndexP1 = 0;
      /*Avalue of 1 indicates that the UE uses two antenna ports */
      pucchDedCtl->numCqiPucchResources = 0;
      /*Avalue of 1 indicates that the UE uses two antenna ports */
      pucchDedCtl->numSrPucchResources = 0;
      /* MAC sends 1 to 4 mapped to 0 to 3 for PHY */
      if( pucchRecpReq->hqInfo.pucchResCnt > 0)
      {
         pucchDedCtl->numPucchResourcesHarq = pucchRecpReq->hqInfo.pucchResCnt - 1;
      }
      /* 0 Only 1 Antenna is used 
       * 1 Two Antenna Ports are used for Format1a1b. It also applies to 
       * f1af1b transmission when format 3 is configured 
       */
      pucchDedCtl->twoAntPortActPucchF1aF1b = 0;
      /*0 No simultaneous Pucch and * Pusch is allowed 
       * 1 Simultaneous Pucch and * Pusch is enabled 
       */
      pucchDedCtl->simultaneousPucchPusch = 0;
      /*used in Tdd Case so Fill Dummy*/
      pucchDedCtl->subframeMultiplexNum = 0;
#else
      pucchDedCtl->harqPucchIndex = pucchRecpReq->hqInfo.hqRes[0];
      pucchDedCtl->harqSizebits = pucchRecpReq->hqInfo.hqSz;
      pucchDedCtl->n1PUCCHResourceIndex = 0;

#endif /*CA_PHY*/
#else /*TFU_TDD*/

#ifdef CA_PHY
#if 0
#else
      pucchDedCtl->ackPUCCHResourceIndex0 = ((pucchRecpReq->hqInfo.hqRes[0] == 0) ? 0xfff:pucchRecpReq->hqInfo.hqRes[0]);
      pucchDedCtl->ackPUCCHResourceIndex1 = ((pucchRecpReq->hqInfo.hqRes[1] == 0) ? 0xfff:pucchRecpReq->hqInfo.hqRes[1]);
      pucchDedCtl->ackPUCCHResourceIndex2 = pucchRecpReq->hqInfo.hqRes[2];
      pucchDedCtl->ackPUCCHResourceIndex3 = pucchRecpReq->hqInfo.hqRes[3];
#endif
      pucchDedCtl->numPucchResourcesHarq  = pucchRecpReq->hqInfo.pucchResCnt;
#else
      pucchDedCtl->ackPUCCHResourceIndex0 = pucchRecpReq->hqInfo.hqRes[0];
      pucchDedCtl->ackPUCCHResourceIndex1 = pucchRecpReq->hqInfo.hqRes[1];
      pucchDedCtl->ackPUCCHResourceIndex2 = pucchRecpReq->hqInfo.hqRes[2];
      pucchDedCtl->ackPUCCHResourceIndex3 = pucchRecpReq->hqInfo.hqRes[3];
#endif
      pucchDedCtl->subframeMultiplexNum = pucchMVal;
      pucchDedCtl->ackNackReportMode = pucchRecpReq->hqInfo.hqFdbkMode;
      if (pucchDedCtl->ackNackReportMode == TFU_ACK_NACK_CHANNEL_SELECTION)
      {
         pucchDedCtl->harqSizebits = 2;
      }
      else
      {
         pucchDedCtl->harqSizebits = pucchRecpReq->hqInfo.hqSz; 
      }
#endif      
   }
   if (pucchRecpReq->uciInfo == TFU_PUCCH_SR ||
       pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR ||
       pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR_SRS ||
       pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR_CQI ||
       pucchRecpReq->uciInfo == TFU_PUCCH_SR_SRS ||
       pucchRecpReq->uciInfo == TFU_PUCCH_SR_CQI ||
       pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR_CQI_SRS ||
       pucchRecpReq->uciInfo == TFU_PUCCH_SR_CQI_SRS)
   {
         pucchDedCtl->srPUCCHResourceIndex = pucchRecpReq->srInfo.n1PucchIdx;
   }
   if (pucchRecpReq->uciInfo == TFU_PUCCH_CQI ||
       pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_CQI ||
       pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR_CQI ||
       pucchRecpReq->uciInfo == TFU_PUCCH_SR_CQI ||
       pucchRecpReq->uciInfo == TFU_PUCCH_HARQ_SR_CQI_SRS ||
       pucchRecpReq->uciInfo == TFU_PUCCH_SR_CQI_SRS)
   {
      pucchDedCtl->cqiPUCCHResourceIndex = pucchRecpReq->cqiInfo.n2PucchIdx;
      pucchDedCtl->dlCqiPmiSizeBits = pucchRecpReq->cqiInfo.cqiPmiSz;
   }   
#else /* TFU_ALLOC_EVENT_NO_INIT */
   pucchDedCtl->srPUCCHResourceIndex = pucchRecpReq->srInfo.n1PucchIdx;
   pucchDedCtl->cqiPUCCHResourceIndex = pucchRecpReq->cqiInfo.n2PucchIdx;
   pucchDedCtl->dlCqiPmiSizeBits = pucchRecpReq->cqiInfo.cqiPmiSz;
#ifndef TFU_TDD
#if 0//def LTE_ADV
#if 0
#else
   pucchDedCtl->ackPUCCHResourceIndex0 = ((pucchRecpReq->hqInfo.hqRes[0] != 0xFFFF) ? pucchRecpReq->hqInfo.hqRes[0]:0x7ff);
   pucchDedCtl->ackPUCCHResourceIndex1 = ((pucchRecpReq->hqInfo.hqRes[1] != 0xFFFF) ? pucchRecpReq->hqInfo.hqRes[1]:0x7ff);
   pucchDedCtl->ackPUCCHResourceIndex2 = ((pucchRecpReq->hqInfo.hqRes[2] != 0xFFFF) ? pucchRecpReq->hqInfo.hqRes[2]:0x7ff);
   pucchDedCtl->ackPUCCHResourceIndex3 = ((pucchRecpReq->hqInfo.hqRes[3] != 0xFFFF) ? pucchRecpReq->hqInfo.hqRes[3]:0x7ff);
#endif

   pucchDedCtl->harqSizebits = pucchRecpReq->hqInfo.hqSz;
   pucchDedCtl->harqAckFeedbackMethod = ysMsMapHarqAckNackMode(pucchRecpReq->hqInfo.hqFdbkMode);
   /* * Number of configured serving cells 
    * 0 corresponds to one  
    * 1 corresponds to two or more
    */ 
   if(ueCb->noOfCfgSCells <= 0)
   {
      pucchDedCtl->numConfiguredServingCells = 0; 
   }
   else
   {
      pucchDedCtl->numConfiguredServingCells = 1; 
   }
   /*Avalue of 1 indicates that the UE uses two antenna ports */
   pucchDedCtl->numCqiPucchResources = 0;
   /*Avalue of 1 indicates that the UE uses two antenna ports */
   pucchDedCtl->numSrPucchResources = 0;
   pucchDedCtl->cqiPucchResourceIndexP1 = 0;
   /* MAC sends 1 to 4 mapped to 0 to 3 for PHY */
   if( pucchRecpReq->hqInfo.pucchResCnt > 0)
   {
      pucchDedCtl->numPucchResourcesHarq = pucchRecpReq->hqInfo.pucchResCnt - 1;
   }
   pucchDedCtl->srPucchResourceIndexP1 = 0;
   /* 0 Only 1 Antenna is used 
    * 1 Two Antenna Ports are used for Format1a1b. It also applies to 
    * f1af1b transmission when format 3 is configured 
    */
   pucchDedCtl->twoAntPortActPucchF1aF1b = 0;
   /*0 No simultaneous Pucch and * Pusch is allowed 
    * 1 Simultaneous Pucch and * Pusch is enabled 
    */
   pucchDedCtl->simultaneousPucchPusch = 0;
   /*used in TDD case to fill Dummy Value */
   pucchDedCtl->subframeMultiplexNum = 0;
//#else
   pucchDedCtl->harqSizebits = pucchRecpReq->hqInfo.hqSz;
#ifdef PHY_3_8_3
   pucchDedCtl->ackPUCCHResourceIndex0 = pucchRecpReq->hqInfo.hqRes[0];
#else
   pucchDedCtl->n1PUCCHResourceIndex = 0;
   pucchDedCtl->harqPucchIndex = pucchRecpReq->hqInfo.hqRes[0];
#endif /*PHY_3_8_3*/ 
#endif /*CA_PHY*/     
#else /* TFU_TDD */ 
#ifdef CA_PHY
   pucchDedCtl->ackPUCCHResourceIndex0 = ((pucchRecpReq->hqInfo.hqRes[0] != 0xFFFF) ? pucchRecpReq->hqInfo.hqRes[0]:0xfff);
   pucchDedCtl->ackPUCCHResourceIndex1 = ((pucchRecpReq->hqInfo.hqRes[1] != 0xFFFF) ? pucchRecpReq->hqInfo.hqRes[1]:0xfff);
   pucchDedCtl->ackPUCCHResourceIndex2 = ((pucchRecpReq->hqInfo.hqRes[2] != 0xFFFF) ? pucchRecpReq->hqInfo.hqRes[2]:0xfff);
   pucchDedCtl->ackPUCCHResourceIndex3 = ((pucchRecpReq->hqInfo.hqRes[3] != 0xFFFF) ? pucchRecpReq->hqInfo.hqRes[3]:0xfff);
#ifndef XEON_SPECIFIC_CHANGES
   pucchDedCtl->numPucchResourcesHarq  = pucchRecpReq->hqInfo.pucchResCnt;
#endif
#else
   pucchDedCtl->ackPUCCHResourceIndex0 = pucchRecpReq->hqInfo.hqRes[0];
   pucchDedCtl->ackPUCCHResourceIndex1 = pucchRecpReq->hqInfo.hqRes[1];
   pucchDedCtl->ackPUCCHResourceIndex2 = pucchRecpReq->hqInfo.hqRes[2];
   pucchDedCtl->ackPUCCHResourceIndex3 = pucchRecpReq->hqInfo.hqRes[3];
#endif
   pucchDedCtl->subframeMultiplexNum = pucchMVal;
#ifdef XEON_SPECIFIC_CHANGES
   pucchDedCtl->harqAckFeedbackMethod = pucchRecpReq->hqInfo.hqFdbkMode;//CRAN: New Phy
#else
   pucchDedCtl->ackNackReportMode = pucchRecpReq->hqInfo.hqFdbkMode;
#endif
#ifdef XEON_SPECIFIC_CHANGES
   if (pucchDedCtl->harqAckFeedbackMethod == TFU_ACK_NACK_CHANNEL_SELECTION)//CRAN: New Phy
#else
   if (pucchDedCtl->ackNackReportMode == TFU_ACK_NACK_CHANNEL_SELECTION)
#endif
   {
      /* TDD CA FIX: Harq size should be 4 for 1B with Channel selection */
      pucchDedCtl->harqSizebits = 4;
   }
   else
   {
      pucchDedCtl->harqSizebits = pucchRecpReq->hqInfo.hqSz; 
   }
#endif /* TFU_TDD */
#endif /* TFU_ALLOC_EVENT_NO_INIT */ 
   pucchDedCtl->ackNackRepetition = 0;
   pucchDedCtl->repetitionFactor = 0;
   pucchDedCtl->msPucchSrSel = 0;
   pucchDedCtl->n1PucchANRep = 0;

#ifdef CA_PHY
   ueCb->harqRecpReqInfo[timingInfo.subframe].ackNackMode =  pucchRecpReq->hqInfo.hqFdbkMode;
#ifdef LTE_TDD
   ueCb->harqRecpReqInfo[timingInfo.subframe].a =  pucchRecpReq->hqInfo.a;

#endif
#endif
   RETVOID;
} /* ysMsMapPucchDedCtl */


#ifdef EMTC_ENABLE
/*
*       Fun:  ysMsCalcEmtcPucchRes
*  
*       Desc:  Determine PUCCH RB for the EMTC UE
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void  ysMsCalcEmtcPucchRes
(
YsCellCb         *cellCb,
U8               subframe, 
U8               mVal,
Bool             isFormat1,
ULCTRLCHDESC     *ulCtlChDesc
)
{
   U8 nNbUlCh = 1;/* This value shud be interval-UlHoppingConfigCommonModeA in sib2.
                  This needs to be passed in CTF.Revisit*/
   U8 jVal    = subframe/nNbUlCh;
   U8 mDashJVal = 0;

   /* this function is as per 5.4.3 of 36.211 version 13 for BL /CE ues */
   if((jVal % 2) == 0)
   {
      mDashJVal = mVal;
   }else
   {/* jmod2 == 1 case */
      if((mVal % 2 == 0))
      {
         mDashJVal = mVal + 1;
      }else
      {
         mDashJVal = mVal - 1;
      }
   }

   if((mDashJVal % 2 ) == 0)
   {
      ulCtlChDesc->startRes = mDashJVal/2 ;
   }else
   {
      ulCtlChDesc->startRes = cellCb->cellInfo.ulBw - 1 - (mDashJVal/2) ;
   }

   if(isFormat1)
   {/* Filling SR */
      ulCtlChDesc->startResSr = ulCtlChDesc->startRes; /* need to understand the diff
                                                          and fill properly if startRes 
                                                          and startSrRes are different */
   }

   RETVOID;

}
#endif


/*
*       Fun:  ysMsMapPucchDedRb
*  
*       Desc:  Determine PUCCH RB for the UE
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
#ifndef EMTC_ENABLE
PRIVATE void ysMsMapPucchDedRb
(
YsCellCb         *ysCellCb,
YsUeCb           *ysUeCb,
ULCTRLCHDESC     *ulCtlChDesc
)
#else
PRIVATE void ysMsMapPucchDedRb
(
YsCellCb         *ysCellCb,
YsUeCb           *ysUeCb,
ULCTRLCHDESC     *ulCtlChDesc,
CmLteTimingInfo  timingInfo
)
#endif
{

   PUCCHDEDCTL    *pucchDedCtl;
   U8             c = ysCellCb->cellCfg.txCfg.cycPfx ? 3:2;
   U32            n1Pucch = 0;
   U32            n2Pucch = 0;
   Bool           isFormat1 =FALSE;
   U8             nScPerRb = 12;
   U8             n2Rb = ysCellCb->preDefVal.ulSubFrCmnCtrl.nRBCQI;
   U8             n1Cs = ysCellCb->preDefVal.ulSubFrCmnCtrl.nCSAn;
   U8             deltaShiftPucch = ysCellCb->preDefVal.ulSubFrCmnCtrl.deltaPUCCHShift;
   U8             ulBw = ysCellCb->cellInfo.ulBw;
   U8             mVal;

   TRC2(ysMsMapPucchDedRb)

   pucchDedCtl = &ulCtlChDesc->pucchDedCtl;

   switch(pucchDedCtl->formatType)
   {
      case FORMAT1: 
      {
         n1Pucch = pucchDedCtl->srPUCCHResourceIndex;
#if (!defined(TFU_TDD) || defined(XEON_SPECIFIC_CHANGES))
#if (defined(PHY_3_8_3) || defined(CA_PHY))
         pucchDedCtl->ackPUCCHResourceIndex0 = n1Pucch;
#else
         pucchDedCtl->harqPucchIndex = n1Pucch;
#endif		 
#endif
         isFormat1 = TRUE;  
         break;
      }
      case FORMAT1A:
      case FORMAT1B:
      {
#ifndef TFU_TDD
#if (defined(PHY_3_8_3) || defined(CA_PHY))
         n1Pucch = pucchDedCtl->ackPUCCHResourceIndex0;
#else
         //New PHY Does't have this param
         n1Pucch = pucchDedCtl->harqPucchIndex;
#endif 
#else
#if CA_PHY
       if (pucchDedCtl->ackPUCCHResourceIndex0 == 0xfff)
       {
#ifdef XEON_SPECIFIC_CHANGES 
          if (pucchDedCtl->harqAckFeedbackMethod == 2)//CRAN: New Phy
#else
          if (pucchDedCtl->ackNackReportMode == 2)
#endif
          {
             n1Pucch = pucchDedCtl->ackPUCCHResourceIndex2;	
          }
          else
          {
             n1Pucch = 0;
          }
       }
       else
       {
           n1Pucch = pucchDedCtl->ackPUCCHResourceIndex0;
       }
#else
#ifdef XEON_SPECIFIC_CHANGES
       if((pucchDedCtl->harqAckFeedbackMethod == TFU_ACK_NACK_BUNDLING) || 
#else
       if((pucchDedCtl->ackNackReportMode == TFU_ACK_NACK_BUNDLING) || 
#endif
           (pucchDedCtl->subframeMultiplexNum == 1))
       {
          n1Pucch = pucchDedCtl->ackPUCCHResourceIndex0;
       }
       else
       {
          STKLOG(STK_MD_YS,STK_LOG_ERR,"\n ERROR : Multiplexing M >1 is not supported \n");
       /* TDD_TODO multiplexing case needs to be filled*/
       }

       if(ysUeCb)
       {/* TDD_COM: Remove this when CTF_VER3 support is added */
#ifdef XEON_SPECIFIC_CHANGES
          ysUeCb->ackNackMode = pucchDedCtl->harqAckFeedbackMethod;
#else
          ysUeCb->ackNackMode = pucchDedCtl->ackNackReportMode;
#endif
       }
#endif
#endif
         isFormat1 = TRUE;
         break;
      }
      case FORMAT2:
      case FORMAT2A:
      case FORMAT2B:
      { 
         n2Pucch = pucchDedCtl->cqiPUCCHResourceIndex;
         break;   
      }   
   }

   if (isFormat1)
   {
      U8 shift = (c * n1Cs/deltaShiftPucch);
     mVal = n1Pucch < shift ? n2Rb : ((n1Pucch - shift)/(c * nScPerRb/deltaShiftPucch) + n2Rb + (n1Cs + 7)/8);
#ifndef TFU_TDD
#ifndef CA_PHY
#ifndef PHY_3_8_3	  
   ulCtlChDesc->pucchDedCtl.n1PUCCHResourceIndex = n1Pucch;
#endif	  
#endif	  
#endif
   }
   else
   {
       mVal = n2Pucch/nScPerRb;
   }

   if (mVal % 2 == 0)
   {
      ulCtlChDesc->startRes = mVal/2;
   }
   else
   {
      ulCtlChDesc->startRes = ulBw - 1 - (mVal/2);
   }
#ifdef EMTC_ENABLE
   if(ysUeCb)
   {
       if(ysUeCb->isEmtcUe)
       {/* TODO:: isFormat1 argument needs to be changed
           when support for format 3 and 5 is added*/
          ysMsCalcEmtcPucchRes(ysCellCb,timingInfo.subframe,
                mVal,isFormat1,ulCtlChDesc);      
       }  
   }
#endif
   
   RETVOID;
} /* ysMsMapPucchDedRb*/
/* 
*
*       Fun:  ysMsMapCtlChanDesc
*  
*       Desc:  Map Control Channel Descriptor
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PRIVATE void ysMsMapCtlChanDesc
(
YsCellCb             *ysCellCb,
YsUeCb               *ueCb,
TfuUePucchRecpReq    *pucchRecpReq,  /*!< Reception request for PUCCH */
ULCTRLCHDESC         *ulCtlChDesc,
CmLteTimingInfo       timingInfo,
Bool                 isEmtcEnable
)
{
   TRC2(ysMsMapCtlChanDesc)

   ulCtlChDesc->txpowerControl         = YS_TX_PWR_CNTRL;
   ulCtlChDesc->crcLength              = YS_PUCCH_CRC_LEN;
   ulCtlChDesc->channelType            = PUCCH;

   ulCtlChDesc->scrmblerInitValue      = ueCb->ueId;
   ulCtlChDesc->codingDescriptor       = YS_PUCCH_COD_DES;
   ulCtlChDesc->blockCodeConcatenation = YS_PUCCH_BLK_CAT;
   ulCtlChDesc->mcsType                = YS_PUCCH_MCS_TYP;
   ysMsMapPucchDedCtl(ueCb, pucchRecpReq, &ulCtlChDesc->pucchDedCtl, timingInfo);
   ulCtlChDesc->modulationType = ysUeModulation[ulCtlChDesc->pucchDedCtl.formatType];

   /* The entire structure ulCtlChDesc->cqiPmiRiRpt is unused, so don't
    * care about it */

   ulCtlChDesc->numberofEntries = YS_SINGLE_MAPPING;

#ifdef EMTC_ENABLE	
   if(TRUE == isEmtcEnable)
	{
		ulCtlChDesc->catMenabled = isEmtcEnable;
		ulCtlChDesc->catMScramblerInitializationVal = 
									pucchRecpReq->catMScramblerInitVal;
		switch(ulCtlChDesc->pucchDedCtl.formatType)
   	{
   		case FORMAT1: 
			case FORMAT1A:
			case FORMAT1B:
			{
				ulCtlChDesc->repetitionNumber = 
									pucchRecpReq->format1aRepNumber;

				break;
			}
			case FORMAT2:
      	case FORMAT2A:
      	case FORMAT2B:
			{
				ulCtlChDesc->repetitionNumber = 
									pucchRecpReq->format2aRepNumber;
				break;
      	}
		}

      ulCtlChDesc->pucchRepetitions = ulCtlChDesc->repetitionNumber;
      ulCtlChDesc->pucchRepetitonIndex = 0;
      ulCtlChDesc->pucchRfTuningSymbols = 0; /* Not reqd during attach..need to fill it from mac */
	}
#endif 
	
   /* 36.211 Section 5.4 */
#ifndef EMTC_ENABLE
   ysMsMapPucchDedRb(ysCellCb, ueCb, ulCtlChDesc);
#else
   ysMsMapPucchDedRb(ysCellCb, ueCb, ulCtlChDesc,timingInfo);
#endif
   ulCtlChDesc->numRes    = 0;

   cmMemcpy((U8 *)&ulCtlChDesc->timAdvErrInfo, (U8 *)&ueCb->timingAdvErrInfo, sizeof(TIMADVERRINF));
   
   RETVOID;
} /*ysMsMapCtlChanDesc*/


/* 
*
*       Fun:   ysMsMapRxVector
*  
*       Desc:  Create Rx Vector
*
*       Ret:   void 
*
*       Notes: None
*
*       File:  ys_ms_map.c
*
*/
PUBLIC S16 ysMsUtlMapRxVector
(
YsCellCb         *cellCb,
TfuRecpReqInfo   *recpReq,
PULSUBFRDESC     ulSubFrDesc,
CmLteTimingInfo  timingInfo
)
{
   YsUeCb               *ueCb = NULLP;
   U8                   rxSduSf;
   U32                  numPuschCh = 0;
   U32                  numPucchCh = 0;
   U32                  numCh = 0;
   U32                  numSrs = 0;
   CmLList              *cmLstEnt;
#ifdef EMTC_ENABLE
	CmLList              *cmEmtcLstEnt;
#endif
   TfuUeRecpReqInfo     *recpReqInfo;
   CtfCellCfgInfo       *cellCfg;
   SRSDED           *srsDed = NULLP;
   TfuUePucchSrsRecpInfo  *srsInfo = NULLP ;

   TRC2(ysMsUtlMapRxVector)

   cellCfg                     = &cellCb->cellCfg;
   cmLstEnt = recpReq->ueRecpReqLst.first;
/*
   RLOG2(L_INFO,"ysMsUtlMapRxVector(): (%d) (%d);", 
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
*/
   /* Filling ULSUBFRDESC */
   ulSubFrDesc->frameNumber    = cellCb->timingInfo.sfn;
   ulSubFrDesc->subframeNumber = cellCb->timingInfo.subframe;
   ulSubFrDesc->subframeType   = ULRX;
   ulSubFrDesc->antennaPortcount = YS_MS_GET_NUM_TX_ANT(cellCfg->antennaCfg); 

   /* Getting values from stored predefined configuration */
   cmMemcpy((U8*) &ulSubFrDesc->ulSfrCtrl,
            (U8*) &cellCb->preDefVal.ulSubFrCmnCtrl,
            sizeof(ULSUBFRCMNCTRL));
   
   rxSduSf = (timingInfo.subframe + 2) % YS_NUM_SUB_FRAMES;
   while (cmLstEnt != NULLP)
   {
      recpReqInfo = (TfuUeRecpReqInfo*)cmLstEnt->node;
      ueCb = ysMsCfgGetUe(cellCb, recpReqInfo->rnti);
      if(ueCb == NULLP)
      {
         RLOG1(L_DEBUG,"UeCb not found for rnti(%u)", recpReqInfo->rnti);
      }

      /* PUSCH */
      if (recpReqInfo->type == TFU_RECP_REQ_PUSCH)
      {
#ifdef PHY_3828
         /* API change for 3.8.2.8 */
         /* cqiOnlyFlag = TRUE if PUSCH is scheduled only for CQI on PUSCH
          * else FALSE
          * TODO:: As of now MAC doesnt support only CQI on PUSCH.
          * THis needs to be enhance once this feature is available */
#ifdef XEON_SPECIFIC_CHANGES
        //ulSubFrDesc->ulCh[numPuschCh].ulSubChInfo.cqiOnlyFlag = 0;//CRAN: New Phy
#else
         ulSubFrDesc->ulCh[numPuschCh].ulSubChInfo.cqiOnlyFlag = 0;
#endif
#endif

#ifndef TFU_TDD
         /* HARQ_UL: If PUSCH reception request, mark CRC information */
         ysMsMapChanDesc(cellCb, ueCb, &recpReqInfo->t.puschRecpReq, &ulSubFrDesc->ulCh[numPuschCh],timingInfo.subframe,FALSE);
#else
         ysMsMapChanDesc(cellCb, ueCb, recpReqInfo->rnti,
               &recpReqInfo->t.puschRecpReq, &ulSubFrDesc->ulCh[numPuschCh],timingInfo.subframe,FALSE );
#endif

         cellCb->isCrcExptd[rxSduSf] = TRUE;

         ulSubFrDesc->ulCh[numPuschCh].ulSubChInfo.scrInfo.scrinitValueinput = recpReqInfo->rnti;
         ysMsMapRntiToChan(cellCb, recpReqInfo->rnti, timingInfo.subframe, numCh);
         ulSubFrDesc->ulCh[numPuschCh].channelId = numCh;
         numPuschCh++;
         numCh++;
         /* Store the Reception Req mode for handling HARQ IND -Reception
          * request from UE */
#ifdef CA_PHY
//         ueCb->harqRecpReqInfo[timingInfo.subframe].ackNackMode = TFU_UCI_FORMAT_1A_1B;
#endif


      } /* schReqInfo */
      /* PUCCH */
      else
      {
        if ((recpReqInfo->t.pucchRecpReq.uciInfo != TFU_PUCCH_SRS) && ueCb)
        {
            ysMsMapCtlChanDesc(cellCb, ueCb, &recpReqInfo->t.pucchRecpReq, 
                  &ulSubFrDesc->ulCtlCh[numPucchCh], timingInfo,FALSE);
            ulSubFrDesc->ulCtlCh[numPucchCh].channelId = numCh;
           ysMsMapRntiToChan(cellCb, recpReqInfo->rnti, timingInfo.subframe, numCh);
            numPucchCh++;
            numCh++;
        }
        /* Adding support for SRS mapping in PUCCH */
        else if ((recpReqInfo->t.pucchRecpReq.uciInfo == TFU_PUCCH_SRS) && ueCb)
        {
           srsDed = &(ulSubFrDesc->srsInfo[numSrs]);
           srsInfo = &recpReqInfo->t.pucchRecpReq.srsInfo;

           if (TRUE == recpReq->srsPres)
           {
              srsDed->enableDisable = recpReq->srsPres;
#ifdef MSPD_TDD_LTE 
#ifndef XEON_SPECIFIC_CHANGES
              srsDed->rnti = ueCb->ueId;
              srsDed->antSelEnable        = 1; /* SUBBU Need to Check */ 
#endif
#endif
              srsDed->srsBandwidth        = srsInfo->srsBw;
              srsDed->srsHoppingBandwidth = srsInfo->srsHopBw;
              srsDed->transmissionComb    = srsInfo->transComb;
              srsDed->cyclicShift         = srsInfo->srsCyclicShft;
              srsDed->freqDomainPosition  = srsInfo->nRrc;
              srsDed->duration            = 1; /* SUBBU Need to check */
              srsDed->srsConfigIndex      = srsInfo->srsCfgIdx;
              //MSPD_LOG("\n\n[SRS] UEId[%d], enableDisable[%d], BW[%d], HoppinBw[%d], tC[%d], CS[%d], freqDo[%d], dur[%d],antSelEnable[%d], srsCfgIdx[%d], SFN[%d], SF[%d]\n", srsDed->rnti, srsDed->enableDisable, srsDed->srsBandwidth, srsDed->srsHoppingBandwidth, srsDed->transmissionComb, srsDed->cyclicShift, srsDed->freqDomainPosition, srsDed->duration, srsDed->antSelEnable, srsDed->srsConfigIndex, timingInfo.sfn, timingInfo.subframe);
           }
           numSrs++;
        }
      } /* CtlChanInfo */

      cmLstEnt = cmLstEnt->next;
   } /* cmLstEnt while */

#ifdef EMTC_ENABLE	
	cmEmtcLstEnt = recpReq->emtcUeRecpReqLst.first;
	while (cmEmtcLstEnt != NULLP)
	{
      recpReqInfo = (TfuUeRecpReqInfo*)cmEmtcLstEnt->node;
      ueCb = ysMsCfgGetUe(cellCb, recpReqInfo->rnti);
      if(ueCb == NULLP)
      {
         RLOG1(L_DEBUG,"UeCb not found for rnti(%u)", recpReqInfo->rnti);
      }

      /* PUSCH */
      if (recpReqInfo->type == TFU_RECP_REQ_PUSCH)
      {
#ifdef PHY_3828
         /* API change for 3.8.2.8 */
         /* cqiOnlyFlag = TRUE if PUSCH is scheduled only for CQI on PUSCH
          * else FALSE
          * TODO:: As of now MAC doesnt support only CQI on PUSCH.
          * THis needs to be enhance once this feature is available */
         ulSubFrDesc->ulCh[numPuschCh].ulSubChInfo.cqiOnlyFlag = 0;
#endif

#ifndef TFU_TDD
         /* HARQ_UL: If PUSCH reception request, mark CRC information */
         ysMsMapChanDesc(cellCb, ueCb, &recpReqInfo->t.puschRecpReq, &ulSubFrDesc->ulCh[numPuschCh],timingInfo.subframe,TRUE);
#else
         ysMsMapChanDesc(cellCb, ueCb, recpReqInfo->rnti,
               &recpReqInfo->t.puschRecpReq, &ulSubFrDesc->ulCh[numPuschCh],timingInfo.subframe,TRUE );
#endif
         cellCb->isCrcExptd[rxSduSf] = TRUE;

         ulSubFrDesc->ulCh[numPuschCh].ulSubChInfo.scrInfo.scrinitValueinput = recpReqInfo->rnti;
         ysMsMapRntiToChan(cellCb, recpReqInfo->rnti, timingInfo.subframe, numCh);
         ulSubFrDesc->ulCh[numPuschCh].channelId = numCh;
         numPuschCh++;
         numCh++;
         /* Store the Reception Req mode for handling HARQ IND -Reception
          * request from UE */
#ifdef CA_PHY
//         ueCb->harqRecpReqInfo[timingInfo.subframe].ackNackMode = TFU_UCI_FORMAT_1A_1B;
#endif


      } /* schReqInfo */
      /* PUCCH */
      else
      {
        if ((recpReqInfo->t.pucchRecpReq.uciInfo != TFU_PUCCH_SRS) && ueCb)
        {
            ysMsMapCtlChanDesc(cellCb, ueCb, &recpReqInfo->t.pucchRecpReq, 
                  &ulSubFrDesc->ulCtlCh[numPucchCh], timingInfo,TRUE);
            ulSubFrDesc->ulCtlCh[numPucchCh].channelId = numCh;
           ysMsMapRntiToChan(cellCb, recpReqInfo->rnti, timingInfo.subframe, numCh);
            numPucchCh++;
            numCh++;
        }
        /* Adding support for SRS mapping in PUCCH */
        else if ((recpReqInfo->t.pucchRecpReq.uciInfo == TFU_PUCCH_SRS) && ueCb)
        {
           srsDed = &(ulSubFrDesc->srsInfo[numSrs]);
           srsInfo = &recpReqInfo->t.pucchRecpReq.srsInfo;

           if (TRUE == recpReq->srsPres)
           {
              srsDed->enableDisable = recpReq->srsPres;
#ifdef MSPD_TDD_LTE 
              srsDed->rnti = ueCb->ueId;
              srsDed->antSelEnable        = 1; /* SUBBU Need to Check */ 
#endif
              srsDed->srsBandwidth        = srsInfo->srsBw;
              srsDed->srsHoppingBandwidth = srsInfo->srsHopBw;
              srsDed->transmissionComb    = srsInfo->transComb;
              srsDed->cyclicShift         = srsInfo->srsCyclicShft;
              srsDed->freqDomainPosition  = srsInfo->nRrc;
              srsDed->duration            = 1; /* SUBBU Need to check */
              srsDed->srsConfigIndex      = srsInfo->srsCfgIdx;
              //MSPD_LOG("\n\n[SRS] UEId[%d], enableDisable[%d], BW[%d], HoppinBw[%d], tC[%d], CS[%d], freqDo[%d], dur[%d],antSelEnable[%d], srsCfgIdx[%d], SFN[%d], SF[%d]\n", srsDed->rnti, srsDed->enableDisable, srsDed->srsBandwidth, srsDed->srsHoppingBandwidth, srsDed->transmissionComb, srsDed->cyclicShift, srsDed->freqDomainPosition, srsDed->duration, srsDed->antSelEnable, srsDed->srsConfigIndex, timingInfo.sfn, timingInfo.subframe);
           }
           numSrs++;
        }
      } /* CtlChanInfo */

      cmEmtcLstEnt = cmEmtcLstEnt->next;
   }
#endif

   if ((cellCb->cellId > CM_START_CELL_ID) && ((numPucchCh > 0) || (numSrs > 0)))
   {
      RLOG_ARG2(L_ALWAYS, DBG_CELLID, cellCb->cellId, "numPucchCh = %u, numSrs = %u", numPucchCh, numSrs);
   }
   ulSubFrDesc->numberofChannelDescriptors =  numCh;
   ulSubFrDesc->numberOfCtrlChannelDescriptors  = numPucchCh;
   ulSubFrDesc->numberSrsinSf                   = numSrs;

#ifdef BIT_64
   ulSubFrDesc->offsetRachCtrlStruct            = (U64)&ulSubFrDesc->rachCtrl - (U64)ulSubFrDesc;
   ulSubFrDesc->offsetULCtrlChannels            = (U64)&ulSubFrDesc->ulCtlCh - (U64)ulSubFrDesc;
   ulSubFrDesc->offsetsrsInfo                   = (U64)&ulSubFrDesc->srsInfo - (U64)ulSubFrDesc;
#else
   ulSubFrDesc->offsetRachCtrlStruct            = (U32)&ulSubFrDesc->rachCtrl - (U32)ulSubFrDesc;
   ulSubFrDesc->offsetULCtrlChannels            = (U32)&ulSubFrDesc->ulCtlCh - (U32)ulSubFrDesc;
   ulSubFrDesc->offsetsrsInfo                   = (U32)&ulSubFrDesc->srsInfo - (U32)ulSubFrDesc;
#endif
   ulSubFrDesc->offsetCustomFeatures            = 0;

   RETVALUE(ROK);
} /* ysMsUtlMapRxVector */


#endif /* TFU_UPGRADE*/
/********************************************************************30**
  
         End of file:     yw_ms_map.c@@/main/TeNB_Main_BR/5 - Wed Jun 11 13:19:53 2014
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      mraj   1. initial release.
/main/1    ys004.102  vr   1. Merged MSPD code with phy 1.7
*********************************************************************91*/


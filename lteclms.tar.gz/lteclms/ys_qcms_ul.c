
/*
                 IMPORTANT LIMITATION(S) ON USE
                    
This files include the QC platform DL handle
     

    
 
**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_MODULE_ID=1;
static int RLOG_FILE_ID=234;
#include "envopt.h"             /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "fapiApiInternal.h"
#include "ssi.h"           /* system services */
#include "gen.h"                /* general layer */
#include "tfu.h"
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "lys.h"
#include "resultcodes.h"
#include "ctf.h"
#include "ys_ms.h"
#include "ys_ms_err.h"
#include "ac_ltePhyL2Api.h"
#include "fsl_ipc_types.h"

#include "gen.x"                /* general layer */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"
	
#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#include "ctf.x"
	
#include "ys_ms.x"
#include "fsl_usmmgr.h"

#include "ys_qcms.h"

void ys_qcAddtoHarqList(TfuUePucchHqRecpInfo *hqInfo,U16 rnti,U16 sfn, U8 subframe, CmLteCellId cellId);
void ys_qcAddtoCrcIndList(TfuCrcIndInfo	  *crcIndInfo, U16 rnti);
void ys_qcPrcTmAdvInd(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId);
void ys_qcUlCqiInUlSchHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId);
Bool updatePucchSNR(U8 ul_CQI, YsUeCb* ueCb, S8* pucchDeltaPwr_p);

QcUlMsgInfoS   ysQcPhyUlMsgInfo[YS_LTE_MAX_CELLS][YS_NUM_SUB_FRAMES];
U8 qc_mapTblFrmHarqToNumbrOfAcks[4] = {0, 3, 2, 1};

EXTERN U16 g_MacRntiStart[2];

S16 ys_qcGetUlCqi
(
YsCellCb        *cellCb,
U8              sinr
)
{
    if (sinr <= 101)
       return 0;

    return ysCb.sinrToCqi[sinr]; //syq
} /* end of  ysMsGetUlCqi */

/*
 * -----------------------------------------------------------
 * Function:    MAC_SIM_fapi_mcs_to_tbs
 * Description: determine the I_tbs from the I_mcs from table 8.6.1-1 in 36-213 standard
 *
 * Input:       mcs  - Modulation and coding scheme
 *              isDL - Flag indicating whether to calculate
 *              for DL message or UL message
 *
 * Output:      calculated I_tbs
 * -----------------------------------------------------------
 */
U8 ys_qcMcstoItbs (U8 mcs, Bool isDL)
{
    if(mcs >= 29)
        return 0;

    if(isDL)
    {
        if( mcs <= 9)
            return mcs;

        if (mcs >= 17)
            return (mcs - 2);
    }
    else // if UL
    {
        if( mcs <= 10)
            return mcs;

        if (mcs >= 21)
            return (mcs - 2);
    }

    return (mcs - 1);
}

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_calc_harq_info_size
 * Description:     Calculate the ULSCH HARQ_INFO size of a giver PDU
 *
 * Input:       UL_pdu - the PDU for which to calculate
 *
 * Output:      The size of the CQI_RI_INFO
 *
 * ----------------------------------------------------------------------
 */
static U32 ys_qcCalcHarqInfoSize(void)
{
    return sizeof(FAPI_T_ULSCH_HARQ_INFO);
}  //end of MAC_SIM_fapi_calc_harq_info_size

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_calc_cqi_ri_info_size
 * Description:     Calculate the CQI_RI_INFO size of a giver PDU
 *
 * Input:       UL_pdu - the PDU for which to calculate
 *
 * Output:      The size of the CQI_RI_INFO
 *
 * ----------------------------------------------------------------------
 */
static U32 ys_qcCalcCqiRiInfoSize(void)
{
    U32 cqi_ri_info_size = sizeof(FAPI_T_ULSCH_CQI_RI_INFO);
    cqi_ri_info_size += sizeof(FAPI_T_PMI_RI_PR_RPT);
    return cqi_ri_info_size;
} //end of MAC_SIM_fapi_calc_cqi_ri_info_size

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_calc_ul_config_msg_size
 * Description:     Calculate the UL_CONFIG_REQ messages size
 *
 * Input:       fapi_sf_config - the SF parameters for which to calc
 *
 * Output:      The size of the UL Config message
 *
 * ----------------------------------------------------------------------
 */
 
U32 ys_qcCalcUlConfigMsgSize(TfuRecpReqInfo  *recpReq, 
                                             U8 *ulsch_count,
                                             U8 *uci_count ,
                                             U8 *srs_count,
                                             U32* total_ul_msg_size)
{
    U32          pdu_data_size = 0;
    U32          ul_config_msg_size = 0;
    CmLList      *cmLstEnt;
    TfuUeRecpReqInfo *recpReqInfo;

    (*ulsch_count) =0;
    (*uci_count) = 0;
    (*srs_count) = 0;

    cmLstEnt = recpReq->ueRecpReqLst.first;
    while (cmLstEnt != NULLP)
    {
        recpReqInfo = (TfuUeRecpReqInfo*)cmLstEnt->node;
        pdu_data_size = 0;
        if (recpReqInfo->type == TFU_RECP_REQ_PUCCH)
        {
            switch(recpReqInfo->t.pucchRecpReq.uciInfo)
            {
                case TFU_PUCCH_HARQ:
                    pdu_data_size =  sizeof(FAPI_T_UCI_HARQ_INFO) + sizeof(FAPI_T_UE_INFORMATION);
                    (*uci_count)++;
                    break;
                case TFU_PUCCH_SR:
                    pdu_data_size = sizeof(FAPI_T_UCI_SR_INFO)  + sizeof(FAPI_T_UE_INFORMATION);
                    (*uci_count)++;
                    break;
                case TFU_PUCCH_SRS:
                    pdu_data_size = sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break;
                case TFU_PUCCH_CQI:
                    pdu_data_size = sizeof(FAPI_T_UCI_CQI_INFO)  + sizeof(FAPI_T_UE_INFORMATION);
                    (*uci_count)++;
                    break;
                case TFU_PUCCH_HARQ_SR:
                    pdu_data_size = sizeof(FAPI_T_UCI_SR_HARQ_PDU)+sizeof(FAPI_T_UCI_HARQ_INFO);
                    (*uci_count)++;
                    break;
                case TFU_PUCCH_HARQ_SRS:
                    pdu_data_size = sizeof(FAPI_T_UCI_HARQ_PDU)+sizeof(FAPI_T_UCI_HARQ_INFO);
                    (*uci_count)++;
                    pdu_data_size += sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break;
                case TFU_PUCCH_HARQ_CQI:
                    pdu_data_size = sizeof(FAPI_T_UCI_CQI_HARQ_PDU)+sizeof(FAPI_T_UCI_HARQ_INFO);
                    (*uci_count)++;
                    break;
                case TFU_PUCCH_HARQ_SR_SRS:
                    pdu_data_size = sizeof(FAPI_T_UCI_SR_HARQ_PDU)+sizeof(FAPI_T_UCI_HARQ_INFO);
                    (*uci_count)++;
                    pdu_data_size += sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break;
                case TFU_PUCCH_HARQ_SR_CQI:
                    pdu_data_size = sizeof(FAPI_T_UCI_CQI_SR_HARQ_PDU)+sizeof(FAPI_T_UCI_HARQ_INFO);
                    (*uci_count)++;
                    break;
                case TFU_PUCCH_SR_SRS:
                    pdu_data_size = sizeof(FAPI_T_UCI_SR_PDU);
                    (*uci_count)++;
                    pdu_data_size += sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break;
                case TFU_PUCCH_SR_CQI:
                    pdu_data_size = sizeof(FAPI_T_UCI_CQI_SR_PDU);
                    (*uci_count)++;
                    break;
                case TFU_PUCCH_HARQ_SR_CQI_SRS:
                    pdu_data_size = sizeof(FAPI_T_UCI_CQI_SR_HARQ_PDU)+sizeof(FAPI_T_UCI_HARQ_INFO);
                    (*uci_count)++;
                    pdu_data_size += sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break;
                case TFU_PUCCH_SR_CQI_SRS:
                    pdu_data_size = sizeof(FAPI_T_UCI_CQI_SR_PDU);
                    (*uci_count)++;
                    pdu_data_size += sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break;
            }
        }
        else
        {
            switch(recpReqInfo->t.puschRecpReq.rcpInfo)
            {
                case TFU_PUSCH_DATA:
                    pdu_data_size = sizeof(FAPI_T_ULSCH_PDU);
                    (*ulsch_count)++;
                    break;
                case TFU_PUSCH_DATA_SRS:
                    pdu_data_size += sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break;
                case TFU_PUSCH_DATA_HARQ:
                    pdu_data_size += sizeof(FAPI_T_ULSCH_PDU) + sizeof(FAPI_T_ULSCH_INIT_TRANS_PARAM);
                    pdu_data_size += ys_qcCalcHarqInfoSize();
                    (*ulsch_count)++;
                    break;
                case TFU_PUSCH_DATA_HARQ_SRS:
                    pdu_data_size += sizeof(FAPI_T_ULSCH_PDU) + sizeof(FAPI_T_ULSCH_INIT_TRANS_PARAM);
                    pdu_data_size += ys_qcCalcHarqInfoSize();
                    (*ulsch_count)++;
                    pdu_data_size += sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break;
                case TFU_PUSCH_DATA_CQI:
                    #ifdef NXP_PLATFORM
                    pdu_data_size+=sizeof(FAPI_T_ULSCH_CQI_RI_PDU_REL_8);
                    #else
                    pdu_data_size += sizeof(FAPI_T_ULSCH_PDU) + sizeof(FAPI_T_ULSCH_INIT_TRANS_PARAM);
                    pdu_data_size += ys_qcCalcCqiRiInfoSize();// TBD
                    #endif
                    (*ulsch_count)++;
                    break;
                case TFU_PUSCH_DATA_CQI_SRS:
                    pdu_data_size += sizeof(FAPI_T_ULSCH_PDU) + sizeof(FAPI_T_ULSCH_INIT_TRANS_PARAM);
                    pdu_data_size += ys_qcCalcCqiRiInfoSize();// TBD
                    (*ulsch_count)++;
                    pdu_data_size += sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break; 
                case TFU_PUSCH_DATA_CQI_HARQ:
                    #ifdef NXP_PLATFORM
                    pdu_data_size+=sizeof(FAPI_T_ULSCH_CQI_RI_PDU_REL_8);
                    #else
                    pdu_data_size += sizeof(FAPI_T_ULSCH_PDU) + sizeof(FAPI_T_ULSCH_INIT_TRANS_PARAM);
                    pdu_data_size += ys_qcCalcCqiRiInfoSize();// TBD
                    #endif
                    pdu_data_size += ys_qcCalcHarqInfoSize();
                    (*ulsch_count)++;
                    break;
                case TFU_PUSCH_DATA_CQI_HARQ_SRS:
                    pdu_data_size += sizeof(FAPI_T_ULSCH_PDU) + sizeof(FAPI_T_ULSCH_INIT_TRANS_PARAM);
                    pdu_data_size += ys_qcCalcCqiRiInfoSize();// TBD
                    pdu_data_size += ys_qcCalcHarqInfoSize();
                    (*ulsch_count)++;
                    pdu_data_size += sizeof(FAPI_T_SRS_PDU);
                    (*srs_count)++;
                    break;
            }
        }

        ul_config_msg_size += pdu_data_size;
        cmLstEnt = cmLstEnt->next;
    } /* cmLstEnt while */

    ul_config_msg_size += sizeof(FAPI_T_UL_CONFIG_REQ) +
                          sizeof(FAPI_T_PDU) * (*ulsch_count + *uci_count + *srs_count);
#ifdef NXP_PLATFORM
   *total_ul_msg_size =  ul_config_msg_size + *ulsch_count * sizeof(U32) + sizeof(ltePhyL2ApiUlCfgVendor_t);
#else
   *total_ul_msg_size = ul_config_msg_size;
#endif
                        
    return ul_config_msg_size;
} // end of MAC_SIM_fapi_calc_ul_config_msg_size

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_srs_pdu
 * Description:     Build an SRS PDU
 *
 * Input:       ulpdu       - UL PDU config parameters
 *              advance_imp - implicit step size
 *
 * Output:      pdu_p - pointer to the newly created SRS PDU
 *
 * ----------------------------------------------------------------------
 */
void ys_qcBuildSrsPdu(U16 rnti, FAPI_T_SRS_PDU *pdu_p, TfuUePuschSrsRecpInfo  *srsInfo)
{

    pdu_p->rel8.handle               = 0xFFFFFFFF;
    pdu_p->rel8.size                 = sizeof(FAPI_T_SRS_PDU);
    pdu_p->rel8.rnti                 = rnti;
    pdu_p->rel8.srs_bw               = srsInfo->srsBw;
    pdu_p->rel8.freq_domain_pos      = srsInfo->nRrc;
    pdu_p->rel8.srs_hop_bw           = srsInfo->srsHopBw;
    pdu_p->rel8.trans_comb           = srsInfo->transComb;
    pdu_p->rel8.srs_config_idx       = srsInfo->srsCfgIdx;
    pdu_p->rel8.sound_ref_cyc_shift  = srsInfo->srsCyclicShft;

} // end of MAC_SIM_fapi_build_srs_pdu

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_uci_cqi_info
 * Description:     Build a UCI CQI Information
 *
 * Input:       ulpdu       - UL PDU config parameters
 *              advance_imp - implicit step size
 *
 * Output:      pdu_p - pointer to the newly created UCI PDU
 *
 * ----------------------------------------------------------------------
 */
static U32 ys_qcBuildUciCqiInfo(FAPI_T_UCI_CQI_INFO *uciCqiInfo, TfuUePucchCqiRecpInfo  *cqiInfo)
{
    uciCqiInfo->rel8.pucch_idx       = cqiInfo->n2PucchIdx;
    uciCqiInfo->rel8.dl_cqi_pmi_size = cqiInfo->cqiPmiSz;
    #ifndef NXP_PLATFORM
    uciCqiInfo->rel10.n_pucch_res     = 1;
    uciCqiInfo->rel10.pucch_idx_p1    = 0;
    uciCqiInfo->rel13.csi_mode = 0;
    uciCqiInfo->rel13.cdm_index = 0; 
    uciCqiInfo->rel13.dl_cqi_pmi_size_2 = 0;
    uciCqiInfo->rel13.n_prb = 0;
    uciCqiInfo->rel13.n_srs = 0;
    uciCqiInfo->rel13.starting_prb = 0;
    #endif
    return sizeof(FAPI_T_UCI_CQI_INFO);
} // end of MAC_SIM_fapi_build_uci_cqi_info

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_uci_sr_info
 * Description:     Build a UCI SR Information
 *
 * Input:       ulpdu       - UL PDU config parameters
 *              advance_imp - implicit step size
 *
 * Output:      pdu_p - pointer to the newly created UCI PDU
 *
 * ----------------------------------------------------------------------
 */
static U32 ys_qcBuildUciSrInfo(FAPI_T_UCI_SR_INFO *uciSRInfo, TfuUePucchSrRecpInfo   *srInfo)
{
    uciSRInfo->rel8.pucch_idx    = srInfo->n1PucchIdx;
    #ifndef NXP_PLATFORM
    uciSRInfo->rel10.n_pucch_res  = 1;
    uciSRInfo->rel10.pucch_idx_p1 = 0;
    #endif
    return sizeof(FAPI_T_UCI_SR_INFO);
} // end of MAC_SIM_fapi_build_uci_sr_info

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_uci_harq_info
 * Description:     Build a UCI HARQ Information
 *
 * Input:       ulpdu       - UL PDU config parameters
 *              advance_imp - implicit step size
 *
 * Output:      pdu_p - pointer to the newly created UCI PDU
 *
 * ----------------------------------------------------------------------
 */
static U32 ys_qcBuildUciHarqInfo(FAPI_T_UCI_HARQ_INFO *uciharqInfo, TfuUePucchHqRecpInfo   *hqInfo)
{

#ifdef NXP_PLATFORM
#ifdef TFU_TDD
    uciharqInfo->rel10.harq_size      = hqInfo->hqSz;
    uciharqInfo->rel10.ack_nack_mode  = hqInfo->hqFdbkMode;
    uciharqInfo->rel10.n_pucch_res    = hqInfo->pucchResCnt;
    
    uciharqInfo->rel10.n_pucch_1_0    = (hqInfo->hqRes[0]==0)?0xffff:(hqInfo->hqRes[0]);   //as qc uses 0xffff as default value for unused item, for pCell, we change 0 to oxffff for unused.
    uciharqInfo->rel10.n_pucch_1_1    = (hqInfo->hqRes[1]==0)?0xffff:(hqInfo->hqRes[1]);
    uciharqInfo->rel10.n_pucch_1_2    = hqInfo->hqRes[2];
    uciharqInfo->rel10.n_pucch_1_3    = hqInfo->hqRes[3];
#else
    uciharqInfo->rel8.harq_size = hqInfo->hqSz;
    uciharqInfo->rel8.pucch_idx = (hqInfo->hqRes[0]==0)?0xffff:(hqInfo->hqRes[0]);

#endif
#else
    uciharqInfo->rel10.harq_size      = hqInfo->hqSz;
    uciharqInfo->rel10.ack_nack_mode  = hqInfo->hqFdbkMode;
#ifdef TFU_TDD
    uciharqInfo->rel10.n_pucch_res    = hqInfo->pucchResCnt;
#else
    //TBD, should not hardcode
    uciharqInfo->rel10.n_pucch_res    = 1;
#endif
    
    uciharqInfo->rel10.n_pucch_1_0    = (hqInfo->hqRes[0]==0)?0xffff:(hqInfo->hqRes[0]);   //as qc uses 0xffff as default value for unused item, for pCell, we change 0 to oxffff for unused.
    uciharqInfo->rel10.n_pucch_1_1    = (hqInfo->hqRes[1]==0)?0xffff:(hqInfo->hqRes[1]);
    uciharqInfo->rel10.n_pucch_1_2    = hqInfo->hqRes[2];
    uciharqInfo->rel10.n_pucch_1_3    = hqInfo->hqRes[3];
   
    uciharqInfo->rel11.num_ant_ports = 1;
    uciharqInfo->rel11.n_pucch_2_0 = 0;
    uciharqInfo->rel11.n_pucch_2_1 = 0;
    uciharqInfo->rel11.n_pucch_2_2 = 0;
    uciharqInfo->rel11.n_pucch_2_3 = 0;
    uciharqInfo->rel13.cdm_index = 0;
    uciharqInfo->rel13.harq_size_2 = 0;
    uciharqInfo->rel13.n_prb = 0;
    uciharqInfo->rel13.n_srs = 0;
    uciharqInfo->rel13.starting_prb = 0;
    #endif
    return sizeof(FAPI_T_UCI_HARQ_INFO);
} // end of MAC_SIM_fapi_build_uci_harq_info

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_uci_pdu
 * Description:     Build a UCI PDU
 *
 * Input:       ulpdu       - UL PDU config parameters
 *              advance_imp - implicit step size
 *              cqi_flag    - flag indicating whether to include CQI_INFO
 *              sr_flag     - flag indicating whether to include SR_INFO
 *              harq_flag   - flag indicating whether to include HARQ_INFO
 *
 * Output:      pdu_p - pointer to the newly created UCI PDU
 *
 * ----------------------------------------------------------------------
 */
static U32 ys_qcBuildUciPdu(FAPI_T_PDU *pdu_p, U16 rnti, TfuUePucchCqiRecpInfo  *cqiInfo,
                                        TfuUePucchSrRecpInfo   *srInfo,TfuUePucchHqRecpInfo   *hqInfo,
                                                        Bool cqi_flag, Bool sr_flag, Bool harq_flag)
{
    U8               *uciPdu;
    FAPI_T_UE_INFORMATION       *uciCommonPdu;
    FAPI_T_UCI_CQI_INFO     *uciCqiInfo;
    FAPI_T_UCI_SR_INFO      *uciSRInfo;
    FAPI_T_UCI_HARQ_INFO    *uciharqInfo;
    U32              offset = 0;

    uciPdu          = (U8 *)&(pdu_p->pdu[0]);
    uciCommonPdu    = (FAPI_T_UE_INFORMATION *)(uciPdu + offset);

    uciCommonPdu->rel8.handle = 1;

    uciCommonPdu->rel8.rnti= rnti;
    #ifndef NXP_PLATFORM
    uciCommonPdu->rel11.virt_cell_id_en_flag = 0;
    uciCommonPdu->rel11.nPUCCH_idnetity = 0;

    uciCommonPdu->rel13.ue_type = 0;
    uciCommonPdu->rel13.empty_symbols = 0;
    uciCommonPdu->rel13.total_num_of_repetition = 1;
    uciCommonPdu->rel13.repetition_number = 1;
    #endif
    offset += sizeof(FAPI_T_UE_INFORMATION);

    if(cqi_flag)
    {
        uciCqiInfo = (FAPI_T_UCI_CQI_INFO*)(uciPdu + offset);
        offset += ys_qcBuildUciCqiInfo(uciCqiInfo, cqiInfo);
    }
    if(sr_flag)
    {
        uciSRInfo = (FAPI_T_UCI_SR_INFO*)(uciPdu + offset);
        offset += ys_qcBuildUciSrInfo(uciSRInfo, srInfo);
    }
    if(harq_flag)
    {
        uciharqInfo = (FAPI_T_UCI_HARQ_INFO*)(uciPdu + offset);
        offset += ys_qcBuildUciHarqInfo(uciharqInfo, hqInfo);
    }
    return offset;
} // end of MAC_SIM_fapi_build_uci_pdu

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_cqi_ri_info
 * Description:     Build the RI-CQI of the ULSCH type PDUs
 *
 * Input:       ulpdu - UL PDU config parameters
 *
 * Output:      pdu_p - pointer to the CQI_RI_INFO
 *
 * ----------------------------------------------------------------------
 */
static U32 ys_qcBuildCqiRiInfo(FAPI_T_ULSCH_CQI_RI_INFO *pdu_p, TfuUePuschCqiRecpInfo  *cqiRiInfo, CmLteCellId cellId)
{
    U32 cqi_ri_size   = sizeof(FAPI_T_ULSCH_CQI_RI_INFO);
    pdu_p->rpt_type		= cqiRiInfo->reportType;
    pdu_p->delta_off_cqi = cqiRiInfo->cqiBetaOff;
    pdu_p->delta_off_ri	= cqiRiInfo->riBetaOff;

    if(pdu_p->rpt_type == 0) //periodical cpi supported
    {
        FAPI_T_PMI_RI_PR_RPT* periodic_rpt = (FAPI_T_PMI_RI_PR_RPT*)(pdu_p->pmi_ri_rpt);
        if(cqiRiInfo->riBetaOff)
        {
            periodic_rpt->dl_cqi_pmi_ri_size = cqiRiInfo->riSz[cellId - CM_START_CELL_ID].val;
            periodic_rpt->control_type = 1;
        }
        else
        {
            printf("cellId %d cqiRiInfo->cqiPmiSzR1[0] = %d,cqiRiInfo->cqiPmiSzR1[1] = %d \n",cellId,cqiRiInfo->cqiPmiSzR1[0],
                cqiRiInfo->cqiPmiSzR1[1]);
            RLOG3(L_DEBUG,"cellId %d cqiRiInfo->cqiPmiSzR1[0] = %d,cqiRiInfo->cqiPmiSzR1[1] = %d",cellId,cqiRiInfo->cqiPmiSzR1[0],
                cqiRiInfo->cqiPmiSzR1[1]);
            periodic_rpt->dl_cqi_pmi_ri_size = cqiRiInfo->cqiPmiSzR1[cellId - CM_START_CELL_ID];
            periodic_rpt->control_type = 0;
        }
        periodic_rpt->dl_cqi_pmi_size_2 = 6555;
        cqi_ri_size += sizeof(FAPI_T_PMI_RI_PR_RPT);
    }
    else//aperiodical cpi
    {
        FAPI_T_PMI_RI_APR_RPT* aperiodic_rpt = (FAPI_T_PMI_RI_APR_RPT*)(pdu_p->pmi_ri_rpt);
        aperiodic_rpt->num_cc = cqiRiInfo->cCNum;
        aperiodic_rpt->cc_rpt->ri_size = cqiRiInfo->riSz[cellId - CM_START_CELL_ID].val;
        if(aperiodic_rpt->cc_rpt->ri_size == 1)
        {
            aperiodic_rpt->cc_rpt->dl_cqi_pmi_size[0]= cqiRiInfo->cqiPmiSzR1[cellId - CM_START_CELL_ID];
            aperiodic_rpt->cc_rpt->dl_cqi_pmi_size[1]= cqiRiInfo->cqiPmiSzR1[cellId - CM_START_CELL_ID];
            cqi_ri_size += (sizeof(FAPI_T_PMI_RI_APR_RPT) + sizeof(FAPI_T_RI_DL_PMI_RI_CC_RPT)+ sizeof(U8)*2);
        }
        else if(aperiodic_rpt->cc_rpt->ri_size == 2)
        {
            aperiodic_rpt->cc_rpt->dl_cqi_pmi_size[0]= cqiRiInfo->cqiPmiSzR1[cellId - CM_START_CELL_ID];
            aperiodic_rpt->cc_rpt->dl_cqi_pmi_size[1]= cqiRiInfo->cqiPmiSzRn1[cellId - CM_START_CELL_ID];
            cqi_ri_size += (sizeof(FAPI_T_PMI_RI_APR_RPT) + sizeof(FAPI_T_RI_DL_PMI_RI_CC_RPT) + sizeof(U8)*2);
        }
    }

    return cqi_ri_size;
} // end of MAC_SIM_fapi_build_cqi_ri_info
static U32 ys_NxpBuildCqiRiInfo(FAPI_T_ULSCH_CQI_RI_INFO_R8 *pdu_p, TfuUePuschCqiRecpInfo  *cqiRiInfo, CmLteCellId cellId)
{
    U32 cqi_ri_size   = sizeof(FAPI_T_ULSCH_CQI_RI_INFO_R8);
    pdu_p->dl_cqi_pmi_size_rank1		= 4;//cqiRiInfo->cqiPmiSzR1[0];
    pdu_p->dl_cqi_pmi_size_rank_g1 = 4;//cqiRiInfo->cqiPmiSzRn1[0];
    pdu_p->ri_size	= cqiRiInfo->riSz[0].val;
    pdu_p->delta_off_cqi =cqiRiInfo->cqiBetaOff;
    pdu_p->delta_off_ri = cqiRiInfo->riBetaOff;


    return cqi_ri_size;
} // end of MAC_SIM_fapi_build_cqi_ri_info

static U32 ys_qcBuildInitParamsInfo(FAPI_T_ULSCH_INIT_TRANS_PARAM *pdu_p, TfuUePuschRecpReq   *puschRecpReq)
{
    if(puschRecpReq->initialNSrs.pres)
    {
        pdu_p->n_srs_init   = puschRecpReq->initialNSrs.val;
    }
    else
    {
        pdu_p->n_srs_init = 0;
    }
    pdu_p->n_rb_init    = puschRecpReq->initialNumRbs.val;
    return sizeof(FAPI_T_ULSCH_INIT_TRANS_PARAM);
} // end of MAC_SIM_fapi_build_init_params_info

/*
 * ----------------------------------------------------------------------
 * Function:        MAC_SIM_fapi_build_harq_info
 * Description:     Build the HARQ of the ULSCH type PDUs
 *
 * Input:       ulpdu - UL PDU config parameters
 *
 * Output:      pdu_p - pointer to the HARQ_INFO
 *
 * ----------------------------------------------------------------------
 */
static U32 ys_qcBuildHarqInfo(FAPI_T_ULSCH_HARQ_INFO *pdu_p, TfuUePuschHqRecpInfo   *hqInfo)
{
    U32 pdu_data_size = 0;
    pdu_p->rel10.delta_off_harq   = hqInfo->hqBetaOff;
#ifdef TFU_TDD
    pdu_p->rel10.harq_size        = hqInfo->hqSz;
    pdu_p->rel10.ack_nack_mode    = hqInfo->hqFdbkMode;
#else
    //TBD, should not hardcode here
    pdu_p->rel10.harq_size        = hqInfo->hqSz;
    pdu_p->rel10.ack_nack_mode    = 0;
    pdu_p->rel10.NBundle = 0;
#endif
#ifndef NXP_PLATFORM
    pdu_p->rel13.delta_offset_harq_2 = 0;
    pdu_p->rel13.harq_size_2 = 0;
#endif
    pdu_data_size += sizeof(FAPI_T_ULSCH_HARQ_INFO);

    return pdu_data_size;
} // end of MAC_SIM_fapi_build_harq_info
#ifdef NXP_PLATFORM
EXTERN NxpShareMemInfoS UlShareMem;
static U32 ys_qcBuildUlschPdu(U16 rnti,FAPI_T_ULSCH_PDU *pdu_p, TfuUeUlSchRecpInfo *ulSchInfo,apiUlCfgVendor_t *ulcfgvendor)
#else
static U32 ys_qcBuildUlschPdu(U16 rnti,FAPI_T_ULSCH_PDU *pdu_p, TfuUeUlSchRecpInfo *ulSchInfo)
#endif
{

    pdu_p->rel8.size             = ulSchInfo->size;
    #ifdef NXP_PLATFORM
    ulcfgvendor->ulschPduDataAddr[ulcfgvendor->numUEs] = ac_shmV2P(ac_shmAlloc(ulSchInfo->size+4));

    //ulcfgvendor->ulschPduDataAddr[ulcfgvendor->numUEs] = UlShareMem.Paddress;
    //pdu_p->rel8.handle = UlShareMem.Paddress;
    pdu_p->rel8.handle =  ulcfgvendor->ulschPduDataAddr[ulcfgvendor->numUEs];
   // UlShareMem.offset+=ulSchInfo->size;
    ulcfgvendor->numUEs++;
    #else
    pdu_p->rel8.handle           = 0;
    #endif
    pdu_p->rel8.rnti             = rnti;
    pdu_p->rel8.rb_start         = ulSchInfo->rbStart;
    pdu_p->rel8.n_rb             = ulSchInfo->numRb;
    pdu_p->rel8.mod_type         = ulSchInfo->modType;
    pdu_p->rel8.cyc_shift_2_dmrs = ulSchInfo->nDmrs;
    pdu_p->rel8.freq_hop_enable  = ulSchInfo->hoppingEnbld;
    pdu_p->rel8.freq_hop_bits    = ulSchInfo->hoppingBits;	
    #ifdef NXP_PLATFORM
    pdu_p->rel8.ndi              = ulSchInfo->ndi;
    #else
    pdu_p->rel8.ndi              = (ulSchInfo->rv)?0:1;
    #endif
    pdu_p->rel8.rv               = ulSchInfo->rv;
    pdu_p->rel8.harq_proc_num    = ulSchInfo->harqProcId;
    pdu_p->rel8.ul_tx_mode       = ulSchInfo->txMode;
    pdu_p->rel8.curr_tx_nb       = ulSchInfo->crntTxNb;
    //pdu_p->rel8.n_srs            = ulSchInfo->nSrs;
    pdu_p->rel8.n_srs            = 0;
    #ifndef NXP_PLATFORM
    pdu_p->rel10.ra_type          = 0;
    pdu_p->rel10.rb_coding        = 0;
    pdu_p->rel10.tb_blocks        = 1;
    pdu_p->rel10.transmission_scheme  = 0;
    pdu_p->rel10.num_layers           = 1;
    pdu_p->rel10.codebook_index       = 0;
    pdu_p->rel10.disable_seq_hop_flag = 0;
    pdu_p->rel11.dmrs_config_flag = 0;
    pdu_p->rel11.nDmrs_csh_identity = 0;
    pdu_p->rel11.nPusch_identity = 0;
    pdu_p->rel11.virt_cell_id_en_flag = 0;
    pdu_p->rel13.ue_type = 0;
    pdu_p->rel13.total_num_of_repetition = 1;
    pdu_p->rel13.repetition_number = 1;
    pdu_p->rel13.initial_transmission_sf = 0xFFFF;
    pdu_p->rel13.empty_symbols_for_retuning = 0;
    #endif
    return sizeof(FAPI_T_ULSCH_PDU);
} // end of MAC_SIM_fapi_build_ulsch_pdu

static void* ys_qcBuildAndSendUlConfigMsg(YsCellCb   *cellCb,TfuRecpReqInfo  *recpReq)
{
    CmLList 		 *cmLstEnt;
    TfuUeRecpReqInfo *recpReqInfo;
    U8 prachTime;
    U8 rxSduSf;
    Data    *buff;
    U8       pdu_size;
    U8      n_ulsch_pdu, n_uci_pdu, n_srs_pdu;
    FAPI_T_PDU  *pdu_p;
    
#ifdef NXP_PLATFORM
    U32 total_ul_msg_size = 0;
    ltePhyL2ApiUlCfgVendor_t *ulCfgVendor = NULLP;
#else
    U32 total_ul_msg_size = 0;
#endif

    
    U32 ulConfigReqMsgSize = ys_qcCalcUlConfigMsgSize(recpReq,&n_ulsch_pdu,&n_uci_pdu,&n_srs_pdu, &total_ul_msg_size);
 

    FAPI_T_UL_CONFIG_REQ*	ulConfigReq = NULLP;
    TfuCrcIndInfo	  *crcIndInfo = NULLP;
    CmLteCellId cellId = cellCb->cellId;

    U16 indx = cellId - CM_START_CELL_ID;
#if 0
#ifndef TFU_TDD
	/* Send the CRC Indication to MAC for the corresponding subframe */
	//ret = ysUtlAllocEventMem((Ptr *)&crcIndInfo,sizeof(TfuCrcIndInfo));
	if(ysUtlAllocEventMem((Ptr *)&crcIndInfo,sizeof(TfuCrcIndInfo),indx, __FUNCTION__,__LINE__) == RFAILED)
	{
        printf("ys_qcCrcIndHndl malloc failed \n");
	    return;
	} /* end of if statement */

	cmLListInit(&(crcIndInfo->crcLst));
	crcIndInfo->cellId = ysCb.tfuSapLst[0]->cellCb->cellId;
	crcIndInfo->timingInfo.sfn = recpReq->timingInfo.sfn;
	crcIndInfo->timingInfo.subframe = recpReq->timingInfo.subframe;
#endif
#endif
    if(ysUtlAllocQCIPCSBuf(&buff, total_ul_msg_size, indx) != ROK)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"UlConfigReq SGetSBuf failed.\n");
        return NULLP;
    }

    ulConfigReq = (FAPI_T_UL_CONFIG_REQ*) buff;
    ulConfigReq->msg_hdr.type       = FAPI_E_UL_CONFIG_REQ;
    #ifndef NXP_PLATFORM
    ulConfigReq->msg_hdr.len_ven    = 0;
    #endif
    ulConfigReq->msg_hdr.len        = ulConfigReqMsgSize - sizeof(FAPI_T_MSG_HDR);

    ulConfigReq->sf_sfn             = (recpReq->timingInfo.sfn << 4)+ recpReq->timingInfo.subframe;
    ulConfigReq->length             = ulConfigReqMsgSize - sizeof(FAPI_T_MSG_HDR);
    ulConfigReq->n_pdu              = n_ulsch_pdu + n_uci_pdu + n_srs_pdu;
#ifdef NXP_PLATFORM
    if(n_ulsch_pdu)
    {
        ulConfigReq->msg_hdr.msgVdrSpecFlag = 1;
        ulCfgVendor =(ltePhyL2ApiUlCfgVendor_t* )(buff+ulConfigReqMsgSize);
        ulCfgVendor->vendorLength = sizeof(U16)+n_ulsch_pdu*sizeof(U32);
        ulCfgVendor->ulCfgVendor.numUEs = 0;
    }
    
#endif
    if(ulConfigReq->n_pdu != 0)
    {
        //printf("ulConfigReq->n_pdu = %d\n",ulConfigReq->n_pdu);
    }
#ifdef TFU_TDD
    prachTime = (recpReq->timingInfo.sfn & 0x1)* YS_NUM_SUB_FRAMES +
                recpReq->timingInfo.subframe;

    if((cellCb->prachCb.ysPrachPresArr[prachTime] != YS_PRACH_NOT_PRSNT))
    {
        ulConfigReq->rach_prach_frq_res = 1;
    }
    else
    {
        ulConfigReq->rach_prach_frq_res = 0;
    }
#else
    ulConfigReq->rach_prach_frq_res = (cellCb->prachCb.ysPrachPres &
         (0x01 << ((recpReq->timingInfo.sfn * YS_NUM_SUB_FRAMES)
                   + recpReq->timingInfo.subframe) % YS_NUM_PRACH_PRES_ARR))?1:0;
#endif

    if(0 != n_srs_pdu)
    {
        ulConfigReq->srs_present    = 1;
    }
    else
    {
        ulConfigReq->srs_present    = 0;
    }

//#ifdef TFU_TDD
    rxSduSf = (recpReq->timingInfo.subframe +3) % YS_NUM_SUB_FRAMES;
//#else
   // rxSduSf = (recpReq->timingInfo.subframe +2) % YS_NUM_SUB_FRAMES;
//#endif

    if(0 != ulConfigReq->n_pdu)
    {
        pdu_p = &(ulConfigReq->ul_pdu[0]);
        cmLstEnt = recpReq->ueRecpReqLst.first;
        while (cmLstEnt != NULLP)
        {
            recpReqInfo = (TfuUeRecpReqInfo*)cmLstEnt->node;
            pdu_size = sizeof(FAPI_T_PDU);

            if (recpReqInfo->type == TFU_RECP_REQ_PUCCH)
            {
                switch(recpReqInfo->t.pucchRecpReq.uciInfo)
                {
                    case TFU_PUCCH_HARQ:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_HARQ_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      FALSE,
                                                      FALSE,
                                                      TRUE);

                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe,
                                           cellId);
                        break;

                    case TFU_PUCCH_SR:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_SR_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      FALSE,
                                                      TRUE,
                                                      FALSE);
                        break;

                    case TFU_PUCCH_SRS:
                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti,
                                         (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]),
                                         &recpReqInfo->t.pucchRecpReq.srsInfo);
                        break;

                    case TFU_PUCCH_CQI:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_CQI_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      TRUE,
                                                      FALSE,
                                                      FALSE);
                        rgStats.gCqiRecpCount[indx]++;
                        break;

                    case TFU_PUCCH_HARQ_SR:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_SR_HARQ_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      FALSE,
                                                      TRUE,
                                                      TRUE);
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe,
                                           cellId);
                        break;

                    case TFU_PUCCH_HARQ_SRS:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_HARQ_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      FALSE,
                                                      FALSE,
                                                      TRUE);
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe,
                                           cellId);
                        pdu_p->pdu_size = pdu_size;
                        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);

                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti,
                                         (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]),
                                         &recpReqInfo->t.pucchRecpReq.srsInfo);
                        break;

                    case TFU_PUCCH_HARQ_CQI:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_CQI_HARQ_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      TRUE,
                                                      FALSE,
                                                      TRUE);
                        rgStats.gCqiRecpCount[indx]++;
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe,
                                           cellId);
                        break;

                    case TFU_PUCCH_HARQ_SR_SRS:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_SR_HARQ_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      FALSE,
                                                      TRUE,
                                                      TRUE);
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe,
                                           cellId);
                        pdu_p->pdu_size = pdu_size;
                        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);

                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti, (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]), &recpReqInfo->t.pucchRecpReq.srsInfo);
                        break;

                    case TFU_PUCCH_HARQ_SR_CQI:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_CQI_SR_HARQ_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      TRUE,
                                                      TRUE,
                                                      TRUE);
                        rgStats.gCqiRecpCount[indx]++;
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe, cellId);
                        break;

                    case TFU_PUCCH_SR_SRS:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_SR_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      FALSE,
                                                      TRUE,
                                                      FALSE);
                        pdu_p->pdu_size = pdu_size;
                        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);

                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti,
                                         (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]),
                                         &recpReqInfo->t.pucchRecpReq.srsInfo);
                        break;

                    case TFU_PUCCH_SR_CQI:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_CQI_SR_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      TRUE,
                                                      TRUE,
                                                      FALSE);
                        rgStats.gCqiRecpCount[indx]++;
                        break;

                    case TFU_PUCCH_HARQ_SR_CQI_SRS:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_CQI_SR_HARQ_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      TRUE,
                                                      TRUE,
                                                      TRUE);
                        rgStats.gCqiRecpCount[indx]++;
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe, cellId);
                        pdu_p->pdu_size = pdu_size;
                        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);
                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti,
                                         (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]),
                                         &recpReqInfo->t.pucchRecpReq.srsInfo);
                        break;

                    case TFU_PUCCH_SR_CQI_SRS:
                        pdu_p->pdu_type = FAPI_E_UL_UCI_CQI_SR_PDU;
                        pdu_size  += ys_qcBuildUciPdu(pdu_p,
                                                      recpReqInfo->rnti,
                                                      &recpReqInfo->t.pucchRecpReq.cqiInfo,
                                                      &recpReqInfo->t.pucchRecpReq.srInfo,
                                                      &recpReqInfo->t.pucchRecpReq.hqInfo,
                                                      TRUE,
                                                      TRUE,
                                                      FALSE);
                        rgStats.gCqiRecpCount[indx]++;
                        pdu_p->pdu_size = pdu_size;
                        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);

                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti,
                                         (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]),
                                         &recpReqInfo->t.pucchRecpReq.srsInfo);
                        break;
                }
            }
            else
            {
                cellCb->isCrcExptd[rxSduSf] = TRUE;
                switch(recpReqInfo->t.puschRecpReq.rcpInfo)
                {
                    case TFU_PUSCH_DATA:
                        pdu_p->pdu_type = FAPI_E_UL_ULSCH_PDU;
                        #ifdef NXP_PLATFORM
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo,&ulCfgVendor->ulCfgVendor);
                        #else
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo);
                        #endif
                        ys_qcAddtoCrcIndList(crcIndInfo,recpReqInfo->rnti);
                        break;

                    case TFU_PUSCH_DATA_SRS:
                        pdu_p->pdu_type = FAPI_E_UL_ULSCH_PDU;
                        #ifdef NXP_PLATFORM
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo,&ulCfgVendor->ulCfgVendor);
                        #else
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo);
                        #endif
                        pdu_p->pdu_size = pdu_size;
                        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);
                        ys_qcAddtoCrcIndList(crcIndInfo,recpReqInfo->rnti);
                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti,
                                         (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]),
                                         &recpReqInfo->t.puschRecpReq.srsInfo);
                        break;

                    case TFU_PUSCH_DATA_HARQ:
                        pdu_p->pdu_type = FAPI_E_UL_ULSCH_HARQ_PDU;
                        #ifdef NXP_PLATFORM
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo,&ulCfgVendor->ulCfgVendor);
                        #else
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo);
                        #endif
                        pdu_size  += ys_qcBuildHarqInfo((FAPI_T_ULSCH_HARQ_INFO*)((U8 *)pdu_p + pdu_size),
                                                         &recpReqInfo->t.puschRecpReq.hqInfo);
                        pdu_size  += ys_qcBuildInitParamsInfo((FAPI_T_ULSCH_INIT_TRANS_PARAM*)((U8 *)pdu_p + pdu_size),
                                                              &recpReqInfo->t.puschRecpReq);
                        ys_qcAddtoCrcIndList(crcIndInfo,recpReqInfo->rnti);
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe,
                                           cellId);
                        break;

                    case TFU_PUSCH_DATA_HARQ_SRS:
                        pdu_p->pdu_type = FAPI_E_UL_ULSCH_HARQ_PDU;
                        #ifdef NXP_PLATFORM
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo,&ulCfgVendor->ulCfgVendor);
                        #else
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo);
                        #endif
                        pdu_size  += ys_qcBuildHarqInfo((FAPI_T_ULSCH_HARQ_INFO*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.hqInfo);
                        pdu_size  += ys_qcBuildInitParamsInfo((FAPI_T_ULSCH_INIT_TRANS_PARAM*)((U8 *)pdu_p + pdu_size),
                                                              &recpReqInfo->t.puschRecpReq);
                        pdu_p->pdu_size = pdu_size;
                        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);
                        ys_qcAddtoCrcIndList(crcIndInfo,recpReqInfo->rnti);
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe,
                                           cellId);
                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti, (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]), &recpReqInfo->t.puschRecpReq.srsInfo);
                        break;

                    case TFU_PUSCH_DATA_CQI:
                        pdu_p->pdu_type =FAPI_E_UL_ULSCH_CQI_RI_PDU;
                        #ifdef NXP_PLATFORM
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo,&ulCfgVendor->ulCfgVendor);
                        pdu_size  += ys_NxpBuildCqiRiInfo((FAPI_T_ULSCH_CQI_RI_INFO_R8*)((U8 *)pdu_p + pdu_size),
                                                         &recpReqInfo->t.puschRecpReq.cqiRiInfo,
                                                         cellId);
                        
                        #else
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo);
                        pdu_size  += ys_qcBuildCqiRiInfo((FAPI_T_ULSCH_CQI_RI_INFO*)((U8 *)pdu_p + pdu_size),
                                                         &recpReqInfo->t.puschRecpReq.cqiRiInfo,
                                                         cellId);
                        #endif
                        
                        rgStats.gCqiRecpPuschCount[indx]++;
                        pdu_size  += ys_qcBuildInitParamsInfo((FAPI_T_ULSCH_INIT_TRANS_PARAM*)((U8 *)pdu_p + pdu_size),
                                                              &recpReqInfo->t.puschRecpReq);
                        ys_qcAddtoCrcIndList(crcIndInfo,recpReqInfo->rnti);
                        break;

                    case TFU_PUSCH_DATA_CQI_SRS:
                        pdu_p->pdu_type =FAPI_E_UL_ULSCH_CQI_RI_PDU;
                        #ifdef NXP_PLATFORM
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo,&ulCfgVendor->ulCfgVendor);
                        pdu_size  += ys_NxpBuildCqiRiInfo((FAPI_T_ULSCH_CQI_RI_INFO_R8*)((U8 *)pdu_p + pdu_size),
                                                         &recpReqInfo->t.puschRecpReq.cqiRiInfo,
                                                         cellId);
                        #else
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo);
                        
                        pdu_size  += ys_qcBuildCqiRiInfo((FAPI_T_ULSCH_CQI_RI_INFO*)((U8 *)pdu_p + pdu_size),
                                                         &recpReqInfo->t.puschRecpReq.cqiRiInfo,
                                                         cellId);
                        #endif
                        rgStats.gCqiRecpPuschCount[indx]++;
                        pdu_size  += ys_qcBuildInitParamsInfo((FAPI_T_ULSCH_INIT_TRANS_PARAM*)((U8 *)pdu_p + pdu_size),
                                                              &recpReqInfo->t.puschRecpReq);
                        pdu_p->pdu_size = pdu_size;
                        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);
                        ys_qcAddtoCrcIndList(crcIndInfo,recpReqInfo->rnti);
                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti,
                                         (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]),
                                         &recpReqInfo->t.puschRecpReq.srsInfo);
                        break;

                    case TFU_PUSCH_DATA_CQI_HARQ:
                        pdu_p->pdu_type = FAPI_E_UL_ULSCH_CQI_HARQ_RI_PDU;
                        #ifdef NXP_PLATFORM
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo,&ulCfgVendor->ulCfgVendor);
                        pdu_size  += ys_NxpBuildCqiRiInfo((FAPI_T_ULSCH_CQI_RI_INFO_R8*)((U8 *)pdu_p + pdu_size),
                                                         &recpReqInfo->t.puschRecpReq.cqiRiInfo,
                                                         cellId);
                        #else
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo);
                        pdu_size  += ys_qcBuildCqiRiInfo((FAPI_T_ULSCH_CQI_RI_INFO*)((U8 *)pdu_p + pdu_size),
                                                         &recpReqInfo->t.puschRecpReq.cqiRiInfo,
                                                         cellId);
                        #endif
                        
                        rgStats.gCqiRecpPuschCount[indx]++;
                        pdu_size  += ys_qcBuildHarqInfo((FAPI_T_ULSCH_HARQ_INFO*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.hqInfo);
                        pdu_size  += ys_qcBuildInitParamsInfo((FAPI_T_ULSCH_INIT_TRANS_PARAM*)((U8 *)pdu_p + pdu_size),
                                                              &recpReqInfo->t.puschRecpReq);
                        ys_qcAddtoCrcIndList(crcIndInfo,recpReqInfo->rnti);
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe,
                                           cellId);
                        break;

                    case TFU_PUSCH_DATA_CQI_HARQ_SRS:
                        pdu_p->pdu_type = FAPI_E_UL_ULSCH_CQI_HARQ_RI_PDU;
                        #ifdef NXP_PLATFORM
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo,&ulCfgVendor->ulCfgVendor);
                        pdu_size  += ys_NxpBuildCqiRiInfo((FAPI_T_ULSCH_CQI_RI_INFO_R8*)((U8 *)pdu_p + pdu_size),
                                                         &recpReqInfo->t.puschRecpReq.cqiRiInfo,
                                                         cellId);
                        #else
                        pdu_size  += ys_qcBuildUlschPdu(recpReqInfo->rnti,
                                                        (FAPI_T_ULSCH_PDU*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.ulSchInfo);
                        
                        pdu_size  += ys_qcBuildCqiRiInfo((FAPI_T_ULSCH_CQI_RI_INFO*)((U8 *)pdu_p + pdu_size),
                                                         &recpReqInfo->t.puschRecpReq.cqiRiInfo,
                                                         cellId);
                        #endif
                        rgStats.gCqiRecpPuschCount[indx]++;
                        pdu_size  += ys_qcBuildHarqInfo((FAPI_T_ULSCH_HARQ_INFO*)((U8 *)pdu_p + pdu_size),
                                                        &recpReqInfo->t.puschRecpReq.hqInfo);
                        pdu_size  += ys_qcBuildInitParamsInfo((FAPI_T_ULSCH_INIT_TRANS_PARAM*)((U8 *)pdu_p + pdu_size),
                                                              &recpReqInfo->t.puschRecpReq);
                        pdu_p->pdu_size = pdu_size;
                        pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);
                        ys_qcAddtoCrcIndList(crcIndInfo,recpReqInfo->rnti);
                        ys_qcAddtoHarqList(&recpReqInfo->t.pucchRecpReq.hqInfo,
                                           recpReqInfo->rnti,
                                           recpReq->timingInfo.sfn,
                                           recpReq->timingInfo.subframe,
                                           cellId);
                        pdu_p->pdu_type = FAPI_E_UL_SRS_PDU;
                        pdu_size = sizeof(FAPI_T_PDU) + sizeof(FAPI_T_SRS_PDU);
                        ys_qcBuildSrsPdu(recpReqInfo->rnti,
                                         (FAPI_T_SRS_PDU *)&(pdu_p->pdu[0]),
                                         &recpReqInfo->t.puschRecpReq.srsInfo);
                        break;
                }
            }
            pdu_p->pdu_size = pdu_size;
            pdu_p = (FAPI_T_PDU*)((U8 *)pdu_p + pdu_size);
            cmLstEnt = cmLstEnt->next;
        } /* cmLstEnt while */
    }

    ys_qcSendtoPhy((char*)ulConfigReq,total_ul_msg_size, (int)(cellCb->phyInstId));
    ysUtlFreeQCIPCSBuf(buff, total_ul_msg_size, indx);

    cellCb->ulEncL1Msgs[rxSduSf].tfuCrcIndInfo = crcIndInfo;

    return NULLP;
} // end of MAC_SIM_fapi_build_ul_config_msg

/*
*
*       Fun:   ysqcUlmPrcRecpReq
*
*       Desc:  Process Reception request
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_ul.c
*
*/
PUBLIC S16 ys_qcUlmPrcRecpReq
(
YsCellCb        *cellCb,
TfuRecpReqInfo  *recpReq
)
{
    ys_qcBuildAndSendUlConfigMsg(cellCb,recpReq);
    return (ROK);
} /* End of ysMsUlmPrcRecpReq */

U8 RachInterval[YS_LTE_MAX_CELLS] = {0};
void ys_qcRachIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{
    FAPI_T_RACH_IND* pRachInd = (FAPI_T_RACH_IND*)pMsgHdr;
    U8 i;
    TfuRaReqIndInfo         *rachIndInfo = NULLP;
    YsCellCb    *cellCb;
    S16 ret;
    EXTERN Bool g_ys_DC;
    
    if(RachInterval[carrierId] == 0)
    {
        return;
    }
    
    if(g_ys_DC == FALSE)
    {
      if(carrierId == 1)
      {
         //under CA mode, the scell shouldn't handle the rach_ind
         //it would be a mis-detecting
         return;
      }
    }

    
    for(i = 0; i < pRachInd->n_pre; i ++)
    {
        //if(((FAPI_T_RACH_IND_PRE*)(&(pRachInd->preamble[i])))->rel8.t_a < 35)
        {
            ret = SGetStaticBuffer(ysCb.ysInit[carrierId].region, ysCb.ysInit[carrierId].pool,  (Ptr *)&rachIndInfo, sizeof(TfuRaReqIndInfo), 0);
            if(ret == RFAILED)
            {
                STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRachIndHndl alloc memory failed\n");
                return;
            } /* end of if statement */

            cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
            cmMemset ((U8 *)rachIndInfo, 0, sizeof(TfuRaReqIndInfo));
            rachIndInfo->cellId 	  = cellCb->cellId;
            rachIndInfo->timingInfo.sfn   = pRachInd->sf_sfn >> 4;
            rachIndInfo->timingInfo.subframe  = pRachInd->sf_sfn & 0x0F;
            rachIndInfo->rachInfo.raRnti = ((FAPI_T_RACH_IND_PRE*)(&(pRachInd->preamble[i])))->rel8.rnti;
            rachIndInfo->rachInfo.raReqInfo.ta = ((FAPI_T_RACH_IND_PRE*)(&(pRachInd->preamble[i])))->rel8.t_a;
            rachIndInfo->rachInfo.raReqInfo.rapId = ((FAPI_T_RACH_IND_PRE*)(&(pRachInd->preamble[i])))->rel8.preabmle;
            rachIndInfo->rachInfo.raReqInfo.cqiPres = FALSE;
            rachIndInfo->rachInfo.raReqInfo.tpc = 3;   /* TPC = 0 */
            YsUiTfuRaReqInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, rachIndInfo);
            RachInterval[carrierId] = 0;
            break;
        }
    }

    return;
}

void ys_NxpRxUlschIndHndl(U8* pMsgHdr, const int carrierId)
{

    ltePhyL2ApiRxUlschInd_t* pRxUlschInd = (ltePhyL2ApiRxUlschInd_t*)pMsgHdr;
    U8 pdu_idx;
    TfuDatIndInfo   *tfuDatIndInfo = NULLP;   /* Tfu Dat Indication Information*/
    TfuDatInfo *datInfo = NULLP;
    YsCellCb    *cellCb;
    S16         ret;
    U16         lenInBytes = 0;
    void * vaddr;
    fsl_usmmgr_t* usmmgr_p;
    usmmgr_p = ac_getUsmMgr();

    cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
    
    for(pdu_idx = 0; pdu_idx < pRxUlschInd->numPdus; pdu_idx++)
    {
        if(pRxUlschInd->pdu[pdu_idx].dataOffs != 0)
        {
            if (tfuDatIndInfo == NULLP)
            {
                ret = ysUtlAllocEventMem((Ptr *)&tfuDatIndInfo, sizeof(TfuDatIndInfo), carrierId, __FUNCTION__,__LINE__);
                if(ret == RFAILED)
                {
                    STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcRxUlschIndHndl tfuDatIndInfo malloc failed\n ");
                    return;
                } /* end of if statement */
                cmLListInit(&(tfuDatIndInfo->datIndLst));
            }
            
            tfuDatIndInfo->cellId = cellCb->cellId;
            tfuDatIndInfo->timingInfo.sfn = pRxUlschInd->SFN_SF >> 4;
            tfuDatIndInfo->timingInfo.subframe = pRxUlschInd->SFN_SF & 0x0F;
            lenInBytes = pRxUlschInd->pdu[pdu_idx].length;
            if(ysUtlGetEventMem(&tfuDatIndInfo->memCp, sizeof(TfuDatInfo), (Ptr *)&datInfo) != ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcRxUlschIndHndl malloc failed \n");
                return;
            }

#ifndef TENB_RTLIN_CHANGES
            SGetMsg(CL_REGION, 2, &datInfo->mBuf);
#else
            YS_MS_ALLOC_BUF(datInfo->mBuf, carrierId);
            {
                extern U32 ulIccAlocCnt;
                extern U32 gMemoryAlarm;
                extern U32 totalUlPkts;
                totalUlPkts++;
                if(gMemoryAlarm)
                    ulIccAlocCnt++;
            }
#endif

            datInfo->rnti = pRxUlschInd->pdu[pdu_idx].rnti;
            vaddr = fsl_usmmgr_p2v(pRxUlschInd->pdu[pdu_idx].handle, *usmmgr_p);

            ret = SAddPstMsgMult((Data*)((U8*)vaddr), lenInBytes, datInfo->mBuf);
            if(ret != ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcRxUlschIndHndl copy failed\n");
                YS_MS_FREE_BUF(datInfo->mBuf);
                return;
            } /* end of if statement */

            datInfo->lnk.node = (PTR)datInfo;
            cmLListAdd2Tail(&(tfuDatIndInfo->datIndLst), &(datInfo->lnk));
        }
    }

    if (tfuDatIndInfo != NULLP)
    {
        if(tfuDatIndInfo->datIndLst.count > 0)
        {
            YsUiTfuDatInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, tfuDatIndInfo);
        } /* end of if statement */
        else
        {
            YS_FREE_SDU(tfuDatIndInfo);
        }/* end of else part */
    }

    ys_NxpUlCqiInUlSchHndl(pMsgHdr, carrierId);
    ys_NxpPrcTmAdvInd(pMsgHdr, carrierId);

    return;
}
void ys_NxpRxErrorIndHndl(U8* pMsgHdr, const int carrierId)
{

    ltePhyL2ApiErrorIndAll_t* pErrorInd = (ltePhyL2ApiErrorIndAll_t*)((U8*)pMsgHdr+sizeof(ltePhyL2ApiMsgHdr_t));
    apiErrorIndStru_t *errorIndStru;
    U8 pdu_idx;
    U32 offset = sizeof(U32);
    STKLOG(STK_MD_YS,STK_LOG_INFO,"ltePhyL2ApiErrorIn received allErrorNum %d \n",
                           pErrorInd->allErrorNum);

    for(pdu_idx = 0; pdu_idx < pErrorInd->allErrorNum; pdu_idx++)
    {
        errorIndStru =(apiErrorIndStru_t * )((U8 *)pErrorInd+offset);
        STKLOG(STK_MD_YS,STK_LOG_INFO,"ltePhyL2ApiErrorIn messageId %d errorCode %d\n",
                       errorIndStru->messageId, errorIndStru->errorCode);
        if(errorIndStru->errorCode == API_ERRCODES_SFN_OUT_OF_SYNC)
        {
            offset += 2*sizeof(U8)+sizeof(apiErrorInd_sfn_t);
        }
        else if(errorIndStru->errorCode == API_ERRCODES_MSG_PDU_ERR)
        {
            offset += 2*sizeof(U8)+sizeof(apiErrorInd_pdu_all_t);
        }
        else if(errorIndStru->errorCode == API_ERRCODES_MSG_HI_ERR)
        {
            offset += 2*sizeof(U8)+sizeof(apiErrorInd_hi_all_t);
        }
        else if(errorIndStru->errorCode == API_ERRCODES_MSG_TX_ERR)
        {
            offset += 2*sizeof(U8)+sizeof(apiErrorInd_tx_all_t);
        }
    }

    return;
}

void ys_qcRxUlschIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{
    FAPI_T_RX_ULSCH_IND* pRxUlschInd = (FAPI_T_RX_ULSCH_IND*)pMsgHdr;
    U8 pdu_idx;
    TfuDatIndInfo   *tfuDatIndInfo = NULLP;   /* Tfu Dat Indication Information*/
    TfuDatInfo *datInfo = NULLP;
    YsCellCb    *cellCb;
    S16         ret;
    U16         lenInBytes = 0;
    U16         dataoffset = 0;

    cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
    dataoffset = pRxUlschInd->n_pdu*sizeof(FAPI_T_RX_ULSCH_IND_PDU) +sizeof(FAPI_T_RX_ULSCH_IND);
    for(pdu_idx = 0; pdu_idx < pRxUlschInd->n_pdu; pdu_idx++)
    {
        if(pRxUlschInd->pdu[pdu_idx].rel8.data_offset != 0)
        {
            if (tfuDatIndInfo == NULLP)
            {
                ret = ysUtlAllocEventMem((Ptr *)&tfuDatIndInfo, sizeof(TfuDatIndInfo), carrierId, __FUNCTION__,__LINE__);
                if(ret == RFAILED)
                {
                    STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxUlschIndHndl tfuDatIndInfo malloc failed\n ");
                    return;
                } /* end of if statement */
                cmLListInit(&(tfuDatIndInfo->datIndLst));
            }
            
            tfuDatIndInfo->cellId = cellCb->cellId;
            tfuDatIndInfo->timingInfo.sfn = pRxUlschInd->sf_sfn >> 4;
            tfuDatIndInfo->timingInfo.subframe = pRxUlschInd->sf_sfn & 0x0F;
            lenInBytes = pRxUlschInd->pdu[pdu_idx].rel8.length;
            if(ysUtlGetEventMem(&tfuDatIndInfo->memCp, sizeof(TfuDatInfo), (Ptr *)&datInfo) != ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxUlschIndHndl malloc failed \n");
                return;
            }

#ifndef TENB_RTLIN_CHANGES
            SGetMsg(CL_REGION, 2, &datInfo->mBuf);
#else
            YS_MS_ALLOC_BUF(datInfo->mBuf, carrierId);
            {
                extern U32 ulIccAlocCnt;
                extern U32 gMemoryAlarm;
                extern U32 totalUlPkts;
                totalUlPkts++;
                if(gMemoryAlarm)
                    ulIccAlocCnt++;
            }
#endif

            datInfo->rnti = pRxUlschInd->pdu[pdu_idx].rx_ue_info.rnti;
            ret = SAddPstMsgMult((Data*)((U8*)pRxUlschInd+dataoffset), lenInBytes, datInfo->mBuf);
            if(ret != ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxUlschIndHndl copy failed\n");
                YS_MS_FREE_BUF(datInfo->mBuf);
                return;
            } /* end of if statement */

            datInfo->lnk.node = (PTR)datInfo;
            cmLListAdd2Tail(&(tfuDatIndInfo->datIndLst), &(datInfo->lnk));
            dataoffset += lenInBytes;
        }
    }

    if (tfuDatIndInfo != NULLP)
    {
        if(tfuDatIndInfo->datIndLst.count > 0)
        {
            YsUiTfuDatInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, tfuDatIndInfo);
        } /* end of if statement */
        else
        {
            YS_FREE_SDU(tfuDatIndInfo);
        }/* end of else part */
    }

    ys_qcUlCqiInUlSchHndl(pMsgHdr, carrierId);
    ys_qcPrcTmAdvInd(pMsgHdr, carrierId);

    return;
}

void ys_qcCrcIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{
    FAPI_T_CRC_IND* pCrcInd = (FAPI_T_CRC_IND*)pMsgHdr;
    TfuCrcIndInfo	  *crcIndInfo = NULLP;
    TfuCrcInfo  *crcInfo;
    S16         ret;
    U16         crc_idx = 0;
    YsCellCb    *cellCb;

    cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
    /* Send the CRC Indication to MAC for the corresponding subframe */

    ret = ysUtlAllocEventMem((Ptr *)&crcIndInfo,sizeof(TfuCrcIndInfo), carrierId, __FUNCTION__,__LINE__);
    if(ret == RFAILED)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcCrcIndHndl malloc failed \n");
        return;
    } /* end of if statement */

    cmLListInit(&(crcIndInfo->crcLst));
    crcIndInfo->cellId = cellCb->cellId;
    crcIndInfo->timingInfo.sfn = pCrcInd->sf_sfn >>4;
    crcIndInfo->timingInfo.subframe = pCrcInd->sf_sfn & 0x0F;
    //printf("crcIndInfo->timingInfo.sfn %d  crcIndInfo->timingInfo.subframe%d\n",crcIndInfo->timingInfo.sfn,crcIndInfo->timingInfo.subframe);
    for(crc_idx = 0; crc_idx < pCrcInd->n_crc; crc_idx++)
    {
        if (ysUtlGetEventMem(&crcIndInfo->memCp, sizeof(TfuCrcInfo), (Ptr *)&crcInfo) != ROK)
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcCrcIndHndl  mallco crcInfo failed\n");
            return;
        } /* end of if statement */

        crcInfo->rnti = pCrcInd->pdu[crc_idx].rx_ue_info.rnti;
        crcInfo->isFailure = pCrcInd->pdu[crc_idx].crc_flag;
        crcInfo->lnk.node = (PTR)crcInfo;

        /* begin: add by yaoyuan for ue stk log to web */ 
        if(crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1] >= 0 && crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1] < WEB_LOG_ARRAY_COUNT)
        {
            if(crcInfo->isFailure == TRUE)
            {
                rgStats.webUeLog[cellCb->cellId - 1][crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1]].rnti = crcInfo->rnti;
                rgStats.webUeLog[cellCb->cellId - 1][crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1]].ulNackCnt ++;
            }
            else
            {
                rgStats.webUeLog[cellCb->cellId - 1][crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1]].rnti = crcInfo->rnti;
                rgStats.webUeLog[cellCb->cellId - 1][crcInfo->rnti - g_MacRntiStart[cellCb->cellId - 1]].ulAckCnt ++;
            }
        }
        /* end: add by luopeng for ue stk log to web */ 

           
        cmLListAdd2Tail(&(crcIndInfo->crcLst), &(crcInfo->lnk));
    }
    #ifdef NXP_PLATFORM
    cellCb->ulEncL1Msgs[(crcIndInfo->timingInfo.subframe+2)%10].tfuCrcIndInfo = crcIndInfo;
    #else
    YsUiTfuCrcInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId,crcIndInfo);
    #endif
    return;
}

void ys_qcRxSrIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{
    FAPI_T_RX_SR_IND* pRxSrInd = (FAPI_T_RX_SR_IND *)pMsgHdr;
    S16          ret;
    TfuSrInfo    *srInfo = NULLP;
    TfuSrIndInfo    *srIndInfo = NULLP;
    U16          sr_idx = 0;
    YsCellCb    *cellCb;
    
    cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);

    for(sr_idx = 0; sr_idx < pRxSrInd->n_sr ; sr_idx++)
    {
        if(srIndInfo == NULLP)
        {
            ret = ysUtlAllocEventMem((Ptr *)&srIndInfo, sizeof(TfuSrIndInfo), carrierId, __FUNCTION__,__LINE__);
            if(ret == RFAILED)
            {
                STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxSrIndHndl srIndInfo alloc failed\n");
                return;
            }

            cmLListInit(&(srIndInfo->srLst));
            srIndInfo->cellId = cellCb->cellId;
            srIndInfo->timingInfo.sfn = pRxSrInd->sf_sfn >> 4;
            srIndInfo->timingInfo.subframe = pRxSrInd->sf_sfn & 0x0F;
        }

        if (ysUtlGetEventMem(&srIndInfo->memCp, sizeof(TfuSrInfo), (Ptr *)&srInfo) != ROK)
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxSrIndHndl srInfo malloc failed \n");
        } /* end of if statement */
#ifndef TFU_ALLOC_EVENT_NO_INIT 
        cmMemset ((U8 *)srInfo, 0, sizeof(TfuSrInfo));
#endif

        srInfo->rnti = pRxSrInd->pdu[sr_idx].rx_ue_info.rnti;
        srInfo->lnk.node = (PTR)srInfo;
        cmLListAdd2Tail(&(srIndInfo->srLst), &(srInfo->lnk));
        rgStats.srDetCount++;
    } /* end of else statement */

    if(pRxSrInd->n_sr)
    {
        YsUiTfuSrInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, srIndInfo);
    }
    return;
}

void ys_qcHarqIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{
    FAPI_T_HARQ_TDD_IND          *pHarqInd = (FAPI_T_HARQ_TDD_IND *)pMsgHdr;
    S16                          ret = ROK;
    TfuHqIndInfo                 *harqIndInfo = NULLP;
    TfuHqInfo                    *harqInfo = NULLP;    
    YsCellCb                     *cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
#ifdef TFU_TDD
    U8                           pucchMVal = YsTddPucchMTable[cellCb->ulDlCfgIdx][pHarqInd->sf_sfn & 0x0F];
    U8                           mIdx;
#endif
#ifndef TFU_TDD
    U8 tb_count = 0;
#endif
    U16                          harq_idx = 0;
    U16                          data_offset = 0;    
    FAPI_T_HARQ_TDD_IND_PDU      *harqPdu = NULLP;
    YsUeCb                       *ueCb;
    TfuPucchDeltaPwrIndInfo      *pucchDeltaPwrIndInfo = NULLP;
    TfuPucchDeltaPwr             *pucchDeltaPwrInfo = NULLP;
    S8                           pucchDeltaPwr = 0;
    FAPI_T_UL_CQI_INFORMATION    *ulCqiInfo_p = NULLP;

    /* Allocate memory for harq indication */
    ret = ysUtlAllocEventMem((Ptr *)&harqIndInfo, sizeof(TfuHqIndInfo), carrierId, __FUNCTION__,__LINE__);
    if(ret == RFAILED)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcHarqIndHndl harqIndInfo malloc failed \n");
        return;
    }
    cmLListInit(&(harqIndInfo->hqIndLst));
    harqIndInfo->cellId = cellCb->cellId;
    harqIndInfo->timingInfo.sfn = pHarqInd->sf_sfn >> 4;
    harqIndInfo->timingInfo.subframe = pHarqInd->sf_sfn & 0x0F;

    /* Allocate memory for PUCCH power control */
    ret = ysUtlAllocEventMem((Ptr *)&pucchDeltaPwrIndInfo, sizeof(TfuPucchDeltaPwrIndInfo), carrierId, __FUNCTION__, __LINE__);
    if(ret == RFAILED)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR, "pucchDeltaPwrIndInfo(): Memory allocation failed \n");
        return;
    }
    cmLListInit(&(pucchDeltaPwrIndInfo->pucchDeltaPwrLst));
    pucchDeltaPwrIndInfo->cellId = cellCb->cellId;
    pucchDeltaPwrIndInfo->timingInfo.sfn = pHarqInd->sf_sfn >> 4;
    pucchDeltaPwrIndInfo->timingInfo.subframe = pHarqInd->sf_sfn & 0x0F;

    for(harq_idx = 0; harq_idx < pHarqInd->n_harq; harq_idx++)
    {
        harqPdu = (FAPI_T_HARQ_TDD_IND_PDU *)((U8 *)pHarqInd->pdu + data_offset);
        ulCqiInfo_p = (FAPI_T_UL_CQI_INFORMATION*)((U8*)harqPdu + sizeof(FAPI_T_HARQ_TDD_IND_PDU) + harqPdu->n_ack_nack * sizeof(U8));
        data_offset += sizeof(FAPI_T_HARQ_TDD_IND_PDU)
                       + harqPdu->n_ack_nack * sizeof(U8)
                       + sizeof(FAPI_T_UL_CQI_INFORMATION); // ul cqi field reported by QC PHY, but not specified in fapApiInternal.h, so add it to offset here!

        /* Allocate memory for harq indication per UE */
        if (ysUtlGetEventMem(&harqIndInfo->memCp, sizeof(TfuHqInfo), (Ptr *)&harqInfo) != ROK)
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcHarqIndHndl harqInfo malloc failed \n");
            return;
        }
        cmMemset ((U8 *)harqInfo, 0, sizeof(TfuHqInfo));
#ifdef TFU_TDD
        harqInfo->M = pucchMVal;
#endif
        harqInfo->rnti = harqPdu->rx_ue_info.rnti;

        if (1 != harqPdu->rx_ue_info.handle)
        {
            harqInfo->hqFdbkMode = harqPdu->mode;
            harqInfo->isPusch = TRUE;
#ifdef TFU_TDD
            if(TFU_ACK_NACK_SPECIAL_BUNDLING == harqPdu->mode)
            {
                harqInfo->isAck[0] = harqInfo->isAck[1] = harqPdu->harq_data[0].value_0;
            }
            else if(TFU_ACK_NACK_BUNDLING == harqPdu->mode)
            {
                harqInfo->isAck[0] = harqPdu->harq_data[0].value_0;
                if (harqPdu->n_ack_nack == 2)
                {
                    harqInfo->isAck[1] = harqPdu->harq_data[1].value_0;
                }
            }
            else
            {
                /* TDD_TODO: Need to add support for M>1 multiplexing */
                for(mIdx = 0; mIdx < harqPdu->n_ack_nack; mIdx++)
                {
                    harqInfo->isAck[mIdx] = harqPdu->harq_data[mIdx].value_0;
                    if(harqInfo->isAck[mIdx] == TFU_HQ_ACK_OR_DTX)
                    {
                        harqInfo->isAck[mIdx] = TFU_HQ_ACK;
                    }
                }
            }
#else
            harqInfo->noOfTbs = (TfuHqFdbk)harqPdu->n_ack_nack;
            for(tb_count= 0; tb_count < harqInfo->noOfTbs; tb_count++)
            {
                harqInfo->isAck[tb_count]= (TfuHqFdbk)harqPdu->harq_data[tb_count].value_0;
                if(harqPdu->harq_data[tb_count].value_0 != 1)
                {
                //RLOG1(L_DEBUG, "NACK RNTI %d", harqInfo->rnti);
                }
            }
#endif
        }
        else
        {
            //handle pucch power
            ueCb = ysMsCfgGetUe(cellCb, harqInfo->rnti);
            if((ueCb!= NULLP) && updatePucchSNR(ulCqiInfo_p->ul_cqi, ueCb, &pucchDeltaPwr))
            {
                if (ysUtlGetEventMem(&pucchDeltaPwrIndInfo->memCp, sizeof(TfuPucchDeltaPwr), (Ptr *)&pucchDeltaPwrInfo) != ROK)
                {
                    STKLOG(STK_MD_YS,STK_LOG_ERR, "pucchDeltaPwrInfo: ysUtlGetEventMem returned failure\n");
                    return;
                }
                cmMemset ((U8 *)pucchDeltaPwrInfo, 0, sizeof(TfuPucchDeltaPwr));
                pucchDeltaPwrInfo->rnti = harqInfo->rnti;
                pucchDeltaPwrInfo->pucchDeltaPwr = pucchDeltaPwr;
                pucchDeltaPwrInfo->lnk.node = (PTR)pucchDeltaPwrInfo;
                cmLListAdd2Tail(&(pucchDeltaPwrIndInfo->pucchDeltaPwrLst), &(pucchDeltaPwrInfo->lnk));
            }
            harqInfo->hqFdbkMode = harqPdu->mode;
            harqInfo->isPusch = FALSE;
#ifdef TFU_TDD
            if(TFU_ACK_NACK_BUNDLING == harqPdu->mode)
            {
                harqInfo->isAck[0] = harqPdu->harq_data[0].value_0;
                if(harqInfo->isAck[0] != 1)
                {
                   // printf("harq %d %d %d %d\n",harqInfo->rnti,harqInfo->isAck[0],pHarqInd->sf_sfn >> 4,pHarqInd->sf_sfn & 0x0F);
                }
                if (harqPdu->n_ack_nack == 2)
                {
                    harqInfo->isAck[1] = harqPdu->harq_data[1].value_0;
                    if(harqInfo->isAck[1] != 1)
                    {
                        //printf("2 NACK %d %d %d %d\n",harqInfo->rnti,harqPdu->harq_data[1],pHarqInd->sf_sfn >> 4,pHarqInd->sf_sfn & 0x0F);
                    }
                }
            }
            else if(TFU_ACK_NACK_SPECIAL_BUNDLING == harqPdu->mode)
            {
                harqInfo->isAck[0] = harqInfo->isAck[1] = harqPdu->harq_data[0].value_0;
            }
            else
            {
                /* TDD_TODO: Need to add support for M>1 multiplexing */ 
                for(mIdx = 0; mIdx < harqPdu->n_ack_nack; mIdx++)
                {
                    harqInfo->isAck[mIdx] = harqPdu->harq_data[mIdx].value_0;
                    if(harqInfo->isAck[mIdx] == TFU_HQ_ACK_OR_DTX)
                    {
                        harqInfo->isAck[mIdx] = TFU_HQ_ACK;
                    }
                }
            }
#else
            harqInfo->noOfTbs = (TfuHqFdbk)harqPdu->n_ack_nack;
            for(tb_count= 0; tb_count < harqInfo->noOfTbs; tb_count++)
            {
                harqInfo->isAck[tb_count]= (TfuHqFdbk)harqPdu->harq_data[tb_count].value_0;
                if(harqPdu->harq_data[tb_count].value_0 != 1)
                {
                //RLOG1(L_DEBUG, "NACK RNTI %d", harqInfo->rnti);
                }
            }
#endif
        }
      
        harqInfo->lnk.node = (PTR)harqInfo;
        cmLListAdd2Tail(&(harqIndInfo->hqIndLst), &(harqInfo->lnk));
    } 

    if(harqIndInfo->hqIndLst.count > 0)
    {
        YsUiTfuHqInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, harqIndInfo);
    }
    else
    {
        YS_FREE_SDU(harqIndInfo);
    }

    if (pucchDeltaPwrIndInfo->pucchDeltaPwrLst.count > 0)
    {
        YsUiTfuPucchDeltaPwrInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, pucchDeltaPwrIndInfo);
    }
    else
    {
        YS_FREE_SDU(pucchDeltaPwrIndInfo);
    }

    return;
}

void ys_NxpUlCqiInUlSchHndl(U8* pMsgHdr, const int carrierId)
{
    ltePhyL2ApiRxUlschInd_t* pRxUlschInd = (ltePhyL2ApiRxUlschInd_t*)pMsgHdr;
    TfuUlCqiIndInfo   *ulCqiInd = NULLP;
    TfuUlCqiRpt       *ulCqiRpt = NULLP;
    YsUeCb            *ueCb = NULLP;
    U8                wideCqi;
    S8                tmpUlSinr;
    U16               rnti;
    U16               pdu_idx;
    U32               currentTti, ttiDiff;
    U8                ulCqiAlphaFactor;
    U8                ulCqiBeltaFactor;
    YsCellCb    *cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);

    for(pdu_idx = 0; pdu_idx < pRxUlschInd->numPdus; pdu_idx++)
    {
        if(pRxUlschInd->pdu[pdu_idx].length == 0)
        {
            continue;
        }
        rnti = pRxUlschInd->pdu[pdu_idx].rnti;
        ueCb = ysMsCfgGetUe(cellCb, rnti);
        if (ueCb == NULLP)
        {
            STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcRxCqiIndHndl UE [%d] doesnt exist\n", rnti);
            return;
        }
        /* Smooting algorithm weighs the last report and all the previous */
        /* reports equally. */
        /* wideCqi is used for UL LA, ulSinr is used for UL power ctrl */
        wideCqi = ys_qcGetUlCqi(cellCb, pRxUlschInd->pdu[pdu_idx].ulCqi);         
        tmpUlSinr = (S8)(pRxUlschInd->pdu[pdu_idx].ulCqi - 128) / 2;
        /* KINGTA: UL Cqi filter can be set from CLI
        * Here the ulCqiFactorAlpha must from 0 - 10
        * Because the OAM has already limit the value to be 0 - 10
        * Here may not need to check the value.
        */
        ulCqiAlphaFactor = cellCb->cellCfg.ulCqiFactorAlpha;
        ulCqiBeltaFactor = 10 - ulCqiAlphaFactor;

        /* lastRptdUlCqi is used for UL LA, lastRptUlSINR is used for UL power ctrl */
        ueCb->lastRptdUlCqi = (ueCb->lastRptdUlCqi * ulCqiAlphaFactor)/10;
        ueCb->lastRptdUlCqi += (wideCqi *  ulCqiBeltaFactor);

        ueCb->lastRptUlSINR = (ueCb->lastRptUlSINR * 8)/10;
        ueCb->lastRptUlSINR += (tmpUlSinr * 2);

        currentTti = (((pRxUlschInd->SFN_SF >> 4)* 10) + (pRxUlschInd->SFN_SF & 0x0F));
        if (currentTti < ueCb->ulCqiLastTti)
        {
            ttiDiff = ((currentTti + 10240) - ueCb->ulCqiLastTti);
        }
        else
        {
            ttiDiff = (currentTti - ueCb->ulCqiLastTti);
        }

        /* Send UL CQI once every 20ms */
        if ((ueCb->numCqiSmps < 10) || (ttiDiff < 80))
        {
            ueCb->numCqiSmps++;
            continue;
        }

        ueCb->numCqiSmps = 0;
        ueCb->ulCqiLastTti = currentTti;

        if(NULLP == ulCqiInd)
        {
            S16 ret;

            /* Allocate memory for the structures corresponding to the sub frame.*/
            ret = ysUtlAllocEventMem((Ptr *)&ulCqiInd, sizeof(TfuUlCqiIndInfo), carrierId, __FUNCTION__,__LINE__);
            if(ret == RFAILED)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcRxCqiIndHndl ulCqiInd malloc failed \n");
                return;
            }

            cmLListInit(&(ulCqiInd->ulCqiRpt));
            ulCqiInd->cellId = cellCb->cellId;
            ulCqiInd->timingInfo.sfn = pRxUlschInd->SFN_SF >> 4;
            ulCqiInd->timingInfo.subframe = pRxUlschInd->SFN_SF & 0x0F;
        }

        if (ysUtlGetEventMem(&ulCqiInd->memCp, sizeof(TfuUlCqiRpt), (Ptr *)&ulCqiRpt) != ROK)
        {
            ysUtlFreeEventMem(ulCqiInd);
            STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcRxCqiIndHndl ulCqiRpt malloc failed \n");
            return;
        }

        /* Added for Limiting the CQI for stability Check*/
#ifdef LIMIT_DL_UL_CQI
        if (ueCb->lastRptdUlCqi >= 10)
        {
            ueCb->lastRptdUlCqi = 10;
        }
#endif

        /* Fill the report with the values */
        ulCqiRpt->isTxPort0 = TRUE;

        /* wideCqi is used for UL LA, ulSinr is used for UL power ctrl */
        ulCqiRpt->wideCqi = /*10;*/(ueCb->lastRptdUlCqi + 5)/10;
        ulCqiRpt->ulSinr = /*30;*/(ueCb->lastRptUlSINR + 5)/10;
        ulCqiRpt->rnti = rnti;
        ulCqiRpt->numSubband = 0;
        ulCqiRpt->lnk.node = (PTR)ulCqiRpt;
        cmLListAdd2Tail(&(ulCqiInd->ulCqiRpt), &(ulCqiRpt->lnk));
    }

    if (ulCqiInd != NULLP)
    {
        if(ulCqiInd->ulCqiRpt.count > 0 )
        {
            YsUiTfuUlCqiInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, ulCqiInd);
        } /* end of if statement */
        else
        {
            YS_FREE_SDU(ulCqiInd);
        }/* end of else part */
    }
    return;
}

void ys_qcUlCqiInUlSchHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{
    FAPI_T_RX_ULSCH_IND* pRxUlschInd = (FAPI_T_RX_ULSCH_IND*)pMsgHdr;
    TfuUlCqiIndInfo   *ulCqiInd = NULLP;
    TfuUlCqiRpt       *ulCqiRpt = NULLP;
    YsUeCb            *ueCb = NULLP;
    U8                wideCqi;
    S8                tmpUlSinr;
    U16               rnti;
    U16               pdu_idx;
    U32               currentTti, ttiDiff;
    U8                ulCqiAlphaFactor;
    U8                ulCqiBeltaFactor;
    YsCellCb    *cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);

    for(pdu_idx = 0; pdu_idx < pRxUlschInd->n_pdu; pdu_idx++)
    {
        if(pRxUlschInd->pdu[pdu_idx].rel8.data_offset == 0)
        {
            continue;
        }
        rnti = pRxUlschInd->pdu[pdu_idx].rx_ue_info.rnti;
        ueCb = ysMsCfgGetUe(cellCb, rnti);
        if (ueCb == NULLP)
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxCqiIndHndl UE [%d] doesnt exist\n", rnti);
            return;
        }
        /* Smooting algorithm weighs the last report and all the previous */
        /* reports equally. */
        /* wideCqi is used for UL LA, ulSinr is used for UL power ctrl */
        wideCqi = ys_qcGetUlCqi(cellCb, pRxUlschInd->pdu[pdu_idx].rel8.ul_cqi);         
        tmpUlSinr = (S8)(pRxUlschInd->pdu[pdu_idx].rel8.ul_cqi - 128) / 2;
        /* KINGTA: UL Cqi filter can be set from CLI
        * Here the ulCqiFactorAlpha must from 0 - 10
        * Because the OAM has already limit the value to be 0 - 10
        * Here may not need to check the value.
        */
        ulCqiAlphaFactor = cellCb->cellCfg.ulCqiFactorAlpha;
        ulCqiBeltaFactor = 10 - ulCqiAlphaFactor;

        /* lastRptdUlCqi is used for UL LA, lastRptUlSINR is used for UL power ctrl */
        ueCb->lastRptdUlCqi = (ueCb->lastRptdUlCqi * ulCqiAlphaFactor)/10;
        ueCb->lastRptdUlCqi += (wideCqi *  ulCqiBeltaFactor);

        ueCb->lastRptUlSINR = (ueCb->lastRptUlSINR * 8)/10;
        ueCb->lastRptUlSINR += (tmpUlSinr * 2);

        currentTti = (((pRxUlschInd->sf_sfn >> 4)* 10) + (pRxUlschInd->sf_sfn & 0x0F));
        if (currentTti < ueCb->ulCqiLastTti)
        {
            ttiDiff = ((currentTti + 10240) - ueCb->ulCqiLastTti);
        }
        else
        {
            ttiDiff = (currentTti - ueCb->ulCqiLastTti);
        }

        /*begin: add by yaoyun for ue stk log to web*/
        if(rnti - g_MacRntiStart[cellCb->cellId - 1] >= 0 && rnti - g_MacRntiStart[cellCb->cellId - 1] < WEB_LOG_ARRAY_COUNT )
        {
            rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].rnti = rnti;
            rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].sinrCnt++;
            rgStats.webUeLog[cellCb->cellId - 1][rnti - g_MacRntiStart[cellCb->cellId - 1]].ulSinr += (ueCb->lastRptUlSINR + 5)/10; 
        }
        /*end: add by yaoyuan for ue stk log to web*/
   
        /* Send UL CQI once every 20ms */
        if ((ueCb->numCqiSmps < 10) || (ttiDiff < 80))
        {
            ueCb->numCqiSmps++;
            continue;
        }

        ueCb->numCqiSmps = 0;
        ueCb->ulCqiLastTti = currentTti;

        if(NULLP == ulCqiInd)
        {
            S16 ret;

            /* Allocate memory for the structures corresponding to the sub frame.*/
            ret = ysUtlAllocEventMem((Ptr *)&ulCqiInd, sizeof(TfuUlCqiIndInfo), carrierId, __FUNCTION__,__LINE__);
            if(ret == RFAILED)
            {
                STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxCqiIndHndl ulCqiInd malloc failed \n");
                return;
            }

            cmLListInit(&(ulCqiInd->ulCqiRpt));
            ulCqiInd->cellId = cellCb->cellId;
            ulCqiInd->timingInfo.sfn = pRxUlschInd->sf_sfn >> 4;
            ulCqiInd->timingInfo.subframe = pRxUlschInd->sf_sfn & 0x0F;
        }

        if (ysUtlGetEventMem(&ulCqiInd->memCp, sizeof(TfuUlCqiRpt), (Ptr *)&ulCqiRpt) != ROK)
        {
            ysUtlFreeEventMem(ulCqiInd);
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxCqiIndHndl ulCqiRpt malloc failed \n");
            return;
        }

        /* Added for Limiting the CQI for stability Check*/
#ifdef LIMIT_DL_UL_CQI
        if (ueCb->lastRptdUlCqi >= 10)
        {
            ueCb->lastRptdUlCqi = 10;
        }
#endif

        /* Fill the report with the values */
        ulCqiRpt->isTxPort0 = TRUE;

        /* wideCqi is used for UL LA, ulSinr is used for UL power ctrl */
        ulCqiRpt->wideCqi = /*10;*/(ueCb->lastRptdUlCqi + 5)/10;
        ulCqiRpt->ulSinr = /*30;*/(ueCb->lastRptUlSINR + 5)/10;
        ulCqiRpt->rnti = rnti;
        ulCqiRpt->numSubband = 0;
        ulCqiRpt->lnk.node = (PTR)ulCqiRpt;
        cmLListAdd2Tail(&(ulCqiInd->ulCqiRpt), &(ulCqiRpt->lnk));
    }

    if (ulCqiInd != NULLP)
    {
        if(ulCqiInd->ulCqiRpt.count > 0 )
        {
            YsUiTfuUlCqiInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, ulCqiInd);
        } /* end of if statement */
        else
        {
            YS_FREE_SDU(ulCqiInd);
        }/* end of else part */
    }
    return;
}

S16 ys_qcRxDlCqiHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{

    FAPI_T_RX_CQI_IND* pRxCqiInd = (FAPI_T_RX_CQI_IND *)pMsgHdr;
    TfuRawCqiIndInfo*  dlCqiIndInfo = NULLP;
    TfuRawCqiRpt*      dlCqiRpt = NULLP;
    U8                 numRiBits;
    S16                ret;
    YsUeCb*            ueCb;    
    U16                cqi_idx = 0;
    U16                rnti;
    YsCellCb*          cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
    FAPI_T_RX_CQI_IND_PDU* pCqiPdu = NULLP;
    U8                 nccIndex = 0;
    U8                 *cqiPdu;
    U16                offset = 0;
    TfuPucchDeltaPwrIndInfo *pucchDeltaPwrIndInfo = NULLP;
    TfuPucchDeltaPwr        *pucchDeltaPwrInfo = NULLP;
    S8                       pucchDeltaPwr = 0;

    /* Allocate memory for DL CQI report */
    ret = ysUtlAllocEventMem((Ptr *)&dlCqiIndInfo, sizeof(TfuRawCqiIndInfo), carrierId, __FUNCTION__, __LINE__);
    if(ret == RFAILED)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxDlCqiIndHndl ulCqiInd malloc failed \n");
        return(RFAILED);
    }
    cmLListInit(&(dlCqiIndInfo->rawCqiRpt));
    dlCqiIndInfo->cellId = cellCb->cellId;
    dlCqiIndInfo->timingInfo.sfn = pRxCqiInd->sf_sfn >> 4;
    dlCqiIndInfo->timingInfo.subframe = pRxCqiInd->sf_sfn & 0x0F;

    /* Allocate memory for PUCCH power control */
    ret = ysUtlAllocEventMem((Ptr *)&pucchDeltaPwrIndInfo, sizeof(TfuPucchDeltaPwrIndInfo), carrierId, __FUNCTION__, __LINE__);
    if(ret == RFAILED)
    {
        STKLOG(STK_MD_YS,STK_LOG_ERR, "pucchDeltaPwrIndInfo(): Memory allocation failed \n");
        return;
    }
    cmLListInit(&(pucchDeltaPwrIndInfo->pucchDeltaPwrLst));
    pucchDeltaPwrIndInfo->cellId = cellCb->cellId;
    pucchDeltaPwrIndInfo->timingInfo.sfn = pRxCqiInd->sf_sfn >> 4;
    pucchDeltaPwrIndInfo->timingInfo.subframe = pRxCqiInd->sf_sfn & 0x0F;

    for(cqi_idx = 0; cqi_idx < pRxCqiInd->n_pdu; cqi_idx++)
    {    
        pCqiPdu =(FAPI_T_RX_CQI_IND_PDU*)(((U8 *)pRxCqiInd->pdu) + offset);
        offset += sizeof(FAPI_T_RX_CQI_IND_PDU) + pCqiPdu->pdu_a.n_cc * sizeof(U8);
        ret = ROK;
        rnti = pCqiPdu->pdu_a.rx_ue_info.rnti;
        ueCb = ysMsCfgGetUe(cellCb, rnti);
        if (ueCb == NULLP)
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxDlCqiIndHndl UE [%d] %d %d doesnt exist\n",
                   rnti,pRxCqiInd->sf_sfn >> 4,pRxCqiInd->sf_sfn & 0x0F);
            continue;
        }

        //handle PUCCH power
        if(pCqiPdu->pdu_a.rx_ue_info.handle == 1)
        {
            if(TRUE ==updatePucchSNR(pCqiPdu->pdu_a.ul_cqi, ueCb, &pucchDeltaPwr))
            {
                if (ysUtlGetEventMem(&pucchDeltaPwrIndInfo->memCp, sizeof(TfuPucchDeltaPwr), (Ptr *)&pucchDeltaPwrInfo) != ROK)
                {
                    STKLOG(STK_MD_YS,STK_LOG_ERR, "pucchDeltaPwrInfo: ysUtlGetEventMem returned failure\n");
                    return;
                }
                pucchDeltaPwrInfo->rnti = rnti;
                pucchDeltaPwrInfo->pucchDeltaPwr = pucchDeltaPwr;
                pucchDeltaPwrInfo->lnk.node = (PTR)pucchDeltaPwrInfo;
                cmLListAdd2Tail(&(pucchDeltaPwrIndInfo->pucchDeltaPwrLst), &(pucchDeltaPwrInfo->lnk));
            }
        }
        
        //if the pucch SINR is less than -2  (cqi -128)/2, then take it as invalid CQI report
        if(pCqiPdu->pdu_a.ul_cqi < 124)
        {
            if(pCqiPdu->pdu_a.rx_ue_info.handle == 1)
                rgStats.gCqiPucchLowSnrDropCount[carrierId]++;
            else
                rgStats.gPuschCqiDropCount[carrierId]++;
            
            rgStats.cqiDropCount[carrierId]++;
            continue;
        }

        //handle DL CQI
        if (ysUtlGetEventMem(&dlCqiIndInfo->memCp, sizeof(TfuRawCqiRpt), (Ptr *)&dlCqiRpt) != ROK)
        {
            ysUtlFreeEventMem(dlCqiIndInfo);
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcRxDlCqiIndHndl ulCqiRpt malloc failed \n");
            return(RFAILED);
        }

        dlCqiRpt->crnti = rnti;
        dlCqiRpt->numBits =  4;

        if(pCqiPdu->pdu_a.rx_ue_info.handle == 1) //RI and CQI reported on pucch, periodical same here
        {
            cqiPdu = ((U8*)&(pRxCqiInd->n_pdu))+pCqiPdu->pdu_a.data_off;
            dlCqiRpt->ri[0] = ((*cqiPdu)&0x01)+1; // RI reported as 0 or 1, but MAC uses 1 or 2, so add 1 here
            dlCqiRpt->cqiBits[0] = *cqiPdu;
        }
        else //RI and CQI reported on pusch, periodical and aperiodical are same here
        {
            if(pCqiPdu->pdu_a.data_off == 0) //periodical RI on pusch 
            {
                for(nccIndex=0; nccIndex<pCqiPdu->pdu_a.n_cc;nccIndex++)
                {
                    dlCqiRpt->ri[nccIndex] = pCqiPdu->pdu_a.cc_rpt[nccIndex].ri;
                }
            }
            else
            {
                cqiPdu = ((U8*)(&(pRxCqiInd->n_pdu)))+pCqiPdu->pdu_a.data_off;//CQI on pusch
                cmMemcpy(dlCqiRpt->cqiBits, cqiPdu, sizeof(U32));

                for(U8 nccIndex=0; nccIndex<pCqiPdu->pdu_a.n_cc;nccIndex++)// aperiodical RI on pusch
                {
                    dlCqiRpt->aperiodical_ri[nccIndex] = pCqiPdu->pdu_a.cc_rpt[nccIndex].ri;
                }
            }
        }
        dlCqiRpt->lnk.node = (PTR)dlCqiRpt;
        cmLListAdd2Tail(&(dlCqiIndInfo->rawCqiRpt), &(dlCqiRpt->lnk));
    }

    if(dlCqiIndInfo->rawCqiRpt.count != 0)
    {
        YsUiTfuRawCqiInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, dlCqiIndInfo);
    }
    else
    {
        YS_FREE_SDU(dlCqiIndInfo);
    }

    if (pucchDeltaPwrIndInfo->pucchDeltaPwrLst.count > 0)
    {
        YsUiTfuPucchDeltaPwrInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, pucchDeltaPwrIndInfo);
    }
    else
    {
        YS_FREE_SDU(pucchDeltaPwrIndInfo);
    }

    return(ROK);
} /* end of ysMsPrcDlCqiInd */

Bool updatePucchSNR(U8 ul_CQI, YsUeCb* ueCb, S8* pucchDeltaPwr_p)
{
    S32              currSnr = 0;
    Bool             needDoPwrCtrl = FALSE;
    U32              currentTti, ttiDiff;

    currSnr = (ul_CQI - 128)/2;
    ueCb->lastRptdPucchSnr *= 8;
    ueCb->lastRptdPucchSnr += (currSnr *  2);
    ueCb->lastRptdPucchSnr += 5;        // Rounded
    ueCb->lastRptdPucchSnr /= 10;

    currentTti = SGetTtiCount();
    ttiDiff = currentTti - ueCb->pucchSnrLastTti;

    if ((ttiDiff > 64) || (ueCb->lastRptdPucchSnr < 2))
    {
        needDoPwrCtrl = TRUE;
        ueCb->pucchSnrLastTti = currentTti;

        if(ueCb->lastRptdPucchSnr < 10)
        {
            *pucchDeltaPwr_p = 1;
        }
        else if(ueCb->lastRptdPucchSnr > 15)
        {
            *pucchDeltaPwr_p = -1;
        }
        else
        {
            *pucchDeltaPwr_p = 0;
        }
    }

    return needDoPwrCtrl;
}
void ys_NxpPrcTmAdvInd(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{
    ltePhyL2ApiRxUlschInd_t* pRxUlschInd = (ltePhyL2ApiRxUlschInd_t*)pMsgHdr;
    YsCellCb    *cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
    TfuTimingAdvIndInfo *tmAdvIndInfo = NULLP;
    TfuTimingAdvInfo *tmAdvInfo = NULLP;
    U16         currTa;
    S16         ret;
    U16         pdu_idx;
    CmLteRnti   rnti = 0;
    YsUeCb      *ueCb = NULLP;
    U16         ta = 0;
    U8          currCqi = 0;

    for(pdu_idx = 0; pdu_idx < pRxUlschInd->numPdus; pdu_idx++)
    {
        if(pRxUlschInd->pdu[pdu_idx].length == 0)
        {
            continue;
        }
        rnti = pRxUlschInd->pdu[pdu_idx].rnti;
        ueCb = ysMsCfgGetUe(cellCb,rnti);
        if (ueCb == NULLP)
        {
            STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcPrcTmAdvInd rnti %d not exist \n",rnti);
            continue;
        }

        currTa = pRxUlschInd->pdu[pdu_idx].timAdv;
        currCqi = pRxUlschInd->pdu[pdu_idx].ulCqi;
        if(currCqi > YS_MS_TA_AVG_MIN_CQI)
        {
            if((currTa < 0) || (currTa > 63))
            {
                currTa = 31;
            }
            ueCb->avgTa += (currTa & 0x3f);
            ueCb->avgTaCnt++;
        }

        if(ueCb->avgTaCnt == YA_MS_TA_AVG_TIME)
        {
            ta = (S8)((ueCb->avgTa >> YA_MS_TA_AVG_TIMElog2) +
            ((ueCb->avgTa >> (YA_MS_TA_AVG_TIMElog2 - 1))&1));

            ueCb->avgTaCnt = 0;
            ueCb->avgTa = 0;

            if (ta == 31)//YS_MS_TA_THROTTLED(ueCb))
            {
                /* For now don't report TA to MAC when there is no drift,
                 * OR, when TA reporting is throttled at this time */
                continue;
            }

            if (tmAdvIndInfo == NULLP)
            {
           ret = ysUtlAllocEventMem((Ptr *)&tmAdvIndInfo, sizeof(*tmAdvIndInfo), carrierId, __FUNCTION__,__LINE__);
                if(ret != ROK)
                {
                    STKLOG(STK_MD_YS,STK_LOG_INFO,"ys_qcPrcTmAdvInd tmAdvIndInfo malloc failed \n");
                    return;
                }

                /* Initialize the Data Indication List */
                cmLListInit(&tmAdvIndInfo->timingAdvLst);
                tmAdvIndInfo->cellId = cellCb->cellId;
                tmAdvIndInfo->timingInfo.sfn = pRxUlschInd->SFN_SF >> 4;
                tmAdvIndInfo->timingInfo.subframe = pRxUlschInd->SFN_SF & 0x0F;
            }

            if(ysUtlGetEventMem(&tmAdvIndInfo->memCp, sizeof(TfuTimingAdvInfo), (Ptr *)&tmAdvInfo) != ROK)
            {
                continue;
            }

            tmAdvInfo->rnti	   = rnti;
            tmAdvInfo->timingAdv = ta;
            tmAdvInfo->lnk.node = (PTR)tmAdvInfo;
            cmLListAdd2Tail(&tmAdvIndInfo->timingAdvLst, &tmAdvInfo->lnk);
        }
    }

    if(tmAdvIndInfo != NULLP)
    {
        if (tmAdvIndInfo->timingAdvLst.count > 0 )
        {
            YsUiTfuTimingAdvInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, tmAdvIndInfo);
        }
        else
        {
            YS_FREE_SDU(tmAdvIndInfo);
        }
    }

    return;
} /* end of ysMsPrcTmAdvInd */

void ys_qcPrcTmAdvInd(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{
    FAPI_T_RX_ULSCH_IND* pRxUlschInd = (FAPI_T_RX_ULSCH_IND*)pMsgHdr;
    YsCellCb    *cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);
    TfuTimingAdvIndInfo *tmAdvIndInfo = NULLP;
    TfuTimingAdvInfo *tmAdvInfo = NULLP;
    U16         currTa;
    S16         ret;
    U16         pdu_idx;
    CmLteRnti   rnti = 0;
    YsUeCb      *ueCb = NULLP;
    U16         ta = 0;
    U8          currCqi = 0;

    for(pdu_idx = 0; pdu_idx < pRxUlschInd->n_pdu; pdu_idx++)
    {
        if(pRxUlschInd->pdu[pdu_idx].rel8.data_offset == 0)
        {
            continue;
        }
        rnti = pRxUlschInd->pdu[pdu_idx].rx_ue_info.rnti;
        ueCb = ysMsCfgGetUe(cellCb,rnti);
        if (ueCb == NULLP)
        {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcPrcTmAdvInd rnti %d not exist \n",rnti);
            continue;
        }

        currTa = pRxUlschInd->pdu[pdu_idx].rel8.t_a;
        currCqi = pRxUlschInd->pdu[pdu_idx].rel8.ul_cqi;
        if(currCqi > YS_MS_TA_AVG_MIN_CQI)
        {
            if((currTa < 0) || (currTa > 63))
            {
                currTa = 31;
            }
            ueCb->avgTa += (currTa & 0x3f);
            ueCb->avgTaCnt++;
        }

        if(ueCb->avgTaCnt == YA_MS_TA_AVG_TIME)
        {
            ta = (S8)((ueCb->avgTa >> YA_MS_TA_AVG_TIMElog2) +
            ((ueCb->avgTa >> (YA_MS_TA_AVG_TIMElog2 - 1))&1));

            ueCb->avgTaCnt = 0;
            ueCb->avgTa = 0;

            if (ta == 31)//YS_MS_TA_THROTTLED(ueCb))
            {
                /* For now don't report TA to MAC when there is no drift,
                 * OR, when TA reporting is throttled at this time */
                continue;
            }

            if (tmAdvIndInfo == NULLP)
            {
           ret = ysUtlAllocEventMem((Ptr *)&tmAdvIndInfo, sizeof(*tmAdvIndInfo), carrierId, __FUNCTION__,__LINE__);
                if(ret != ROK)
                {
                    STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcPrcTmAdvInd tmAdvIndInfo malloc failed \n");
                    return;
                }

                /* Initialize the Data Indication List */
                cmLListInit(&tmAdvIndInfo->timingAdvLst);
                tmAdvIndInfo->cellId = cellCb->cellId;
                tmAdvIndInfo->timingInfo.sfn = pRxUlschInd->sf_sfn >> 4;
                tmAdvIndInfo->timingInfo.subframe = pRxUlschInd->sf_sfn & 0x0F;
            }

            if(ysUtlGetEventMem(&tmAdvIndInfo->memCp, sizeof(TfuTimingAdvInfo), (Ptr *)&tmAdvInfo) != ROK)
            {
                continue;
            }

            tmAdvInfo->rnti	   = rnti;
            tmAdvInfo->timingAdv = ta;
            tmAdvInfo->lnk.node = (PTR)tmAdvInfo;
            cmLListAdd2Tail(&tmAdvIndInfo->timingAdvLst, &tmAdvInfo->lnk);
        }
    }

    if(tmAdvIndInfo != NULLP)
    {
        if (tmAdvIndInfo->timingAdvLst.count > 0 )
        {
            YsUiTfuTimingAdvInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, tmAdvIndInfo);
        }
        else
        {
            YS_FREE_SDU(tmAdvIndInfo);
        }
    }

    return;
} /* end of ysMsPrcTmAdvInd */

void ys_qcPrcSrsInd(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId)
{
    FAPI_T_SRS_IND* pSrsInd = (FAPI_T_SRS_IND *)pMsgHdr;
    TfuSrsIndInfo           *srsIndInfo = NULLP;
    TfuSrsRpt            *srsRpt = NULLP; 
    S16                    ret;
    YsUeCb                *ueCb = NULLP;
    CmLteRnti                rnti;
    U16                  srs_idx = 0;
    YsCellCb*          cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierId);

    for(srs_idx = 0; srs_idx < pSrsInd->n_ue; srs_idx++)
    {
       rnti = ((FAPI_T_SRS_IND_UE_TDD_A *)(&(pSrsInd->ue[srs_idx])))->rx_ue_info.rnti;
       ueCb = ysMsCfgGetUe(cellCb, rnti);
       if (ueCb == NULLP)
       {
          STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcPrcSrsInd ue %d not eixst\n",rnti);
          continue;
       }

       if (NULLP == srsIndInfo)
       {
          /* Allocate memory for the structures corresponding to the sub frame.*/
          ret = ysUtlAllocEventMem((Ptr *)&srsIndInfo, sizeof(TfuSrsIndInfo), carrierId, __FUNCTION__,__LINE__);
          if(ret == RFAILED)
          {
             STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcPrcSrsInd srsIndInfo malloc failed \n");
             return;
          }

          srsIndInfo->cellId = cellCb->cellId;
          srsIndInfo->timingInfo.sfn = pSrsInd->sf_sfn >> 4;
          srsIndInfo->timingInfo.subframe = pSrsInd->sf_sfn & 0x0F;
          cmLListInit(&(srsIndInfo->srsRpt));
       }

          if (ysUtlGetEventMem(&srsIndInfo->memCp, sizeof(TfuSrsRpt), (Ptr *)&srsRpt) != ROK)
          {
             ysUtlFreeEventMem(srsIndInfo);
             STKLOG(STK_MD_YS,STK_LOG_ERR,"ys_qcPrcSrsInd srsRpt malloc failed \n");
             return;
          }
        /* Update the SRS info */
          srsRpt->ueId = rnti; 
          srsRpt->ta = ((FAPI_T_SRS_IND_UE_TDD_A*)(&(pSrsInd->ue[srs_idx])))->rel8.t_a;
          srsRpt->numRbs = ((FAPI_T_SRS_IND_UE_TDD_A*)(&(pSrsInd->ue[srs_idx])))->rel8.n_rb;
          srsRpt->rbStart = ((FAPI_T_SRS_IND_UE_TDD_A*)(&(pSrsInd->ue[srs_idx])))->rel8.rb_start;
          srsRpt->dopEst = ((FAPI_T_SRS_IND_UE_TDD_A*)(&(pSrsInd->ue[srs_idx])))->rel8.dopp_est;

          /* Need to Check
          srsRpt->dopEst = 
          */
          /* Updating wideCqi */
          srsRpt->wideCqiPres = FALSE;
          //srsRpt->wideCqi = ysMsGetUlCqi(cellCb, pRxSrsStatusEvent->widebandSnr); 
          //MSPD_LOG("\n\n Received SRS report UeId[%d], ta[%d], numRb[%d], rbSt[%d], wideCqi[%d], wideBandSnr[%d]\n", srsRpt->ueId, srsRpt->ta, srsRpt->numRbs, srsRpt->rbStart, srsRpt->wideCqi, pRxSrsStatusEvent->widebandSnr);
          cmMemcpy(&srsRpt->snr[srsRpt->rbStart], (const U8 *)&(((FAPI_T_SRS_IND_UE_TDD_A*)(&(pSrsInd->ue[srs_idx])))->rel8.rb), ((FAPI_T_SRS_IND_UE_TDD_A*)((&pSrsInd->ue[srs_idx])))->rel8.n_rb);
          /* add SRS Report to list */
          srsRpt->lnk.node = (PTR)srsRpt;
          cmLListAdd2Tail( &(srsIndInfo->srsRpt), &(srsRpt->lnk));
   	}
   /*
    * Need to handle TDB, SRS upgrade, Temporary patch
    * We need to accumulate srs reports in the same subframe and send it to mac
    */
   YsUiTfuSrsInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId, srsIndInfo);

   return;
}

void ys_qcAddtoCrcIndList(TfuCrcIndInfo	  *crcIndInfo, U16 rnti)
{
return;
#ifndef TFU_TDD
   TfuCrcInfo  *crcInfo;

   if (ysUtlGetEventMem(&crcIndInfo->memCp, sizeof(TfuCrcInfo),
   (Ptr *)&crcInfo) != ROK)
   {
      printf("ys_qcAddtoCrcIndList  mallco crcInfo failed\n");
      return;
   } /* end of if statement */

   crcInfo->rnti = rnti;
   crcInfo->isFailure = FALSE;
   crcInfo->lnk.node = (PTR)crcInfo;

   cmLListAdd2Tail(&(crcIndInfo->crcLst), &(crcInfo->lnk));
#endif

   return;
}

void ys_qcAddtoHarqList(TfuUePucchHqRecpInfo *hqInfo,U16 rnti,U16 sfn, U8 subframe, CmLteCellId cellId)
{
    return;
}


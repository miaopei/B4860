/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/



/**********************************************************************

     Name:     LTE-MAC Convergence Layer

     Type:     C souce file

     Desc:     CL for Trillium MAC to PHY TX

     File:     ys_ms_dl.c

     Sid:      yw_ms_dl.c@@/main/TeNB_Main_BR/9 - Mon Aug 11 16:42:37 2014

     Prg:      rp

**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_FILE_ID=296;
static int RLOG_MODULE_ID=1;

#include "stdlib.h"
/* Trillium Includes */
#include "envopt.h"        /* Environment options */
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */

#include "gen.h"           /* General */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common timer defines */
#include "cm_tkns.h"       /* Common tokens defines */
#include "cm_mblk.h"       /* Common memory allocation library defines */
#include "cm_llist.h"      /* Common link list defines  */
#include "cm_hash.h"       /* Common hashlist defines */
#include "cm_lte.h"        /* Common LTEE defines */
#include "ctf.h"           /*-- CTF interface header file --*/
#include "tfu.h"           /*-- TFU interface header file --*/
#include "lys.h"           /*-- LYS interface header file --*/
#include "ys_ms_err.h"        /* CL error header file */
#include "ys_ms.h"         /* CL header file */
#include "ss_diag.h"   /* Common log file */
#include "ss_queue.h"
#include "ss_task.h"   /* Common log file */
#include "ss_msg.h"
#include "ss_mem.h"
#include "ac_ltePhyIpc.h"

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "spaccdrv.h" /*sumanth*/
#endif
#endif

#include "gen.x"           /* General */
#include "ssi.x"           /* System services */

#include "cm5.x"           /* Common timer library */
#include "cm_tkns.x"       /* Common tokens */
#include "cm_mblk.x"       /* Common memory allocation */
#include "cm_llist.x"      /* Common link list */
#include "cm_hash.x"       /* Common hashlist */
#include "cm_lte.x"        /* Common LTE includes */
#include "ctf.x"           /*-- CTF interface header file --*/
#include "tfu.x"           /*-- TFU interface header file --*/
#include "lys.x"           /*-- LYS interface header file --*/
#include "ss_queue.x"
#include "ss_task.x"   /* Common log file */
#include "ss_msg.x"
#include "ss_mem.x"
#include "cm_lib.x"
/* #include "ys_ms.x"*/
#include  "rl_rlog.h"
/* Silicon Includes */
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#include "mlog.h"
#else
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "resultcodes.h"
#endif
#ifdef TENB_STATS
#include "cm_tenb_stats.x"
#include "l2_tenb_stats.x"
#endif
#ifdef RGL_SPECIFIC_CHANGES
#include "cm_debug.h"
#endif
#include "ys_ms.x"
#include "tl_com.h"

#ifdef RSYS_WIRESHARK
#ifdef  L2_OPTMZ
PRIVATE Void ysDlSendPdusForWiresharkLogging(TfuDatReqTbInfo *tbInfo, U8 direction, U8 subframe,U16 rnti);
#else
PRIVATE Void ysDlSendPdusForWiresharkLogging(TfuDatReqPduInfo* pduInfo, U8 direction, U8 subframe,U8 cellidx);
#endif
#endif/*RSYS_WIRESHARK*/

#ifdef RGL_SPECIFIC_CHANGES
EXTERN U32 gDatIndUL;
U8  gMeasSubframe = 0;
#ifdef CM_DBG_PRINT_DEFINED
CmDebugInfo cmDbgInfo[10][CM_DBG_MAX_INFO];
#endif
#ifdef CM_STR_PRINT_DEFINED
CmStrInfoStruct cmStrInfo;
#endif
#endif
#if ((defined(TENB_T2K3K_SPECIFIC_CHANGES) && defined(L2_L3_SPLIT)) && defined(MAC_RLC_UL_RBUF))
PRIVATE Void ysSendRlcUlTtiInd ARGS((U16 index));
#endif
PUBLIC WebPrintParam webUeLogPrint[CM_LTE_MAX_CELLS][WEB_LOG_ARRAY_COUNT];
/* Global variables for HARQ_STATICS logs */
#ifdef TENB_AS_SECURITY
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
PRIVATE Void ysSendPdcpTtiInd ARGS((U16 index));
#endif
#endif
#ifdef HARQ_STATISTICS
U32 ulAcks, ulNacks, dlAcks, dlNacks, totl_ulTbs, totl_dlTbs, totl_ulAcks, \
       totl_ulNacks, totl_dlAcks, totl_dlNacks, totlUlTb, totlDlTb, Secs;
#endif
#ifdef PDCP_RLC_DL_RBUF 
EXTERN  S16 kwDlBatchProc ARGS ((Void));
#endif
#if defined(SPLIT_RLC_DL_TASK) && defined(RLC_MAC_STA_RSP_RBUF)
EXTERN  S16 rgBatchProc (U8 macInst);
#endif
#if (defined(L2_L3_SPLIT) && defined(ICC_RECV_TSK_RBUF))
EXTERN  S16 kwDlBatchProcSplit ARGS ((Void));
#endif
#ifdef TFU_TDD
PUBLIC U8 ysTddUlDlSubfrmTbl[7][10] = {
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME, YS_TDD_UL_SUBFRAME,   YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME, YS_TDD_DL_SUBFRAME,   YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME, YS_TDD_DL_SUBFRAME,   YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_DL_SUBFRAME},
   {YS_TDD_DL_SUBFRAME, YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME,  YS_TDD_SPL_SUBFRAME, YS_TDD_UL_SUBFRAME,  YS_TDD_UL_SUBFRAME,  YS_TDD_DL_SUBFRAME}
};
#endif
/* Begin:Added by liruixuan for HaloB 2018.5.16 */ 
#ifdef SOFT_CN
U32 scnVxlanSnt = 0;
#endif
/* End:Added by liruixuan for HaloB 2018.5.16 */ 

U32 startTti;
U32 robLogs[10];
PUBLIC U32 numeTti = 0;
PUBLIC U32 ysEgTxInd = 0;
PUBLIC U32 ysEgRxInd = 0;
PUBLIC U32 ysPjTtiInd = 0; /* UDAY */

/* Create global objects for TfuTtiIndInfo and avoid Alloc/free every TTI */
TfuTtiIndInfo   macTtiInd;
TfuTtiIndInfo   schTtiInd;

EXTERN U32 ysEgTxPrcCnt;
EXTERN U32 ysEgRxPrcCnt;
EXTERN U32 ysPjPrcTtiInd;



/* SR_RACH_STATS */
EXTERN U32 rgNumRarSched;         /* Num of RARs sent */
EXTERN U32 rgNumBI;               /* Num of BackOff Ind sent */
EXTERN U32 rgNumMsg3CrcPassed;    /* Num of CRC success for Msg3 */
EXTERN U32 rgNumMsg3CrcFailed;    /* Num of CRC fail for Msg 3 */
EXTERN U32 rgNumMsg3FailMaxRetx;  /* Num of Msg3 fail after Max Retx attempts */
EXTERN U32 rgNumMsg4Ack;          /* Num of Acks for Msg4 Tx */
EXTERN U32 rgNumMsg4Nack;         /* Num of Nacks for Msg4 Tx */
EXTERN U32 rgNumMsg4FailMaxRetx;  /* Num of Msg4 Tx failed after Max Retx attempts */
EXTERN U32 rgNumSrRecvd;          /* Num of Sched Req received */
EXTERN U32 rgNumSrGrant;          /* Num of Sched Req Grants sent */
EXTERN U32 rgNumMsg3CrntiCE;      /* Num of Msg 3 CRNTI CE received */
EXTERN U32 rgNumDedPream;         /* Num of Dedicated Preambles recvd */
EXTERN U32 rgNumMsg3CCCHSdu;      /* Num of Msg 3 CCCH Sdus recvd */
EXTERN U32 rgNumCCCHSduCrntiNotFound;  /*UE Ctx not found for CCCH SDU Msg 3 */
EXTERN U32 rgNumCrntiCeCrntiNotFound;  /*UE Ctx not found for CRNTI CE Msg 3 */
EXTERN U32 rgNumMsg4WithCCCHSdu;       /* Num of Msg4 with CCCH Sdu */
EXTERN U32 rgNumMsg4WoCCCHSdu;         /* Num of Msg4 without CCCH Sdu */
EXTERN U32 rgNumMsg4Dtx;               /* Num of DTX received for Msg 4 */
EXTERN U32 rgNumMsg3AckSent;           /* Num of PHICH Ack sent for Msg 3 */
EXTERN U32 rgNumMsg3NackSent;          /* Num of PHICH Nack sent for Msg 3 */
EXTERN U32 rgNumMsg4PdcchWithCrnti;    /* Num of PDCCH for CRNTI based contention resolution */
EXTERN U32 rgNumRarFailDuetoRntiExhaustion; /* Num of RACH Failures due to RNTI pool exhaution */
EXTERN U32 rgNumTAModified;            /* Num of times TA received is different from prev value */
EXTERN U32 rgNumTASent;               /* Num of TA Command sent */
EXTERN U32 rgNumMsg4ToBeTx;           /* Num of times MSG4 that should be sent */
EXTERN U32 rgNumMsg4Txed;             /* Num of MSG4 actually sent *//* ysNumMsg4ToBeTx -ysNumMsg4Txed == Failed MSG4 TX */
EXTERN U32 rgNumMsg3DtxRcvd;         /* CRC Fail with SINR < 0 */

EXTERN U32 rgNumDedPreamUECtxtFound;
EXTERN U32 dropUlSduInds;            /* Num of UlSduInd Drops*/

EXTERN  U8  gRgFapiWiresharkEnable; /*add by luopeng for phy-l2 api send to wireshark 20171204*/


#ifdef MSPD_TDD_DBG
U8 retxStart = 0;
#endif

U32  nackSf[10] = {0};

#ifdef TENB_AS_SECURITY
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
EXTERN Pst pdcpPst;
#if (defined(TENB_AS_SECURITY) && defined(UL_DL_SPLIT))
EXTERN Pst ulPdcpPst;
#endif
#endif
#endif
#if defined(TENB_T2K3K_SPECIFIC_CHANGES) && defined(L2_L3_SPLIT) || defined(MAC_RLC_UL_RBUF)
EXTERN Pst rlcUlPst;
#endif
#ifdef SPLIT_RLC_DL_TASK
EXTERN Pst rlcDlPst;
#endif 
/*TODO:including this file to expose HANDLE for temp debugging,
 * remove this once done.*/
#ifndef TENB_RTLIN_CHANGES
#include "4gmx_types.h"
#endif /*TENB_RTLIN_CHANGES*/

#include "ys_ms.x"         /*-- CL header file --*/
#ifdef TENB_RTLIN_CHANGES
#include <sys/resource.h>
#endif /* TENB_RTLIN_CHANGES */

#define STAT_PERIOD  2
#define STAT_THRESH  1
#define to_kb(x) (((x)*8)/(1000*STAT_PERIOD))

/*variable introduced for temp testing */
/*ys004.102 :  Merged MSPD code with phy 1.7 */
#ifndef TENB_RTLIN_CHANGES
volatile U32 __align(32) prev_sf = 30;
volatile U32 __align(32) prev_sfn = 1024;
#else
volatile U32  prev_sf = 30;
volatile U32  prev_sfn = 1024;
#endif

#ifdef YS_MIB_WARND
Bool  acceptPrimsFrmMac = TRUE; /* modified from FALSE to TRUE for ys_qcPhy_itf by syq */
#endif

/*TODO:exposing this varialbel to this file for temp debugging...
 * need to remove it later*/
#ifndef TENB_RTLIN_CHANGES
extern HANDLE  SvsrMsgPart;
#endif
extern int delayedHarq;
#ifdef CCPU_MLOG
PUBLIC Void L2PrintFunc (U8      *str);
#endif

U32      dlPacketCounter = 0;

#ifdef YS_PHY_STOP_AUTO
extern S16 ysMsSmStRunEvtStop ARGS((YsCellCb *cellCb, Void *status));
#endif

#ifndef TENB_RTLIN_CHANGES
extern S16 DiagDumpPhyApi(PTR vector);
#endif
#ifdef RUN_ICPU_ONLY
PUBLIC Void genUARMMsg (Bool fromUARM );
#endif
PUBLIC S16 ysMsDlmSndVectSDU (
YsCellCb        *cellCb);
#ifdef TENB_RTLIN_CHANGES
/*
PRIVATE U32 ysMsDlmIsDataPres ARGS((
TfuCntrlReqInfo *cntrlReq
));
*/
#else
PRIVATE BOOL ysMsDlmIsDataPres ARGS((
TfuCntrlReqInfo *cntrlReq
));
#endif

U32 DelyedCrcInd;
#ifndef YS_MS_NO_TA
PUBLIC Void ysMsUtlIncrTime ARGS ((
CmLteTimingInfo   *t,
U32                delta
));
PUBLIC Void ysMsUtlAddToTaLst ARGS ((
YsCellCb          *cellCb,
YsUeCb            *ueCb
));
#endif

#ifdef TFU_TDD
PUBLIC S16 ysMsTrigDummyRecpReq ARGS ((
YsCellCb        *cellCb
));
#endif
//#ifdef RG_SCH_DYNDLDELTA
#ifdef SPLIT_RLC_DL_TASK
PUBLIC Bool ysChkSfInfoStatus ARGS ((
YsCellCb        *cellCb
));
#endif

extern U32 rgDlCqiRptCnt[16], rgTotDlCqiRpt;
U32 dldrops_kwu_um, dlpkt_um, buffer_occ;
U32 dlrate_kwu, dlrate_pju;
U32 ulrate_rgu, ulrate_kwu, ulrate_pju;
U32 ulCqiRptCnt[16];
U32 totUlCqiRpt;
U32 ysTotalPkts, ysPktsDropped, ysPktsDrpdMem;
U32 ysMsDlAmTxPdus = 0, ysMsDlAmRetxPdus = 0;
U32 ysMsAmmDlRetxs[10];
U32 ysMsAmmDlPollReTx;
U32 ysMsNumPartRlcNacks, ysMsNumMaxReTx;
U32 ysMsNumCtrlPdus, ysMsNumErrCtrlPdus, ysMsNumRlcNacks, ysMsNumErrSNInStaPdu;
U32 ysMsAmmSduBranch1, ysMsAmmSduBranch2, ysMsAmmSduBranch3;
U32 ysMsAmmReEstReqRcvd, ysMsAmmDelUeReqRcvd, ysMsAmmErrReEstReqRcvd;
U32 invaldl1Tti;
U32 ysMsAmmNumToBeRlsTxLstCount, ysMsAmmNumToBeRlsReTxLstCount;
U32 ysRlcTimerArr[6], ysPdcpTimerArr[5];
U32 ysMsAmmNumStaPduRbLstCount, ysMsAmmNumReassemblyRbLstCount, ysMsAmmNumPduRlsRbLstCount, ysMsAmmNumReestablishRbLstCount, ysMsAmmNumDeleteRbLstCount, ysMsAmmNumReassemblyLstCount;
U32 ysMsAmmStaPduCounter, ysMsAmmNumSduQCount, ysMsAmmNumRetxLstCnt, ysMsAmmPjNumEntries, ysMsAmmPjDatQ;
U32 ysMsAmmUlNumPduDiscarded, ysMsAmmUlMaxLiCntRcvd, ysMsAmmNumAllBo, ysMsAmmNewDataBo, ysAmmNumDynLiArrUsed;
U32 ysMsUmmReEstReqRcvd, ysMsUmmErrReEstReqRcvd, ysMsUmBo;
int fmsSud =0;
U32 missedCntr = 0, apiDropped = 0, noTti = 0, dummyRxSdu = 0;
U32 noStatsTti = 0;
//U32 hqRvStats[2][4][2] = {{{0, 0}, {0, 0}, {0, 0}, {0, 0}}, 
//                          {{0, 0}, {0, 0}, {0, 0}, {0, 0}}};
//U32 hqRvRetxCnt[4][2] = {{0, 0}, {0, 0}, {0, 0}, {0, 0}};
EXTERN U32 rgHqRvRetxCnt[4][2];
EXTERN U32 rgHqRvStats[2][4][2]; 
#ifndef L2_L3_SPLIT
EXTERN U32 dbgPdcpRbOverload;
EXTERN U32 dbgICCMemThreshHoldDropCnt;
EXTERN U32 dbgPdcpQSizeThreshHoldDropCnt;
EXTERN U32 dbgPdcpQMsSpaccQFull;
#endif
U32 ysTmmSearchRntiFailed = 0, gsTmmQCntMax = 0, ysTmmQCntCur = 0, ysTmmDelSduCnt = 0;

U32 tpcPusch[2];
U32 tpcPucch[2];
/* Adding counters to monitor mem stats (ICC) */
U32 rlcslfpstCnt[8];
U32 rlcslfpstprcCnt[8];
U32 p0alocCnt;
U32 p1alocCnt;
U32 p0freeCnt;
U32 p1freeCnt;
U32 ulIccAlocCnt;
U32 totlPkts;
U32 pdcpdrop;
/* Adding counters to fetch UL packet and drop count*/
U32 totalUlPkts;
U32 rlculdrop;

#ifdef RG_SCH_DYNDLDELTA
U32 gDelta0Cnt;
U32 gDelta1Cnt;
U32 gCntrlReqStoreMissCnt;
#endif


/* LTE_UNLICENSED ERR IND SIMULATOR */
#define LAA_MIN_CHAN_AVAIL_WIN_SZ 5
#define LAA_MCOT 10
#define LBT_SIM_WIN_SZ 100
#define LBT_AVAIL_RF_SZ 10 /* LBT_SIM_WIN_SZ/LAA_MCOT */

U32 lbtSndErrInd = FALSE;
U32 enableLaaLBTSim = FALSE;
U32 isLAAChanActive;
U32 chanAvailPercentage = 50;
U32 prevChanAvailPercentage = 50;
U32 chanOccupancyTime = LAA_MCOT; 
U32 totalChanAvailTime;
U32 currentChanAvailTime;
U32 lbtAvailRF[LBT_AVAIL_RF_SZ];
#ifdef LTE_ADV
void processLbtSim(U32 sfn, U32 sf);
#endif



#ifndef ALIGN_64BIT
/**
 * * @brief This API is used to indicate Logging from CL to CORE1(RLC).
 * *
 * * @details
 * *
 * *     Function : ysMsPrintStat
 * *
 * *  @param[in]   Pst *  pst
 * *  @param[in]   SuId  suId
 * *  @param[in]   TfuDatIndInfo *  datInd
 * *  @return   S16
 * *      -# ROK
 * **/
PUBLIC S16 ysMsPrintStat
(
)
{
   U32 memAvail;
   U32 dlCqiRptCntLt15;
   U32 ulCqiRptCntLt15;
   static U32 memStatsCnt=0;
   static U32 balanceTTI=0;
   static U8  region = 0;

#ifndef TENB_RTLIN_CHANGES
   U32 coreId = MxGetCpuID();


   TRC3(ysMsPrintStat);
   //RLOG1(L_DEBUG,"Self post Stat prints are in core ID : %d ", coreId);
#endif

#ifdef RGL_SPECIFIC_CHANGES
	RETVALUE(ROK);
#endif
   if (memStatsCnt == 20)
   {
      memAvail=0;
      
      RLOG0(L_DEBUG,"Memory Pool information");

      SRegInfoShow(region, &memAvail);

      RLOG1(L_DEBUG,"Memory information:Available Mem = %lu", memAvail);
      memStatsCnt = 0;
      region++;
      if (region == 4)
      {
         region = 0;
      }
      RETVALUE(ROK);
   }
   memStatsCnt++;
   noStatsTti = 0;
   
   if (balanceTTI % STAT_PERIOD)
   {
      if (rgStats.dlrate_tfu[0] >= STAT_THRESH * STAT_PERIOD)
      {
         dlCqiRptCntLt15 = rgDlCqiRptCnt[14] + rgDlCqiRptCnt[13] + 
            rgDlCqiRptCnt[12] + rgDlCqiRptCnt[11];

         MSPD_LOG("\ndl kbps tfu=%lu rgu=%lu kwu=%lu pju=%lu "
               "(dlCqi=15)=%lu%% (dlCqi>10&&<15)=%lu%% (dlcqi<10)=%lu%% \n",
               to_kb(rgStats.dlrate_tfu[0]), to_kb(rgStats.rgDlrate_rgu), to_kb(rgStats.dlrate_kwu), 
               to_kb(dlrate_pju), 
               ((rgDlCqiRptCnt[15] * 100)/rgTotDlCqiRpt),
               ((dlCqiRptCntLt15 * 100)/rgTotDlCqiRpt),
               (((rgTotDlCqiRpt - rgDlCqiRptCnt[15] - dlCqiRptCntLt15) * 100)/
                rgTotDlCqiRpt));
         rgTotDlCqiRpt = 0;
         dlrate_pju = 0;
         cmMemset((U8 *) rgDlCqiRptCnt, 0, sizeof(rgDlCqiRptCnt));
      }
      if (rgStats.rgUlrate_tfu >= STAT_THRESH * STAT_PERIOD)
      {
         ulCqiRptCntLt15 = ulCqiRptCnt[14] + ulCqiRptCnt[13] + 
            ulCqiRptCnt[12] + ulCqiRptCnt[11];

         MSPD_LOG("\nul kbps tfu=%lu rgu=%lu kwu=%lu pju=%lu "
               "(ulCqi=15)=%lu%% (ulCqi>10&&<15)=%lu%% (ulcqi<10)=%lu%% \n",
               to_kb(rgStats.rgUlrate_tfu), to_kb(ulrate_rgu), to_kb(ulrate_kwu),
               to_kb(ulrate_pju),  
               (ulCqiRptCnt[15] * 100)/totUlCqiRpt,
               (ulCqiRptCntLt15 * 100)/totUlCqiRpt,
               (((totUlCqiRpt - ulCqiRptCnt[15] - ulCqiRptCntLt15) * 100)/ 
                totUlCqiRpt));

         totUlCqiRpt = 0; 
         ulrate_rgu = ulrate_kwu = ulrate_pju = 0;
         cmMemset((U8 *) ulCqiRptCnt, 0, sizeof(ulCqiRptCnt));
      }

      MSPD_LOG("******************DL MAC STATS*******************\n");
      MSPD_LOG("RV#[#ackTB0,#ackTB1:#nackTB0,#nackTB1][#retxTB0:#retxTB1]\n");
      MSPD_LOG("RV0[%lu,%lu:%lu,%lu][%lu:%lu], RV2[%lu,%lu:%lu,%lu][%lu:%lu],"
            "RV3[%lu,%lu:%lu,%lu][%lu:%lu], RV1[%lu,%lu:%lu,%lu][%lu:%lu]\n", 
            rgHqRvStats[0][0][0], rgHqRvStats[1][0][0], 
            rgHqRvStats[0][0][1], rgHqRvStats[1][0][1],
            rgHqRvRetxCnt[0][0], rgHqRvRetxCnt[0][1],
            rgHqRvStats[0][2][0], rgHqRvStats[1][2][0], 
            rgHqRvStats[0][2][1], rgHqRvStats[1][2][1],
            rgHqRvRetxCnt[2][0], rgHqRvRetxCnt[2][1],
            rgHqRvStats[0][3][0], rgHqRvStats[1][3][0], 
            rgHqRvStats[0][3][1], rgHqRvStats[1][3][1],
            rgHqRvRetxCnt[3][0], rgHqRvRetxCnt[3][1],
            rgHqRvStats[0][1][0], rgHqRvStats[1][1][0], 
            rgHqRvStats[0][1][1], rgHqRvStats[1][1][1],
            rgHqRvRetxCnt[1][0], rgHqRvRetxCnt[1][1]);
#ifndef  L2_L3_SPLIT
      MSPD_LOG("******************PDCP STATS*******************\n");
      MSPD_LOG("dbgPdcpQSizeThreshHoldDropCnt = %ld  dbgPdcpQMsSpaccQFull = %ld"
               "dbgICCMemThreshHoldDropCnt = %ld dbgPdcpRbOverload = %ld\n",
                dbgPdcpQSizeThreshHoldDropCnt, dbgPdcpQMsSpaccQFull,
                dbgICCMemThreshHoldDropCnt, dbgPdcpRbOverload);
#endif
      MSPD_LOG("dropped dropUlSduInds = %ld\n",dropUlSduInds);
      /*MSPD_LOG("#MissdCntr:%lu #TTI:%lu #APIDropped:%lu\n",
            missedCntr, noTti, apiDropped); */

      /*RLOG4(L_DEBUG,"#TTI proc time (>1 to 1.25):%lu (1.25 to 1.5):%lu (1.5 to 2):%lu (>2):%lu",
            robLogs[0], robLogs[1], robLogs[2], robLogs[3]);*/

      /*RLOG3(L_DEBUG,"#DummyTTI:%lu #DatReqDrop:%lu #DelayedCrc:%lu",
            robLogs[4], robLogs[5], DelyedCrcInd);*/
   }
   else
   {
#if 1      
      /* SR_RACH_STATS : PRINT */
      MSPD_LOG("=========================== SR_RACH_STATS START ==============================\n");
      MSPD_LOG("Total RA Preambles rcvd=%lu, Dedicated Preambles rcvd=%lu Ded Pream Expected %lu \n",
            rgStats.rgNumPrachRecvd[0], rgNumDedPream, rgNumDedPreamUECtxtFound);

      MSPD_LOG("RARs sent=%lu, BI sent=%lu \n", rgNumRarSched, rgNumBI);
      MSPD_LOG("RAR Error: RNTI Exhaustion=%lu \n",
            rgNumRarFailDuetoRntiExhaustion);

      MSPD_LOG("MSG3 Rcvd : CCCH_SDU=%lu, CRNTI_CE=%lu\n",
            rgNumMsg3CCCHSdu,rgNumMsg3CrntiCE);

      MSPD_LOG("MSG3 Error:UE Ctxt not found for: CCCH sdu=%lu, Crnti_CE=%lu \n",
            rgNumCCCHSduCrntiNotFound, rgNumCrntiCeCrntiNotFound);

      MSPD_LOG("MSG3 Stats: CRC_Pass=%lu, CRC_Fail=%lu, MaxRetxFail=%lu \n",
            rgNumMsg3CrcPassed,rgNumMsg3CrcFailed, rgNumMsg3FailMaxRetx);
      /*MSPD_LOG("MSG3 PHICH Stats: ACK_sent=%d, NACK_sent=%d \n",
            rgNumMsg3AckSent, rgNumMsg3NackSent);*/

      /*MSPD_LOG("MSG4 Sent: with_only_cont_res_id=%lu, with_ccch_sdu=%lu\n",
            rgNumMsg4WoCCCHSdu, rgNumMsg4WithCCCHSdu);*/
      MSPD_LOG("MSG4 :Num Grant for CRNTI CE=%lu\n",rgNumMsg4PdcchWithCrnti);

      /*MSPD_LOG("MSG4 Stats : ACK=%lu, NACK=%lu, DTX=%lu, MaxRetxFail=%lu\n",
            rgNumMsg4Ack, rgNumMsg4Nack, rgNumMsg4Dtx, rgNumMsg4FailMaxRetx);*/

      /*MSPD_LOG("MSG4 Stats: To be TXed=%d, Actual TXed(Tx + Retx)=%d \n",
            rgNumMsg4ToBeTx, rgNumMsg4Txed);*/

      MSPD_LOG("SR Stats: Rcvd=%lu, Grant_Sent=%lu \n",
            rgNumSrRecvd ,rgNumSrGrant );

      /*MSPD_LOG("TA Stats: Change_in_TA_value=%d, TA_Sent=%d \n",
            rgNumTAModified, rgNumTASent);*/
      MSPD_LOG("=========================== SR_RACH_STATS END ==============================\n");
#endif
   }
#ifdef HARQ_STATISTICS
   totl_dlAcks += dlAcks;
   totl_dlNacks += dlNacks;
   totl_ulAcks += ulAcks;
   totl_ulNacks += ulNacks;
   totlDlTb += totl_dlTbs;
   totlUlTb += totl_ulTbs;
   MSPD_LOG("\n=========================================\n");
   MSPD_LOG("DL HARQ STATS for %ldth Sec- (ACK/NACK/TOTAL DL TBS) \
         (%ld/%ld/%ld)\n",Secs, dlAcks, dlNacks, totl_dlTbs);
   MSPD_LOG("DL HARQ STATS so far - (ACK/NACK/TOTAL DL TBS) \
         (%ld/%ld/%ld)\n", totl_dlAcks, totl_dlNacks, totlDlTb);
   MSPD_LOG("UL HARQ STATS for %ldth Sec- (ACK/NACK/TOTAL UL TBS) \
         (%ld/%ld/%ld)\n", Secs, ulAcks, ulNacks, totl_ulTbs);
   MSPD_LOG("UL HARQ STATS so far - (ACK/NACK/TOTAL UL TBS) \
         (%ld/%ld/%ld)\n", totl_ulAcks, totl_ulNacks, totlUlTb);
   MSPD_LOG("\n=========================================\n");

   dlAcks = dlNacks = ulAcks = ulNacks = totl_dlTbs = totl_ulTbs = 0;
   Secs++;
#endif

   MSPD_LOG("\n ======= UL GROUP PWR CNTRL STATS ======== \n");
   MSPD_LOG("TPC sent on DCI3 for PUCCH :%ld \n", tpcPucch[0]);
   MSPD_LOG("TPC sent on DCI3A for PUCCH :%ld \n", tpcPucch[1]);

   MSPD_LOG("TPC sent on DCI3 for PUSCH :%ld \n", tpcPusch[0]);
   MSPD_LOG("TPC sent on DCI3A for PUSCH :%ld \n", tpcPusch[1]);
   MSPD_LOG("\n ================================ ======== \n");

   MSPD_LOG(" =============== ICC MEM STATS ================= \n");
   MSPD_LOG(" [DL] No Of Pkts Received: %ld, No Of pkts dropped at PDCP: %ld\n",totlPkts, pdcpdrop);
   MSPD_LOG(" [UL] No Of Pkts Received: %ld, No Of pkts dropped at RLC for UL : %ld\n",
         totalUlPkts, rlculdrop);
   MSPD_LOG(" No Of ICC allocs done in UL when ICC usage is > 80percent : %ld\n",ulIccAlocCnt);
   pdcpdrop = rlculdrop = totalUlPkts = totlPkts = 0;

   balanceTTI++;
   RETVALUE(ROK);
}
#else
/**
 * * @brief This API is used to indicate Logging from CL to CORE1(RLC).
 * *
 * * @details
 * *
 * *     Function : ysMsPrintStat
 * *
 * *  @param[in]   Pst *  pst
 * *  @param[in]   SuId  suId
 * *  @param[in]   TfuDatIndInfo *  datInd
 * *  @return   S16
 * *      -# ROK
 * **/
PUBLIC S16 ysMsPrintStat
(
)
{
   U32 memAvail;
   U32 dlCqiRptCntLt15;
   U32 ulCqiRptCntLt15;
   static U32 memStatsCnt=0;
   static U32 balanceTTI=0;
   static U8  region = 0;

#ifndef TENB_RTLIN_CHANGES
   U32 coreId = MxGetCpuID();


   TRC3(ysMsPrintStat);
   //RLOG1(L_DEBUG,"Self post Stat prints are in core ID : %d ", coreId);
#endif

#ifdef RGL_SPECIFIC_CHANGES
	RETVALUE(ROK);
#endif
   if (memStatsCnt == 20)
   {
      memAvail=0;
      
      RLOG0(L_DEBUG,"Memory Pool information");

      SRegInfoShow(region, &memAvail);

      RLOG1(L_DEBUG,"Memory information:Available Mem = %u", memAvail);
      memStatsCnt = 0;
      region++;
      if (region == 4)
      {
         region = 0;
      }
      RETVALUE(ROK);
   }
   memStatsCnt++;
   noStatsTti = 0;
   
   if (balanceTTI % STAT_PERIOD)
   {
      if (rgStats.dlrate_tfu[0] >= STAT_THRESH * STAT_PERIOD)
      {
         dlCqiRptCntLt15 = rgDlCqiRptCnt[14] + rgDlCqiRptCnt[13] + 
            rgDlCqiRptCnt[12] + rgDlCqiRptCnt[11];

         MSPD_LOG("\ndl kbps tfu=%u rgu=%u kwu=%u pju=%u "
               "(dlCqi=15)=%u%% (dlCqi>10&&<15)=%u%% (dlcqi<10)=%u%% \n",
               to_kb(rgStats.dlrate_tfu[0]), to_kb(rgStats.rgDlrate_rgu), to_kb(rgStats.dlrate_kwu), 
               to_kb(dlrate_pju), 
               ((rgDlCqiRptCnt[15] * 100)/rgTotDlCqiRpt),
               ((dlCqiRptCntLt15 * 100)/rgTotDlCqiRpt),
               (((rgTotDlCqiRpt - rgDlCqiRptCnt[15] - dlCqiRptCntLt15) * 100)/
                rgTotDlCqiRpt));
         rgTotDlCqiRpt = 0;
         dlrate_pju = 0;
         cmMemset((U8 *) rgDlCqiRptCnt, 0, sizeof(rgDlCqiRptCnt));
      }
      if (rgStats.rgUlrate_tfu >= STAT_THRESH * STAT_PERIOD)
      {
         ulCqiRptCntLt15 = ulCqiRptCnt[14] + ulCqiRptCnt[13] + 
            ulCqiRptCnt[12] + ulCqiRptCnt[11];

         MSPD_LOG("\nul kbps tfu=%u rgu=%u kwu=%u pju=%u "
               "(ulCqi=15)=%u%% (ulCqi>10&&<15)=%u%% (ulcqi<10)=%u%% \n",
               to_kb(rgStats.rgUlrate_tfu), to_kb(ulrate_rgu), to_kb(ulrate_kwu),
               to_kb(ulrate_pju),  
               (ulCqiRptCnt[15] * 100)/totUlCqiRpt,
               (ulCqiRptCntLt15 * 100)/totUlCqiRpt,
               (((totUlCqiRpt - ulCqiRptCnt[15] - ulCqiRptCntLt15) * 100)/ 
                totUlCqiRpt));

         totUlCqiRpt = 0; 
         rgStats.rgUlrate_tfu = ulrate_rgu = ulrate_kwu = ulrate_pju = 0;
         cmMemset((U8 *) ulCqiRptCnt, 0, sizeof(ulCqiRptCnt));
      }

      MSPD_LOG("******************DL MAC STATS*******************\n");
      MSPD_LOG("RV#[#ackTB0,#ackTB1:#nackTB0,#nackTB1][#retxTB0:#retxTB1]\n");
      MSPD_LOG("RV0[%u,%u:%u,%u][%u:%u], RV2[%u,%u:%u,%u][%u:%u],"
            "RV3[%u,%u:%u,%u][%u:%u], RV1[%u,%u:%u,%u][%u:%u]\n", 
            rgHqRvStats[0][0][0], rgHqRvStats[1][0][0], 
            rgHqRvStats[0][0][1], rgHqRvStats[1][0][1],
            rgHqRvRetxCnt[0][0], rgHqRvRetxCnt[0][1],
            rgHqRvStats[0][2][0], rgHqRvStats[1][2][0], 
            rgHqRvStats[0][2][1], rgHqRvStats[1][2][1],
            rgHqRvRetxCnt[2][0], rgHqRvRetxCnt[2][1],
            rgHqRvStats[0][3][0], rgHqRvStats[1][3][0], 
            rgHqRvStats[0][3][1], rgHqRvStats[1][3][1],
            rgHqRvRetxCnt[3][0], rgHqRvRetxCnt[3][1],
            rgHqRvStats[0][1][0], rgHqRvStats[1][1][0], 
            rgHqRvStats[0][1][1], rgHqRvStats[1][1][1],
            rgHqRvRetxCnt[1][0], rgHqRvRetxCnt[1][1]);
#ifndef  L2_L3_SPLIT
      MSPD_LOG("******************PDCP STATS*******************\n");
      MSPD_LOG("dbgPdcpQSizeThreshHoldDropCnt = %d  dbgPdcpQMsSpaccQFull = %d"
               "dbgICCMemThreshHoldDropCnt = %d dbgPdcpRbOverload = %d\n",
                dbgPdcpQSizeThreshHoldDropCnt, dbgPdcpQMsSpaccQFull,
                dbgICCMemThreshHoldDropCnt, dbgPdcpRbOverload);
#endif
      MSPD_LOG("dropped dropUlSduInds = %d\n",dropUlSduInds);
      /*MSPD_LOG("#MissdCntr:%lu #TTI:%lu #APIDropped:%lu\n",
            missedCntr, noTti, apiDropped); */

      /*RLOG4(L_DEBUG,"#TTI proc time (>1 to 1.25):%lu (1.25 to 1.5):%lu (1.5 to 2):%lu (>2):%lu",
            robLogs[0], robLogs[1], robLogs[2], robLogs[3]);*/

      /*RLOG3(L_DEBUG,"#DummyTTI:%lu #DatReqDrop:%lu #DelayedCrc:%lu",
            robLogs[4], robLogs[5], DelyedCrcInd);*/
   }
   else
   {
#if 1      
      /* SR_RACH_STATS : PRINT */
      MSPD_LOG("=========================== SR_RACH_STATS START ==============================\n");
      MSPD_LOG("Total RA Preambles rcvd=%u, Dedicated Preambles rcvd=%u Ded Pream Expected %u \n",
            rgStats.rgNumPrachRecvd[0], rgNumDedPream, rgNumDedPreamUECtxtFound);

      MSPD_LOG("RARs sent=%u, BI sent=%u \n", rgNumRarSched, rgNumBI);
      MSPD_LOG("RAR Error: RNTI Exhaustion=%u \n",
            rgNumRarFailDuetoRntiExhaustion);

      MSPD_LOG("MSG3 Rcvd : CCCH_SDU=%u, CRNTI_CE=%u\n",
            rgNumMsg3CCCHSdu,rgNumMsg3CrntiCE);

      MSPD_LOG("MSG3 Error:UE Ctxt not found for: CCCH sdu=%u, Crnti_CE=%u \n",
            rgNumCCCHSduCrntiNotFound, rgNumCrntiCeCrntiNotFound);

      MSPD_LOG("MSG3 Stats: CRC_Pass=%u, CRC_Fail=%u, MaxRetxFail=%u \n",
            rgNumMsg3CrcPassed,rgNumMsg3CrcFailed, rgNumMsg3FailMaxRetx);
      /*MSPD_LOG("MSG3 PHICH Stats: ACK_sent=%d, NACK_sent=%d \n",
            rgNumMsg3AckSent, rgNumMsg3NackSent);*/

      /*MSPD_LOG("MSG4 Sent: with_only_cont_res_id=%lu, with_ccch_sdu=%lu\n",
            rgNumMsg4WoCCCHSdu, rgNumMsg4WithCCCHSdu);*/
      MSPD_LOG("MSG4 :Num Grant for CRNTI CE=%u\n",rgNumMsg4PdcchWithCrnti);

      /*MSPD_LOG("MSG4 Stats : ACK=%u, NACK=%u, DTX=%u, MaxRetxFail=%u\n",
            rgNumMsg4Ack, rgNumMsg4Nack, rgNumMsg4Dtx, rgNumMsg4FailMaxRetx);*/

      /*MSPD_LOG("MSG4 Stats: To be TXed=%d, Actual TXed(Tx + Retx)=%d \n",
            rgNumMsg4ToBeTx, rgNumMsg4Txed);*/

      MSPD_LOG("SR Stats: Rcvd=%u, Grant_Sent=%u \n",
            rgNumSrRecvd ,rgNumSrGrant );

      /*MSPD_LOG("TA Stats: Change_in_TA_value=%d, TA_Sent=%d \n",
            rgNumTAModified, rgNumTASent);*/
      MSPD_LOG("=========================== SR_RACH_STATS END ==============================\n");
#endif
   }
#ifdef HARQ_STATISTICS
   totl_dlAcks += dlAcks;
   totl_dlNacks += dlNacks;
   totl_ulAcks += ulAcks;
   totl_ulNacks += ulNacks;
   totlDlTb += totl_dlTbs;
   totlUlTb += totl_ulTbs;
   MSPD_LOG("\n=========================================\n");
   MSPD_LOG("DL HARQ STATS for %dth Sec- (ACK/NACK/TOTAL DL TBS) \
         (%d/%d/%d)\n",Secs, dlAcks, dlNacks, totl_dlTbs);
   MSPD_LOG("DL HARQ STATS so far - (ACK/NACK/TOTAL DL TBS) \
         (%d/%d/%d)\n", totl_dlAcks, totl_dlNacks, totlDlTb);
   MSPD_LOG("UL HARQ STATS for %dth Sec- (ACK/NACK/TOTAL UL TBS) \
         (%d/%d/%d)\n", Secs, ulAcks, ulNacks, totl_ulTbs);
   MSPD_LOG("UL HARQ STATS so far - (ACK/NACK/TOTAL UL TBS) \
         (%d/%d/%d)\n", totl_ulAcks, totl_ulNacks, totlUlTb);
   MSPD_LOG("\n=========================================\n");

   dlAcks = dlNacks = ulAcks = ulNacks = totl_dlTbs = totl_ulTbs = 0;
   Secs++;
#endif

   MSPD_LOG("\n ======= UL GROUP PWR CNTRL STATS ======== \n");
   MSPD_LOG("TPC sent on DCI3 for PUCCH :%d \n", tpcPucch[0]);
   MSPD_LOG("TPC sent on DCI3A for PUCCH :%d \n", tpcPucch[1]);

   MSPD_LOG("TPC sent on DCI3 for PUSCH :%d \n", tpcPusch[0]);
   MSPD_LOG("TPC sent on DCI3A for PUSCH :%d \n", tpcPusch[1]);
   MSPD_LOG("\n ================================ ======== \n");

   MSPD_LOG(" =============== ICC MEM STATS ================= \n");
   MSPD_LOG(" [DL] No Of Pkts Received: %d, No Of pkts dropped at PDCP: %d\n",totlPkts, pdcpdrop);
   MSPD_LOG(" [UL] No Of Pkts Received: %d, No Of pkts dropped at RLC for UL : %d\n",
         totalUlPkts, rlculdrop);
   MSPD_LOG(" No Of ICC allocs done in UL when ICC usage is > 80percent : %d\n",ulIccAlocCnt);
   pdcpdrop = rlculdrop = totalUlPkts = totlPkts = 0;

   balanceTTI++;
   RETVALUE(ROK);
}
#endif

U32 tticount = 0;
/*
*
*       Fun:   ysMsDlmPrcDatReq
*
*       Desc:  Dat request handler
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  ys_ms_dl.c
*
*/
PUBLIC S16 ysMsDlmPrcDatReq
(
YsCellCb        *cellCb,
TfuDatReqInfo   *datReq
)
{
   PGENMSGDESC      pMsgDesc = NULLP;
#ifdef BATCH_PROCESSING_DL
   U8               *pStrtAddr = NULLP;
#endif
   DLSUBFRDESC      *txVect;
   TfuDatReqPduInfo *pduInfo;
#if 0
   CmLteTimingInfo  ulCntrlTiming;
   YsPhyLstCp *pUlCntrl = NULLP;
#endif

   CmLList          *cmLstEnt;
   S16              ret = ROK;
   U8               idx = 0;
   U8               chIdx = 0;
   /* HARQ */
   YsPhyLstCp        *pDlData;
   YsPhyLstCp        *pUlDlLst;
   PMAC2PHY_QUEUE_EL pElem;
#ifdef TL_ALLOC_ICC_MEM
#endif
   U8                sfNum;
   YsPhyTxSdu       phyTxSdu;
   CmLteTimingInfo  timingInfo;
   Bool cwSwapFlag  = FALSE;
   U8 tbCount;
   U8 tbIdx = 0;
   YsUeCb      *ueCb = NULL;
   U32    ueCnt = 0;
#ifndef TENB_RTLIN_CHANGES
   Bool   isAdvanceDatReq = FALSE;
   CmLteTimingInfo expDatReqTiming;
   CmLteTimingInfo advDatReqTiming;
#endif 

   U8 loop=0;
   DCICHANNELDESC *dciCh = NULL;

   TRC2(ysMsDlmPrcDatReq)
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   ++tticount;
   /* Dropping the previous TTI's DatReq and the delayed DatReq for the current TTI */
    
#ifndef TENB_RTLIN_CHANGES /* Does not make sense for T2K */
   expDatReqTiming = cellCb->timingInfo;
   YS_INCR_TIMING_INFO(expDatReqTiming, TFU_DELTA);

   advDatReqTiming = expDatReqTiming;
   YS_INCR_TIMING_INFO(advDatReqTiming, 1);

   if((cellCb->isAdvTtiSent[(cellCb->timingInfo.subframe + 1) % YS_NUM_SUB_FRAMES] == TRUE)
         && (advDatReqTiming.sfn == datReq->timingInfo.sfn &&
         advDatReqTiming.subframe == datReq->timingInfo.subframe))
   {
      /* RLOG2(L_DEBUG,"Received Advance datReq (%d %d)", datReq->timingInfo.sfn, 
                                           datReq->timingInfo.subframe); */
     isAdvanceDatReq = TRUE;
   }
   else
   {
      if (((cellCb->prev_sf == cellCb->timingInfo.subframe) &&
            (cellCb->prev_sfn == cellCb->timingInfo.sfn))) 
      {   
         MSPD_LOG("Dropping duplicate DatReq(%d,%d)\n",
                 datReq->timingInfo.sfn, datReq->timingInfo.subframe);
         RETVALUE(ROK);
     }
   }
   /* RLOG2(L_DEBUG,"Recieved DatReq %d %d", datReq->timingInfo.sfn,
            datReq->timingInfo.subframe); */
#endif /* TENB_RTLIN_CHANGES */
   timingInfo = datReq->timingInfo;
   sfNum = datReq->timingInfo.subframe;
   pDlData = &cellCb->dlEncL1Msgs[sfNum].dlData;


   /* dlMsgLst = &(cellCb->dlEncL1Msgs[sfNum].txSduLst); */

   /* at this point it is possible that Cntrl Req has arrived and
    * we have already allocated the txVector - as it is loosely coupled it
    * is also possible that CntrlReq hasn't arrived yet - so we should
    * check and allocated
    */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   /* When INTEL_ALLOC_WLS_MEM or TL_ALLOC_ICC_MEM flag is enabled then txVector is 
     pre-allocated. So based on the addTxVecToLst flag it will comes to know wheater 
     to populate the txvector or not. 
   */
   pElem = cellCb->dlEncL1Msgs[sfNum].txVector;
   if(NULLP == pElem)
   {
      stop_printf("558:pElem pointing to NULLP\n");
      RETVALUE(RFAILED);
   }
   pMsgDesc = (PGENMSGDESC)(pElem + 1);

   if(cellCb->dlEncL1Msgs[sfNum].addTxVecToLst == FALSE)
#else
   /* When TL_ALLOC_ICC_MEM or INTEL_ALLOC_WLS_MEM flag is disabled then txVector needs to be 
     allocated for populating. So based on the allocation, it will comes to know wheather to 
     populate the txvector or not.  
   */
   pMsgDesc = cellCb->dlEncL1Msgs[sfNum].txVector;

   if (NULLP == pMsgDesc)
#endif
   {
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      /* 
        Since the pElem is pre-allocated better to do memset before populating the contents. 
      */
      cmMemset((U8 *)pElem, 0, (sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC) + sizeof(MAC2PHY_QUEUE_EL)));
      pElem->AlignOffset = sizeof(DLSUBFRDESC) + sizeof(GENMSGDESC);
      pElem->Next = NULLP;
      pElem->NumMessageInBlock = 1;
#else
#ifdef BATCH_PROCESSING_DL
      pElem = ysMsUtlGetPhyListElem();
      if (!pElem)
      {
         /* HARQ_DBG */
         RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
         cellCb->dlEncL1Msgs[sfNum].txVector = NULLP;
         RETVALUE(RFAILED);
      }
      pElem->AlignOffset = sizeof(DLSUBFRDESC) + sizeof(GENMSGDESC);
      pElem->NumMessageInBlock = 1;
      pMsgDesc = (PGENMSGDESC)(pElem + 1);
#else
      /* Allocate a message towards Phy using sysCore */
      pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg (FALSE);
      if (pMsgDesc == NULLP)
      {
         uart_printf("Unable to allocate memory for TxVector\n");
         RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId, "Unable to allocate memory for TxVector");
         MSPD_ERR("Unable to allocate memory for TxVector");
         RETVALUE (RFAILED);
      }
#endif
      cellCb->dlEncL1Msgs[sfNum].txVector = pMsgDesc;
#endif
      pMsgDesc->msgType     = PHY_TXSTART_REQ;
      pMsgDesc->phyEntityId = cellCb->phyInstId;
      pMsgDesc->msgSpecific = sizeof(DLSUBFRDESC);
      txVect   = (PDLSUBFRDESC)(pMsgDesc + 1);
      txVect->numberofChannelDescriptors = 0;
#ifndef CA_PHY
#ifndef PHY_3_8_3	  
      //New Phy has removed this Param
      txVect->numberOfPhichChannels = 0;
#endif	  
#endif	  

#ifdef YS_PHY_3_8_2
    txVect->prsNumRB = 0; //VZ: for 3.8.2
    txVect->prsEnable = 0; //VZ: for 3.8.2
#endif
#ifdef EMTC_ENABLE
    txVect->lprime_mpdcch_start = cellCb->cellInfo.mPdcchStart;
#endif
      /* TODO:Setting this for the time being as per Vitaliy input.
         Can be reverted at later stage */
      /* Add message to the linked list of PHY messages */

#ifndef BATCH_PROCESSING_DL
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
      pElem = ysMsUtlGetPhyListElem();
      if (!pElem)
      {
         /* HARQ_DBG */
         uart_printf("ysMsUtlAllocSvsrMsg failed for PHY list element for TXVECTOR\
               in DatReq at time(%d,%d)\n", cellCb->timingInfo.sfn,
               cellCb->timingInfo.subframe);
        // SvsrFreeMsg(pMsgDesc);/*FREE_SVSR*/
         ysFreePhyMsg(pMsgDesc);
         cellCb->dlEncL1Msgs[sfNum].txVector = NULLP;
         RETVALUE(RFAILED);
      }
#endif
#ifdef TENB_RTLIN_CHANGES
      YS_MS_FILL_PHY_LIST_ELEM(pElem, datReq->timingInfo.sfn, datReq->timingInfo.subframe, 
           ysGetPhyPtr(pMsgDesc), sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC), PHY_TXSTART_REQ);
#else
      YS_MS_FILL_PHY_LIST_ELEM(pElem, txVect->frameNumber, txVect->subframeNumber,
            pMsgDesc, sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC), PHY_TXSTART_REQ);
#endif
#else
      YS_MS_FILL_PHY_LIST_ELEM(pElem, datReq->timingInfo.sfn, datReq->timingInfo.subframe, 
            NULLP, (sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC)), PHY_TXSTART_REQ);
#endif
      ysMsUtlAddToPhyList(pDlData,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      cellCb->dlEncL1Msgs[sfNum].addTxVecToLst = TRUE;  
#endif
   }


   txVect   = (PDLSUBFRDESC)(pMsgDesc + 1);
   chIdx = txVect->numberofChannelDescriptors;
#if(defined(PHY_3_8_3) || defined(CA_PHY))
   idx = 0;
#else
   //New Phy has removed this Param
   idx = txVect->numberOfPhichChannels;
#endif
#ifndef RGL_SPECIFIC_CHANGES
#ifdef BATCH_PROCESSING_DL
   /* Add DL SDUs to the linked list of PHY messages */
   if ((datReq->bchDat.pres) || 
         (datReq->pdus.count > 0))
   {
#ifdef TL_ALLOC_ICC_MEM
      pElem = ysMsUtlGetPhyListElem(YS_MS_MAX_MEM_SIZE);
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG :TODO: need to free the allocated messages */
         RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
         RETVALUE(RFAILED);
      }
      pElem->NumMessageInBlock = 0; 
      pStrtAddr = (U8 *)(pElem + 1);  
      /* Hardcoding the AlignOffset to 2048*/
#ifndef L2_L3_SPLIT 
      pElem->AlignOffset = 2048;
#else
      pElem->AlignOffset = 1024;
#endif
   }
#endif
#endif

   /* Process BCH data */
   if (datReq->bchDat.pres)
   {

      static U32 bchCnt = 0;
#ifdef RGL_SPECIFIC_CHANGES
/* RANGELEY Fix */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      pElem = ysMsUtlGetPhyListElem(YS_MS_MAX_MEM_SIZE);
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG :TODO: need to free the allocated messages */
         uart_printf("Memory allocation failed for PHY list element"
              " for TXSDU for BCH at time(%d,%d))\n",
               cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
         RETVALUE(RFAILED);
      }
      pElem->NumMessageInBlock = 0; 
      pStrtAddr = (U8 *)(pElem + 1);  
      /* Hardcoding the AlignOffset to 2048*/
      pElem->AlignOffset = 1024; /* 4UE_TTI_ON_T2K_2.1 */

/* End RANGELEY Fix */
#endif

#ifdef BATCH_PROCESSING_DL
      phyTxSdu.txSduReq = (PGENMSGDESC)pStrtAddr;
#endif
      /* Fill the TXSDU for PBCH */
      if (ysMsUtlFillTxSduForPBCH(&phyTxSdu, datReq, chIdx, cellCb) != ROK)
      {
         MSPD_ERR("Failed to build PBCH TXSDU\n");
         RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "Failed to build PBCH TXSDU");
#ifdef BATCH_PROCESSING_DL
         ysFreePhyMsg(pElem);
#endif
         RETVALUE(RFAILED);
      }

      /* Fill the channel descriptor for PBCH */
      ysMsUtlFillDlChanDesc(NULLP, NULLP, cellCb, &txVect->dlCh[idx], PBCH,
            chIdx, timingInfo);
      /*
         printf("682: TXSDU REQ: PBCH Channel Id %d Channel Type %d\n"
         "683: TxVector: PBCH Channel Id %d Channel Type %d \n",((PTXSDUREQ )phyTxSdu.txSduReq)->chanId, 
         ((PTXSDUREQ )phyTxSdu.txSduReq)->channelType, 
         txVect->dlCh[idx].channelId, 
         txVect->dlCh[idx].channelType);
       */

      chIdx++;
      idx++;
#ifdef BATCH_PROCESSING_DL
      pElem->NumMessageInBlock++;
      pStrtAddr = pStrtAddr + pElem->AlignOffset;
#endif
#ifndef BATCH_PROCESSING_DL
      /* Add DL SDUs to the linked list of PHY messages */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG :TODO: need to free the allocated messages */
         RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
         RETVALUE(RFAILED);
      }
#ifdef TENB_RTLIN_CHANGES
      YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
            ysGetPhyPtr(phyTxSdu.txSduReq), (sizeof(TXSDUREQ)),PHY_TXSDU_REQ);
#else
      YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
            phyTxSdu.txSduReq, (sizeof(TXSDUREQ)),PHY_TXSDU_REQ);
#endif
      ysMsUtlAddToPhyList(pDlData,pElem);	
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
#endif

      /* fix - need to increment the number of channel descriptors
            * for each channel added */
      txVect->numberofChannelDescriptors++;
      if(bchCnt % 1000 == 0)
      {
         /* RLOG4(L_DEBUG,"===== MIB Bch Message Send out in Frame (%d:%d) current time" 
               "(%d:%d)=========",timingInfo.sfn,timingInfo.subframe,
               cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
         /*
         printf("736: StartAddress %p pElem %p NumBlks %d QUEUE %d sdulen %d\n", (void *)pStrtAddr, (void *)pElem, pElem->NumMessageInBlock, sizeof(MAC2PHY_QUEUE_EL), phyTxSdu.sduLen);
         U32 id = 0, len = sizeof(MAC2PHY_QUEUE_EL) + phyTxSdu.sduLen;
         U8  *dat = (U8 *)pElem;
         while(id <  len)
         {
            printf("%x ",dat[id++]);
            if(id% 32 == 0)
               printf("\n");
         }*/

      }
      phyTxSdu.txSduReq = NULLP;
      phyTxSdu.sduLen = 0;
      bchCnt++;
#ifdef RGL_SPECIFIC_CHANGES
/* RANGELEY Fix */
#ifdef BATCH_PROCESSING_DL
      if(pElem != NULLP)
      {
         pElem->MessageLen = (pStrtAddr - (U8 *)(pElem));
 
         YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
               NULLP, pElem->MessageLen, PHY_BATCH_MSG_REQ);

         /* Add DL SDUs to the linked list of PHY messages */
         ysMsUtlAddToPhyList(pDlData,pElem);
#ifdef INTEL_ALLOC_WLS_MEM
         YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
      }
#endif /* BATCH_PROCESSING_DL */
/* End of RANGELEY Fix */
#endif
   }


   /* Process PDSCH data */
   cmLstEnt = datReq->pdus.first;
   while (cmLstEnt != NULLP)
   {
#ifdef BATCH_PROCESSING_DL
#if (defined(RGL_SPECIFIC_CHANGES) || defined(L2_L3_SPLIT))
      if(pElem->NumMessageInBlock >= 13)
#else
      if(pElem->NumMessageInBlock > 7)
#endif
      {
         /* Should never happen this scenario */
         MSPD_ERR("ysMsDlmPrcDatReq(): NumMessage blocks greater than expected\n");
#if (defined(RGL_SPECIFIC_CHANGES) || defined(L2_L3_SPLIT))
         pElem->NumMessageInBlock = 12; /* 4UE_TTI_ON_T2K_2.1 */
#else
         pElem->NumMessageInBlock = 7;
#endif
         break;
      }
#endif
      pduInfo = (TfuDatReqPduInfo*)cmLstEnt->node;
      cmLstEnt = cmLstEnt->next;
      if (pduInfo->rnti != YS_SI_RNTI)
      {
#ifdef HARQ_STATISTICS
         totl_dlTbs += pduInfo->nmbOfTBs;     
#endif
         ++ueCnt;      
      }

      ueCb = ysMsCfgGetUe(cellCb, pduInfo->rnti);
      if (pduInfo->rnti != YS_SI_RNTI && !ueCb)
      {
         RLOG_ARG0(L_DEBUG,DBG_CRNTI,pduInfo->rnti, "UE doesnt exist");
         if( pduInfo->rnti < 60 )
         {
            RLOG_ARG0(L_INFO,DBG_CRNTI,pduInfo->rnti, "Sending RAR PDU to PHY");
         }
      }
#ifndef YS_MS_NO_TA
      if (pduInfo->isTApres && ueCb)
      {
         ueCb->tarptInfo.throttleExp.sfn    = datReq->timingInfo.sfn;
         ueCb->tarptInfo.throttleExp.subframe = datReq->timingInfo.subframe;
         ysMsUtlIncrTime(&ueCb->tarptInfo.throttleExp, 30);
         if (ueCb->tarptInfo.lnk.node == NULLP) /*  MS_FIX for ccpu00123413 */
         {
            ysMsUtlAddToTaLst(cellCb, ueCb);
            /* RLOG4(L_DEBUG,"Transmitting TA at DatReqtime(%d,%d) celltime(%d,%d)",
               *datReq->timingInfo.sfn, datReq->timingInfo.subframe,
               *cellCb->timingInfo.sfn, cellCb->timingInfo.subframe); */
         }
      }
#endif
      /*TENB_T2KTDD_TM4*/
      if((( pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A ) 
               || ( pduInfo->dciInfo.format == TFU_DCI_FORMAT_2 )
         ) &&
            (1 == pduInfo->nmbOfTBs))
      { 
/* RANGELEY Fix */
#ifdef RGL_SPECIFIC_CHANGES
#ifdef INTEL_ALLOC_WLS_MEM
         pElem = ysMsUtlGetPhyListElem(YS_MS_MAX_MEM_SIZE);
#else
         pElem = ysMsUtlGetPhyListElem();
#endif
         if (!pElem)
         {
            /* HARQ_DBG :TODO: need to free the allocated messages */
            uart_printf("Memory allocation failed for PHY list element"
                  " for TXSDU for BCH at time(%d,%d))\n",
                  cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
            RETVALUE(RFAILED);
         }
         pElem->NumMessageInBlock = 0;
         pStrtAddr = (U8 *)(pElem + 1);
         /* Hardcoding the AlignOffset to 2048*/
         pElem->AlignOffset = 1024; /* 4UE_TTI_ON_T2K_2.1 */
/* END of RANGELEY Fix */
#endif /*RGL_SPECIFIC_CHANGES*/

         if (pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A)
         {
            /* We need to get the correct TB based on which is enabled */
            if ((pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].rv == 1) &&
                  (pduInfo->dciInfo.u.format2AAllocInfo.tbInfo[0].mcs == 0))
            {
               tbIdx = 1;
               /* MSPD_DBG("Retransmitting 1st TB alone with TM2 mode\n"); */
            }
            else
            {
               tbIdx = 0;
               /* MSPD_DBG("Retransmitting 0th TB alone with TM2 mode\n"); */
            }
         }
         else if(pduInfo->dciInfo.format == TFU_DCI_FORMAT_2)
         {
            /* We need to get the correct TB based on which is enabled */
            if ((pduInfo->dciInfo.u.format2AllocInfo.tbInfo[0].rv == 1) &&
                  (pduInfo->dciInfo.u.format2AllocInfo.tbInfo[0].mcs == 0))
            {
               tbIdx = 1;
               /* RLOG0(L_DEBUG,"Retransmitting 1st TB alone with TM2 mode"); */
            }
            else
            {
               tbIdx = 0;
               /* RLOG0(L_DEBUG,"Retransmitting 0th TB alone with TM2 mode"); */
            }
         }
#ifdef  L2_OPTMZ
         if(pduInfo->tbInfo[tbIdx].tbPres != TRUE || (( pduInfo->tbInfo[tbIdx].tbPres == TRUE) && ( pduInfo->tbInfo[tbIdx].tbSize == 0)))
         {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"Single TB is  Zero......tbIdx %d tbPres %d tbsz %d\n",
            tbIdx,
            pduInfo->tbInfo[tbIdx].tbPres,
            pduInfo->tbInfo[tbIdx].tbSize);

            continue;
         }  
#endif          
#ifdef BATCH_PROCESSING_DL
         /* To avoid the multiplication pStrtAddr shall be updated by AlignOffset while
            incrementing NumMessageInBlocks.
            */
         phyTxSdu.txSduReq = (PGENMSGDESC)pStrtAddr;
#endif

         /* Fill in the TX SDU from tbIdx selected */
         if(ysMsUtlFillTxSduForPDSCH(&phyTxSdu, pduInfo, 
                  chIdx, cellCb, tbIdx) != ROK)
         {
            RLOG_ARG0(L_ERROR,DBG_CRNTI,pduInfo->rnti, "Failed to build PDSCH TXSDU");
            MSPD_ERR("Failed to build PDSCH TXSDU\n");
#ifdef BATCH_PROCESSING_DL
            ysFreePhyMsg(pElem);
#endif
            RETVALUE(RFAILED);
         }
#ifndef BATCH_PROCESSING_DL
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
         pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
         pElem = ysMsUtlGetPhyListElem();
#endif

         if (!pElem)
         {
            /* HARQ_DBG :TODO: need to free the allocated messages */
            uart_printf("ysMsUtlAllocSvsrMsg failed for PHY list element for \
                  TXSDU at cellTime(%d,%d)\n",
                  cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
            RETVALUE(RFAILED);
         }

#ifdef TENB_RTLIN_CHANGES
         YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
               ysGetPhyPtr(phyTxSdu.txSduReq), sizeof(TXSDUREQ), PHY_TXSDU_REQ);
#else
         YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
               phyTxSdu.txSduReq, sizeof(TXSDUREQ), PHY_TXSDU_REQ);
#endif

         /* Add DL SDUs to the linked list of PHY messages */
         ysMsUtlAddToPhyList(pDlData,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
         YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
#else
         pElem->NumMessageInBlock++;
         pStrtAddr = pStrtAddr +  pElem->AlignOffset;
#endif

#ifdef RGL_SPECIFIC_CHANGES
         if(pElem->NumMessageInBlock >= 13) /* 4UE_TTI_ON_T2K_2.1 */
         {
            /* Ideally should be stopped and take the new pElem, 
               But for the time being stopping here and allow to process the pElem dropping 
               next datReqs. */ 
            MSPD_ERR("ysMsDlmPrcDatReq(): NumMessage blocks greater than expected\n");
            STKLOG(STK_MD_YS,STK_LOG_ERR,"\n\n\n22 ysMsDlmPrcDatReq(): NumMessage blocks greater than expected\n\n\n\n");
            pElem->NumMessageInBlock = 12; /* 4UE_TTI_ON_T2K_2.1 */
            //printf("ERROR: ysMsDlmPrcDatReq: Number of message block reached maximum\n");
            break;
         }
#endif
         phyTxSdu.txSduReq = NULLP;
#ifdef RGL_SPECIFIC_CHANGES
/* RANGELEY Fix */
#ifdef BATCH_PROCESSING_DL
         if(pElem != NULLP)
         {
            pElem->MessageLen = (pStrtAddr - (U8 *)(pElem));

            YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
                  NULLP, pElem->MessageLen, PHY_BATCH_MSG_REQ);

            /* Add DL SDUs to the linked list of PHY messages */
            ysMsUtlAddToPhyList(pDlData,pElem);
#ifdef INTEL_ALLOC_WLS_MEM
            YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
         }
#endif /* BATCH_PROCESSING_DL */
/* End of RANGELEY Fix */
#endif
      }
      else
      {
         for( tbCount = 0; tbCount < pduInfo->nmbOfTBs; tbCount++ )
         {

#ifdef LTEMAC_MIMO
#ifdef  L2_OPTMZ
            if(pduInfo->tbInfo[tbCount].tbPres != TRUE || (( pduInfo->tbInfo[tbCount].tbPres == TRUE) && ( pduInfo->tbInfo[tbCount].tbSize == 0))) 
#else 
            if (!pduInfo->mBuf[tbCount])
#endif 
            {
               STKLOG(STK_MD_YS,STK_LOG_ERR,"continue  TB tbIndex in zero  %d\n",tbCount);
               continue;
            }
#endif
#ifdef RGL_SPECIFIC_CHANGES
/* RANGELEY Fix */
#ifdef INTEL_ALLOC_WLS_MEM
            pElem = ysMsUtlGetPhyListElem(YS_MS_MAX_MEM_SIZE);
#else
            pElem = ysMsUtlGetPhyListElem();
#endif
            if (!pElem)
            {
               /* HARQ_DBG :TODO: need to free the allocated messages */
               uart_printf("Memory allocation failed for PHY list element"
                     " for TXSDU for BCH at time(%d,%d))\n",
                     cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
               RETVALUE(RFAILED);
            }
            pElem->NumMessageInBlock = 0;
            pStrtAddr = (U8 *)(pElem + 1);
            /* Hardcoding the AlignOffset to 2048*/
            pElem->AlignOffset = 1024; /* 4UE_TTI_ON_T2K_2.1 */
/* END of RANGELEY Fix */
#endif
#ifdef BATCH_PROCESSING_DL
#if (defined(RGL_SPECIFIC_CHANGES) || defined(L2_L3_SPLIT))
            if(pElem->NumMessageInBlock >= 13)
#else
            if(pElem->NumMessageInBlock > 7)
#endif
            {
               /* Ideally should be stopped and take the new pElem, 
                  But for the time being stopping here and allow to process the pElem dropping 
                  next datReqs. */ 
               MSPD_ERR("ysMsDlmPrcDatReq(): NumMessage blocks greater than expected\n");
#if   (defined(L2_L3_SPLIT) || defined(RGL_SPECIFIC_CHANGES))
               pElem->NumMessageInBlock = 12; /* 4UE_TTI_ON_T2K_2.1 */
#else
               pElem->NumMessageInBlock = 7;
#endif
               //printf("ERROR: ysMsDlmPrcDatReq: Number of message block reached maximum\n");
               break;
            }
            //printf("931: StartAddress %p pElem %p NumBlks %d\n", (void *)pStrtAddr, (void *)pElem, pElem->NumMessageInBlock);
            phyTxSdu.txSduReq =(PGENMSGDESC )pStrtAddr;
#endif
            if (ysMsUtlFillTxSduForPDSCH(&phyTxSdu, pduInfo,
                     chIdx, cellCb, tbCount) != ROK)
            {
               RLOG_ARG1(L_ERROR,DBG_CRNTI,pduInfo->rnti, "Failed to build PDSCH TXSDU cellId=%u", cellCb->cellId);
               MSPD_ERR( "Failed to build PDSCH TXSDU\n");
#ifdef BATCH_PROCESSING_DL
               ysFreePhyMsg(pElem);
#endif
               RETVALUE(RFAILED);
            }
            if ((pduInfo->rnti == YS_P_RNTI))
            {
               RLOG_ARG4(L_DEBUG,DBG_CRNTI,pduInfo->rnti,"===== Paging/SIB Message Send out in Frame (%d:%d)"
                     "current time (%d:%d) =========",timingInfo.sfn,
                     timingInfo.subframe, cellCb->timingInfo.sfn,
                     cellCb->timingInfo.subframe);
            }

            /* Filling the cwId */
            /* Get the DCI format
               Get the cwSwap flag
               */
            if( pduInfo->dciInfo.format == TFU_DCI_FORMAT_2 )
            {
               cwSwapFlag = pduInfo->dciInfo.u.format2AllocInfo.transSwap;
            }
            else if( pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A )
            {
               cwSwapFlag = pduInfo->dciInfo.u.format2AAllocInfo.transSwap;
            }

            if( ( pduInfo->dciInfo.format == TFU_DCI_FORMAT_2 ) ||
                  ( pduInfo->dciInfo.format == TFU_DCI_FORMAT_2A ) )
            {
               /* mimo_comment */
               ((PTXSDUREQ)(phyTxSdu.txSduReq))->cwId = (cwSwapFlag) ?
                  ((tbCount) ? 0:1 ) : tbCount;
               if (FALSE != cwSwapFlag && ueCb)
               {
                  /* Keep track of TBtoCW swapped subframes */
#ifndef TFU_UPGRADE
                  ueCb->cwSwpflg[datReq->timingInfo.subframe] = TRUE;
#endif
               }
            }
#ifndef BATCH_PROCESSING_DL
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
            pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
            pElem = ysMsUtlGetPhyListElem();
#endif

            if (!pElem)
            {
               /* HARQ_DBG :TODO: need to free the allocated messages */
               uart_printf("ysMsUtlAllocSvsrMsg failed for PHY list element \
                     for TXSDU at cellTime(%d,%d)\n",
                     cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
               RETVALUE(RFAILED);
            }

#ifdef TENB_RTLIN_CHANGES
            YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
                  ysGetPhyPtr(phyTxSdu.txSduReq), sizeof(TXSDUREQ), PHY_TXSDU_REQ);
#else
            YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
                  phyTxSdu.txSduReq, sizeof(TXSDUREQ), PHY_TXSDU_REQ);
#endif

            /* Add DL SDUs to the linked list of PHY messages */
            ysMsUtlAddToPhyList(pDlData,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
            YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
#else
            pElem->NumMessageInBlock++;
            pStrtAddr = pStrtAddr + pElem->AlignOffset;
#endif

            phyTxSdu.txSduReq = NULLP;
#ifdef RGL_SPECIFIC_CHANGES
/* RANGELEY Fix */
#ifdef BATCH_PROCESSING_DL
            if(pElem != NULLP)
            {
               pElem->MessageLen = (pStrtAddr - (U8 *)(pElem));

               YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
                     NULLP, pElem->MessageLen, PHY_BATCH_MSG_REQ);

               /* Add DL SDUs to the linked list of PHY messages */
               ysMsUtlAddToPhyList(pDlData,pElem);
#ifdef INTEL_ALLOC_WLS_MEM
               YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
            }
#endif /* BATCH_PROCESSING_DL */
/* End of RANGELEY Fix */
#endif
         }
      }
      /*-- Fill the channel descriptor --*/
      ysMsUtlFillDlChanDesc(pduInfo, NULLP, cellCb, &txVect->dlCh[idx],
            PDSCH, chIdx, timingInfo);

      chIdx++;
      idx++;


      txVect->numberofChannelDescriptors++;
#ifdef RSYS_WIRESHARK
#ifdef  L2_OPTMZ
      for(tbIdx = 0; tbIdx < pduInfo->nmbOfTBs; tbIdx++)
      {
         ysDlSendPdusForWiresharkLogging(&pduInfo->tbInfo[tbIdx],YS_LOG_DL_DIRECTION, \
               datReq->timingInfo.subframe, pduInfo->rnti);
      }
#else
      ysDlSendPdusForWiresharkLogging(pduInfo,YS_LOG_DL_DIRECTION,datReq->timingInfo.subframe,cellCb->phyInstId);
#endif
#endif /*RSYS_WIRESHARK*/
   }
   /* 4UE_TTI_ON_T2K_2.1 */
   if (ueCnt < 17)
   {
      ++rgStats.uespertti[ueCnt];
   }
   else
      ++rgStats.uespertti[17];
#if 0
#ifdef RSYS_WIRESHARK
   cmLstEnt = datReq->pdus.first;
   while (cmLstEnt != NULLP)
   {
      Buffer *mBuf;
      S16    ret;
      pduInfo = (TfuDatReqPduInfo*)cmLstEnt->node;
      if (pduInfo->rnti != YS_SI_RNTI)
      {
         if (pduInfo->mBuf[0] != NULLP)
         {
             SAddMsgRef(pduInfo->mBuf[0], ysCb.ysInit.region, ysCb.ysInit.pool, &mBuf);
              postToApp(mBuf, 1, 1, 3, pduInfo->rnti, pduInfo->rnti,
                  datReq->timingInfo.subframe, 0, 0, 1);
         }
         if (pduInfo->mBuf[1] != NULLP)
         {
             ret = SAddMsgRef(pduInfo->mBuf[1], ysCb.ysInit.region, ysCb.ysInit.pool, &mBuf);
             postToApp(mBuf, 1, 1, 3, pduInfo->rnti, pduInfo->rnti,
             datReq->timingInfo.subframe, 0, 0, 1);
         }
      }
      cmLstEnt = cmLstEnt->next;
   }
#endif
#endif

#ifndef RGL_SPECIFIC_CHANGES
#ifdef BATCH_PROCESSING_DL
   if(pElem != NULLP)
   {
      if (idx==0)
      {
#ifdef L2_OPTMZ
         if ((datReq->bchDat.pres) || 
               (datReq->pdus.count > 0))
         {
            ysFreePhyMsg(pElem);
         }
#else
         ysFreePhyMsg(pElem);
#endif
          pElem =NULLP;  
          RETVALUE(ROK);
      }
      pElem->MessageLen = (pStrtAddr - (U8 *)(pElem));

      YS_MS_FILL_PHY_LIST_ELEM(pElem,timingInfo.sfn,timingInfo.subframe,
            NULLP, pElem->MessageLen, PHY_BATCH_MSG_REQ);

      /* Add DL SDUs to the linked list of PHY messages */
      ysMsUtlAddToPhyList(pDlData,pElem);
#ifdef TL_ALLOC_ICC_MEM
      YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
   }
#endif
#endif

   /*-- Fill the offset for the last channel --*/
   /*--  Check for Buffer overflow --*/
   if (idx >= MAXCHSUBFRAME)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "Exceeding Channel configuration");
      MSPD_ERR("Exceeding Channel configuration\n");
      RETVALUE (RFAILED);
   }

   /* TODO:Setting this for the time being as per Vitaliy input.Can be
      reverted at later stage */
   if (idx)
   {
   }
   else
   {
      RLOG2(L_DEBUG,"Got dummy dat req @ CL (%d,%d)",
        cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
   }
   txVect->numberofChannelDescriptors = chIdx;
   cellCb->dlEncL1Msgs[sfNum].numChannels = chIdx;

   /* Update the combined list appropriately with DL Data info */

   pUlDlLst = &cellCb->dlEncL1Msgs[sfNum].ulDlLst;
   if (pDlData->count)
   {
      ysMsUtlCatPhyList(pUlDlLst, pDlData);

      ysMsUtlInitPhyList(pDlData);
   }

   /*begin : add by luopeng for phy-l2 api send to wireshark 20171204*/
   if(gRgFapiWiresharkEnable)
   {
      dciCh=(DCICHANNELDESC *)&(txVect->dlCh[7]);
      for(loop = 0;loop < txVect->numCtrlChannels;loop++)
      {
         if(dciCh[loop].scrmblerInitValue!=0xffff)
         {     		
            sendFapiWiresharkToApp((U8*)pMsgDesc, 1400, 0, indx);		
            break;
         }
      }
   }	
   /*ened : add by luopeng for phy-l2 api send to wireshark 20171204*/

    /* Check whether the CRC indication has been sent for this subframe or not
     * if yes
     * 1. append the UlCntrlreq elements into the PHY message list at the end.
     * 2. Send the TX and RX vector down.
     * else
    * 2. set the flag isdatReqPres to FALSE as the DatReq is already
    *    processed here.
     * */
    /* RLOG3(L_DEBUG,"crcSnt %d isDatReq %d %d",cellCb->crcSent[cellCb->timingInfo.subframe],
            cellCb->dlEncL1Msgs[sfNum].isdatReqPres, ysGT);*/
#if 0/* Commenting below code to avoid recursion */
#ifndef SPLIT_RLC_DL_TASK
#ifndef TENB_RTLIN_CHANGES /* Does not make sense for T2K */
    if (!isAdvanceDatReq && (TRUE == cellCb->crcSent[cellCb->timingInfo.subframe]))
#else
    /* RLOG3(L_DEBUG,"crcSnt %d isDatReq %d %d",cellCb->crcSent[cellCb->timingInfo.subframe],
            cellCb->dlEncL1Msgs[sfNum].isdatReqPres, ysGT);*/
    if (TRUE == cellCb->crcSent[cellCb->timingInfo.subframe])
#endif
    {

      /* As we always combine the UlCnrl for previous subframe with current
       * subframes
    * DlCnrl info we are retrieving the UlCntrl from the previous subframe */
        
       YS_MS_DECR_TIME(timingInfo,ulCntrlTiming, (TFU_DELTA - TFU_ULCNTRL_DELTA));
        
        pUlCntrl= &cellCb->dlEncL1Msgs[ulCntrlTiming.subframe].ulCntrl;
       if (0 < pUlCntrl->count)
       {
           ysMsUtlCatPhyList(pUlDlLst, pUlCntrl);
           ysMsUtlInitPhyList(pUlCntrl);
       }
       /* sending the Tx&RX vector down */
        ysMsDlmSndVectSDU(cellCb);
       /* reset the flag as the current subframe is sent out*/
       cellCb->dlEncL1Msgs[sfNum].isdatReqPres = FALSE;
    }
    else
    {
       cellCb->dlEncL1Msgs[sfNum].isdatReqPres = FALSE;
    }
#endif
#endif

   /* All channels except PCFICH will be filled in TXSDU */
   RETVALUE(ret);
}

#ifndef TENB_RTLIN_CHANGES
/*
*
*       Fun:   ysMsDlmIsDataPres
*
*       Desc:  Checks if Data is expected for the control request 
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  ys_ms_dl.c
*
*/
PRIVATE U32 ysMsDlmIsDataPres
(
TfuCntrlReqInfo *cntrlReq
)
{
   CmLList      *lnk = NULLP;
   TfuPdcchInfo *pdcchInfo = NULLP;

   if (!cntrlReq->dlPdcchLst.count)
   {
      if (((cntrlReq->dlTiming.subframe == 0)
            && ((cntrlReq->dlTiming.sfn % 4) == 0)))
         {
#ifdef CL_DEBUG
            RLOG4(L_DEBUG,"Received CntrlReq for DLPDCCH and also setting the flag"
                  " cell Time (%d) (%d) CntrlReqTime (%d) (%d)",
                  cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
                  cntrlReq->dlTiming.sfn , cntrlReq->dlTiming.subframe);
            RLOG1(L_DEBUG,"Received CntrlReq for DLPDCCH Count (%u)",
                  cntrlReq->dlPdcchLst.count);
#endif
            RETVALUE(TRUE);
         }
     RETVALUE(FALSE);
   }
   else
   {
      for (lnk = cntrlReq->dlPdcchLst.first; lnk; lnk = lnk->next)
      {
         pdcchInfo = (TfuPdcchInfo*)(lnk->node);
       if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3 || pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3A)
       {
          continue;
       }
       else
       {
          break;
       }
      }
     if (lnk)
     {
#ifdef CL_DEBUG
        RLOG4(L_DEBUG,"Received CntrlReq for DLPDCCH and also setting the flag"
              " cell Time (%d) (%d) CntrlReqTime (%d) (%d)",
              cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
              cntrlReq->dlTiming.sfn , cntrlReq->dlTiming.subframe);
        RLOG1(L_DEBUG,"Received CntrlReq for DLPDCCH Count (%u)",
           cntrlReq->dlPdcchLst.count);
#endif
       RETVALUE(TRUE);
     }
     else
     {
        RETVALUE(FALSE);
     }
      
   }

}
#endif

/*
*
*       Fun:   ysMsDlmPrcCntrlReq
*
*       Desc:  Cntrl Request Handler
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  ys_ms_dl.c
*
*/
PUBLIC S16 ysMsDlmPrcCntrlReq
(
YsCellCb        *cellCb,
TfuCntrlReqInfo *cntrlReq
)
{
   PGENMSGDESC  pMsgDesc = NULLP;
   PDLSUBFRDESC txVector;
   /* HARQ: DCI0_PHICH */
#ifndef BATCH_PROCESSING_DL
   PHIADCIULMSGDESC dci0HiVector;

#else 
   /*shivani*/
/*   YsPhyTxSdu      phyTxSdu;
   U8              *pStrtAddr = NULLP;
   PMAC2PHY_QUEUE_EL pElem_ul = NULLP;*/
#endif 
   U8               sfNum;
   S16 ret = ROK;
   PMAC2PHY_QUEUE_EL pElem;
   YsPhyLstCp *pDlCntrl = NULLP;
   YsPhyLstCp *pUlCntrl = NULLP;
   YsPhyLstCp *pUlDlLst = NULLP;
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
   VOLATILE U32     startTime1 = 0;
#endif
   TRC2(ysMsDlmPrcCntrlReq)
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   /*starting Task*/
   SStartTask(&startTime, PID_CL_CNTRL_REQ_UL);
   SStartTask(&startTime1, PID_CL_CNTRL_REQ_DL);
#ifdef RG_SCH_DYNDLDELTA
   if (cntrlReq->dlPdcchLst.count) 
   {
      cellCb->numDlActUes  = cntrlReq->numDlActvUes;
   }
#endif
   /* RLOG7(L_DEBUG,"Rceived cntrlReq (%d %d %d %d) %d %d %d", cntrlReq->ulTiming.sfn,
            cntrlReq->ulTiming.subframe,cntrlReq->dlTiming.sfn,
            cntrlReq->dlTiming.subframe, cntrlReq->ulPdcchLst.count,
            cntrlReq->phichLst.count,  cntrlReq->dlPdcchLst.count);*/
#ifdef EMTC_ENABLE
   if (cntrlReq->ulPdcchLst.count || cntrlReq->phichLst.count
		|| cntrlReq->ulMpdcchLst.count)
#else
   if (cntrlReq->ulPdcchLst.count || cntrlReq->phichLst.count)
#endif
   {
  
      CmLteTimingInfo timingInfo;
      YS_MS_DECR_TIME(cntrlReq->ulTiming,timingInfo, 2);
      if (!YS_TIMING_INFO_SAME(timingInfo, cellCb->timingInfo))
      {
#ifndef TENB_RTLIN_CHANGES
         if(cellCb->isAdvTtiSent[(cellCb->timingInfo.subframe + 1) % 10] == TRUE)
         {
          RLOG4(L_DEBUG,"Received cntrl Req in advance(%d, %d) (%d,%d)",
            cntrlReq->ulTiming.sfn, cntrlReq->ulTiming.subframe,
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
         }
         else
         {
         RLOG4(L_DEBUG,"Dropping the Invalid UL CNTRLREQ(DCI0&HI) (%d,%d) crnttime(%d,%d)****",
         cntrlReq->ulTiming.sfn, cntrlReq->ulTiming.subframe, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
         RETVALUE(ROK);
      }
#else
         RLOG4(L_DEBUG,"Dropping the Invalid UL CNTRLREQ(DCI0&HI) (%d,%d) crnttime(%d,%d)****",
         cntrlReq->ulTiming.sfn, cntrlReq->ulTiming.subframe, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
         RETVALUE(ROK);
#endif
      }
         
      sfNum = cntrlReq->ulTiming.subframe;
#if 0 /* This code is moved to ysMsUtlFillAndAddDci0HiInfo */
      U8 dci0flg = 0;
      U8 dci3flg = 0;
      DCICHANNELDESC *dciCh = NULLP;
      DLCMNTXPWRCTL  *dlCmnPwrCtl = NULLP;
      U8               dlsfNum = 0;
      CmLList          *cmLstEnt = NULLP;
      U8 chIdx =  0;
      TfuPdcchInfo* pdcchInfo = NULLP;
      
      dlsfNum = (sfNum + (TFU_DELTA - TFU_ULCNTRL_DELTA)) % YS_NUM_SUB_FRAMES;
      pMsgDesc = cellCb->dlEncL1Msgs[dlsfNum].txVector;
      txVector = (PDLSUBFRDESC)(pMsgDesc + 1);
      dciCh = (DCICHANNELDESC *)&txVector->dlCh[7];
      chIdx = txVector->numberofChannelDescriptors;
#ifdef BATCH_PROCESSING_DL
      if( cntrlReq->ulPdcchLst.count > 0)
      {
#ifdef TL_ALLOC_ICC_MEM
         U32 l1Size = sizeof(MAC2PHY_QUEUE_EL) + ( cntrlReq->ulPdcchLst.count * 32);
         pElem_ul = ysMsUtlGetPhyListElem(l1Size);
#else
         pElem_ul = ysMsUtlGetPhyListElem();
#endif
         if (!pElem_ul)
         {
            /* HARQ_DBG */
            RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
            RETVALUE(RFAILED);
         }
         /* For PDCCH as per the document the size of Align Offset is 32 */
         pElem_ul->AlignOffset = 32; 
         pElem_ul->NumMessageInBlock = 0;
         pStrtAddr = (U8 *)(pElem_ul + 1);
      }
#endif
      /* Appending the DCI 3/3A for PUSCH into already formed Tx vector */
      for (cmLstEnt = cntrlReq->ulPdcchLst.first; cmLstEnt
#ifdef BATCH_PROCESSING_DL
            && pStrtAddr && pElem
#endif
            ;
              cmLstEnt = cmLstEnt->next)
      {
         pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
         if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3) || 
              ((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3A)))
         {
            /* Fill the DCI Chan Desc structure with dlPdcchLst, DCI FORMAT 3/3A */
            if (chIdx < MAXCHSUBFRAME)
            {
#ifdef BATCH_PROCESSING_DL
                phyTxSdu.txSduReq = (PGENMSGDESC)pStrtAddr;
                if (ysMsUtlFillDCIChanDesc(pdcchInfo, cellCb, &phyTxSdu, 
                           &dciCh[chidx], chIdx, cntrlReq->ulTiming) == RFAILED)
#else
               if (ysMsUtlFillDCIChanDesc(pdcchInfo, cellCb,
                        &dciCh[chIdx], chIdx, cntrlReq->ulTiming) == RFAILED)
#endif
               {
#ifdef BATCH_PROCESSING_DL
                  ysFreePhyMsg(pElem);
#endif
                  RETVALUE(RFAILED);
               }
               txVector->numCtrlChannels += 1;
               chIdx++;
               dci3flg = 1;
#ifdef BATCH_PROCESSING_DL
               pElem_ul->NumMessageInBlock++;
               pStrtAddr = pStrtAddr + pElem_ul->AlignOffset;
#endif
            }
         }
         else
         {
            dci0flg = 1;
         }
      }
      /* Pushing the  power control info right after 
       * newly added DCIs 3/3a */
      if (dci3flg == 1)
      {
         dlCmnPwrCtl = (DLCMNTXPWRCTL* )&dciCh[chIdx];
         txVector->offsetPowerCtrl       = (U32)dlCmnPwrCtl - (U32)txVector;
         dlCmnPwrCtl->pilotPower     = cellCb->cellCfg.pilotSigPwr;
         dlCmnPwrCtl->psyncPower     = cellCb->cellCfg.priSigPwr;
         dlCmnPwrCtl->ssyncPower     = cellCb->cellCfg.secSigPwr;

         dlCmnPwrCtl->ciPower        = 0;
         txVector->numberofChannelDescriptors = chIdx;
         cellCb->dlEncL1Msgs[dlsfNum].numChannels= chIdx;
         pDlCntrl= &cellCb->dlEncL1Msgs[cntrlReq->ulTiming.subframe].dlCntrl;
         pUlDlLst = &cellCb->dlEncL1Msgs[sfNum].ulDlLst;
#ifdef BATCH_PROCESSING_DL
         pElem_ul->MessageLen = (pStrtAddr - (U8 *)(pElem_ul)) - sizeof(MAC2PHY_QUEUE_EL);
         YS_MS_FILL_PHY_LIST_ELEM(pElem_ul, cntrlReq->ulTiming.sfn, cntrlReq->ulTiming.subframe,
               NULLP, pElem_ul->MessageLen, PHY_BATCH_MSG_REQ);
         ysMsUtlAddToPhyList(pDlCntrl,pElem_ul);
#ifdef TL_ALLOC_ICC_MEM
         YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem_ul);
#endif
#endif
         ysMsUtlCatPhyList(pUlDlLst, pDlCntrl);
         ysMsUtlInitPhyList(pDlCntrl);
      }
      /* Case where the UL Cntrl Request came with only DCI3/3A */
      if((!dci0flg) && (!cntrlReq->phichLst.count))
      {
         RETVALUE(ROK);
      }
#endif
#ifndef BATCH_PROCESSING_DL
      /* Allocate a message towards Phy using sysCore for DCI0HI vector */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      pElem = cellCb->dlEncL1Msgs[sfNum].pDci0HiVector;
      pMsgDesc = (PGENMSGDESC)(pElem + 1);
#else
      pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg (FALSE);
#endif
      if (pMsgDesc == NULLP)
      {
         RLOG_ARG0(L_FATAL, DBG_CELLID,cellCb->cellId,"Unable to allocate memory for HIDCI0 Vector");
         uart_printf("Memory for HIDC0 vector \n");
         RETVALUE (RFAILED);
      }

      dci0HiVector = (PHIADCIULMSGDESC)(pMsgDesc);
      ret = ysMsUtlFillAndAddDci0HiInfo(cntrlReq, cellCb, dci0HiVector);
#else
      ret = ysMsUtlFillAndAddDci0HiInfo(cntrlReq, cellCb);
#endif
      if (ret != ROK) /* FREE_SVSR*/
      {
         RLOG_ARG0(L_ERROR, DBG_CELLID,cellCb->cellId," Element filling failed ");
        // SvsrFreeMsg(pMsgDesc);/*FREE_SVSR*/
#ifndef BATCH_PROCESSING_DL
         ysFreePhyMsg(pMsgDesc);
#endif
         RETVALUE(RFAILED);
      }
#ifdef LTE_TDD
	  /*Begin: add by luopeng for phy-l2 api send to wireshark 20171204*/
	  if(gRgFapiWiresharkEnable)
      {
         CmLList      *cmLstEnt;
         TfuPhichInfo *phichInfo = NULLP;
         TfuPdcchInfo *pdcchInfo = NULLP;
         U8  maxHiNum = 0; /*max = 4*/
         U8  maxSduNum = 0; /*max = 4*/

         memcpy(FAPIToWireshark,pMsgDesc,100);
         /*Structure is PHIADCIULMSGDESC + TfuPhichInfo*numHiSdus */
         if(dci0HiVector->numHiSdus> 0)
         {
            for (cmLstEnt = cntrlReq->phichLst.first;cmLstEnt;
                  cmLstEnt = cmLstEnt->next)
            {
               phichInfo = (TfuPhichInfo*)(cmLstEnt->node);            
               memcpy((U8*)FAPIToWireshark + 100 + 100*maxHiNum,
                  phichInfo, 100);
               maxHiNum++;
               if(maxHiNum == 4) 
               break;
            }
         }

         if(dci0HiVector->numDciUlSdus> 0)
         {
            for (cmLstEnt = cntrlReq->ulPdcchLst.first; cmLstEnt;
                     cmLstEnt = cmLstEnt->next)
            {
               pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);        
               memcpy((U8*)FAPIToWireshark + 500 + maxSduNum*100,
                  pdcchInfo, 100);
               maxSduNum++;
               if(maxSduNum == 4) 
               break;
            }
         }
         sendFapiWiresharkToApp((U8*)FAPIToWireshark, 900, 4, indx);
      }
	  /*End:   add by luopeng for phy-l2 api send to wireshark 20171204*/

#endif


      /* Append the ulCntrl to combined list of next subframe if the DatReq is not
       * expected for this subframe */
      /* As the ULCntrl always comes for the previous subframe timing info
       * move it to the subfame for which DLCntrlReq was recieved */
      sfNum = (sfNum + (TFU_DELTA - TFU_ULCNTRL_DELTA)) % YS_NUM_SUB_FRAMES;
      if (FALSE == cellCb->dlEncL1Msgs[sfNum].isdatReqPres)
      {
         pUlCntrl= &cellCb->dlEncL1Msgs[cntrlReq->ulTiming.subframe].ulCntrl;
         pUlDlLst = &cellCb->dlEncL1Msgs[sfNum].ulDlLst;
#ifdef CL_DEBUG
         RLOG4(L_DEBUG,"ULCNTRL (%d) (%d) count : %d at sfNum %u",
         cntrlReq->ulTiming.sfn, cntrlReq->ulTiming.subframe, pUlDlLst->count, sfNum);
#endif
         ysMsUtlCatPhyList(pUlDlLst, pUlCntrl);
         ysMsUtlInitPhyList(pUlCntrl);
      }

     /*stopping Task*/
     SStopTask(startTime, PID_CL_CNTRL_REQ_UL);

//#ifdef RG_SCH_DYNDLDELTA
#ifdef SPLIT_RLC_DL_TASK
     YS_FREE_SDU(cntrlReq);
#endif
      RETVALUE(ROK);
   }

   pMsgDesc = NULLP;
   /* Detecting the existence of DatReq from the MAC for this fubframe
      checking for PDSCH or PBCH DatReq */
   sfNum = cntrlReq->dlTiming.subframe;
//#ifdef RG_SCH_DYNDLDELTA
#ifdef SPLIT_RLC_DL_TASK
   YS_FREE_SDU(cellCb->dlEncL1Msgs[sfNum].cntrlReq)
   cellCb->dlEncL1Msgs[sfNum].cntrlReq = cntrlReq;

#endif
#ifdef TENB_RTLIN_CHANGES
   cellCb->dlEncL1Msgs[sfNum].isdatReqPres = FALSE;
#else
   cellCb->dlEncL1Msgs[sfNum].isdatReqPres = ysMsDlmIsDataPres(cntrlReq);
#endif
   /* RLOG1(L_DEBUG,"%d Is DatReq", cellCb->dlEncL1Msgs[sfNum].isdatReqPres);*/

   pDlCntrl = &cellCb->dlEncL1Msgs[sfNum].dlCntrl;

#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = cellCb->dlEncL1Msgs[sfNum].txVector;
   if(NULLP == pElem)
   {
      stop_printf("ysMsDlmPrcCntrlReq:1359:pElem is NULL\n");
      RETVALUE(RFAILED);
   }

#ifdef CA_PHY
   pMsgDesc = (PGENMSGDESC)(pElem + 1);
#endif
   /* When TL_ALLOC_ICC_MEM or INTEL_ALLOC_WLS_MEM flag is enabled then txVector is 
    * pre-allocated. So based on the addTxVecToLst flag it will comes to know wheater 
    * to populate the txvector or not. 
   */
   if(cellCb->dlEncL1Msgs[sfNum].addTxVecToLst == FALSE)
#else
   /* When TL_ALLOC_ICC_MEM or INTEL_ALLOC_WLS_MEM flag is disabled then txVector needs to be 
     allocated for populating. So based on the allocation, it will comes to know wheather to 
     populate the txvector or not.  
   */
   pMsgDesc = cellCb->dlEncL1Msgs[sfNum].txVector;

    /* At this point it is possible that Data Req has arrived and
        * we have already allocated the txVector - as it is loosely coupled it
        * is also possible that Data Req hasn't arrived yet - so we should
        * check and allocated
        */
      if (pMsgDesc == NULLP)
#endif
      {
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      /* 
        Since the pElem is pre-allocated better to do memset before populating the contents. 
      */
      cmMemset((U8 *)pElem, 0, (sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC) + sizeof(MAC2PHY_QUEUE_EL)));
#ifndef CA_PHY
      pMsgDesc = (PGENMSGDESC)(pElem + 1);
#endif
      pElem->AlignOffset = sizeof(DLSUBFRDESC) + sizeof(GENMSGDESC);
      pElem->Next = NULLP;
      pElem->NumMessageInBlock = 1;
#else
#ifdef BATCH_PROCESSING_DL
      pElem = ysMsUtlGetPhyListElem();
      if (!pElem)
      {
         /* HARQ_DBG */
         RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
         cellCb->dlEncL1Msgs[sfNum].txVector = NULLP;
         RETVALUE(RFAILED);
      }
      pElem->AlignOffset = sizeof(DLSUBFRDESC) + sizeof(GENMSGDESC);
      pElem->NumMessageInBlock = 1;
      pMsgDesc = (PGENMSGDESC)(pElem + 1);
#else
         /* Allocate a message towards Phy using sysCore */
         pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg (FALSE);
         if (pMsgDesc == NULLP)
         {
            RLOG_ARG0(L_FATAL, DBG_CELLID,cellCb->cellId,"Unable to allocate memory for TxVector");
            uart_printf("No Memory for Tx Vector in CntrlReq\n");
            RETVALUE (RFAILED);
         }
#endif
      /* Buffer the txVector for next transmission */
      cellCb->dlEncL1Msgs[sfNum].txVector = pMsgDesc;
#endif
         pMsgDesc->msgType     = PHY_TXSTART_REQ;
         pMsgDesc->phyEntityId = cellCb->phyInstId;
         pMsgDesc->msgSpecific = sizeof(DLSUBFRDESC);
         txVector = (PDLSUBFRDESC)(pMsgDesc + 1);
         txVector->numberofChannelDescriptors = 0;
      /* TODO:Setting this for the time being as per Vitaliy input.
         Can be reverted at later stage */


         /* Add message to the linked list of PHY messages */

#ifndef BATCH_PROCESSING_DL
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
         pElem = ysMsUtlGetPhyListElem();
         if (!pElem)
         {
            /* HARQ_DBG */
            RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
            ysFreePhyMsg(pMsgDesc);
            RETVALUE(RFAILED);
         }
#endif
#ifdef TENB_RTLIN_CHANGES
//ABHINAV
//      MSPD_DBG("ABHINAV sending PHY_TXSTART_REQ cntrlReq->dlTiming.sfn:subframeNum(%d:%d),txVector->frameNumer:subFrameNumber(%d:%d) \n", cntrlReq->dlTiming.sfn, cntrlReq->dlTiming.subframe, txVector->frameNumber, txVector->subframeNumber);
#if 1
         YS_MS_FILL_PHY_LIST_ELEM(pElem, cntrlReq->dlTiming.sfn, cntrlReq->dlTiming.subframe, 
           ysGetPhyPtr(pMsgDesc), sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC), PHY_TXSTART_REQ);
#else 
         YS_MS_FILL_PHY_LIST_ELEM(pElem, txVector->frameNumber, txVector->subframeNumber, 
           ysGetPhyPtr(pMsgDesc), sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC), PHY_TXSTART_REQ);
#endif         
#else
         YS_MS_FILL_PHY_LIST_ELEM(pElem, txVector->frameNumber, txVector->subframeNumber,
               pMsgDesc, sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC), PHY_TXSTART_REQ);
#endif
#else
      YS_MS_FILL_PHY_LIST_ELEM(pElem,cntrlReq->dlTiming.sfn, cntrlReq->dlTiming.subframe,
            NULLP, (sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC)),
            PHY_TXSTART_REQ);
#endif
         ysMsUtlAddToPhyList(pDlCntrl,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      cellCb->dlEncL1Msgs[sfNum].addTxVecToLst = TRUE;  
#endif
      }
      txVector = (PDLSUBFRDESC)(pMsgDesc + 1);

      /* Fill the TxVector with the recieved CntrlReqInfo */
      if (ysMsUtlFillTxVector(cntrlReq, cellCb, txVector) != ROK)
      {
         /* HARQ_TODO: Free the last allocated message and element of PHY linked list */
         RLOG0(L_FATAL, "ysMsUtlFillTxVector(): Memory allocation failed");
         RETVALUE(RFAILED);
      }

      /* HARQ: Assuming there is a control request always from MAC */
      /* Append the DL control and data to the combined list also*/
      pUlDlLst = &cellCb->dlEncL1Msgs[sfNum].ulDlLst;
      ysMsUtlCatPhyList(pUlDlLst, pDlCntrl);
      ysMsUtlInitPhyList(pDlCntrl);


      pMsgDesc = NULLP;

      /*stopping Task*/
      SStopTask(startTime1, PID_CL_CNTRL_REQ_DL);
#ifdef TFU_TDD  /* Nawas:: Triggering Dummy RxVector */
   // if(ysTddUlDlSubfrmTbl[cellCb->ulDlCfgIdx][(cellCb->timingInfo.subframe + PHY_RECPREQ_DLDELTA )%YS_NUM_SUB_FRAMES] != YS_TDD_UL_SUBFRAME)
   /* As part of 4.0 SRS recp req from mac will come on SPL subframe. So dummy req
   * is reqd only for DL subframes */
   if(ysTddUlDlSubfrmTbl[cellCb->ulDlCfgIdx][(cellCb->timingInfo.subframe + PHY_RECPREQ_DLDELTA )%YS_NUM_SUB_FRAMES] == YS_TDD_DL_SUBFRAME)
   {
      ysMsTrigDummyRecpReq(cellCb);
   }
#endif

   RETVALUE(ROK);

}

PUBLIC U8 memAlrm = 0;

/*!<This function is used to send indication to 
eGTP Layer to start Tx/Rx Operation >*/
void ysSendEgtpInd(U32 indType, U16 index)
{
   //return;
   static Pst pst = {.dstEnt = ENTEG, .srcEnt = ENTYS};
   Buffer *mBuf = NULLP;

   /*Get Message for General Use*/
   SGetMsg(ysCb.ysInit[index].region, ysCb.ysInit[index].region, (Buffer **) &mBuf);

#ifdef L2_L3_SPLIT
   pst.srcProcId  = SFndProcId();
#endif
   pst.event = indType;
   S16 ret = SPstTsk(&pst,mBuf);
   if(ret != ROK)
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"failed to pst msg %d %s %d\n", ret, __FILE__, __LINE__);
      SPutMsg(mBuf);
   }
   return;
}
#ifdef TENB_AS_SECURITY
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
/*
 *  @brief This API is used to indicate TTI Indication to PDCP. 
 * 
 *  @details
 * 
 *      Function : ysSendPdcpTtiInd 
 * 
 *   @param[in] :Void 
 *   @return  Void 
 */
PRIVATE Void ysSendPdcpTtiInd(U16 index)
{
   // return;

   Buffer *mBuf = NULLP;

   /*Get Message for General Use*/
   SGetMsg(ysCb.ysInit[index].region, ysCb.ysInit[index].region, (Buffer **) &mBuf);

   SPstTsk(&pdcpPst,mBuf);

#if (defined(TENB_AS_SECURITY) && defined(UL_DL_SPLIT))
   SGetMsg(ysCb.ysInit[index].region, ysCb.ysInit[index].region, (Buffer **) &mBuf);
   SPstTsk(&ulPdcpPst,mBuf);
#endif

   RETVOID;
}
#endif
#endif
#if (defined(TENB_T2K3K_SPECIFIC_CHANGES) && (defined(L2_L3_SPLIT) ))
#ifdef MAC_RLC_UL_RBUF
/*
 *  @brief This API is used to indicate TTI Indication to UL RLC
 * 
 *  @details
 * 
 *      Function : ysSendRlcUlTtiInd
 * 
 *   @param[in] :Void 
 *   @return  Void 
 */
PRIVATE Void ysSendRlcUlTtiInd(U16 index)
{
   // return;

#if 1	
   Buffer *mBuf = NULLP;

   /*Get Message for General Use*/
   SGetMsg(ysCb.ysInit[index].region, ysCb.ysInit[index].region, (Buffer **) &mBuf);

   SPstTsk(&rlcUlPst,mBuf);
#else
   iccPstTskB(&rlcUlPst, NULLP, 0);	 /* replace SPstTsk, by lichangwu, 2017-10-24 */
#endif
   RETVOID;
}
#endif
#endif
#ifdef SPLIT_RLC_DL_TASK
/*
 *  @brief This API is used to indicate TTI Indication to UL RLC
 *
 *  @details
 *
 *      Function : ysSendRlcUlTtiInd
 *
 *   @param[in] :Void
 *   @return  Void
 */
PRIVATE Void ysSendRlcDlTtiInd(U16 index)
{
    
    //return;

   Buffer *mBuf = NULLP;

   /*Get Message for General Use*/
   SGetMsg(ysCb.ysInit[index].region, ysCb.ysInit[index].region, (Buffer **) &mBuf);

   /* RLC DL entity Instance = 1  as we are using common Pst structure for both RLC UL/DL */
   SPstTsk(&rlcDlPst,mBuf);

   RETVOID;
}
#endif
#ifdef RG_SCH_DYNDLDELTA
#define YS_DELTA_CHANGE_PERIOD 10000
#define YS_DELTA_UP_PRCNTG     100
#define YS_DELTA_DOWN_PRCNTG   900
#define YS_DELTA_CHG_NONE      0
#define YS_DELTA_CHG_UP        1
#define YS_DELTA_CHG_DOWN      2
#define YS_MAX_TDD_UL_DL_CFG   7

/* Stepping up occasions for Dynamic delta */
Bool ysTddStepDownTbl[YS_MAX_TDD_UL_DL_CFG][10] = {
   {FALSE, FALSE, TRUE,  TRUE,  TRUE,   FALSE,  FALSE, TRUE,  TRUE,  TRUE},
   {FALSE, FALSE, FALSE, FALSE, FALSE,  TRUE,   FALSE, FALSE, FALSE, FALSE},
   {FALSE, FALSE, FALSE, FALSE, TRUE,   FALSE,  FALSE, FALSE, FALSE, FALSE},
   {FALSE, FALSE, TRUE,  TRUE,  TRUE,   FALSE,  FALSE, FALSE, FALSE, FALSE},
   {FALSE, FALSE, TRUE,  TRUE,  FALSE,  FALSE,  FALSE, FALSE, FALSE, FALSE},
   {FALSE, FALSE, TRUE,  FALSE, FALSE,  FALSE,  FALSE, FALSE, FALSE, FALSE},
   {FALSE, FALSE, TRUE,  TRUE,  TRUE,   FALSE,  FALSE, TRUE,  TRUE,  FALSE}
};

Bool ysTddStepUpTbl[YS_MAX_TDD_UL_DL_CFG][10] = {
   {FALSE, TRUE,  FALSE, FALSE, FALSE,  FALSE,  TRUE, FALSE, FALSE, FALSE},
   {FALSE, FALSE, FALSE, FALSE, FALSE,  TRUE,   FALSE, FALSE, FALSE, FALSE},
   {FALSE, FALSE, FALSE, FALSE, TRUE,   FALSE,  FALSE, FALSE, FALSE, FALSE},
   {FALSE, TRUE,  FALSE, FALSE, FALSE,  FALSE,  TRUE,  FALSE, FALSE, FALSE},
   {FALSE, TRUE,  FALSE, FALSE, FALSE,  FALSE,  FALSE, FALSE, FALSE, FALSE},
   {FALSE, TRUE,  FALSE, FALSE, FALSE,  FALSE,  FALSE, FALSE, FALSE, FALSE},
   {FALSE, TRUE,  FALSE, FALSE, FALSE,  FALSE,  FALSE, FALSE, FALSE, FALSE},
};

void ysDynDeltaChange(YsCellCb *cellCb, U32 *deltaChgAction)
{
    U32 numDlActUes = cellCb->numDlActUes;
   *deltaChgAction = YS_DELTA_CHG_NONE;
   
   /* Increment the hysteresis count */
   cellCb->deltaChangeCnt++;

   switch(cellCb->curDlDelta)
   {
      case 0:
      /* Verify only the delta up algorithm */
      if(numDlActUes >= cellCb->cellCfg.numDlUePerTti)
      {
        /* Number of UEs with data pending is more than the number of UE scheduled per TTI */
        cellCb->dlDeltaUpCnt++;
      }
#ifdef LTE_TDD
      if(cellCb->deltaChangeCnt >= YS_DELTA_CHANGE_PERIOD)
      {
        if (cellCb->dlDeltaUpCnt < ((cellCb->deltaChangeCnt * 9)/10) )
        {
           cellCb->dlDeltaUpCnt =0;
           cellCb->deltaChangeCnt = 0;
        }
        /* Delta UP algoritm satisfied */   
        if(cellCb->dlDeltaUpCnt > YS_DELTA_UP_PRCNTG) 
        {
           if(ysTddStepUpTbl[cellCb->cellCfg.tddSfCfg.sfAssignment][macTtiInd.timingInfo.subframe])
           {
             *deltaChgAction = YS_DELTA_CHG_UP;
             cellCb->dlDeltaUpCnt   = 0;
             cellCb->deltaChangeCnt = 0;
           }
        }
      }
#else
      if(cellCb->deltaChangeCnt == YS_DELTA_CHANGE_PERIOD)
      {
        /* Delta UP algoritm satisfied */   
        if(cellCb->dlDeltaUpCnt > YS_DELTA_UP_PRCNTG) 
        {
           *deltaChgAction = YS_DELTA_CHG_UP;
        }

        cellCb->dlDeltaUpCnt   = 0;
        cellCb->deltaChangeCnt = 0;

      }
#endif
      break;

      case 1:
      /* Verify only the Delta down algorithm */
      if(((numDlActUes > 0) && (numDlActUes < cellCb->cellCfg.numDlUePerTti)) || (1 == cellCb->cellCfg.numDlUePerTti))
      {
        cellCb->dlDeltaDownCnt++;
      }
#ifdef LTE_TDD
      if(cellCb->deltaChangeCnt >= YS_DELTA_CHANGE_PERIOD)
      {
         if (cellCb->dlDeltaDownCnt < ((cellCb->deltaChangeCnt * 9)/10) )
         {
            cellCb->dlDeltaDownCnt = 0;
            cellCb->deltaChangeCnt = 0;
         }
         if(cellCb->dlDeltaDownCnt > YS_DELTA_DOWN_PRCNTG)
         {
            if(ysTddStepDownTbl[cellCb->cellCfg.tddSfCfg.sfAssignment]\
                 [macTtiInd.timingInfo.subframe])
            {
               *deltaChgAction = YS_DELTA_CHG_DOWN;
               cellCb->dlDeltaDownCnt  = 0;
               cellCb->deltaChangeCnt  = 0;
            }
         }
         else
         {
            cellCb->dlDeltaDownCnt  = 0;
            cellCb->deltaChangeCnt  = 0;
         }
      }
#else
      if(cellCb->deltaChangeCnt == YS_DELTA_CHANGE_PERIOD)
      {

        if(cellCb->dlDeltaDownCnt > YS_DELTA_DOWN_PRCNTG)
        {
           *deltaChgAction = YS_DELTA_CHG_DOWN;
        }

        cellCb->dlDeltaDownCnt = 0;
        cellCb->deltaChangeCnt   = 0;
      }
#endif
      break;
   }
}
#endif
#ifdef RG_ULSCHED_AT_CRC
#ifdef XEON_SPECIFIC_CHANGES
/*
*
*       Fun:   ysMsDlmSduIndPrcCrcForSch
*
*       Desc:  Handles the SDU Indication to process
*              CRC at Priority for UL Scheduling 
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_dl.c
*
*/

PRIVATE S16 ysMsDlmSduIndPrcCrcForSch
(
YsUlL1Msg *ulRxSduInds,
YsCellCb        *cellCb
)
{
   TfuCrcIndInfo     *crcIndInfo = NULLP;
   VOLATILE U32     startTime = 0;
   S16                ret;
   U16                loopCnt;
   U8                 sfrm=0;
   U16                indx = cellCb->cellId - CM_START_CELL_ID;
   
   if (ulRxSduInds->sduIndCnt)
   {
      for (loopCnt = 0; loopCnt < ulRxSduInds->sduIndCnt; loopCnt++)
      {
	 /* Process all RXSDU except ULSCH */
	 ret = ysMsUlmSduInd(ulRxSduInds->pRxSduInd[loopCnt], cellCb);
      }
   }

   if (NULLP != ulRxSduInds->pRxEndInd)
   {
      sfrm =   ulRxSduInds->pRxEndInd->subFrameNum;
      crcIndInfo = cellCb->ulEncL1Msgs[sfrm].tfuCrcIndInfo;
   }
   /* Send the CRC Indication to MAC for the corresponding subframe */
   if (crcIndInfo != NULLP)
   {
      if(crcIndInfo->crcLst.count > 0)
      {

	 /*71827: If a second CRC Indication for the subframe is erroneously being generated to MAC, stop it*/
	 if(cellCb->crcSent[cellCb->timingInfo.subframe] == TRUE)
	 {
	    MSPD_ERR("CRC already sent for this subframe\n");
	    YS_FREE_SDU(crcIndInfo);
	 }
	 else
	 {
	    /*starting Task*/
	    SStartTask(&startTime, PID_CRC_IND_REAL);
	    ysSendCrcToMac(cellCb, crcIndInfo);
	    cellCb->isCrcExptd[cellCb->timingInfo.subframe] = FALSE;
#ifdef RG_ULSCHED_AT_CRC
	    cellCb->crcSent[cellCb->timingInfo.subframe] = TRUE;
#endif

	    /*stopping Task*/
	    SStopTask(startTime, PID_CRC_IND_REAL);
	 }
      }
      else
      {
	 YS_FREE_SDU(crcIndInfo);
      }/* end of else part */
      cellCb->ulEncL1Msgs[sfrm].tfuCrcIndInfo = NULLP;
   }

   /* HARQ_UL: If TTI indication is recieved for subframe which is not expected
      to have CRC indication, send dummy CRC indication here */
   if ((!cellCb->isCrcExptd[cellCb->timingInfo.subframe]) &&
	 (!cellCb->crcSent[cellCb->timingInfo.subframe]))
   {
     /*TfuCrcIndInfo     *crcIndInfo = NULLP;*/
      /*starting Task*/
      SStartTask(&startTime, PID_CRC_IND_DUMMY);
      /* Send the CRC Indication to MAC for the corresponding subframe */
      ret = ysUtlAllocEventMem((Ptr *)&crcIndInfo,
	    sizeof(TfuCrcIndInfo), indx, __FUNCTION__,__LINE__);
      if(ret == RFAILED)
      {
	 RLOG_ARG0(L_FATAL, DBG_CELLID,cellCb->cellId,"Memory allocation failed for CrcInd");
	 RETVALUE(RFAILED);
      } /* end of if statement */

#ifdef CL_DEBUG
      RLOG3(L_DEBUG,"Fake CRC without RX SDU %x at (%d, %d)",
	    crcIndInfo, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
#endif

      cmLListInit(&(crcIndInfo->crcLst));

      crcIndInfo->cellId = cellCb->cellId;
      crcIndInfo->timingInfo.sfn = cellCb->timingInfo.sfn;
      crcIndInfo->timingInfo.subframe = cellCb->timingInfo.subframe;
      /* RLOG1(L_DEBUG,"Calling ysSendCrcToMac %x",  MX_GET_RADDR);*/
      ysSendCrcToMac(cellCb, crcIndInfo);
      /* RLOG2(L_DEBUG,"Sent dummy CRC Indication to MAC(%d,%d)", timingInfo.sfn,
	 timingInfo.subframe);*/
      cellCb->crcSent[cellCb->timingInfo.subframe] = TRUE;
      /*stopping Task*/
      SStopTask(startTime, PID_CRC_IND_DUMMY);
   }

   RETVALUE(ROK);

} /* ysMsDlmSduIndPrcCrcForSch*/
#endif
#endif

/* Added by syq for double YS in double MAC threads.
 * This function only process the cell 2's L2 MAC schedule.
*/
PUBLIC S16 ysMsDlmPrc2ndTtiInd
(
PMSGIND         txStartInd,
YsCellCb        *cellCb,
Bool            isDummyTti
)
{
   CmLteTimingInfo timingInfo;
   TfuTtiIndInfo   macTtiInd;
   TfuTtiIndInfo   schTtiInd;

   TRC2(ysMsDlmPrc2ndTtiInd)

   if (!cellCb->phyState)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "PHY is not in running state");
      uart_printf( "PHY is not in running state cell %d\n", cellCb->cellId);
      SStopTask(startTime, PID_CL_DLM_PRC_TTI_IND);
      RETVALUE(RFAILED);
   }
   /* Set the current time information */
   timingInfo = cellCb->timingInfo;

   macTtiInd.numCells                     = 1;/*Per mac inst its only 1 cell */
   macTtiInd.cells[0].cellId              = cellCb->cellId;
   macTtiInd.cells[0].timingInfo.subframe = timingInfo.subframe;
   macTtiInd.cells[0].timingInfo.sfn      = timingInfo.sfn;
   macTtiInd.cells[0].timingInfo.hfn      = timingInfo.hfn;
   macTtiInd.cells[0].isDummyTti          = isDummyTti;
   /*TODO*/
   macTtiInd.cells[0].schTickDelta        = 0;
   macTtiInd.cells[0].dlBlankSf           = 0;
   macTtiInd.cells[0].ulBlankSf           = 0;
   schTtiInd = macTtiInd;

   /* send TTI indication to MAC */
   YsUiTfuTtiInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, &macTtiInd);

#if defined(SPLIT_RLC_DL_TASK) && defined(RLC_MAC_DAT_REQ_RBUF)
   rgDlDatReqBatchProc();
#endif
   /* send TTI indication to scheduler */
   YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
                    cellCb->schTfuSap->suId,
                    &schTtiInd);

#ifdef RLC_MAC_STA_RSP_RBUF
   rgBatchProc((U8)(cellCb->cellId - CM_START_CELL_ID));
#endif

#if defined(TENB_T2K3K_SPECIFIC_CHANGES) && defined(LTE_TDD)
   YsUiTfuNonRtInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId);
#endif

#if defined(LTE_TDD) && defined(TENB_STATS)
   if (ysCb.statsPer)
   {
      if (numeTti % ysCb.statsPer == 0)
      {
         //NAVEEN TODO
#if defined(LTE_TDD) && !defined(UL_RLC_NET_CLUSTER)
         TSInfTrigStats(ysCb.ysInit[indx].region, ysCb.ysInit[indx].pool);   /*(region, pool)*/
#else
         {
            TSL2SendStatsToApp(&ysCb.ysInit[1].lmPst, 0);
         }
#endif
      }
   }
#endif

   RETVALUE(ROK);
}

/*
*
*       Fun:   ysMsDlmPrcTtiIndDC
*
*       Desc:  TTI handler from PHY
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  ys_ms_dl.c
*
*/
extern sem_t freeMgrSem;
#ifdef MLOG_XEON
EXTERN U32  mlogTimeRef;
#endif
#ifdef LGW_SUPPORT
EXTERN S32 g_lgwSwitch;
#endif

PUBLIC S16 ysMsDlmPrcTtiIndDC
(
PMSGIND         txStartInd,
YsCellCb        *cellCb,
Bool            isDummyTti
)
{
   CmLteTimingInfo timingInfo;
   TfuTtiIndInfo   macTtiInd;
   TfuTtiIndInfo   schTtiInd;
   #ifdef XXX_TASK_MEAS
      VOLATILE U32     startTime = 0;
   #endif

   TRC2(ysMsDlmPrcTtiIndDC);

   ++numeTti;
   SStartTask(&startTime, PID_CL_DLM_PRC_TTI_IND);

   if (!cellCb->phyState)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "PHY is not in running state");
      uart_printf( "PHY is not in running state cell %d\n", cellCb->cellId);
      SStopTask(startTime, PID_CL_DLM_PRC_TTI_IND);
      RETVALUE(RFAILED);
   }
   /* Set the current time information */
   timingInfo = cellCb->timingInfo;
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
#ifdef LTE_ADV
   /* LBT SIM PROCESSING */
   processLbtSim(timingInfo.sfn, timingInfo.subframe);
#endif

   /* Allocate TTI for MAC */
   macTtiInd.numCells                     = 1;/*Per mac inst its only 1 cell */
   macTtiInd.cells[0].cellId              = cellCb->cellId;
   macTtiInd.cells[0].timingInfo.subframe = timingInfo.subframe;
   macTtiInd.cells[0].timingInfo.sfn      = timingInfo.sfn;
   macTtiInd.cells[0].timingInfo.hfn      = timingInfo.hfn;
   macTtiInd.cells[0].isDummyTti          = isDummyTti;
   /*TODO*/
   macTtiInd.cells[0].schTickDelta        = 0;
   macTtiInd.cells[0].dlBlankSf           = 0;
   macTtiInd.cells[0].ulBlankSf           = 0;
   schTtiInd = macTtiInd;

   /* send TTI indication to MAC */
   YsUiTfuTtiInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, &macTtiInd);

#if defined(SPLIT_RLC_DL_TASK) && defined(RLC_MAC_DAT_REQ_RBUF)
   rgDlDatReqBatchProc();
#endif 
#ifndef RG_SCH_DYNDLDELTA
   /* send TTI indication to scheduler */
   YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
                    cellCb->schTfuSap->suId,
                    &schTtiInd);

#ifdef RGL_SPECIFIC_CHANGES
      CM_MEAS_TIME(timingInfo.subframe, CM_DBG_MAC_TTI_IND, CM_DBG_SCH_TTI_IND);
#endif
#else
   /* Enabling dynamic delta for less than 4 UEs per TTI */
   if((cellCb->dlDeltaChgEnb)&& (cellCb->cellCfg.numDlUePerTti >= 2 ))
   {
#ifndef L2_L3_SPLIT
      ysDynDeltaChange(cellCb, &deltaChgAction);
#endif

   }
  switch(deltaChgAction)
  {
     case YS_DELTA_CHG_UP:
       macTtiInd.schTickDelta = cellCb->curDlDelta;
       macTtiInd.dlBlankSf    = 0;
       macTtiInd.ulBlankSf    = 0;
       //macTtiInd.isDummyTti   = 0;
       schTtiInd = macTtiInd;
       YsUiTfuTtiInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, &macTtiInd);
       /* send TTI indication to scheduler */
       YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
             cellCb->schTfuSap->suId,
             &schTtiInd);
       RLOG0(L_INFO,"Incrementing RGU SCH Delta to 1");
       cellCb->curDlDelta     =  1;
       gDelta1Cnt++;
#ifndef LTE_TDD
       /* In case of TDD, since step is performed in a DL subframe just before the UL subframe, it is not required to
        * post another TTI indication to scheduler with new delta. The new delta will be applied in the next TTI */
       //macTtiInd.schTickDelta = ttidelta;
       //macTtiInd.dlBlankSf = 0;
       //macTtiInd.ulBlankSf = 1;
       //macTtiInd.isDummyTti = 1;
#endif
       break;

       case YS_DELTA_CHG_DOWN:
          RLOG0(L_INFO,"Decrementing RGU SCH Delta to 0");
          cellCb->curDlDelta     = 0;
          gDelta0Cnt++;
          macTtiInd.schTickDelta = cellCb->curDlDelta;
          macTtiInd.dlBlankSf    = 1;
          macTtiInd.ulBlankSf    = 0;
          //macTtiInd.isDummyTti   = 0;
          schTtiInd = macTtiInd;
          YsUiTfuTtiInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, &macTtiInd);
          /* send TTI indication to scheduler */
          YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
                cellCb->schTfuSap->suId,
                &schTtiInd);
          break;

       case YS_DELTA_CHG_NONE:
         macTtiInd.schTickDelta = cellCb->curDlDelta;
         macTtiInd.dlBlankSf    = 0;
         macTtiInd.ulBlankSf    = 0;
         //macTtiInd.isDummyTti   = 0;
         schTtiInd = macTtiInd;
         YsUiTfuTtiInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, &macTtiInd);
         /* send TTI indication to scheduler */
         YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
               cellCb->schTfuSap->suId,
               &schTtiInd);
         break;

   }
   /* 4UE_TTI_DELTA */

#endif

#if defined(PDCP_RLC_DL_RBUF) && !defined(SPLIT_RLC_DL_TASK)  
   kwDlBatchProc();
#endif
#ifndef SPLIT_RLC_DL_TASK
#if (defined(L2_L3_SPLIT) && defined(ICC_RECV_TSK_RBUF))
   kwDlBatchProcSplit();
#endif
#endif
/* Moving the STA_RSP ring buffer reading to mt task handler function */

#ifdef SPLIT_RLC_DL_TASK
   ysSendRlcDlTtiInd(indx);
#endif

#ifdef RLC_MAC_STA_RSP_RBUF
   //rgDlStaRspBatchProc();
   rgBatchProc((U8)indx);
#endif


#ifdef L2_L3_SPLIT
#ifdef MAC_RLC_UL_RBUF
   ysSendRlcUlTtiInd(indx);

#endif

#if (defined (MAC_FREE_RING_BUF) || defined (RLC_FREE_RING_BUF))
         /* Release semaphore of free mgr thread */
         {
            //extern sem_t freeMgrSem;
            if( 0 != sem_post(&freeMgrSem))
               STKLOG(STK_MD_YS,STK_LOG_ERR,"Sem post failed...\n");



         }

#endif
   ysSendPdcpTtiInd(indx);
   if((ysPjTtiInd % 30000) == 0)
   {
    //  STKLOG(STK_MD_YS,STK_LOG_INFO,"Time : %ld sec\n", (ysPjTtiInd/1000));
   }
   ysPjTtiInd++;
#else
#endif

#ifdef L2_L3_SPLIT
   //if(numeTti % 2 == 0)
   {
#ifdef LGW_SUPPORT
      if(g_lgwSwitch == TRUE)
      {
          ysSendEgtpInd(EVTEGTRXLGWDATA, indx); /* RX LGW NL IND */
      }
      else
#endif
      {
         ysSendEgtpInd(EVTEGTRXDATA, indx);/*RX IND*/
      }
   }
   ysSendEgtpInd(EVTEGTTXDATA, indx);/*TX IND*/
#else
#ifdef RGL_SPECIFIC_CHANGES
   ysEgRxInd++;
   ysSendEgtpInd(EVTEGTRXDATA, indx);/*RX IND*/

   ysEgTxInd++;
   ysSendEgtpInd(EVTEGTTXDATA, indx);/*TX IND*/
#ifdef TENB_AS_SECURITY
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
   /*Rangeley debug */
   ysSendPdcpTtiInd(indx);
#endif
#endif
#else
   if(numeTti % 2 == 0)
   {
      if((ysEgRxInd - ysEgRxPrcCnt) < 10)
      {
         ysEgRxInd++;
         ysSendEgtpInd(EVTEGTRXDATA, indx);/*RX IND*/
      }
   }
#ifdef LGW_SUPPORT   
   if(numeTti % 2 == 0)
   {
      ysSendEgtpInd(EVTEGTRXLGWDATA, indx); /* RX LGW NL IND */
   }
#endif   
   if((ysEgTxInd - ysEgTxPrcCnt) < 20)
   {
      ysEgTxInd++;
      ysSendEgtpInd(EVTEGTTXDATA, indx);/*TX IND*/
#ifdef TENB_AS_SECURITY
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
      ysSendPdcpTtiInd(indx);
#endif
#endif
   }
#endif
#endif

#ifdef TUCL_TTI_RCV
   if(numeTti % 10 == 0)
   { 
      static Pst tmpPst = {
         .dstEnt = ENTHI, 
         .srcEnt = ENTYS
         };
      tmpPst.srcProcId = SFndProcId();
      
      Buffer   *buf = NULLP;
      
      SGetMsg(ysCb.ysInit[indx].region, ysCb.ysInit[indx].pool, &buf);
      SPstTsk(&tmpPst, buf);
   }
#endif /* TUCL_TTI_RCV */

#ifdef SS_DIAG 
   if((ssDiagSndToPack( &ysCb.ysInit[indx].lmPst)) != ROK)
   {
      RLOG_ARG0(L_ERROR, "ssPackLogs(): Packing of log failed");
   }
#endif
#if defined(TENB_T2K3K_SPECIFIC_CHANGES) && defined(LTE_TDD)
   YsUiTfuNonRtInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId);
#endif

#if 0
#ifdef TENB_STATS
   if (ysCb.statsPer)
   {
      if (numeTti % ysCb.statsPer == 0)
      {
         //NAVEEN TODO
#ifndef UL_RLC_NET_CLUSTER
         TSInfTrigStats(ysCb.ysInit[indx].region, ysCb.ysInit[indx].pool);   /*(region, pool)*/
#else
         {
            TSL2SendStatsToApp(&ysCb.ysInit[indx].lmPst, 0);
         }

#endif
      }
   }
#endif
#endif
   rlProcessTicks();
   SStopTask(startTime, PID_CL_DLM_PRC_TTI_IND);
   RETVALUE(ROK);

}

PUBLIC S16 ysMsDlmPrcTtiInd
(
PMSGIND         txStartInd,
YsCellCb        *cellCb,
Bool            isDummyTti
)
{
#if 0
   PGENMSGDESC  pMsgDesc = NULLP;
   YsPhyLstCp           *pUlDlList = NULLP;
#endif
  // U8                   sfNum;
   //S16             ret = ROK;
   CmLteTimingInfo timingInfo;
   /* HARQ */
   //CmLteTimingInfo rxSduSf;

   //YsUlL1Msg *ulRxSduInds = NULLP;
   //U8 loopCnt = 0;
#ifdef XXX_TASK_MEAS
#ifdef RG_ULSCHED_AT_CRC
   VOLATILE U32     startTime1 = 0;
   VOLATILE U32     startTime = 0;
#endif
/*   VOLATILE U32     startTime2 = 0;*/
   VOLATILE U32     startTime3 = 0;
#endif
#ifdef RG_SCH_DYNDLDELTA  
   U32              deltaChgAction = YS_DELTA_CHG_NONE;
#endif
   ++numeTti;

   TRC2(ysMsDlmPrcTtiInd)

   SStartTask(&startTime3, PID_CL_DLM_PRC_TTI_IND);

#ifdef RGL_SPECIFIC_CHANGES
   CM_MEAS_TIME(((gMeasSubframe+1)%10), CM_DBG_MAC_TTI_IND, CM_DBG_CL_TTI);                                          
#endif
   if (!cellCb->phyState)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "PHY is not in running state");
      uart_printf( "PHY is not in running state cell %d\n", cellCb->cellId);
      SStopTask(startTime3, PID_CL_DLM_PRC_TTI_IND);
      RETVALUE(RFAILED);
   }
   /* Set the current time information */
   timingInfo = cellCb->timingInfo;

#ifdef LTE_ADV
   /* LBT SIM PROCESSING */
   processLbtSim(timingInfo.sfn, timingInfo.subframe);
#endif

   {
   /* Allocate TTI for MAC */
      /* MSPD_DBG("Process TTI Indication On Receipt of TTI Ind %d %d %x\n", cellCb->timingInfo.sfn,
         cellCb->timingInfo.subframe, MX_GET_RADDR);*/
      /* CA dev Start */
      U8 idx = 0;
      YsCellCb    *macCellCb = NULLP;
#ifdef SPLIT_RLC_DL_TASK
      ysSendRlcDlTtiInd(0);
#endif 
      for(idx = 0; idx < (ysCb.numOfCells); idx++)
      {
         macCellCb = ysCb.tfuSapLst[idx]->cellCb; 
         macTtiInd.numCells                     = 1;/*Per mac inst its only 1 cell */
         macTtiInd.cells[0].cellId              = macCellCb->cellId;
         macTtiInd.cells[0].timingInfo.subframe = timingInfo.subframe;
         macTtiInd.cells[0].timingInfo.sfn      = timingInfo.sfn;
         macTtiInd.cells[0].timingInfo.hfn      = timingInfo.hfn;
         macTtiInd.cells[0].isDummyTti          = isDummyTti;     
         /*TODO*/ 
         macTtiInd.cells[0].schTickDelta        = 0;      
         macTtiInd.cells[0].dlBlankSf           = 0;      
         macTtiInd.cells[0].ulBlankSf           = 0;      

         schTtiInd.cells[idx] = macTtiInd.cells[0];/*CA dev*/
         /*Important Note: NumofTTIind to mac = num of cells
          * but for SCH only 1 TTInd is sent*/
         /* CA dev End */

         /* changing the order of TTI invocation
          * Old order - MAC then SCH
          * New order - SCH then MAC
          * This is a crude work around to get the TX vector in order
          * i.e. Data followed by PDCCH information.
          */
         /* send TTI indication to MAC */
         /* MSPD_DBG("Send MAC TTI Ind (%d %d)\n", macTtiInd.timingInfo.sfn, 
            macTtiInd.timingInfo.subframe); */
         YsUiTfuTtiInd(&macCellCb->macTfuSap->sapPst, macCellCb->macTfuSap->suId, &macTtiInd);
         /* MSPD_DBG("Send SCH TTI Ind (%d %d)\n", macTtiInd.timingInfo.sfn, 
            macTtiInd.timingInfo.subframe);*/
      }
      schTtiInd.numCells = ysCb.numOfCells;/*CA dev*/
#if defined(SPLIT_RLC_DL_TASK) && defined(RLC_MAC_DAT_REQ_RBUF)
      rgDlDatReqBatchProc();
#endif 
#ifndef RG_SCH_DYNDLDELTA
   /* send TTI indication to scheduler */
   YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
                    cellCb->schTfuSap->suId,
                    &schTtiInd);
   handleACIPCMsg(SC_TO_PA_SR_INDICATION_CH, cellCb->cellId- CM_START_CELL_ID);
   handleACIPCMsg(SC_TO_PA_CRC_INDICATION_CH, cellCb->cellId- CM_START_CELL_ID);
   handleACIPCMsg(SC_TO_PA_CQI_INDICATION_CH, cellCb->cellId- CM_START_CELL_ID);  
   handleACIPCMsg(SC_TO_PA_ULSCH_INDICATION_CH, cellCb->cellId- CM_START_CELL_ID);
   handleACIPCMsg(SC_TO_PA_ERROR_INDICATION_CH, cellCb->cellId- CM_START_CELL_ID);
#ifdef RGL_SPECIFIC_CHANGES
      CM_MEAS_TIME(timingInfo.subframe, CM_DBG_MAC_TTI_IND, CM_DBG_SCH_TTI_IND);
#endif
#else
   /* Enabling dynamic delta for less than 4 UEs per TTI */
   if((cellCb->dlDeltaChgEnb)&& (cellCb->cellCfg.numDlUePerTti >= 2 ))
   {
#ifndef L2_L3_SPLIT
      ysDynDeltaChange(cellCb, &deltaChgAction);
#endif

   }
  switch(deltaChgAction)
  {
     case YS_DELTA_CHG_UP:
       macTtiInd.schTickDelta = cellCb->curDlDelta;
       macTtiInd.dlBlankSf    = 0;
       macTtiInd.ulBlankSf    = 0;
       //macTtiInd.isDummyTti   = 0;
       schTtiInd = macTtiInd;
       YsUiTfuTtiInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, &macTtiInd);
       /* send TTI indication to scheduler */
       YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
             cellCb->schTfuSap->suId,
             &schTtiInd);
       RLOG0(L_INFO,"Incrementing RGU SCH Delta to 1");
       cellCb->curDlDelta     =  1;
       gDelta1Cnt++;
#ifndef LTE_TDD
       /* In case of TDD, since step is performed in a DL subframe just before the UL subframe, it is not required to
        * post another TTI indication to scheduler with new delta. The new delta will be applied in the next TTI */
       //macTtiInd.schTickDelta = ttidelta;
       //macTtiInd.dlBlankSf = 0;
       //macTtiInd.ulBlankSf = 1;
       //macTtiInd.isDummyTti = 1;
#endif
       break;

       case YS_DELTA_CHG_DOWN:
          RLOG0(L_INFO,"Decrementing RGU SCH Delta to 0");
          cellCb->curDlDelta     = 0;
          gDelta0Cnt++;
          macTtiInd.schTickDelta = cellCb->curDlDelta;
          macTtiInd.dlBlankSf    = 1;
          macTtiInd.ulBlankSf    = 0;
          //macTtiInd.isDummyTti   = 0;
          schTtiInd = macTtiInd;
          YsUiTfuTtiInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, &macTtiInd);
          /* send TTI indication to scheduler */
          YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
                cellCb->schTfuSap->suId,
                &schTtiInd);
          break;

       case YS_DELTA_CHG_NONE:
         macTtiInd.schTickDelta = cellCb->curDlDelta;
         macTtiInd.dlBlankSf    = 0;
         macTtiInd.ulBlankSf    = 0;
         //macTtiInd.isDummyTti   = 0;
         schTtiInd = macTtiInd;
         YsUiTfuTtiInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId, &macTtiInd);
         /* send TTI indication to scheduler */
         YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
               cellCb->schTfuSap->suId,
               &schTtiInd);
         break;

   }
   /* 4UE_TTI_DELTA */

#endif

#if defined(PDCP_RLC_DL_RBUF) && !defined(SPLIT_RLC_DL_TASK)  
      kwDlBatchProc();
#endif
#ifndef SPLIT_RLC_DL_TASK
#if (defined(L2_L3_SPLIT) && defined(ICC_RECV_TSK_RBUF))
      kwDlBatchProcSplit();
#endif
#endif
/* Moving the STA_RSP ring buffer reading to mt task handler function */

#ifdef RLC_MAC_STA_RSP_RBUF
      //rgDlStaRspBatchProc();
      rgBatchProc(0);
#endif


#ifdef L2_L3_SPLIT
#ifdef MAC_RLC_UL_RBUF
         ysSendRlcUlTtiInd(0);

#endif

#if (defined (MAC_FREE_RING_BUF) || defined (RLC_FREE_RING_BUF))
         /* Release semaphore of free mgr thread */
         {
            //extern sem_t freeMgrSem;
            if( 0 != sem_post(&freeMgrSem))
               STKLOG(STK_MD_YS,STK_LOG_ERR,"Sem post failed...\n");



         }

#endif
   ysSendPdcpTtiInd(0);
   if((ysPjTtiInd % 30000) == 0)
   {
    //  STKLOG(STK_MD_YS,STK_LOG_INFO,"Time : %ld sec\n", (ysPjTtiInd/1000));
   }
   ysPjTtiInd++;
#else
#endif

   }

#ifdef L2_L3_SPLIT
   //if(numeTti % 2 == 0)
   {
#ifdef LGW_SUPPORT
      if(g_lgwSwitch == TRUE)
      {
          ysSendEgtpInd(EVTEGTRXLGWDATA, 0); /* RX LGW NL IND */
      }
      else
#endif
      {
         ysSendEgtpInd(EVTEGTRXDATA, 0);/*RX IND*/
      }
   }
   ysSendEgtpInd(EVTEGTTXDATA, 0);/*TX IND*/
#else
#ifdef RGL_SPECIFIC_CHANGES
   ysEgRxInd++;
   ysSendEgtpInd(EVTEGTRXDATA,0);/*RX IND*/

   ysEgTxInd++;
   ysSendEgtpInd(EVTEGTTXDATA,0);/*TX IND*/
#ifdef TENB_AS_SECURITY
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
   /*Rangeley debug */
   ysSendPdcpTtiInd(0);
#endif
#endif
#else
   if(numeTti % 2 == 0)
   {
      if((ysEgRxInd - ysEgRxPrcCnt) < 10)
      {
         ysEgRxInd++;
         ysSendEgtpInd(EVTEGTRXDATA,0);/*RX IND*/
      }
   }
#ifdef LGW_SUPPORT   
   if(numeTti % 2 == 0)
   {
      ysSendEgtpInd(EVTEGTRXLGWDATA,0); /* RX LGW NL IND */
   }
#endif   
   if((ysEgTxInd - ysEgTxPrcCnt) < 20)
   {
      ysEgTxInd++;
      ysSendEgtpInd(EVTEGTTXDATA,0);/*TX IND*/
#ifdef TENB_AS_SECURITY
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
      ysSendPdcpTtiInd(0);
#endif
#endif
   }
#endif
#endif

#ifdef TUCL_TTI_RCV
   if(numeTti % 10 == 0)
   { 
      static Pst tmpPst = {
         .dstEnt = ENTHI, 
         .srcEnt = ENTYS
         };
      tmpPst.srcProcId = SFndProcId();
      
      Buffer   *buf = NULLP;
      
      SGetMsg(ysCb.ysInit[0].region, ysCb.ysInit[0].pool, &buf);
      SPstTsk(&tmpPst, buf);
   }
#endif /* TUCL_TTI_RCV */

#ifdef SS_DIAG 
   if((ssDiagSndToPack( &ysCb.ysInit[0].lmPst)) != ROK)
   {
      RLOG_ARG0(L_ERROR, "ssPackLogs(): Packing of log failed");
   }
#endif
#if defined(TENB_T2K3K_SPECIFIC_CHANGES) && defined(LTE_TDD)
   YsUiTfuNonRtInd(&cellCb->macTfuSap->sapPst, cellCb->macTfuSap->suId);
#endif

#if defined(LTE_TDD) && defined(TENB_STATS)
   if (ysCb.statsPer)
   {
      if (numeTti % ysCb.statsPer == 0)
      {
         //NAVEEN TODO
#ifndef UL_RLC_NET_CLUSTER
         TSInfTrigStats(ysCb.ysInit[0].region, ysCb.ysInit[0].pool);   /*(region, pool)*/
#else
         {
            TSL2SendStatsToApp(&ysCb.ysInit[0].lmPst, 0);
         }

#endif
      }
   }
#endif
   rlProcessTicks();
   SStopTask(startTime3, PID_CL_DLM_PRC_TTI_IND);
   RETVALUE(ROK);

}

#ifdef YS_ALL_PERF

#if YS_PHY_STOP_AUTO  /* Useful when auto stop is enabled */
PRIVATE Void ysAllPerfPrntTimes (YsCellCb      *cellCb)
{
   U32   indx;
   U32   prevIndx;
   float timeTaken;
   float ttiDiff;
   Txt   _prntBuf[256];

   sprintf(_prntBuf, "ysAllPerfPrntTimes Number of entries  (%d)\n",
         cellCb->ttiIndex);
   SPrint(_prntBuf);
   sprintf(_prntBuf, "\nStart EndTime\t\tDiff\t\tInterTtiDiff\tAvailMem \n");
   SPrint(_prntBuf);
   for (indx = 0; indx < YS_MS_MAX_PERF_TTI; indx++)
   {
      timeTaken = (cellCb->perfInfo[indx].ttiEndTick -
            cellCb->perfInfo[indx].ttiStartTick);
      timeTaken = (timeTaken / 150000.0);

      prevIndx = (indx == 0)? 0: (indx - 1);

      ttiDiff = (cellCb->perfInfo[indx].ttiStartTick -
            cellCb->perfInfo[prevIndx].ttiStartTick);
      ttiDiff = (ttiDiff / 150000.0);

      if(cellCb->maxtimeTaken < timeTaken)
         cellCb->maxtimeTaken = timeTaken;

      if(cellCb->maxttiDiff < ttiDiff)
         cellCb->maxttiDiff = ttiDiff;

      sprintf(_prntBuf, "\n\t(%d)\t(%d)\t(%u)\t(%u)\t(%f)\t(%f)\t(%d)",
            cellCb->perfInfo[indx].timingInfo.sfn,
            cellCb->perfInfo[indx].timingInfo.subframe,
            cellCb->perfInfo[indx].ttiStartTick,
            cellCb->perfInfo[indx].ttiEndTick, timeTaken, ttiDiff,
               cellCb->perfInfo[indx].avlMem);
      SPrint(_prntBuf);
   }

   sprintf(_prntBuf, "\nmaxtimeTaken=%f   maxttiDiff=%f\n",
         cellCb->maxtimeTaken, cellCb->maxttiDiff);
   SPrint(_prntBuf);
   RETVOID;
}

#else

PUBLIC Void ysPerfPrntTimes (YsCellCb      *cellCb)
{
   float timeTaken;
   float ttiDiff;
   Txt   _prntBuf[256];

   if(cellCb->ttiIndex == 0)
      cellCb->perfInfo.ttiEndTick = cellCb->perfInfo.ttiStartTick;

   timeTaken = (cellCb->perfInfo.ttiEndTick - cellCb->perfInfo.ttiStartTick);
   timeTaken = (timeTaken / 150000.0);
   sprintf(_prntBuf, "\t%f\n",timeTaken );

   SPrint(_prntBuf);

   RETVOID;
}

#endif
#endif

/*
*
*       Fun:   ysMsDlmSndVectSDU
*
*       Desc:  Send Tx and Rx vectors prepared in a linked list
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  ys_ms_dl.c
*
*/
PUBLIC S16 ysMsDlmSndVectSDU
(
YsCellCb        *cellCb
)
{
#if 0
   PGENMSGDESC          pMsgDesc;
#endif
   YsPhyLstCp           *pUlDlList = NULLP;
   PMAC2PHY_QUEUE_EL    pElem = NULLP;
   CmLteTimingInfo      timingInfo;
   U8                   sfNum;
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
#ifdef TENB_RTLIN_CHANGES
   TfuDatReqInfo     *datReq;
#endif
   S16 ret = ROK;   
 

#if defined(YS_MIB_WARND) || defined (YS_PHY_STOP_AUTO)
   static unsigned int  tticnt = 0;
#endif

   TRC2(ysMsDlmSndVectSDU)

   /* ys_qcPhy_itf by syq, begin */
   RETVALUE(ROK);
   /* ys_qcPhy_itf by syq, end */

   /*starting Task*/
   SStartTask(&startTime, PID_CL_SND_VECT_TO_PHY);

   if (!cellCb->phyState)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "PHY is not in running state");
      uart_printf( "PHY is not in running state cell %d", cellCb->cellId);
      RETVALUE(RFAILED);
   }

#ifdef YS_MIB_WARND
   if(++tticnt == 36)
   {
      acceptPrimsFrmMac = TRUE;
   }
#else
   tticnt++;
#endif
   if (tticnt >= 1000 * STAT_PERIOD)
   {
      tticnt =0;
   }

   timingInfo.subframe = cellCb->timingInfo.subframe;
   timingInfo.sfn      = cellCb->timingInfo.sfn;


   /* HARQ: CL Sending 2 subframes in advance */
   sfNum = (timingInfo.subframe + (TFU_DELTA )) % YS_NUM_SUB_FRAMES;

   /* Send the TxVector, Tx SDUs for PDCCH and DL Data, HIDCI0 vector and
      HIDCI0 SDUs */
   pUlDlList = &cellCb->dlEncL1Msgs[sfNum].ulDlLst;

#ifdef TENB_RTLIN_CHANGES
   /* Madhur : Somewhat a good story to ponder and to know. MSPD has strict sequencing of
      message Id. MSPD expects Tx Control + Tx Sdu + Rx Control, (PDCCH, PDSCH, PUSCH) in 
      order. This means our SCH TtiIndication should be processed ahead of data request.
      Providing SCH Tti Indication ahead of MAC TTI Indication in case of single core
      solution will delay the Bo Processing at MAC. Leading MAC to discard the PDSCH 
      data. Hence I had to end  up sending MAC TtiIndication ahead of SCH TtiIndication.
      This would lead to MAC data request arriving ahead of Control, which will mess up
      the sequence to PDSCH , PDCCH, PUSCH, incorrectly.  Hence at the data request we would 
      not be populating the uldlList with data. It will be populated just before data
      dispatch to lower layers 
      This whole point of me writing is to highlight the poor implementation, rather this has
      arised because of poor implementation and amendment from MSPD interface. The presence of
      statemachine would have nullified the problem forever. Going ahead a function shall 
      be implemented which should be called from Control request, Reception request and
      data request, which shall decide whether subframe is ready for dispatch. */
   datReq = cellCb->dlEncL1Msgs[sfNum].datReq;
   if (datReq)
   {
      ret = ysMsDlmPrcDatReq(cellCb, datReq);

      if(ret != ROK)
      {
         RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "Failed to process Data Request");
       /*Dat Request will be freed when this subframe comes for processing next in TTI indication*/
/*         ysUtlFreeDatReq(datReq);*/
         RETVALUE(RFAILED);
      }
      /*Dat Request will be freed when this subframe comes for processing next in TTI indication*/
      /*ysUtlFreeDatReq(datReq);
      cellCb->dlEncL1Msgs[sfNum].datReq = NULLP;*/
   }
#endif


    /* HARQ_DBG */
#ifdef CL_DEBUG
    RLOG4(L_DEBUG,"Tx Vector %x at TTI(%d, %d) for sfNum %d",
         pUlDlList->head, timingInfo.sfn, timingInfo.subframe, sfNum);
#endif

   /* Add rxVector to the list */
   {
      PGENMSGDESC   pRxVector;
      PULSUBFRDESC  pUlSf;
      /* HARQ: CL sending 1 subframes in advance */
      sfNum = (timingInfo.subframe + (PHY_RECPREQ_DLDELTA)) % YS_NUM_SUB_FRAMES;
      /* If batch processing is enabled along with TL ALLOC ICC MEM  then rxVector memory has 
         MAC2PHY_QUEUE_EL also else we need to allocate memory of pELem */
#ifndef BATCH_PROCESSING_DL
      pRxVector = (cellCb->ulEncL1Msgs[sfNum].rxVector);
#else
      pElem = (cellCb->ulEncL1Msgs[sfNum].rxVector);
#endif

#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
#ifndef BATCH_PROCESSING_DL
      if (pRxVector == NULLP)
#else
      if (pElem == NULLP)
#endif
      {
         stop_printf("pElem is NULLP %d\n", sfNum);
      }
      if(cellCb->ulEncL1Msgs[sfNum].addRxVecToLst == TRUE)
#else
#ifndef BATCH_PROCESSING_DL
      if (pRxVector)
#else
      if (pElem)
#endif
#endif
      {
#ifdef BATCH_PROCESSING_DL
         pRxVector = (PGENMSGDESC)(pElem + 1);
#endif
         pUlSf = (PULSUBFRDESC) (pRxVector + 1);
/*
         RLOG4(L_INFO,"Sending RX Vector to PHY :  RX VECTOR time -" 
               "(%d) (%d) Cell Time (%d) (%d)",
               pUlSf->frameNumber, 
               pUlSf->subframeNumber,
               cellCb->timingInfo.sfn, 
               cellCb->timingInfo.subframe);
*/
         if ((pUlSf->numberofChannelDescriptors -
                  pUlSf->numberOfCtrlChannelDescriptors) >= 2)
         {
//#ifdef CL_DEBUG
           /* RLOG4(L_DEBUG,"MUE_PER_TTI_UL: pUlSf->frameNumber %u "
                  "pUlSf->subframeNumber %u total"
                  "channels %u PUSCH %u",
               pUlSf->frameNumber,pUlSf->subframeNumber,
               pUlSf->numberofChannelDescriptors,
                  pUlSf->numberofChannelDescriptors,
                  pUlSf->numberOfCtrlChannelDescriptors); */
//#endif
         }

#ifndef BATCH_PROCESSING_DL
      /* As batch is disabled, we need to allocate memory for pElem */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
         pElem = ysMsUtlGetPhyListElem();
#endif
         if (!pElem)
         {
            /* HARQ_DBG */
            uart_printf("Memory allocation failed for PHY list element"
                        "for rxVector at time(%d,%d)\n",
                        cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
            RETVALUE(RFAILED);
         }
         
       
#ifdef TENB_RTLIN_CHANGES
         YS_MS_FILL_PHY_LIST_ELEM(pElem, pUlSf->frameNumber, pUlSf->subframeNumber,
               ysGetPhyPtr(pRxVector), sizeof(GENMSGDESC) + sizeof(ULSUBFRDESC), PHY_RXSTART_REQ);
#else
         YS_MS_FILL_PHY_LIST_ELEM(pElem, pUlSf->frameNumber, pUlSf->subframeNumber,
               pRxVector, sizeof(GENMSGDESC) + sizeof(ULSUBFRDESC), PHY_RXSTART_REQ);
#endif
#else
#ifdef RGL_SPECIFIC_CHANGES
         YS_MS_FILL_PHY_LIST_ELEM(pElem, pUlSf->frameNumber, pUlSf->subframeNumber,
               NULLP, (sizeof(GENMSGDESC) + pUlSf->offsetRachCtrlStruct + sizeof(RACHCTRL)), PHY_RXSTART_REQ);
#else
         YS_MS_FILL_PHY_LIST_ELEM(pElem, pUlSf->frameNumber, pUlSf->subframeNumber,
               NULLP, (sizeof(GENMSGDESC) + sizeof(ULSUBFRDESC)), PHY_RXSTART_REQ);
#endif
#endif
         ysMsUtlAddToPhyList(pUlDlList,pElem);
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
         cellCb->ulEncL1Msgs[sfNum].rxVector = NULLP;
#else
         cellCb->ulEncL1Msgs[sfNum].addRxVecToLst = FALSE;
#endif
      }
   }

   /* Send the pointer to the linked list to PHY */

   if (pUlDlList->count < 2)
   {
     if (acceptPrimsFrmMac)
      {
#ifdef CL_DEBUG
         RLOG5(L_DEBUG,"Dropping vectors at cell time(%d,%d):ListCp count (%d) Head (%x) Tail (%x)",
                  cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
                  pUlDlList->count, pUlDlList->head, pUlDlList->tail);
#endif
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
        ysMsUtlFreePhyList(pUlDlList);
        cellCb->dlEncL1Msgs[sfNum].txVector = NULLP;
#else
   /* Re-initialize the sent lists */
   sfNum = (timingInfo.subframe + (TFU_DELTA)) % YS_NUM_SUB_FRAMES;
   //ysMsUtlInitPhyList(&ysCb.combUlDlLst[sfNum]);
   ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[sfNum].dlData);
   ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[sfNum].dlCntrl);
   cellCb->dlEncL1Msgs[sfNum].addTxVecToLst = FALSE;
#endif
      }
     RETVALUE(ROK);
   }
#ifdef ENABLE_CNM
   /* Append ICTA msgs if any */
   
   sfNum = (timingInfo.subframe + (TFU_DLCNTRL_DLDELTA)) % YS_NUM_SUB_FRAMES;
   if(cellCb->ictaMsgLst[sfNum].ictaLst.count)
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"\n Sending the icta msgs for (%d) at (%d %d)\n",
         sfNum,cellCb->timingInfo.sfn,
         cellCb->timingInfo.subframe);

      ysMsUtlCatPhyList(pUlDlList, &cellCb->ictaMsgLst[sfNum].ictaLst);
   }
#endif

#ifdef CL_DEBUG
   RLOG4(L_DEBUG,"(%u, %u) head(%0x) count (%0x)",
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
            pUlDlList->head, pUlDlList->count);
#endif
   /* Drop the TX & RX vector we detect that we are late. 
    * This will be flushed in next TTI by Missed Sending Vector 
    * handler */
   cellCb->prev_sf  = timingInfo.subframe;
   cellCb->prev_sfn = timingInfo.sfn;


   /* Re-initialize the sent lists */
   sfNum = (timingInfo.subframe + (TFU_DELTA)) % YS_NUM_SUB_FRAMES;
   //ysMsUtlInitPhyList(&ysCb.combUlDlLst[sfNum]);
   ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[sfNum].dlData);
   ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[sfNum].dlCntrl);
//#ifdef RG_SCH_DYNDLDELTA
#ifdef SPLIT_RLC_DL_TASK
   cellCb->dlEncL1Msgs[sfNum].isCrcToMacSnd = FALSE;
   YS_FREE_SDU(cellCb->dlEncL1Msgs[sfNum].cntrlReq);
#endif
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
   cellCb->dlEncL1Msgs[sfNum].txVector = NULLP;
#else
   cellCb->dlEncL1Msgs[sfNum].addTxVecToLst = FALSE;
#endif
#ifndef TENB_RTLIN_CHANGES
   cellCb->isAdvTtiSent[timingInfo.subframe] = FALSE;
   //RLOG1(L_DEBUG,"Reset Hq Var %d", timingInfo.subframe);
#endif
   cellCb->isAdvTtiSent[timingInfo.subframe] = FALSE;
   //RLOG1(L_DEBUG,"Reset Hq Var %d", timingInfo.subframe);
   sfNum = (timingInfo.subframe + (TFU_ULCNTRL_DELTA)) % YS_NUM_SUB_FRAMES;
   ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[sfNum].ulCntrl);
   cellCb->dlEncL1Msgs[sfNum].numChannels = 0;

   sfNum = (timingInfo.subframe + (PHY_RECPREQ_DLDELTA )) % YS_NUM_SUB_FRAMES;      
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
   cellCb->ulEncL1Msgs[sfNum].rxVector = NULLP;
#else
   cellCb->ulEncL1Msgs[sfNum].addRxVecToLst = FALSE;
#endif
#ifdef ENABLE_CNM
   sfNum = (timingInfo.subframe + (TFU_DLCNTRL_DLDELTA)) % YS_NUM_SUB_FRAMES;
   ysMsUtlInitPhyList(&cellCb->ictaMsgLst[sfNum].ictaLst);
   cellCb->ictaMsgLst[sfNum].ictaMsg  = NULLP;
#endif
   /*stopping Task*/
   SStopTask(startTime, PID_CL_SND_VECT_TO_PHY);
   RETVALUE(ROK);
}

/*
*
*       Fun:   ysMsDlmPrcTxEndInd
*
*       Desc:  TxEnd.Ind handler from PHY
*
*       Ret:   ROK/RFAILED
*
*       Notes: None
*
*       File:  ys_ms_dl.c
*
*/
PUBLIC S16 ysMsDlmPrcTxEndInd
(
PINITIND        txEndInd,
YsCellCb        *cellCb
)
{
   TRC2(ysMsDlmPrcTxEndInd)

   RETVALUE(ROK);
} /* End of ysMsDlmPrcTxEndInd */








/** Print LTE PHY API message
 *
 * @param level Bitmask specifying current debug level
 * @param vector Pointer to the PHY API message
 * @return Standard result code
 */
#ifndef TENB_RTLIN_CHANGES
PUBLIC S16 DiagDumpPhyApi(PTR vector)
{
    PGENMSGDESC pGen = (PGENMSGDESC) vector;
    PDLSUBFRDESC pDlSf;
    PULSUBFRDESC pUlSf;
    PTXSDUREQ pTxSduReq;
    PRXSDUIND pRxSduInd;
    DLCHANDESC *pDlCh;
    ULCHANDESC *pUlCh;
    DLSUBCHINFO *pSubCh;
    ULSUBCHINFO *pUlSubCh;
#ifdef DEBUGP
    CRCINFO *pCrc;
    SCRAMBLERINFO *pScram;
    DLDEDICATEDPRECODERINFO *pPrecoder;
    DLCMNTXPWRCTL *pPwrCtl;
    PULSUBFRCMNCTRL pUlCmnCtrl;
    RACHCTRL *pRachCtrl;
    PINITPARM pInit;
    PMSGIND pMsgInd;
#endif
    MAPPINGINFO *pMapping;
    DCICHANNELDESC *pDciCh;
    ULCTRLCHDESC *pUlCtrlCh;
    SRSDED *pSrs;
    unsigned int i, j, k;
    unsigned char *pDat;


    RLOG1(L_INFO,"pGen->msgSpecific=%i", pGen->msgSpecific);
    RLOG1(L_INFO,"pGen->msgType=%i", pGen->msgType);
    RLOG1(L_INFO,"pGen->phyEntityId=%i", pGen->phyEntityId);

    switch (pGen->msgType)
    {
    case PHY_TXSTART_REQ:
        pDlSf = (PDLSUBFRDESC) (pGen + 1);

        RLOG1(L_INFO,"  pDlSf->frameNumber=%i", pDlSf->frameNumber);
        RLOG1(L_INFO,"  pDlSf->subframeNumber=%i", pDlSf->subframeNumber);
        RLOG1(L_INFO,"  pDlSf->subframeType=%i", pDlSf->subframeType);
        RLOG1(L_INFO,"  pDlSf->antennaPortcount=%i", pDlSf->antennaPortcount);
         RLOG1(L_INFO,"  pDlSf->numberofChannelDescriptors=%i",
                  pDlSf->numberofChannelDescriptors);
        RLOG1(L_INFO,"  pDlSf->offsetPowerCtrl=%i", pDlSf->offsetPowerCtrl);
         RLOG1(L_INFO,"  pDlSf->offsetDCIChannels=%i",
                  pDlSf->offsetDCIChannels);
         RLOG1(L_INFO,"  pDlSf->offsetCustomFeatures=%i",
                  pDlSf->offsetCustomFeatures);
        RLOG1(L_INFO,"  pDlSf->numCtrlSymbols=%i", pDlSf->numCtrlSymbols);
        RLOG1(L_INFO,"  pDlSf->phichResource=%i", pDlSf->phichResource);
        RLOG1(L_INFO,"  pDlSf->phichDuration=%i", pDlSf->phichDuration);
         RLOG1(L_INFO,"  pDlSf->numberOfPhichChannels=%i",
                  pDlSf->numberOfPhichChannels);
        RLOG1(L_INFO,"  pDlSf->numCtrlChannels=%i", pDlSf->numCtrlChannels);

        pDlCh = &pDlSf->dlCh[0];
        for (i = 0; i < pDlSf->numberofChannelDescriptors - pDlSf->numCtrlChannels; i++)
        {
            RLOG1(L_INFO,"CHANNEL %i:----------", i);
            RLOG1(L_INFO,"    pDlCh->offsetNextCh=%i", pDlCh->offsetNextCh);
            RLOG1(L_INFO,"    pDlCh->channelId=%i", pDlCh->channelId);
            RLOG1(L_INFO,"    pDlCh->txpowerControl=%i", pDlCh->txpowerControl);
            RLOG1(L_INFO,"    pDlCh->persistEnable=%i",
                     pDlCh->persistEnable);
            RLOG1(L_INFO,"    pDlCh->repeatCycle=%i", pDlCh->repeatCycle);
            RLOG1(L_INFO,"    pDlCh->channelType=%i", pDlCh->channelType);
            RLOG1(L_INFO,"    pDlCh->hCid=%i", pDlCh->hCid);
            RLOG1(L_INFO,"    pDlCh->numCodeWords=%i", pDlCh->numCodeWords);
            RLOG1(L_INFO,"    pDlCh->nLayers=%i", pDlCh->nLayers);
            RLOG1(L_INFO,"    pDlCh->transmissionMode=%i",
                     pDlCh->transmissionMode);

            pSubCh = &pDlCh->subChInfo[0];
            for (j = 0; j < pDlCh->numCodeWords; j++)
            {
                RLOG1(L_INFO,"SUBCHANNEL %i:----------", j);
                RLOG1(L_INFO,"      pSubCh->codingDescriptor=%i", pSubCh->codingDescriptor);
                RLOG1(L_INFO,"      pSubCh->blockCodeConcatenation=%i", pSubCh->blockCodeConcatenation);
                RLOG1(L_INFO,"      pSubCh->modulationType=%i", pSubCh->modulationType);
                RLOG1(L_INFO,"      pSubCh->mcsType=%i", pSubCh->mcsType);
                RLOG1(L_INFO,"      pSubCh->nDi=%i", pSubCh->nDi);
                RLOG1(L_INFO,"      pSubCh->rV=%i", pSubCh->rV);
                RLOG1(L_INFO,"      pSubCh->flushReq=%i", pSubCh->flushReq);

                pSubCh++;
            }

#ifdef DEBUGP
            pCrc = &pDlCh->crcInfo;
            RLOG1(L_INFO,"    pCrc->crcLength=%i", pCrc->crcLength);
            RLOG1(L_INFO,"    pCrc->crcScrambling=%i", pCrc->crcScrambling);

            pScram = &pDlCh->scrInfo;
            RLOG1(L_INFO,"    pScram->scramblerType=%i", pScram->scramblerType);
            RLOG1(L_INFO,"    pScram->scrinitValueinput=%i", pScram->scrinitValueinput);

            pPrecoder = &pDlCh->dlPrecoderInfo;
            RLOG1(L_INFO,"    pPrecoder->cddType=%i", pPrecoder->cddType);
            RLOG1(L_INFO,"    pPrecoder->codeBookIdx=%i", pPrecoder->codeBookIdx);
#endif

            pMapping = &pDlCh->mapInfo;
            RLOG1(L_INFO,"    pMapping->numberofEntries=%i", pMapping->numberofEntries);
            for (k = 0; k < pMapping->numberofEntries; k++)
            {
                RLOG1(L_INFO,"        pMapping->reselmInfo startRes=[%i]......",
                       pMapping->reselmInfo[k].startRes);
                RLOG1(L_INFO,"        pMapping->reselmInfo numRes=[%i]",
                       pMapping->reselmInfo[k].numRes);
            }

            pDlCh++;
        }

        pDciCh = (DCICHANNELDESC *) ((unsigned long) pDlSf + (unsigned long) pDlSf->offsetDCIChannels);
        for (i = 0; i < pDlSf->numCtrlChannels; i++)
        {
            RLOG1(L_INFO,"CTRL CHANNEL %i:---------------", i);
            RLOG1(L_INFO,"    pDciCh->offsetNextCh=%i", pDciCh->offsetNextCh);
            RLOG1(L_INFO,"    pDciCh->channelId=%i", pDciCh->channelId);
            RLOG1(L_INFO,"    pDciCh->txpowerControl=%i", pDciCh->txpowerControl);
            RLOG1(L_INFO,"    pDciCh->crcLength=%i", pDciCh->crcLength);
            RLOG1(L_INFO,"    pDciCh->crcScrambling=%i", pDciCh->crcScrambling);
            RLOG1(L_INFO,"    pDciCh->channelType=%i", pDciCh->channelType);
            RLOG1(L_INFO,"    pDciCh->numCodeWords=%i", pDciCh->numCodeWords);
            RLOG1(L_INFO,"    pDciCh->nLayers=%i", pDciCh->nLayers);
            RLOG1(L_INFO,"    pDciCh->transmissionMode=%i", pDciCh->transmissionMode);
            RLOG1(L_INFO,"    pDciCh->scrmblerInitValue=%i", pDciCh->scrmblerInitValue);
            RLOG1(L_INFO,"    pDciCh->numberofEntries=%i", pDciCh->numberofEntries);
            RLOG1(L_INFO,"    pDciCh->startRes=%i", pDciCh->startRes);
            RLOG1(L_INFO,"    pDciCh->numRes=%i", pDciCh->numRes);

            pDciCh++;
        }
#ifdef DEBUGP
        if (pDlSf->offsetPowerCtrl != 0)
        {
            pPwrCtl = (DLCMNTXPWRCTL*) ((unsigned long)pDlSf + (unsigned long)pDlSf->offsetPowerCtrl);
            RLOG1(L_INFO,"  pPwrCtl->pilotPower=%i", pPwrCtl->pilotPower);
            RLOG1(L_INFO,"  pPwrCtl->psyncPower=%i", pPwrCtl->psyncPower);
            RLOG1(L_INFO,"  pPwrCtl->ssyncPower=%i", pPwrCtl->ssyncPower);
            RLOG1(L_INFO,"  pPwrCtl->ciPower=%i", pPwrCtl->ciPower);
            RLOG1(L_INFO,"  pPwrCtl->paprControl=%i", pPwrCtl->paprControl);
            RLOG1(L_INFO,"  pPwrCtl->paprThreshold=%i", pPwrCtl->paprThreshold);
        }
#endif
        break;

    case PHY_TXSDU_REQ:
        {

           U32          msgIdx = 0;
           U16          numBytes;

           pTxSduReq = (PTXSDUREQ) pGen;
           RLOG1(L_INFO,"  pTxSdu->nackAck=%i", pTxSduReq->nackAck);
           RLOG1(L_INFO,"  pTxSdu->uciFormat=%i", pTxSduReq->uciFormat);
           RLOG1(L_INFO,"  pTxSdu->channelType=%i", pTxSduReq->channelType);
           RLOG1(L_INFO,"  pTxSdu->phichSeqIndex=%i", pTxSduReq->phichSeqIndex);
           RLOG1(L_INFO,"  pTxSdu->cwId=%i", pTxSduReq->cwId);
           RLOG1(L_INFO,"  pTxSdu->msgLen=%i", pTxSduReq->msgLen);
           RLOG1(L_INFO,"  pTxSdu->phichGrpNumber=%i", pTxSduReq->phichGrpNumber);
           RLOG1(L_INFO,"  pTxSdu->maxBitsperCw=%i", pTxSduReq->maxBitsperCw);
           numBytes = (pTxSduReq->maxBitsperCw / 8);
           if ((pTxSduReq->maxBitsperCw % 8) != 0)
           {
              numBytes++;
           }

           pDat = (unsigned char *) (pTxSduReq + 1);
           for (i = 0; i < numBytes;i++)
           {

              msgIdx += 4;
           }

           msgIdx++;
        }
        break;

         /*TODO:Commeting these for the time being, to avoid unnnecessary prints, uncomment it further */
    case PHY_RXSTART_REQ:
        pUlSf = (PULSUBFRDESC) (pGen + 1);

        RLOG1(L_INFO,"  pUlSf->frameNumber=%i", pUlSf->frameNumber);
        RLOG1(L_INFO,"  pUlSf->subframeNumber=%i", pUlSf->subframeNumber);
        RLOG1(L_INFO,"  pUlSf->subframeType=%i", pUlSf->subframeType);
        RLOG1(L_INFO,"  pUlSf->antennaPortcount=%i", pUlSf->antennaPortcount);
        RLOG1(L_INFO,"  pUlSf->numberofChannelDescriptors=%i", pUlSf->numberofChannelDescriptors);
        RLOG1(L_INFO,"  pUlSf->numberOfCtrlChannelDescriptors=%i", pUlSf->numberOfCtrlChannelDescriptors);
        RLOG1(L_INFO,"  pUlSf->numberSrsinSf=%i", pUlSf->numberSrsinSf);
        RLOG1(L_INFO,"  pUlSf->offsetRachCtrlStruct=%i", pUlSf->offsetRachCtrlStruct);
        RLOG1(L_INFO,"  pUlSf->offsetULCtrlChannels=%i", pUlSf->offsetULCtrlChannels);
        RLOG1(L_INFO,"  pUlSf->offsetsrsInfo=%i", pUlSf->offsetsrsInfo);
        RLOG1(L_INFO,"  pUlSf->offsetCustomFeatures=%i", pUlSf->offsetCustomFeatures);

#ifdef DEBUGP
        pUlCmnCtrl = &pUlSf->ulSfrCtrl;
        RLOG1(L_INFO,"    pUlCmnCtrl->deltaPUCCHShift=%i", pUlCmnCtrl->deltaPUCCHShift);
        RLOG1(L_INFO,"    pUlCmnCtrl->nRBCQI=%i", pUlCmnCtrl->nRBCQI);
        RLOG1(L_INFO,"    pUlCmnCtrl->nCSAn=%i", pUlCmnCtrl->nCSAn);
        RLOG1(L_INFO,"    pUlCmnCtrl->n1PucchAN=%i", pUlCmnCtrl->n1PucchAN);
        RLOG1(L_INFO,"    pUlCmnCtrl->srsBandwitdhConfig=%i", pUlCmnCtrl->srsBandwitdhConfig);
        RLOG1(L_INFO,"    pUlCmnCtrl->srsSubframeConfig=%i", pUlCmnCtrl->srsSubframeConfig);
        RLOG1(L_INFO,"    pUlCmnCtrl->ackNackSRSSimultaneousTransmission=%i", pUlCmnCtrl->ackNackSRSSimultaneousTransmission);
        RLOG1(L_INFO,"    pUlCmnCtrl->nSB=%i", pUlCmnCtrl->nSB);
        RLOG1(L_INFO,"    pUlCmnCtrl->hoppingMode=%i", pUlCmnCtrl->hoppingMode);
        RLOG1(L_INFO,"    pUlCmnCtrl->puschhoppingOffset=%i", pUlCmnCtrl->puschhoppingOffset);
        RLOG1(L_INFO,"    pUlCmnCtrl->enable64QAM=%i", pUlCmnCtrl->enable64QAM);
        RLOG1(L_INFO,"    pUlCmnCtrl->groupHoppingEnabled=%i", pUlCmnCtrl->groupHoppingEnabled);
        RLOG1(L_INFO,"    pUlCmnCtrl->groupAssignmentPUSCH=%i", pUlCmnCtrl->groupAssignmentPUSCH);
        RLOG1(L_INFO,"    pUlCmnCtrl->sequenceHoppingEnabled=%i", pUlCmnCtrl->sequenceHoppingEnabled);
        RLOG1(L_INFO,"    pUlCmnCtrl->cyclicShift=%i", pUlCmnCtrl->cyclicShift);
#endif

        pUlCh = &pUlSf->ulCh[0];
        for (i = 0; (int)i < (pUlSf->numberofChannelDescriptors - pUlSf->numberOfCtrlChannelDescriptors); i++)
        {
            RLOG1(L_INFO,"CHANNEL %i:----------", i);
            RLOG1(L_INFO,"    pUlCh->offsetNextCh=%i", pUlCh->offsetNextCh);
            RLOG1(L_INFO,"    pUlCh->channelId=%i", pUlCh->channelId);
            RLOG1(L_INFO,"    pUlCh->txpowerControl=%i", pUlCh->txpowerControl);
            RLOG1(L_INFO,"    pUlCh->persistEnable=%i", pUlCh->persistEnable);
            RLOG1(L_INFO,"    pUlCh->repeatCycle=%i", pUlCh->repeatCycle);
            RLOG1(L_INFO,"    pUlCh->channelType=%i", pUlCh->channelType);
            RLOG1(L_INFO,"    pUlCh->halfIterations=%i", pUlCh->halfIterations);

            pUlSubCh = &pUlCh->ulSubChInfo;
            RLOG1(L_INFO,"    pUlSubCh->mcinfo.codingDescriptor=%i", pUlSubCh->mcinfo.codingDescriptor);
            RLOG1(L_INFO,"    pUlSubCh->mcinfo.blockCodeConcatenation=%i", pUlSubCh->mcinfo.blockCodeConcatenation);
            RLOG1(L_INFO,"    pUlSubCh->mcinfo.modulationType=%i", pUlSubCh->mcinfo.modulationType);
            RLOG1(L_INFO,"    pUlSubCh->mcinfo.mcsType=%i", pUlSubCh->mcinfo.mcsType);
            RLOG1(L_INFO,"    pUlSubCh->harqInfo.nDi=%i", pUlSubCh->harqInfo.nDi);
            RLOG1(L_INFO,"    pUlSubCh->harqInfo.rV=%i", pUlSubCh->harqInfo.rV);
            RLOG1(L_INFO,"    pUlSubCh->harqInfo.flushReq=%i", pUlSubCh->harqInfo.flushReq);
            RLOG1(L_INFO,"    pUlSubCh->crcInfo.crcLength=%i", pUlSubCh->crcInfo.crcLength);
            RLOG1(L_INFO,"    pUlSubCh->crcInfo.crcScrambling=%i", pUlSubCh->crcInfo.crcScrambling);
            RLOG1(L_INFO,"    pUlSubCh->scrInfo.scramblerType=%i", pUlSubCh->scrInfo.scramblerType);
            RLOG1(L_INFO,"    pUlSubCh->scrInfo.scrinitValueinput=%i", pUlSubCh->scrInfo.scrinitValueinput);
            RLOG1(L_INFO,"    pUlSubCh->puschDed.betaOffsetACKIndex=%i", pUlSubCh->puschDed.betaOffsetACKIndex);
            RLOG1(L_INFO,"    pUlSubCh->puschDed.betaOffsetRIIndex=%i", pUlSubCh->puschDed.betaOffsetRIIndex);
            RLOG1(L_INFO,"    pUlSubCh->puschDed.betaOffsetCQIIndex=%i", pUlSubCh->puschDed.betaOffsetCQIIndex);
            RLOG1(L_INFO,"    pUlSubCh->cqiPmiRiRpt.cqiReportModeAperiodic=%i", pUlSubCh->cqiPmiRiRpt.cqiReportModeAperiodic);
            RLOG1(L_INFO,"    pUlSubCh->cqiPmiRiRpt.nomPDSCHRSEPREOffset=%i", pUlSubCh->cqiPmiRiRpt.nomPDSCHRSEPREOffset);
            RLOG1(L_INFO,"    pUlSubCh->cqiPmiRiRpt.cqiReportPeriodicEnable=%i", pUlSubCh->cqiPmiRiRpt.cqiReportPeriodicEnable);
            RLOG1(L_INFO,"    pUlSubCh->cqiPmiRiRpt.cqiPUCCHResourceIndex=%i", pUlSubCh->cqiPmiRiRpt.cqiPUCCHResourceIndex);
            RLOG1(L_INFO,"    pUlSubCh->cqiPmiRiRpt.cqipmiConfigIndex=%i", pUlSubCh->cqiPmiRiRpt.cqipmiConfigIndex);
            RLOG1(L_INFO,"    pUlSubCh->cqiPmiRiRpt.cqiFormatIndicatorPeriodic=%i", pUlSubCh->cqiPmiRiRpt.cqiFormatIndicatorPeriodic);
            RLOG1(L_INFO,"    pUlSubCh->cqiPmiRiRpt.K=%i", pUlSubCh->cqiPmiRiRpt.K);
            RLOG1(L_INFO,"    pUlSubCh->cqiPmiRiRpt.riConfigIndex=%i", pUlSubCh->cqiPmiRiRpt.riConfigIndex);
            RLOG1(L_INFO,"    pUlSubCh->cqiPmiRiRpt.simultaneousAckNackAndCQI=%i", pUlSubCh->cqiPmiRiRpt.simultaneousAckNackAndCQI);

            RLOG1(L_INFO,"    pUlSubCh->mapInfo.numberofEntries=%i", pUlSubCh->mapInfo.numberofEntries);
            for (j = 0; j < pUlSubCh->mapInfo.numberofEntries; j++)
            {
                RLOG3(L_INFO,"      pUlSubCh->mapInfo.reselmInfo[%i]=(%i,%i)", j,
                       pUlSubCh->mapInfo.reselmInfo[j].startRes,
                       pUlSubCh->mapInfo.reselmInfo[j].numRes);
            }
            pUlCh++;
        }
        pUlCtrlCh = &pUlSf->ulCtlCh[0];
        for (i = 0; i < pUlSf->numberOfCtrlChannelDescriptors; i++)
        {
            RLOG1(L_INFO,"CTRL CHANNEL %i:----------", i);
            RLOG1(L_INFO,"    pUlCtrlCh->offsetNextCh=%i", pUlCtrlCh->offsetNextCh);
            RLOG1(L_INFO,"    pUlCtrlCh->channelId=%i", pUlCtrlCh->channelId);
            RLOG1(L_INFO,"    pUlCtrlCh->txpowerControl=%i", pUlCtrlCh->txpowerControl);
            RLOG1(L_INFO,"    pUlCtrlCh->crcLength=%i", pUlCtrlCh->crcLength);
            RLOG1(L_INFO,"    pUlCtrlCh->channelType=%i", pUlCtrlCh->channelType);
            RLOG1(L_INFO,"    pUlCtrlCh->scrmblerInitValue=%i", pUlCtrlCh->scrmblerInitValue);
            RLOG1(L_INFO,"    pUlCtrlCh->codingDescriptor=%i", pUlCtrlCh->codingDescriptor);
            RLOG1(L_INFO,"    pUlCtrlCh->blockCodeConcatenation=%i", pUlCtrlCh->blockCodeConcatenation);
            RLOG1(L_INFO,"    pUlCtrlCh->modulationType=%i", pUlCtrlCh->modulationType);
            RLOG1(L_INFO,"    pUlCtrlCh->mcsType=%i", pUlCtrlCh->mcsType);

            RLOG1(L_INFO,"    pUlCtrlCh->pucchDedCtl.formatType=%i", pUlCtrlCh->pucchDedCtl.formatType);
            RLOG1(L_INFO,"    pUlCtrlCh->pucchDedCtl.ackNackRepetition=%i", pUlCtrlCh->pucchDedCtl.ackNackRepetition);
            RLOG1(L_INFO,"    pUlCtrlCh->pucchDedCtl.repetitionFactor=%i", pUlCtrlCh->pucchDedCtl.repetitionFactor);
            RLOG1(L_INFO,"    pUlCtrlCh->pucchDedCtl.n1PucchANRep=%i", pUlCtrlCh->pucchDedCtl.n1PucchANRep);
            RLOG1(L_INFO,"    pUlCtrlCh->pucchDedCtl.cqiPUCCHResourceIndex=%i", pUlCtrlCh->pucchDedCtl.cqiPUCCHResourceIndex);
            RLOG1(L_INFO,"    pUlCtrlCh->pucchDedCtl.srPUCCHResourceIndex=%i", pUlCtrlCh->pucchDedCtl.srPUCCHResourceIndex);

            RLOG1(L_INFO,"    pUlCtrlCh->cqiPmiRiRpt.cqiReportModeAperiodic=%i", pUlCtrlCh->cqiPmiRiRpt.cqiReportModeAperiodic);
            RLOG1(L_INFO,"    pUlCtrlCh->cqiPmiRiRpt.nomPDSCHRSEPREOffset=%i", pUlCtrlCh->cqiPmiRiRpt.nomPDSCHRSEPREOffset);
            RLOG1(L_INFO,"    pUlCtrlCh->cqiPmiRiRpt.cqiReportPeriodicEnable=%i", pUlCtrlCh->cqiPmiRiRpt.cqiReportPeriodicEnable);
            RLOG1(L_INFO,"    pUlCtrlCh->cqiPmiRiRpt.cqiPUCCHResourceIndex=%i", pUlCtrlCh->cqiPmiRiRpt.cqiPUCCHResourceIndex);
            RLOG1(L_INFO,"    pUlCtrlCh->cqiPmiRiRpt.cqipmiConfigIndex=%i", pUlCtrlCh->cqiPmiRiRpt.cqipmiConfigIndex);
            RLOG1(L_INFO,"    pUlCtrlCh->cqiPmiRiRpt.cqiFormatIndicatorPeriodic=%i", pUlCtrlCh->cqiPmiRiRpt.cqiFormatIndicatorPeriodic);
            RLOG1(L_INFO,"    pUlCtrlCh->cqiPmiRiRpt.K=%i", pUlCtrlCh->cqiPmiRiRpt.K);
            RLOG1(L_INFO,"    pUlCtrlCh->cqiPmiRiRpt.riConfigIndex=%i", pUlCtrlCh->cqiPmiRiRpt.riConfigIndex);
            RLOG1(L_INFO,"    pUlCtrlCh->cqiPmiRiRpt.simultaneousAckNackAndCQI=%i", pUlCtrlCh->cqiPmiRiRpt.simultaneousAckNackAndCQI);

            RLOG1(L_INFO,"    pUlCtrlCh->numberofEntries=%i", pUlCtrlCh->numberofEntries);
            RLOG1(L_INFO,"    pUlCtrlCh->startRes=%i", pUlCtrlCh->startRes);
            RLOG1(L_INFO,"    pUlCtrlCh->numRes=%i", pUlCtrlCh->numRes);

            pUlCtrlCh++;
        }

        pSrs = (SRSDED *)(((unsigned long)pUlSf) + pUlSf->offsetsrsInfo);
        for (i = 0; i < pUlSf->numberSrsinSf; i++)
        {
            RLOG1(L_INFO,"SRS %i:----------", i);
            RLOG1(L_INFO,"      pSrs->enableDisable=%i", pSrs->enableDisable);
            RLOG1(L_INFO,"      pSrs->srsBandwidth=%i", pSrs->srsBandwidth);
            RLOG1(L_INFO,"      pSrs->srsHoppingBandwidth=%i", pSrs->srsHoppingBandwidth);
            RLOG1(L_INFO,"      pSrs->transmissionComb=%i", pSrs->transmissionComb);
            RLOG1(L_INFO,"      pSrs->cyclicShift=%i", pSrs->cyclicShift);
            RLOG1(L_INFO,"      pSrs->freqDomainPosition=%i", pSrs->freqDomainPosition);
            RLOG1(L_INFO,"      pSrs->duration=%i", pSrs->duration);
            RLOG1(L_INFO,"      pSrs->srsConfigIndex=%i", pSrs->srsConfigIndex);

            pSrs++;
        }

#ifdef DEBUGP
        pRachCtrl = (RACHCTRL *)(((unsigned long)pUlSf) + pUlSf->offsetRachCtrlStruct);
        RLOG1(L_INFO,"    pRachCtrl->prachEnable=%i", pRachCtrl->prachEnable);
        RLOG1(L_INFO,"    pRachCtrl->rootSequenceIndex=%i", pRachCtrl->rootSequenceIndex);
        RLOG1(L_INFO,"    pRachCtrl->prachConfigIndex=%i", pRachCtrl->prachConfigIndex);
        RLOG1(L_INFO,"    pRachCtrl->highSpeedFlag=%i", pRachCtrl->highSpeedFlag);
        RLOG1(L_INFO,"    pRachCtrl->zeroCorrelationZoneConfig=%i", pRachCtrl->zeroCorrelationZoneConfig);
        RLOG1(L_INFO,"    pRachCtrl->prachFreqOffset=%i", pRachCtrl->prachFreqOffset);
#endif
        break;

    case PHY_RXSTART_IND:
#ifdef DEBUGP
        pMsgInd = (PMSGIND) pGen;
        RLOG1(L_INFO,"  pRxStartInd->subFrameNum=%i", pMsgInd->subFrameNum);
#endif
        break;

    case PHY_RXSDU_IND:
        pRxSduInd = (PRXSDUIND) pGen;
        RLOG1(L_INFO,"  pRxSdu->channelId=%i", pRxSduInd->channelId);
        RLOG1(L_INFO,"  pRxSdu->msgType=%i", pRxSduInd->msgType);
        RLOG1(L_INFO,"  pRxSdu->phyEntityId=%i", pRxSduInd->phyEntityId);
        RLOG1(L_INFO,"  pRxSdu->numBitsRx=%i", pRxSduInd->numBitsRx);
        RLOG1(L_INFO,"  pRxSdu->status=%i", pRxSduInd->status);
        RLOG1(L_INFO,"  pRxSdu->frameNum=%i", pRxSduInd->frameNum);
        RLOG1(L_INFO,"  pRxSdu->subFrameNum=%i", pRxSduInd->subFrameNum);
        RLOG1(L_INFO,"  pRxSdu->chanType=%i", pRxSduInd->chanType);
        RLOG1(L_INFO,"  pRxSdu->pRxSdu=%p", (void*)pRxSduInd->pRxSdu);

        // Currently payload starts at this field
        pDat = (unsigned char *) (&pRxSduInd->pRxSdu);
        for (i = 0; i < pRxSduInd->numBitsRx >> 3;)
        {
            for (j = 0; j < 16; j++)
            {
                RLOG1(L_INFO,"%02X ", pDat[j]);
                if (i + j + 1 >= (pRxSduInd->numBitsRx >> 3))
                    break;
            }
            for (j = 0; j < 16; j++)
            {
                //if (isprint(pDat[j]))
                if (TRUE)
                {
                    RLOG1(L_INFO,"%c", pDat[j]);
                }
                else
                {
                    RLOG0(L_INFO,".");
                }
                if (i + j + 1 >= (pRxSduInd->numBitsRx >> 3))
                    break;
            }
            RLOG0(L_INFO,"");
            i += 16;
            pDat += 16;

            // FIXME: This is debug check and to be removed
            if (i > 64)
                break;
        }
        break;

    case PHY_RXEND_IND:
#ifdef DEBUGP
        pMsgInd = (PMSGIND) pGen;
        RLOG1(L_INFO,"  pRxEndInd->subFrameNum=%i", pMsgInd->subFrameNum);
        RLOG1(L_INFO,"  pRxEndInd->frameNumber=%i", pMsgInd->frameNumber);
#endif
        break;

    case PHY_INIT_REQ:
#ifdef DEBUGP
        pInit = (PINITPARM) (pGen + 1);

        RLOG1(L_INFO,"  pInit->channelBandwidth=%i", pInit->channelBandwidth);
        RLOG1(L_INFO,"  pInit->frtypeDuplexmode=%i", pInit->frtypeDuplexmode);
        RLOG1(L_INFO,"  pInit->radioAccessMode=%i", pInit->radioAccessMode);
        RLOG1(L_INFO,"  pInit->physicalResourceBandwidth=%i", pInit->physicalResourceBandwidth);
        RLOG1(L_INFO,"  pInit->numberResourceBlocksperSlot=%i", pInit->numberResourceBlocksperSlot);
        RLOG1(L_INFO,"  pInit->phyLayerCellIdGroup=%i", pInit->phyLayerCellIdGroup);
        RLOG1(L_INFO,"  pInit->phyLayerId=%i", pInit->phyLayerId);
        RLOG1(L_INFO,"  pInit->txAntennaPortCount=%i", pInit->txAntennaPortCount);
        RLOG1(L_INFO,"  pInit->fastfwdorPreclockingNumber=%i", pInit->fastfwdorPreclockingNumber);
        RLOG1(L_INFO,"  pInit->fftSize=%i", pInit->fftSize);
        RLOG1(L_INFO,"  pInit->numberUsedSubcarriers=%i", pInit->numberUsedSubcarriers);
        RLOG1(L_INFO,"  pInit->nMaxDlRb=%i", pInit->nMaxDlRb);
        RLOG1(L_INFO,"  pInit->nMaxUlRb=%i", pInit->nMaxUlRb);
        RLOG1(L_INFO,"  pInit->referenceSignalPower=%i", pInit->referenceSignalPower);
        RLOG1(L_INFO,"  pInit->primarySyncSignalPower=%i", pInit->primarySyncSignalPower);
        RLOG1(L_INFO,"  pInit->secondarySyncSignalPower=%i", pInit->secondarySyncSignalPower);
        RLOG1(L_INFO,"  pInit->numDataRePerPRB=%i", pInit->numDataRePerPRB);
        RLOG1(L_INFO,"  pInit->cyclicPrefixType=%i", pInit->cyclicPrefixType);
        RLOG1(L_INFO,"  pInit->rxAntennaPortCount=%i", pInit->rxAntennaPortCount);
        RLOG1(L_INFO,"  pInit->pb=%i", pInit->pb);
        RLOG1(L_INFO,"  pInit->customExtensionReportEn=%i", pInit->customExtensionReportEn);
        RLOG1(L_INFO,"  pInit->rachReportMode=%i", pInit->rachReportMode);
        RLOG1(L_INFO,"  pInit->txSduConfEnable=%i", pInit->txSduConfEnable);
        RLOG1(L_INFO,"  pInit->txStartConfDisable =%i", pInit->txStartConfDisable);
        RLOG1(L_INFO,"  pInit->rxStartConfDisable =%i", pInit->rxStartConfDisable);
        RLOG1(L_INFO,"  pInit->sduConfig=%i", pInit->sduConfig);
        RLOG1(L_INFO,"  pInit->radioFrameNumber=%i", pInit->radioFrameNumber);
        RLOG1(L_INFO,"  pInit->subframeNumber=%i", pInit->subframeNumber);
        RLOG1(L_INFO,"  pInit->slotNumber=%i", pInit->slotNumber);
        RLOG1(L_INFO,"  pInit->srsBandwidthConfig=%i", pInit->srsBandwidthConfig);
        RLOG1(L_INFO,"  pInit->srsSubframeConfig=%i", pInit->srsSubframeConfig);
        RLOG1(L_INFO,"  pInit->srsSimultaneousANandSRS=%i", pInit->srsSimultaneousANandSRS);
        RLOG1(L_INFO,"  pInit->prachConfigurationIndex=%i", pInit->prachConfigurationIndex);
        RLOG1(L_INFO,"  pInit->prachFrequencyOffset=%i", pInit->prachFrequencyOffset);
        RLOG1(L_INFO,"  pInit->prachHighSpeedFlag=%i", pInit->prachHighSpeedFlag);
        RLOG1(L_INFO,"  pInit->prachCyclicShiftConfig=%i", pInit->prachCyclicShiftConfig);
        RLOG1(L_INFO,"  pInit->prachRootSequenceIndex=%i", pInit->prachRootSequenceIndex);
#ifdef TFU_TDD
        RLOG1(L_INFO,"  pInit->ulDlConfig=%i", pInit->ulDlConfig);
        RLOG1(L_INFO,"  pInit->specialSubframeConfig=%i", pInit->specialSubframeConfig);
#endif
#endif
        break;
/* LTE_UNLICENSED */
    case PHY_ERROR_IND:
        break;

    default:
        //RLOG0(L_WARNING,"Unknown command:----------------");
        // Dump 64 bytes of unknown command
        pDat = (unsigned char *) vector;
        for (i = 0; i < 64; i += 16)
        {
            for (j = 0; j < 16; j++)
            {
                RLOG1(L_INFO,"%02X ", pDat[j]);
            }
            for (j = 0; j < 16; j++)
            {
                //if (isprint(pDat[j]))
                if (TRUE)
                {
                    RLOG1(L_INFO,"%c", pDat[j]);
                }
                else
                {
                    RLOG0(L_INFO,".");
                }
            }
            RLOG0(L_INFO,"");
            pDat += 16;
        }
        break;
    }
    return SUCCESS;
}
#endif /*TENB_RTLIN_CHANGES */

#ifdef CCPU_MLOG
PUBLIC Void L2PrintFunc (U8      *str)
{
    RLOG1(L_INFO," External Print=%s", str);
    RETVOID;
}


#endif
PUBLIC Void ysMsCleanupTxRxVectors
(
YsCellCb        *cellCb,
U8               sfNum
)
{
   U8           lclSf;

   lclSf = (sfNum + TFU_DELTA) % YS_NUM_SUB_FRAMES;
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
   ysMsUtlFreePhyList(&cellCb->dlEncL1Msgs[lclSf].ulDlLst);
   //ysMsUtlFreePhyList(&ysCb.combUlDlLst[lclSf]);
   ysMsUtlFreePhyList(&cellCb->dlEncL1Msgs[lclSf].dlData);
   ysMsUtlFreePhyList(&cellCb->dlEncL1Msgs[lclSf].dlCntrl);
#endif
   ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[lclSf].ulDlLst);
   //ysMsUtlInitPhyList(&ysCb.combUlDlLst[lclSf]);
   ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[lclSf].dlData);
   ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[lclSf].dlCntrl);
   cellCb->dlEncL1Msgs[lclSf].isdatReqPres = FALSE;
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
   cellCb->dlEncL1Msgs[lclSf].txVector  = NULLP;
#else
   cellCb->dlEncL1Msgs[lclSf].addTxVecToLst = FALSE;
#endif
#ifndef TENB_RTLIN_CHANGES
   cellCb->isAdvTtiSent[sfNum] = FALSE;
#endif
   cellCb->dlEncL1Msgs[lclSf].numChannels = 0;
   
   lclSf = (sfNum + TFU_ULCNTRL_DELTA) % YS_NUM_SUB_FRAMES;
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
   ysMsUtlFreePhyList(&cellCb->dlEncL1Msgs[lclSf].ulCntrl);
#endif
   ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[lclSf].ulCntrl);
   
   /* Add PHY_RECPREQ_DLDELTA to get RxVector subframe */
   lclSf = (sfNum + PHY_RECPREQ_DLDELTA) % YS_NUM_SUB_FRAMES;
#if !defined (INTEL_ALLOC_WLS_MEM) && !defined (TL_ALLOC_ICC_MEM)
   if (cellCb->ulEncL1Msgs[lclSf].rxVector != NULLP)
   {
#ifndef TENB_RTLIN_CHANGES
      SvsrFreeMsg(cellCb->ulEncL1Msgs[lclSf].rxVector);
#else
      ysFreePhyMsg(cellCb->ulEncL1Msgs[lclSf].rxVector);
#endif
      cellCb->ulEncL1Msgs[lclSf].rxVector = NULLP;
   }
#else
   cellCb->ulEncL1Msgs[lclSf].addRxVecToLst = FALSE;
#endif

   /* Add PHY_RECPREQ_DLDELTA + TFU_CRCIND_ULDELTA to get CRC subframe */
   lclSf = (sfNum + PHY_RECPREQ_DLDELTA + TFU_CRCIND_ULDELTA) % YS_NUM_SUB_FRAMES; 
   cellCb->isCrcExptd[lclSf] = FALSE;
   
   //checkIcorePartitions();
//   RLOG0(L_DEBUG,"Cleaning Up ysMsCleanupTxRxVectors End");

   RETVOID;
}

PUBLIC Void ysMsPrcMissedVectors
(
YsCellCb       *cellCb,
U8              missedSf
)
{
   ysMsCleanupTxRxVectors(cellCb, missedSf);
}

#ifndef TENB_RTLIN_CHANGES
PUBLIC S16 ysMsDlmPrcTtiIndOnHqReceipt
(
YsCellCb        *cellCb,
Bool            isDummyTti
)
{
   S16             ret = ROK;
   CmLteTimingInfo timingInfo;
   /* HARQ */
   CmLteTimingInfo rxSduSf;
   volatile int              t;
   YsUlL1Msg *ulRxSduInds = NULLP;
   U8 loopCnt = 0;
   Status status = 0;


   TRC2(ysMsDlmPrcTtiIndOnHqReceipt)
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   
   /* Set the current time information */
   timingInfo = cellCb->timingInfo;
   YS_INCR_TIMING_INFO(timingInfo, 1);
  

   macTtiInd.cellId              = cellCb->cellId;
   macTtiInd.timingInfo.subframe = timingInfo.subframe;
   macTtiInd.timingInfo.sfn      = timingInfo.sfn;
   macTtiInd.isDummyTti          = isDummyTti;      

   schTtiInd = macTtiInd;

   /* changing the order of TTI invocation
    * Old order - MAC then SCH
    * New order - SCH then MAC
    * This is a crude work around to get the TX vector in order
    * i.e. Data followed by PDCCH information.
    */
      /* send TTI indication to MAC */
   /* RLOG2(L_DEBUG,"Send MAC TTI Ind (%d %d)", macTtiInd.timingInfo.sfn, 
                                          macTtiInd.timingInfo.subframe); */
   YsUiTfuTtiInd(&cellCb->macTfuSap->sapPst, 
                          cellCb->macTfuSap->suId, &macTtiInd);

   /* RLOG2(L_DEBUG,"Send MAC Sch Ind (%d %d)", schTtiInd.timingInfo.sfn, 
                                          schTtiInd.timingInfo.subframe); */
   /* send TTI indication to scheduler */
   YsUiTfuSchTtiInd(&cellCb->schTfuSap->sapPst,
                    cellCb->schTfuSap->suId,
                    &schTtiInd);
   
   cellCb->isAdvTtiSent[timingInfo.subframe]  = TRUE;
#ifdef SS_DIAG 
   if((ssDiagSndToPack( &ysCb.ysInit[indx].lmPst)) != ROK)
   {
      RLOG0(L_ERROR, "ssPackLogs(): Packing of log failed");
   }
#endif

   RETVALUE(ROK);

}
#endif

#ifdef TFU_TDD
PUBLIC S16 ysMsTrigDummyRecpReq
(
YsCellCb        *cellCb
)
{
   TfuRecpReqInfo  dummyRecpReqInfo;

   dummyRecpReqInfo.cellId = cellCb->cellId;
   cmLListInit(&dummyRecpReqInfo.ueRecpReqLst);
   YS_MS_ADD_TO_CRNT_TIME(cellCb->timingInfo, dummyRecpReqInfo.timingInfo,
                      PHY_RECPREQ_DLDELTA);

   if(ROK != ysMsUlmPrcRecpReq(cellCb, &dummyRecpReqInfo))
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"\n Dummy RxVector proc failed\n");
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "Failed to process dummyRecpReqInfo");
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
}
#endif

//#ifdef RG_SCH_DYNDLDELTA
/**
 * @brief Function checks if all messages have been received from MAC for
 * a subframe
 *
 * @details
 *
 *     Function: ysChkSfInfoStatus
 *
 *     This API is invoked to check if all the messages for a subframe have
 *     been received from MAC and if processing towards PHY can be started.
 *     MAC will always send cntrlReq and recpReq even if there is no tx in
 *     this subframe. Only datReq is an optional message from MAC.
 *
 *  @param[in] cellCb
 *  @return BOOL
 *      -# TRUE
 *      -# FALSE
 **/
PUBLIC Bool ysChkSfInfoStatus
(
YsCellCb        *cellCb
)
{
   TfuCntrlReqInfo *ctrlReq = NULL;
   TfuDatReqInfo   *datReq = NULL;
#if 0
   TfuRecpReqInfo  *recpReq = NULL;
#endif
   U8 cntrlReqSf = 0;
   U8 datReqSf = 0;
   //U8 recpReqSf = 0;
   CmLList           *cmLstEnt = NULL;
   TfuPdcchInfo      *pdcchInfo= NULL;
   U8 dci3_count,sps_release = 0;
   U8 pdcchOrderDciCount = 0;
        Bool allRcvd = TRUE;
   cntrlReqSf = ((cellCb->timingInfo.subframe + TFU_DLCNTRL_DLDELTA) % YS_NUM_SUB_FRAMES) ;
   datReqSf   = ((cellCb->timingInfo.subframe + TFU_DLDATA_DLDELTA ) % YS_NUM_SUB_FRAMES) ;
   //recpReqSf  = ((cellCb->timingInfo.subframe + TFU_RECPREQ_DLDELTA ) % YS_NUM_SUB_FRAMES) ;
   datReq = cellCb->dlEncL1Msgs[datReqSf].datReq;
   ctrlReq = cellCb->dlEncL1Msgs[cntrlReqSf].cntrlReq;
   dci3_count = 0;
  /*
   1. CntrlReq and RecpReq are mandatory to be received. DatReq is optional.
   2. If dlPdcchLst.count = 0 and it is MIB occassion, datReq is must
   3. If dlPdcchLst.count > 0 and one of the Pdcch is DCI format 3, # of datReq = dlPdcchLst.count - # of dci3/3a. Special handling in case of MIB occassion.
   */
   allRcvd = TRUE;
  
   if(!acceptPrimsFrmMac)
   {
      return allRcvd;
   }

   if (NULL == ctrlReq) 
   {
      allRcvd = FALSE;
      return allRcvd;
   }
   // If Pdcch = 0, we need to wait for datReq in case of MIB occassion or SPS indication
   if (0 == ctrlReq->dlPdcchLst.count)
   {
      if ((0 == ctrlReq->dlTiming.sfn%4) && (0 ==ctrlReq->dlTiming.subframe))
      {
         /*if (ctrlReq->isSPSOcc)
         {
            printf ("BCM CL PDSCH for SPS OCC sfn %d subf %d \n",
            ctrlReq->dlTiming.sfn,
            ctrlReq->dlTiming.subframe);
         }*/
         {
            if(datReq)
               allRcvd = TRUE;
            else
               allRcvd = FALSE;
          }
      }
      return allRcvd;
   }
   if (ctrlReq->dlPdcchLst.count > 0)
   {
      cmLstEnt = ctrlReq->dlPdcchLst.first;
      while(cmLstEnt)
      {
         pdcchInfo = (TfuPdcchInfo *)cmLstEnt->node;
       if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3)||(pdcchInfo->dci.dciFormat ==TFU_DCI_FORMAT_3A))
        {
            dci3_count++;
        }
#ifdef LTEMAC_SPS
        else if( (pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A ) &&
                 (pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.alloc.type == TFU_ALLOC_TYPE_RIV ) &&
                 (pdcchInfo->dci.u.format1aInfo.t.pdschInfo.allocInfo.alloc.u.riv == 0xFFFFFFFF))
        {
           sps_release++;
#ifdef RGSCH_SPS_STATS
           numdlSpsRelRcvdAtCl++;
#endif

        }
#endif
         else if(pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_1A)
         {
            if(pdcchInfo->dci.u.format1aInfo.isPdcchOrder)
            {
               pdcchOrderDciCount++;
            }
         }

         cmLstEnt = cmLstEnt->next;
      }
      if (ctrlReq->dlPdcchLst.count - (dci3_count + sps_release + pdcchOrderDciCount) > 0)
      {
         if ((datReq) && (TRUE == cellCb->dlEncL1Msgs[cntrlReqSf].isCrcToMacSnd)) 
            allRcvd = TRUE;
         else
         {
            allRcvd = FALSE;
         }
         return allRcvd;
      }
      else
      {
         if ( ((0 == ctrlReq->dlTiming.sfn%4) && (0 == ctrlReq->dlTiming.subframe))
#ifdef LTEMAC_SPS
                         || (ctrlReq->isSPSOcc)
#endif
            )
         {
            if ((datReq) && (TRUE == cellCb->dlEncL1Msgs[cntrlReqSf].isCrcToMacSnd))
               allRcvd = TRUE;
            else
            {
               allRcvd = FALSE;
            }
            return allRcvd;
         } // MIB occassion or SPS indication is TRUE
      } // dlPdcchLst.count - dci3_count == 0
   } // dlPdcchLst.count > 0
   return TRUE;
}
//#endif

#ifdef RSYS_WIRESHARK
#ifdef  L2_OPTMZ
   /**
    * 	@brief	This function is used for capturing logs into wireshark
    by traversing MAC PDU header information.
    * 	@param[in]	tbInfo    MAC TB Information
    * 	@param[in]	direction  UL/DL information.
    * 	@param[in]	subframe   subframe information.
    */
PRIVATE Void ysDlSendPdusForWiresharkLogging(TfuDatReqTbInfo *tbInfo, U8 direction, U8 subframe, U16 rnti)
{
   int lchIdx = 0, pIdx = 0;
   if(ysCb.genCfg.enblSIAndPagngLog == 1)
  // printf("\n in CL : ysDlSendPdusForWiresharkLogging enblSIAndPagngLog=%d \n",ysCb.genCfg.enblSIAndPagngLog);
   if(ysCb.genCfg.enblSIAndPagngLog && (rnti == YS_SI_RNTI || rnti == YS_P_RNTI))
   {
      for(lchIdx = 0; lchIdx < tbInfo->numLch; lchIdx++)
      {
         for(pIdx = 0; pIdx < tbInfo->lchInfo[lchIdx].numPdu; pIdx++)
         {
            if (tbInfo->lchInfo[lchIdx].mBuf[pIdx] != NULLP)
            {
               /* check whether the ccch/srb1/srb2 data present */
               /* If present then send to wireshark application */
               ysMsUtlSendMsgToWireShark(tbInfo->lchInfo[lchIdx].mBuf[pIdx],
                     rnti,subframe,direction);
            }

         }
      }
   }
   RETVOID;
}

#else
   
/**
    * 	@brief	This function is used for capturing logs into wireshark
    by traversing MAC PDU header information.
    * 	@param[in]	pduInfo    MAC PDU information.
    * 	@param[in]	direction  UL/DL information.
    * 	@param[in]	subframe   subframe information.
*/
PRIVATE Void ysDlSendPdusForWiresharkLogging(TfuDatReqPduInfo* pduInfo, U8 direction, U8 subframe,U8 cellIdx)
{
   //  printf("\n in CL : ysDlSendPdusForWiresharkLogging enblSIAndPagngLog=%d \n",ysCb.genCfg.enblSIAndPagngLog);
   if(ysCb.genCfg.enblSIAndPagngLog)
   {
      if ((pduInfo->rnti == YS_SI_RNTI) || (pduInfo->rnti == YS_P_RNTI))
      {
         if (pduInfo->mBuf[0] != NULLP)
         {
            /* check whether the ccch/srb1/srb2 data present */
            /* If present then send to wireshark application */
            ysMsUtlSendMsgToWireShark(pduInfo->mBuf[0],
                  pduInfo->rnti,
                  subframe,
                  direction,
                  cellIdx);
         }

         if (pduInfo->mBuf[1] != NULLP)
         {
            /* check whether the ccch/srb1/srb2 data present */
            /* If present then send to wireshark application */
            ysMsUtlSendMsgToWireShark(pduInfo->mBuf[1],
                  pduInfo->rnti,
                  subframe,
                  direction,
                  cellIdx);
         }
      }
   }
   RETVOID;
}
#endif/*L2_OPMTZ*/
#endif


#ifdef LTE_ADV
/* LTE_UNLICENSED ERR IND SIMULATOR */
void lbtSimulatorInit()
{
   if (!enableLaaLBTSim)
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"LBT SIM is DISABLED !!!!!!!!!!!!!\n");
      RETVOID;
   }

   totalChanAvailTime = (LBT_SIM_WIN_SZ * chanAvailPercentage)/100;

   STKLOG(STK_MD_YS,STK_LOG_INFO,"\n\n*********************LBT SIM ENABLED********************\n");
   STKLOG(STK_MD_YS,STK_LOG_INFO,"LBT_SIM_WIN_SZ %d chanAvailPercentage %lu totalChanAvailTime %lu\n",
         LBT_SIM_WIN_SZ,
         chanAvailPercentage,
         totalChanAvailTime);

}

void reinitLbtSim()
{
   U32 rfToDistribute = totalChanAvailTime/LAA_MCOT;
#if 0
   U32 randIdx;
   U32 timeSeed = time(NULL);
   U32 try =0;
#endif


   while(rfToDistribute)
   {
     lbtAvailRF[rfToDistribute-1] = 1;    
#if 0
      randIdx = (rand_r((unsigned int *)&timeSeed))% LBT_AVAIL_RF_SZ;

      if (!lbtAvailRF[randIdx])
      {
         lbtAvailRF[randIdx] = 1;
      }
      else
      {
         while(try < LBT_AVAIL_RF_SZ)
         {
            if (!lbtAvailRF[try])
            {
               lbtAvailRF[try] = 1;
               break;
            }
            try++;
         }
      }
#endif
      rfToDistribute--;
   }
/*
   printf (" RANDOM RF AVAIL DIST : ");
   for (i = 0; i < LBT_AVAIL_RF_SZ; i++)
   {
      printf ("%d ", lbtAvailRF[i]);
   }
   printf ("\n");
   */
}

void processLbtSim(U32 sfn, U32 sf)
{
   if (!enableLaaLBTSim)
   {
      RETVOID;
   }

   if (prevChanAvailPercentage != chanAvailPercentage)
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,">>>>>>>>>>>>> Change in CHANNEL AVAILABILITY old %ld new %ld\n",
      prevChanAvailPercentage,
      chanAvailPercentage);

      prevChanAvailPercentage = chanAvailPercentage;
      /* LBT SIM INIT */
      lbtSimulatorInit();
   }
   if (!(sfn % LBT_AVAIL_RF_SZ) && !(sf % LBT_AVAIL_RF_SZ))
   {
    //  printf (" RE INIT RF AVAIL DIST \n");
      reinitLbtSim();
   }
 
   /* Chan availability state changes only at RF boundary */ 
   if (sf)
   {
      RETVOID;
   }
   if (lbtAvailRF[sfn%LBT_AVAIL_RF_SZ])
   {
     // printf ("CHAN AVAILABLE sfn %d \n",sfn);
      isLAAChanActive = TRUE;
      lbtAvailRF[sfn%LBT_AVAIL_RF_SZ] = 0;
   }
   else
   {
      isLAAChanActive = FALSE;
   }
}



void sendErrInd()
{
   YsCellCb  *cellCb = ysCb.tfuSapLst[1]->cellCb;
   TfuErrIndInfo errInd;

   if (!enableLaaLBTSim)
   {
      RETVOID;
   }

   if (!isLAAChanActive)
   {
      /* send the ERR Ind for LAA CELL */
      errInd.cellId = cellCb->cellId;
      errInd.timingInfo = cellCb->timingInfo; 
      YsUiTfuErrInd(&cellCb->schTfuSap->sapPst,
            cellCb->schTfuSap->suId,
            &errInd);
   }
} 
#endif
/********************************************************************30**

         End of file:     yw_ms_dl.c@@/main/TeNB_Main_BR/9 - Mon Aug 11 16:42:37 2014

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      pk   1. initial release.
/main/1    ys004.102  vr   1. Merged MSPD code with phy 1.7
*********************************************************************91*/

/*******************************************************************************
 *                       ArrayComm Confidential
 *                  Copyright (c) ArrayComm, LLC. 1995-2014
 *
 *      This software is furnished under license and may be used or
 *      copied only in accordance with the terms of such license.
 *******************************************************************************
 * @file   ac_ltePhyIpc.h
 * @brief  IPC driver header for B486x platform
 *
 * Change Log:
 *      Date              Who               What
 *      2014/03/19        Xin Chen          Create
 *******************************************************************************
 */
#ifndef AC_LTEPHYIPC_H_
#define AC_LTEPHYIPC_H_

typedef enum
{
    RESERVED0= 0,

	PA_TO_SC_CONFIG_REQUEST_CH = 1,
	PA_TO_SC_START_REQUEST_CH,
	PA_TO_SC_STOP_REQUEST_CH,
	PA_TO_SC_PARAM_REQUEST_CH,
	PA_TO_SC_DLCONF_REQUEST_CH,
	PA_TO_SC_ULCONF_REQUEST_CH,
	PA_TO_SC_HIDCI0_REQUEST_CH,
	PA_TO_SC_TX_REQUEST_CH,
	SC_TO_PA_PARAM_RESPONSE_CH ,
	SC_TO_PA_CONFIG_RESPONSE_CH,
	SC_TO_PA_STOP_INDICATION_CH,
	SC_TO_PA_ERROR_INDICATION_CH,
	SC_TO_PA_SUBFRAME_INDICATION_CH,
	SC_TO_PA_HARQ_INDICATION_CH,
	SC_TO_PA_CRC_INDICATION_CH,
	SC_TO_PA_ULSCH_INDICATION_CH,
	SC_TO_PA_RACH_INDICATION_CH,
	SC_TO_PA_SRS_INDICATION_CH,
	SC_TO_PA_SR_INDICATION_CH,
	SC_TO_PA_CQI_INDICATION_CH,

	PA_TO_SC_OAM_REQ_CH = 41,
	SC_TO_PA_OAM_RSP_CH,
	SC_TO_PA_OAM_RPT_CH,
	PA_TO_SC_CPRI_CM_REQ_CH,
	SC_TO_PA_CPRI_CM_RSP_CH,

	MAX_IPC_SC_PA_CH_NUM

}ipcChannelNum;

#endif /* AC_LTEPHYIPC_H_ */
/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************
 
     Name:     LTE MAC Convergence Layer
  
     Type:     C source file
  
     Desc:     C source code for Entry point fucntions
  
     File:     ys_init.c
  
     Sid:      yw_ms_init.c@@/main/TeNB_Main_BR/5 - Mon Aug 11 16:42:38 2014
  
     Prg:      pk
  
**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_FILE_ID=251;
static int RLOG_MODULE_ID=1;

/** @file ys_init.c
@brief This module acts as an interface handler for upper interface and 
manages Pst and Sap related information for upper interface APIs.
*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_lte.h"
#include "ctf.h"           /* CTF defines */
#include "lys.h"           /* layer management defines for LTE-CL */
#include "tfu.h"
#ifndef NOFILESYS
#include "cm_os.h"         /* file operations */
#endif

#if !(defined SS_CAVIUM || defined SS_4GMX_LCORE)
#include "cm_inet.h"       /* common tokens */
#endif /* SS_CAVIUM */


#ifdef YS_MSPD
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "resultcodes.h"
#endif
#ifndef TENB_RTLIN_CHANGES
#include "mlog.h"
#include "apidefs.h"
#include "tcb.h"
#include "lte_entry.h"
#endif /*TENB_RTLIN_CHANGES*/

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "spaccdrv.h" /*sumanth*/
#endif
#endif


#include "ys_ms.h"         /* defines and macros for CL */

#ifndef TENB_RTLIN_CHANGES
#include "lte_entry.h"
#include "appids.h"
#endif
#else
#include "ys_ms.h"            /* defines and macros for CL */
#include <sys/time.h>
#endif
#include <stdlib.h>        /*  ys004.102 :186 : exit warning */
#include "ys_ms_err.h"        /* YS error defines */
#include <stdlib.h>        /* ys004.102 : CR 7528 exit warning */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"
#include "ctf.x"           /* CTF types */
#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#ifndef NOFILESYS
#include "cm_os.x"         /* file operations */
#endif
#if (defined(TENB_STATS) && (defined(L2_L3_SPLIT)))
#include "l2_tenb_stats.x"   
#endif

#if !(defined SS_CAVIUM || defined SS_4GMX_LCORE)
#include "cm_inet.x"       /* common tokens */
#endif /* SS_CAVIUM */


#ifdef YS_MSPD
#include "ys_ms.x"            /* typedefs for CL */
#else
#include "ys_ms.x"            /* typedefs for CL */
#endif

#ifdef YS_MSPD
#ifndef RGL_SPECIFIC_CHANGES
PUBLIC RESULTCODE MacDispatch ARGS((U32 isList, PTR l1Msg));
#endif

#ifdef YS_PHY_3_8_2
unsigned int Icpu1Init(void)
{

    return 0;
}

unsigned int Icpu2Init(void)
{

    return 0;
}
#endif

#endif /*YS_MSPD*/

extern U8 cellPhyInstId;

#ifndef TENB_RTLIN_CHANGES
#ifndef NOFILESYS
U32  YS_TTI_TMR_VAL_CFG;/* ys004.102 : CR 7531 TTI configured*/
U16 YS_PORT_ENB;
U16 YS_PORT_UE;
U8  YS_IP_ADDR_ENB[YS_IP_ADDR_STR_LEN];
U8  YS_IP_ADDR_UE[YS_IP_ADDR_STR_LEN];
U8 WIRESHARK_SRVR_IP_ADDR[YS_IP_ADDR_STR_LEN]; 

PRIVATE S8 ysCfgParams[][YS_MAX_CFG_PARAM_LEN] = 
{
   "YS_IP_ADDR_ENB",
   "YS_IP_ADDR_UE",
   "YS_PORT_ENB",
   "YS_PORT_UE",
   "YS_TTI_TMR_VAL_CFG", /* ys004.102 : CR 7531 TTI configured */
   "WIRESHARK_SRVR_IP_ADDR" 
};

/**
 * @Configuration file read function.
 *
 * @details
 *
 *     Function : ysInitCfg
 *
 *     This function is called suring the CL's initialization for 
 *     reading the CL configuration file
 *
 *  @param[in]  NONE
 *  @return  S16
 *     -# ROK 
 *     -# RFAILED
 **/
#ifdef ANSI
PUBLIC S16  ysInitCfg
(
Void
)
#else
PUBLIC S16  ysInitCfg (Void)
#endif
{
   S8               line[YS_MAX_CFG_FILE_LINE_LEN];
   OsFile           *fp = NULLP;
   S8               *ret1 = NULLP;
   U32              idx = 0;
   S32              lineNo = 0;
   U8               numParams;
   S8               *lPtr;
   S8               word[YS_MAX_CFG_PARAM_LEN];
   U8               lineLen;
   Bool             inToken = TRUE;

   TRC2(ysInitCfg);

   if((fp = (OsFile*)osFopen("ys_cfg.txt","r")) == (S32)NULLP)
   {
      /* ys004.102 : Defect 117186 */
      /* Configuration file check */
      RLOG0(L_ERROR, "FAILED to open the file ys_cfg.txt");
      exit(0);
   } /* if */
   /* ys004.102 Kworks warning fix*/
   numParams = (U8)(sizeof(ysCfgParams)/YS_MAX_CFG_PARAM_LEN);

   lineNo = 1;

   for (;;)
   {
      cmMemset((U8*)line, 0, YS_MAX_CFG_FILE_LINE_LEN);

      ret1 = osFgets(line, YS_MAX_CFG_FILE_LINE_LEN, fp);

      if (ret1 == (S8*)-1 || ret1 == NULLD) /* eof or NULL */
      {
         RLOG0(L_ERROR, "End of File reached ys_cfg.txt");
         break;
      }
      /* ys004.102 Kworks warnings fix*/
      if (!(lineLen = (U8)(osStripBlanks(line))))
      {
         lineNo++;
         continue;   /* blank line */
      }

      if (*line == '#')
      {
         lineNo++;
         continue;   /* blank line */
      }

      lPtr = line;

      /* Get each of the words from the line */
      while ((lPtr = osGetWord(lPtr, word)) != NULLP)
      {
         if (word[0] == '#')
         {
            break;
         }

         if (inToken)
         {
            /* Compare the word with the list of tokens */
            for (idx = 0; idx < numParams; idx++)
            {
               if(!osStrcmp(word, ysCfgParams[idx]))
               {
                  inToken = FALSE;
                  break;
               }
               if (idx == numParams)
               {
                  RLOG0(L_ERROR, " invalid configuration parameter ");
                  if(fp) osFclose(fp);
                  RETVALUE(RFAILED);
               }
            }/*ys004.102 Kworks warning fix*/
         }
         else
         {
            /* Now based on the index store the configuration values */
            switch(idx)
            {
               case 0: /* YS_IP_ADDR_ENB */
               {
                  osStrcpy((S8*)YS_IP_ADDR_ENB, word);
                  break;
               }
               case 1: /* YS_IP_ADDR_UE */
               {
                  osStrcpy((S8*)YS_IP_ADDR_UE, word);
                  break;
               }
               case 2: /* YS_PORT_ENB */
               {
                  YS_PORT_ENB = (U16)osStrtol(word, NULL, 10);
                  break;
               }
               case 3: /* YS_PORT_UE */
               {
                  YS_PORT_UE = (U16)osStrtol(word, NULL, 10);
                  break;
               }
               case 4:/* ys004.102 : CR 7531 TTI configured */ 
               {
                  YS_TTI_TMR_VAL_CFG = (U32)osStrtol(word, NULL, 10);
                  break;
               }
               case 5: /* added case 5 */ 
               {
                   osStrcpy((S8*)WIRESHARK_SRVR_IP_ADDR, word);
                   break;
               }


               default:
               {
                  break;
               }
            }
            inToken = TRUE;
         }

         cmMemset((U8*)word, 0, YS_MAX_CFG_PARAM_LEN);

      }
   } /* End of for loop */

   if(fp) osFclose(fp);

   RETVALUE(ROK);
}
#endif
#endif /* ifndef TENB_RTLIN_CHANGES */
#ifdef MSPD
#ifndef TENB_RTLIN_CHANGES
extern void SetMacInstanceId(UINT32 MacId);
static U32  ysMsgList = 0;
#endif /*TENB_RTLIN_CHANGES*/
/* extern U32 YsLiMsgHandler (Void * ysCtx, Void * msg);*/
#endif

/**
 * @brief Task Initiation callback function. 
 *
 * @details
 *
 *     Function : ysActvInit
 *     
 *     This function is supplied as one of parameters during CL's 
 *     task registration. SSI will invoke this function once, after
 *     it creates and attaches this Tapa Task to a system task.
 *     
 *  @param[in]  Ent entity, the entity Id of this task.     
 *  @param[in]  Inst inst, the instance Id of this task.
 *  @param[in]  Region region, the region Id registered for memory 
 *              usage of this task.
 *  @param[in]  Reason reason.
 *  @return  S16
 *      -# ROK
 **/
#ifdef SPLIT_RLC_DL_TASK
Pst phyRcvPst = {0};
Buffer *phyRcvThreadMBuf[YS_NUM_SUB_FRAMES] = {NULLP};
#endif
#ifdef ANSI
PUBLIC S16 ysActvInit
(
Ent entity,            /* entity */
Inst inst,             /* instance  0 - 1 */
Region region,         /* region */
Reason reason          /* reason */
)
#else
PUBLIC S16 ysActvInit(entity, inst, region, reason)
Ent entity;            /* entity */
Inst inst;             /* instance */
Region region;         /* region */
Reason reason;         /* reason */
#endif
{

   TRC2(ysActvInit);

   /* Initialize the CL TskInit structure to zero */
   if(inst == 0)
   {
      cmMemset ((U8 *)&ysCb, 0, sizeof(ysCb));
   }

   /* Initialize the CL TskInit with received values */
   ysCb.ysInit[inst].ent = entity;
   ysCb.ysInit[inst].inst = inst;
   ysCb.ysInit[inst].region = region;
#ifdef MSPD
   ysCb.ysInit[inst].pool = 0;
#else
   ysCb.ysInit[inst].pool = 3; /* Changing from 0 to 3 for performance */
#endif
   ysCb.ysInit[inst].reason = reason;
   ysCb.ysInit[inst].cfgDone = FALSE;
   ysCb.ysInit[inst].acnt = FALSE;
   ysCb.ysInit[inst].usta = FALSE;
   ysCb.ysInit[inst].trc = FALSE;
   ysCb.trcLen = 0; 
#ifdef DEBUGP
#ifdef MSPD
   ysCb.ysInit[inst].dbgMask = 0x0;
#else
#ifdef YS_DEBUG
   ysCb.ysInit[inst].dbgMask = 0xffffffff; 
#endif
#endif
#endif /* DEBUGP */
#ifdef SS_DIAG
   ysCb.ysInit[inst].logMask = 0x0;
#endif
   ysCb.ysInit[inst].procId = SFndProcId();

   /* Initialize CTF sap state */
   ysCb.ctfSap.sapState = LYS_NOT_CFG;

#ifndef NOFILESYS
#ifndef TENB_RTLIN_CHANGES
   if ((ysInitCfg()) != ROK)
   {
      RETVALUE (RFAILED);
   }
#endif
#endif



#ifdef  YS_WIRESHARK_LOG
  ysInitLogWireless();
#endif
#ifdef YS_MSPD
   /* ysMsInit(); */
   /* changes for new SysCore
    * Need to register a call back function over here
    * Currently passing context as null dont see a usage as of now */
#ifndef TENB_RTLIN_CHANGES
   SvsrRegMsgHandler (IID_LTE_MAC, YsLiMsgHandler, NULLP);
   SvsrRegMsgHandler (IID_LTE_MAC_EX, YsLiMsgHandler, &ysMsgList);
   SetMacInstanceId(IID_LTE_MAC);
#else
#ifndef RGL_SPECIFIC_CHANGES
   ysCb.phymsgHdr.control = CTRL_BYPASS | CTRL_VERSION;
   ysCb.phymsgHdr.length  = 0;
   ysCb.phymsgHdr.type    = MSGT_DATA;
   ysCb.phymsgHdr.srcID   = MSGS_MAC;
   ysCb.phymsgHdr.dstID   = MSGS_LARM | 0x26; /*0x8026, phyinstance id is 0x26 */
   ysCb.phymsgHdr.msgID   = PHY_LTE_MSG_LIST; /* We always use list based messaging */
#endif
#endif

   /* Store the post structure */
   ysCb.clPst.dstProcId = SFndProcId();
   ysCb.clPst.srcProcId = SFndProcId();
   ysCb.clPst.dstEnt = ENTTF;
   ysCb.clPst.srcEnt = ENTTF;
   ysCb.clPst.srcInst = 0;
   ysCb.clPst.dstInst = 0;
   ysCb.clPst.route = RTESPEC;
   ysCb.clPst.prior = PRIOR0;
   ysCb.clPst.region = ysCb.ysInit[inst].region;
   ysCb.clPst.pool = ysCb.ysInit[inst].pool;
   ysCb.clPst.selector = 1;
   ysCb.clPst.event = 0;

   /* Sumanth - Added SPAcc initialisation for MSPD accelerators */
#ifdef TENB_AS_SECURITY
   /*ret = SPAccDrvInit();
   if(ret == ROK)
   {
       RLOG0(L_DEBUG,"SPACC Driver Inititalised Successfully");
   }*/
#endif


#endif /* YS_MSPD */
#ifdef SS_USE_ICC_MEMORY
   ysCb.ysIccHdl = ssGetIccHdl(region);
#endif
#ifdef L2_OPTMZ
#define UR_MAC_PAD_SIZE 10000
//  MsgLen dLen;
  /* Pre allocate MAC padding buffer */
//  ssGetDBufOfSize(BC_SHARED_REG,UR_MAC_PAD_SIZE, &urCb.macPadBuf);
//  SGetDataRx(urCb.macPadBuf, 0, &urCb.macPadPtr, &dLen);
  Size           msgLen = 10000;
  Data          *dataPtr[2];
  SGetStaticBuffer(ysCb.ysInit[inst].region, ysCb.ysInit[inst].pool, &dataPtr[0], msgLen, 0);
  ysCb.macPadPtr[inst] = dataPtr[0]; 
#endif

#ifdef ENABLE_CNM
   ysCb.isCnmProcInitiated = FALSE;
   ysCb.cnmState = YS_MS_INIT_STATE;
   ysCb.cnmNmmStatus = ROK;
   STKLOG(STK_MD_YS,STK_LOG_INFO,"CNM:: Init in yscb done...\n");
   RLOG0(L_INFO, "CNM:: Init in yscb done...");
#endif
#ifdef SPLIT_RLC_DL_TASK
   /* Nawas:: There is no icc hdl associated with
    * phy receiver thread. mBuf for posting msg from phy
    * recvr thread to Cl thread is allocated from Cl thread 
    * region and is never deallocated. This logic can be changed
    * if required and if an icc handle can be associated with the
    * phy rcvr thread*/
   phyRcvPst.srcProcId  = SFndProcId();
   phyRcvPst.dstProcId  = SFndProcId();
   phyRcvPst.dstEnt	 = ENTYS;
   phyRcvPst.srcEnt	 = ENTYS;
   phyRcvPst.event 	 = EVTTFUTTIIND;
   {
      U32   i;
      for (i = 0; i < YS_NUM_SUB_FRAMES; i++)
         SGetMsg(ysCb.ysInit[inst].region, ysCb.ysInit[inst].pool, &phyRcvThreadMBuf[i]);
   }
#endif
#if ((defined(UL_RLC_NET_CLUSTER) && defined(TENB_STATS) && (defined(L2_L3_SPLIT))) || !defined(LTE_TDD))
   TSL2AllocStatsMem(ysCb.ysInit[inst].region, ysCb.ysInit[inst].pool, inst);
#endif
   cellPhyInstId = YS_PHY_INST_ID;

   RETVALUE(ROK);
} /* ysActvInit */
#ifdef MSPD
#define PID_MAC_PROCESSING_THREAD   30000

U32 MacGetTick(void)
{
#ifdef TENB_RTLIN_CHANGES
#ifdef XEON_SPECIFIC_CHANGES
     return GetTIMETICK();
#else
     return 0;
#endif
#else
    return *(volatile U32 *)0xFE050004;
#endif
}


#ifdef TENB_RTLIN_CHANGES
PUBLIC U32 YsLiMsgHandler (Void * ysCtx, Void * msg)
{
#ifndef RGL_SPECIFIC_CHANGES
#ifdef MSPD_MLOG_NEW
   static Bool firstMsg = TRUE;
#endif  
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   /*starting Task*/
      SStartTask(&startTime, PID_CL_PHY_MSG);
#ifndef TENB_RTLIN_CHANGES
   U32       isList = ysCtx == (void *)&ysMsgList ? TRUE : FALSE;
   //uart_printf("YsLiMsgHandler %x\n", *(U32*)msg);
   /* ysCtx is not used ignore */
#else
   U32       isList = ((MSGHEADER *)msg)->msgID == PHY_LTE_MSG_LIST;
#endif

   /* sdass_ssi */
#ifndef TENB_RTLIN_CHANGES
   if (firstMsg)
   {
      MxSetThreadPriority(MxGetCurrentThread(),0);
      firstMsg = FALSE;
   }
   MacDispatch(isList, (PTR)msg);
#endif

#ifdef TENB_RTLIN_CHANGES
   {
      MSGHEADER *hdr = (MSGHEADER *)msg;
      if (!(hdr->control & CTRL_BYPASS))
      {
         STKLOG(STK_MD_YS,STK_LOG_ERR,"%s: error: Invalid msg from PHY\n", __func__);
         RETVALUE(SUCCESS);
      }
   }
#endif
   ysReceivePHYMsg(isList, (PTR)msg);
   /*stopping Task*/
   SStopTask(startTime, PID_CL_PHY_MSG);
#endif /* RGL_SPECIFIC_CHANGES */
   return SUCCESS;
}
#endif /*TENB_RTLIN_CHANGES*/
#endif



#ifdef YS_MSPD


/**
 * @brief Task Initiation callback function.
 *
 * @details
 *
 *     Function : ysMsInit
 *
 *     This function is supplied as one of parameters during CL's
 *     task registration. SSI will invoke this function once, after
 *     it creates and attaches this Tapa Task to a system task.
 *
 *  @param[in]  Ent entity, the entity Id of this task.
 *  @param[in]  Inst inst, the instance Id of this task.
 *  @param[in]  Region region, the region Id registered for memory
 *              usage of this task.
 *  @param[in]  Reason reason.
 *  @return  S16
 *      -# ROK
 **/
#ifdef ANSI
PUBLIC S16 ysMsInit
(
Void
)
#else
PUBLICE S16 ysMsInit()
#endif
{
   U16       idx;
   U8        a0, a1, a2, a3, bit, cnt;
   U16       value;

   TRC2(ysMsInit);

   memset(&(ysCb.cellCfgLst), 0, sizeof(ysCb.cellCfgLst));

   /* initialize SR Configuration DB */
   for(idx = 0; idx < YS_NUM_SR_CFG; idx++)
   {
      /* idx value can not go beyond 255. No loss of precission */
      ysSrCfgDb[idx].srCfgIndex = idx;

      if(idx <= 4)
      {
         ysSrCfgDb[idx].srPeriod = 5;
         ysSrCfgDb[idx].srSfOffSet = idx;
      }
      else if (idx >= 5 && idx <= 14)
      {
         ysSrCfgDb[idx].srPeriod = 10;
         ysSrCfgDb[idx].srSfOffSet = idx - 5;
      }
      else if (idx >= 15 && idx <= 34)
      {
         ysSrCfgDb[idx].srPeriod = 20;
         ysSrCfgDb[idx].srSfOffSet = idx - 15;
      }
      else if (idx >= 35 && idx <= 74)
      {
         ysSrCfgDb[idx].srPeriod = 40;
         ysSrCfgDb[idx].srSfOffSet = idx - 35;
      }
      else if (idx >= 75 && idx <= 154)
      {
         ysSrCfgDb[idx].srPeriod = 80;
         ysSrCfgDb[idx].srSfOffSet = idx - 75;
      }
      else if (idx >=155 && idx <=156)
      {
         ysSrCfgDb[idx].srPeriod = 2;
         ysSrCfgDb[idx].srSfOffSet = idx - 155;
      }
      else /*-- if (idx == 157) -- Last entry --*/
      {
         ysSrCfgDb[idx].srPeriod = 1;
         ysSrCfgDb[idx].srSfOffSet = idx - 157;
      }
   }

   /* initialize SRS Configuration DB */
   /* 3GPP Spec 36.213 Table 8.2-1 */
   for(idx = 0; idx < YS_NUM_SRS_CFG; idx++)
   {
      ysSrsCfgDb[idx].srsCfgIndex = idx;

      if(idx <= 1)
      {
         ysSrsCfgDb[idx].srsPeriod = 2;
         ysSrsCfgDb[idx].srsSfOffSet = idx;
      }
      else if (idx >= 2 && idx <= 6)
      {
         ysSrsCfgDb[idx].srsPeriod = 5;
         ysSrsCfgDb[idx].srsSfOffSet = idx - 2;
      }
      else if (idx >= 7 && idx <= 16)
      {
         ysSrsCfgDb[idx].srsPeriod = 10;
         ysSrsCfgDb[idx].srsSfOffSet = idx - 7;
      }
      else if (idx >= 17 && idx <= 36)
      {
         ysSrsCfgDb[idx].srsPeriod = 20;
         ysSrsCfgDb[idx].srsSfOffSet = idx - 17;
      }
      else if (idx >= 37 && idx <= 76)
      {
         ysSrsCfgDb[idx].srsPeriod = 40;
         ysSrsCfgDb[idx].srsSfOffSet = idx - 37;
      }
      else if (idx >= 77 && idx <= 156)
      {
         ysSrsCfgDb[idx].srsPeriod = 80;
         ysSrsCfgDb[idx].srsSfOffSet = idx - 77;
      }
      else if (idx >= 157 && idx <= 316)
      {
         ysSrsCfgDb[idx].srsPeriod = 160;
         ysSrsCfgDb[idx].srsSfOffSet = idx - 157;
      }
      else /*-- if (idx >= 317 && idx <= 636) Single Entry */
      {
         ysSrsCfgDb[idx].srsPeriod = 320;
         ysSrsCfgDb[idx].srsSfOffSet = idx - 317;
      }
   }

   /* initialize Cqi-Pmi Configuration DB */
   /* 3GPP Spec 36.213 7.2.2-1A */
   for(idx = 0; idx < YS_NUM_CQI_CFG; idx++)
   {
      ysCqiPmiCfgDb[idx].cqiPmiCfgIndex = idx;

      if(idx <= 1)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 2;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx;
      }
      else if (idx >= 2 && idx <= 6)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 5;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx - 2;
      }
      else if (idx >= 7 && idx <= 16)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 10;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx - 7;
      }
      else if (idx >= 17 && idx <= 36)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 20;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx - 17;
      }
      else if (idx >= 37 && idx <= 76)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 40;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx - 37;
      }
      else if (idx >= 77 && idx <= 156)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 80;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx - 77;
      }
      else if (idx >= 157 && idx <= 316)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 160;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx - 157;
      }
      else if (idx == 317)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 0;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = 0;
      }
      else if (idx >= 318 && idx <= 349)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 32;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx - 318;
      }
      else if (idx >= 350 && idx <= 413)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 64;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx - 350;
      }
      else if (idx >= 414 && idx <= 541)
      {
         ysCqiPmiCfgDb[idx].cqiPeriod = 128;
         ysCqiPmiCfgDb[idx].cqiSfOffSet = idx - 414;
      }

   }

   /* Compute and fill the cqiTo20BitMap array
   */
   for(cnt =0; cnt < 16; cnt++)
   {
      a0 = cnt & 0x00;
      a1 = cnt & 0x02;
      a2 = cnt & 0x04;
      a3 = cnt & 0x08;
      value = 0;
      bit = 0;
      for(idx =0; idx < 20; idx++)
      {
         bit = (a0 * MSeq[idx][0] + a1 * MSeq[idx][1] + a2 * MSeq[idx][2] + \
               a3 * MSeq[idx][3]) % 2;
         value = (value << 1) | bit;
      } /* end of inner for loop */
      cqiTo20BitMap[cnt][1] = value;
   } /* end of outer for loop */

   ysMsSetupUlCqiInfo(ysCb.sinrToCqi);

   RETVALUE(ROK);
} /* ysMsInit */


#endif /* YS_MSPD */

/********************************************************************30**
  
         End of file:     yw_ms_init.c@@/main/TeNB_Main_BR/5 - Mon Aug 11 16:42:38 2014
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/2      ---     sgm        1. eNodeB 1.2 release
/main/2   ys003.102  sgm        1.Fix for CID:1622-02-01 DefectId:ccpu00115333
/main/2   ys004.102  ms         1.configuration file check.                                   
                                2.TTI configured.
                     pkd        3.Kworks warnings fix.
                     pkd        4.Cell Delete functionality CRID:ccpu00117556
/main/2   ys005.102  psb        1.TIC_ID :ccpu00117545 Fixed warning for gcc compilation on CentOS
*********************************************************************91*/

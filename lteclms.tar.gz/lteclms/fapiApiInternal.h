/*-----------------------------------------------------------
 * fapiApiInternal.h
 *
 * DAN Physical interface internal header
 *
 * The definitions are compatible with API version
 * as described in "LTE FAPI API" docuemnt revision 2.4
 *
 * Copyright (C) 2013-2017 Qualcomm Technologies, Inc.
 * All Rights Reserved.
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 *-----------------------------------------------------------
 */

#ifndef _FAP_API_INTERNAL_H_
#define _FAP_API_INTERNAL_H_
#define FAPI_VER_NUM_3_0_6 1
#define FAPI_VER_NUM_1_1_0 0

#define FAPI_VER_NUM FAPI_VER_NUM_3_0_6
/*
 * -----------------------------------------------------------
 * Include section
 * -----------------------------------------------------------
 */

/*
 * -----------------------------------------------------------
 * MACRO (define) section
 * -----------------------------------------------------------
 */
#ifdef __cplusplus
extern "C" {
#endif

#define FAPI_CONV_SEND_PRIORITY     IPC_trns_prio_e_1
#define FAPI_CONV_MIRROR_PRIORITY   IPC_trns_prio_e_1
#define PACK_STRUCT __attribute__((packed))

/*
 * -----------------------------------------------------------
 * Type definition section
 * -----------------------------------------------------------
 */

#define DEFAULT_CARRIER_ID 0xFF


/**********************************************
 *  FAPI Vendor Specific Extension Version
 **********************************************
*/
#define FAPI_VSM_API_REVISION "1.6"
#define FAPI_VSM_REVISION_MAJOR 1
#define FAPI_VSM_REVISION_MINOR 6

 /********************************************
  *  FAPI Physical Interface API Enumerators
  ********************************************
 */
#ifndef FAPI_UINT8
#define FAPI_UINT8      unsigned char
#endif
#ifndef FAPI_UINT16
#define FAPI_UINT16     unsigned short
#endif
#ifndef FAPI_UINT32
#define FAPI_UINT32     unsigned long
#endif
#ifndef FAPI_UINT64
#define FAPI_UINT64     unsigned long long
#endif
#ifndef FAPI_INT8
#define FAPI_INT8       signed char
#endif
#ifndef FAPI_INT16
#define FAPI_INT16      signed short
#endif
#ifndef FAPI_INT32
#define FAPI_INT32      signed long
#endif
#ifndef FAPI_BOOL
#define FAPI_BOOL       unsigned long
#endif
#ifndef FAPI_TBOOL
#define FAPI_TBOOL       unsigned long
#endif
#ifndef FAPI_VOID_P
#define FAPI_VOID_P     void *
#endif

#ifndef FAPI_VUINT8
#define FAPI_VUINT8     volatile unsigned char
#endif
#ifndef FAPI_VUINT16
#define FAPI_VUINT16    volatile unsigned short
#endif
#ifndef FAPI_VUINT32
#define FAPI_VUINT32    volatile unsigned long
#endif
#ifndef FAPI_VINT8
#define FAPI_VINT8      volatile signed char
#endif
#ifndef FAPI_VINT16
#define FAPI_VINT16     volatile signed short
#endif
#ifndef FAPI_VINT32
#define FAPI_VINT32     volatile signed long
#endif
#ifndef FAPI_VBOOL
#define FAPI_VBOOL      volatile unsigned long
#endif

/*********************************
 *  MAC-PHY Interface message
 *  types
 *********************************
*/
typedef enum
{
    FAPI_E_PARAM_REQ          = 0x00,
    FAPI_E_PARAM_RSP          = 0x01,
    FAPI_E_CONFIG_REQ         = 0x02,
    FAPI_E_CONFIG_RSP         = 0x03,
    FAPI_E_START_REQ          = 0x04,
    FAPI_E_STOP_REQ           = 0x05,
    FAPI_E_STOP_IND           = 0x06,
    FAPI_E_UE_CONFIG_REQ      = 0x07,
    FAPI_E_UE_CONFIG_RSP      = 0x08,
    FAPI_E_ERROR_IND          = 0x09,
    FAPI_E_UE_RELEASE_REQ     = 0x0A,
    FAPI_E_UE_RELEASE_RSP     = 0x0B,
    FAPI_E_RX_ULSCH_IND_DATA  = 0x0C, // Data mirroring. 0x0c isn't defined in FAPI standart. Use this entry to not change OAM_ws_levels[] (see OAM_DUMMY.c)
                                      // This is temporary for FR6. Should be changed in FR7
    FAPI_E_DL_CONFIG_REQ      = 0x80,
    FAPI_E_UL_CONFIG_REQ      = 0x81,
    FAPI_E_SF_IND             = 0x82,
    FAPI_E_HI_DCI0_REQ        = 0x83,
    FAPI_E_TX_REQ             = 0x84,
    FAPI_E_HARQ_IND           = 0x85,
    FAPI_E_CRC_IND            = 0x86,
    FAPI_E_RX_ULSCH_IND       = 0x87,
    FAPI_E_RACH_IND           = 0x88,
    FAPI_E_SRS_IND            = 0x89,
    FAPI_E_RX_SR_IND          = 0x8A,
    FAPI_E_RX_CQI_IND         = 0x8B,
    FAPI_E_LBT_DL_CONFIG_REQ  = 0x8C,
    FAPI_E_LBT_DL_IND         = 0x8D,
    FAPI_E_RX_VSM_MEAS_IND    = 0xE0,
    FAPI_E_LBT_VSM_MEAS_IND   = 0xE1,
    FAPI_E_RX_VSM_NI_IND      = 0xE2,
    FAPI_E_VSM_CFG_REPORT     = 0xE3,
    FAPI_E_PHY_INFRA_CFG_REQ  = 0xE4,
    FAPI_E_ERROR_IND_DL       = 0XE5, //internal for ipc alloc
    FAPI_E_ERROR_IND_UL       = 0XE6, //internal for ipc alloc
    FAPI_E_ERROR_IND_CFG      = 0XE7, //internal for ipc alloc
    FAPI_E_ERROR_IND_LBT      = 0XE8, //internal for ipc alloc
    FAPI_E_MSG_TYPE_LAST
} FAPI_E_MSG_TYPE;

// FAPI State machine
typedef enum {
    FAPI_E_STATE_IDLE           = 0,
    FAPI_E_STATE_CONFIGURED     = 1,
    FAPI_E_STATE_RUNNING        = 2,
    FAPI_E_STATE_PRE_STOP       = 3,
    FAPI_E_STATE_PRE_RUNNING    = 4,
}FAPI_E_STATE;

// FAPI State machine
typedef enum {
    FAPI_E_TLV_TAG_VALUE    = 0,
    FAPI_E_TLV_TAG_PTR      = 1
}FAPI_E_TLV_TAGS;

//FAPI Modulation
typedef enum {
    FAPI_E_MOD_QPSK         = 2,
    FAPI_E_MOD_16QAM        = 4,
    FAPI_E_MOD_64QAM        = 6,
    FAPI_E_MOD_256QAM       = 8
}FAPI_E_MOD;

//FAPI Bandwidth Support Bits
typedef enum {
    FAPI_E_BW_SUPPORT_MASK_6   = 0x1,  // Bit0
    FAPI_E_BW_SUPPORT_MASK_15  = 0x2,  // Bit1
    FAPI_E_BW_SUPPORT_MASK_25  = 0x4,  // Bit2
    FAPI_E_BW_SUPPORT_MASK_50  = 0x8,  // Bit3
    FAPI_E_BW_SUPPORT_MASK_75  = 0x10, // Bit4
    FAPI_E_BW_SUPPORT_MASK_100 = 0x20, // Bit5
}FAPI_E_BW_SUPPORT_MASK;


// Config Request TLV types (FAPI 2.5.2)
typedef enum
{
    FAPI_E_GEN_CFG_DUPLEXING_MODE                   = 0x01,
    FAPI_E_GEN_CFG_PCFICH_PWR_OFF                   = 0x02,
    FAPI_E_GEN_CFG_P_B                              = 0x03,
    FAPI_E_GEN_CFG_DL_CYC_PREFIX                    = 0x04,
    FAPI_E_GEN_CFG_UL_CYC_PREFIX                    = 0x05,
    FAPI_E_RF_CFG_DL_CH_BW                          = 0x0A,
    FAPI_E_RF_CFG_UL_CH_BW                          = 0x0B,
    FAPI_E_RF_CFG_RS_POWER                          = 0x0C,
    FAPI_E_RF_CFG_TX_ANT_PORTS                      = 0x0D,
    FAPI_E_RF_CFG_RX_ANT_PORTS                      = 0x0E,
    FAPI_E_PHICH_CFG_RESOURCE                       = 0x14,
    FAPI_E_PHICH_CFG_DURATION                       = 0x15,
    FAPI_E_PHICH_CFG_POWER_OFF                      = 0x16,
    FAPI_E_SCH_CFG_PSS                              = 0x1E,
    FAPI_E_SCH_CFG_SSS                              = 0x1F,
    FAPI_E_SCH_CFG_CELL_ID                          = 0x20,
    FAPI_E_PRACH_CFG_CONFIG_IDX                     = 0x28,
    FAPI_E_PRACH_CFG_ROOT_SEQ_IDX                   = 0x29,
    FAPI_E_PRACH_CFG_ZCZ_CONFIG                     = 0x2A,
    FAPI_E_PRACH_CFG_HIGH_SPEED                     = 0x2B,
    FAPI_E_PRACH_CFG_FREQ_OFF                       = 0x2C,
    FAPI_E_PUSCH_CFG_HOPPING_MODE                   = 0x32,
    FAPI_E_PUSCH_CFG_HOPPING_OFF                    = 0x33,
    FAPI_E_PUSCH_CFG_N_SUBBANDS                     = 0x34,
    FAPI_E_PUCCH_CFG_DELTA_SHIFT                    = 0x3C,
    FAPI_E_PUCCH_CFG_N_CQI_RB                       = 0x3D,
    FAPI_E_PUCCH_CFG_N_AN_CS                        = 0x3E,
    FAPI_E_PUCCH_CFG_N1_PUCCH_AN                    = 0x3F,
    FAPI_E_SRS_CFG_BW_CONFIG                        = 0x46,
    FAPI_E_SRS_CFG_MAX_UP_PTS                       = 0x47,
    FAPI_E_SRS_CFG_SF_CONFIG                        = 0x48,
    FAPI_E_SRS_CFG_SIM_AN_TRANS                     = 0x49,
    FAPI_E_UL_RS_CFG_HOPPING                        = 0x50,
    FAPI_E_UL_RS_CFG_GRP_ASSIGN                     = 0x51,
    FAPI_E_UL_RS_CFG_CS1DMRS                        = 0x52,
    FAPI_E_TDD_CFG_SF_ASSIGN                        = 0x5A,
    FAPI_E_TDD_CFG_S_SF_PATTERN                     = 0x5B,
    FAPI_E_LAA_ED_THR_LBT_PDSCH                     = 0x64,
    FAPI_E_LAA_ED_THR_LBT_DRS                       = 0x65,
    FAPI_E_LAA_PD_THR                               = 0x66,
    FAPI_E_LAA_MULTI_CARRIER_TYPE                   = 0x67,
    FAPI_E_LAA_MULTI_CARRIER_TX                     = 0x68,
    FAPI_E_LAA_MULTI_CARRIER_FREEZE                 = 0x69,
    FAPI_E_LAA_DRS_TX_ANT_PORTS                     = 0x6A,
    FAPI_E_LAA_DRS_TRANSMISSION_POWER               = 0x6B,
//---------------------------------------------------------
// Release 13 support:
    FAPI_E_PBCH_REPETITIONS_ENABLE                  = 0x78,
    FAPI_E_PRACH_CATM_ROOT_SEQUENCE_INDEX           = 0x79,
    FAPI_E_PRACH_CATM_ZERO_CORRELATION_ZONE_CFG     = 0x7A,
    FAPI_E_PRACH_CATM_HIGH_SPEED_FLAG               = 0x7B,
    FAPI_E_PRACH_CE_LEVEL_0_ENABLE                  = 0x7C,
    FAPI_E_PRACH_CE_LEVEL_0_CFG_IDX                 = 0x7D,
    FAPI_E_PRACH_CE_LEVEL_0_FREQ_OFFSET             = 0x7E,
    FAPI_E_PRACH_CE_LEVEL_0_NUM_OF_REPETITION       = 0x7F,
    FAPI_E_PRACH_CE_LEVEL_0_STARTING_SF_PERIODICITY = 0x80,
    FAPI_E_PRACH_CE_LEVEL_0_HOPPING_ENABLE          = 0x81,
    FAPI_E_PRACH_CE_LEVEL_0_HOPPING_OFFSET          = 0x82,
    FAPI_E_PRACH_CE_LEVEL_1_ENABLE                  = 0x83,
    FAPI_E_PRACH_CE_LEVEL_1_CFG_IDX                 = 0x84,
    FAPI_E_PRACH_CE_LEVEL_1_FREQ_OFFSET             = 0x85,
    FAPI_E_PRACH_CE_LEVEL_1_NUM_OF_REPETITION       = 0x86,
    FAPI_E_PRACH_CE_LEVEL_1_STARTING_SF_PERIODICITY = 0x87,
    FAPI_E_PRACH_CE_LEVEL_1_HOPPING_ENABLE          = 0x88,
    FAPI_E_PRACH_CE_LEVEL_1_HOPPING_OFFSET          = 0x89,
    FAPI_E_PRACH_CE_LEVEL_2_ENABLE                  = 0x8A,
    FAPI_E_PRACH_CE_LEVEL_2_CFG_IDX                 = 0x8B,
    FAPI_E_PRACH_CE_LEVEL_2_FREQ_OFFSET             = 0x8C,
    FAPI_E_PRACH_CE_LEVEL_2_NUM_OF_REPETITION       = 0x8D,
    FAPI_E_PRACH_CE_LEVEL_2_STARTING_SF_PERIODICITY = 0x8E,
    FAPI_E_PRACH_CE_LEVEL_2_HOPPING_ENABLE          = 0x8F,
    FAPI_E_PRACH_CE_LEVEL_2_HOPPING_OFFSET          = 0x90,
    FAPI_E_PRACH_CE_LEVEL_3_ENABLE                  = 0x91,
    FAPI_E_PRACH_CE_LEVEL_3_CFG_IDX                 = 0x92,
    FAPI_E_PRACH_CE_LEVEL_3_FREQ_OFFSET             = 0x93,
    FAPI_E_PRACH_CE_LEVEL_3_NUM_OF_REPETITION       = 0x94,
    FAPI_E_PRACH_CE_LEVEL_3_STARTING_SF_PERIODICITY = 0x95,
    FAPI_E_PRACH_CE_LEVEL_3_HOPPING_ENABLE          = 0x96,
    FAPI_E_PRACH_CE_LEVEL_3_HOPPING_OFFSET          = 0x97,
    FAPI_E_PUCCH_INTERVAL_UL_HOPPING_CFG_MODEA      = 0x98,
    FAPI_E_PUCCH_INTERVAL_UL_HOPPING_CFG_MODEB      = 0x99,
//---------------------------------------------------------
    FAPI_E_L1_CFG_DL_BW_SUPPORT                     = 0xC8,
    FAPI_E_L1_CFG_UL_BW_SUPPORT                     = 0xC9,
    FAPI_E_L1_CFG_DL_MOD_SUPPORT                    = 0xCA,
    FAPI_E_L1_CFG_UL_MOD_SUPPORT                    = 0xCB,
    FAPI_E_L1_CFG_ANT_CAP                           = 0xCC,
    FAPI_E_L1_CFG_REL_CAP                           = 0xCD,
    FAPI_E_L1_CFG_MBSFN_CAP                         = 0xCE,
    FAPI_E_L1_CFG_LAA_CAP_SUPPORT                   = 0xD1,
    FAPI_E_L1_CFG_LAA_CAP_PD_SENSING_LBT            = 0xD2,
    FAPI_E_L1_CFG_LAA_CAP_MULTI_CARRIER_LBT         = 0xD3,
    FAPI_E_L1_CFG_LAA_CAP_PARTIAL_SF                = 0xD4,
    FAPI_E_GEN_CFG_DATA_REP_MODE                    = 0xF0,
    FAPI_E_GEN_CFG_SFN_SF                           = 0xF1,
    FAPI_E_L1_CFG_STATE                             = 0xFA,
    FAPI_E_VSM_CFG_CFI                              = 0xFB, // Obsolete - The CFI is part of the DL_CONFIG and can be canged every TTI
    FAPI_E_INVALID_VALUE
}FAPI_E_CONFIG_TLV_TYPE;
// Config Request TLV types (FAPI 1.1)
typedef enum
{
    FAPI_E_REL_8_GEN_CFG_DUPLEXING_MODE     = 1,
    FAPI_E_REL_8_GEN_CFG_PCFICH_PWR_OFF     = 2,
    FAPI_E_REL_8_GEN_CFG_P_B                = 3,
    FAPI_E_REL_8_GEN_CFG_DL_CYC_PREFIX      = 4,
    FAPI_E_REL_8_GEN_CFG_UL_CYC_PREFIX      = 5,
    FAPI_E_REL_8_RF_CFG_DL_CH_BW            = 6,
    FAPI_E_REL_8_RF_CFG_UL_CH_BW            = 7,
    FAPI_E_REL_8_RF_CFG_RS_POWER            = 8,
    FAPI_E_REL_8_RF_CFG_TX_ANT_PORTS        = 9,
    FAPI_E_REL_8_RF_CFG_RX_ANT_PORTS        = 10,
    FAPI_E_REL_8_PHICH_CFG_RESOURCE         = 11,
    FAPI_E_REL_8_PHICH_CFG_DURATION         = 12,
    FAPI_E_REL_8_PHICH_CFG_POWER_OFF        = 13,
    FAPI_E_REL_8_SCH_CFG_PSS                = 14,
    FAPI_E_REL_8_SCH_CFG_SSS                = 15,
    FAPI_E_REL_8_SCH_CFG_CELL_ID            = 16,
    FAPI_E_REL_8_PRACH_CFG_CONFIG_IDX       = 17,
    FAPI_E_REL_8_PRACH_CFG_ROOT_SEQ_IDX     = 18,
    FAPI_E_REL_8_PRACH_CFG_ZCZ_CONFIG       = 19,
    FAPI_E_REL_8_PRACH_CFG_HIGH_SPEED       = 20,
    FAPI_E_REL_8_PRACH_CFG_FREQ_OFF         = 21,
    FAPI_E_REL_8_PUSCH_CFG_HOPPING_MODE     = 22,
    FAPI_E_REL_8_PUSCH_CFG_HOPPING_OFF      = 23,
    FAPI_E_REL_8_PUSCH_CFG_N_SUBBANDS       = 24,
    FAPI_E_REL_8_PUCCH_CFG_DELTA_SHIFT      = 25,
    FAPI_E_REL_8_PUCCH_CFG_N_CQI_RB         = 26,
    FAPI_E_REL_8_PUCCH_CFG_N_AN_CS          = 27,
    FAPI_E_REL_8_PUCCH_CFG_N1_PUCCH_AN      = 28,
    FAPI_E_REL_8_SRS_CFG_BW_CONFIG          = 29,
    FAPI_E_REL_8_SRS_CFG_MAX_UP_PTS         = 30,
    FAPI_E_REL_8_SRS_CFG_SF_CONFIG          = 31,
    FAPI_E_REL_8_SRS_CFG_SIM_AN_TRANS       = 32,
    FAPI_E_REL_8_UL_RS_CFG_HOPPING          = 33,
    FAPI_E_REL_8_UL_RS_CFG_GRP_ASSIGN       = 34,
    FAPI_E_REL_8_UL_RS_CFG_CS1DMRS          = 35,
    FAPI_E_REL_8_TDD_CFG_SF_ASSIGN          = 36,
    FAPI_E_REL_8_TDD_CFG_S_SF_PATTERN       = 37,
    FAPI_E_REL_8_L1_CFG_DL_BW_SUPPORT       = 40,
    FAPI_E_REL_8_L1_CFG_UL_BW_SUPPORT       = 41,
    FAPI_E_REL_8_L1_CFG_DL_MOD_SUPPORT      = 42,
    FAPI_E_REL_8_L1_CFG_UL_MOD_SUPPORT      = 43,
    FAPI_E_REL_8_L1_CFG_ANT_CAP             = 44,
    FAPI_E_REL_8_GEN_CFG_DATA_REP_MODE      = 50,
    FAPI_E_REL_8_GEN_CFG_SFN_SF             = 51,
    FAPI_E_REL_8_L1_CFG_STATE               = 60,
    FAPI_E_REL_8_VSM_CFG_CFI                = 61,
    FAPI_E_REL_8_VSM_END
}FAPI_E_CONFIG_REL_8_TLV_TYPE;
#define LEGAL_CFI(x)    ((x >= 1) && (x<=3))

// Infra config request PDU types
typedef enum
{
    FAPI_E_INFRA_DPD_CFG_PDU= 0,
    FAPI_E_INFRA_TRIGGER_REQ_PDU = 1,
    FAPI_E_INFRA_UNSOLICITED_ACK_NACK_THRESHOLD_PDU =2,
    FAPI_E_INFRA_PUCCH_PFA_PDU                      = 3,
    FAPI_E_INFRA_FORCE_DL_FULL_ALLOCATION_PDU       = 4,
}FAPI_E_INFRA_CFG_REQ_PDU_TYPE;


// DL config PDU types
typedef enum
{
    FAPI_E_DL_DCI_DL_PDU    = 0,
    FAPI_E_DL_BCH_PDU       = 1,
    FAPI_E_DL_MCH_PDU       = 2,
    FAPI_E_DL_DLSCH_PDU     = 3,
    FAPI_E_DL_PCH_PDU       = 4,
    FAPI_E_DL_ETM_DLSCH_PDU = 0x80,
    FAPI_E_DL_PRS_PDU       = 5,
    FAPI_E_DL_CSI_RS_PDU    = 6,
    FAPI_E_DL_EPDCCH_PDU        = 7,
    FAPI_E_DL_MPDCCH_DL_PDU     = 8,
    FAPI_E_DL_NPDCCH_PDU        = 9,
}FAPI_E_DL_CONFIG_PDU_TYPE;
// DL config PDU types (FAPI_1.1; REL_8)
typedef enum
{
    FAPI_E_REL_8_DL_DCI_DL_PDU      = 0,
    FAPI_E_REL_8_DL_BCH_PDU         = 1,
    FAPI_E_REL_8_DL_MCH_PDU         = 2,
    FAPI_E_REL_8_DL_DLSCH_PDU       = 3,
    FAPI_E_REL_8_DL_PCH_PDU         = 4,
    FAPI_E_REL_8_DL_ETM_DLSCH_PDU   = 5,
}FAPI_E_DL_REL_8_CONFIG_PDU_TYPE;

// DL DCI FORMAT types
typedef enum
{
    FAPI_E_DL_DCI_1         = 0,
    FAPI_E_DL_DCI_1A        = 1,
    FAPI_E_DL_DCI_1B        = 2,
    FAPI_E_DL_DCI_1C        = 3,
    FAPI_E_DL_DCI_1D        = 4,
    FAPI_E_DL_DCI_2         = 5,
    FAPI_E_DL_DCI_2A        = 6,
    FAPI_E_DL_DCI_2B        = 7,
    FAPI_E_DL_DCI_2C        = 8,
    FAPI_E_DL_DCI_2D        = 9,
    FAPI_E_DL_DCI_6_1A      = 10,
    FAPI_E_DL_DCI_6_1B      = 11,
    FAPI_E_DL_DCI_6_2       = 12,
}FAPI_E_DL_DCI_FORMAT_TYPE;

//Resource allocation types
typedef enum
{
    FAPI_E_RESOURCE_ALLOCATION_TYPE_0                               = 0,
    FAPI_E_RESOURCE_ALLOCATION_TYPE_1                               = 1,
    FAPI_E_RESOURCE_ALLOCATION_TYPE_2_DCI_FORMAT_1A_1B_1D           = 2,
    FAPI_E_RESOURCE_ALLOCATION_TYPE_2_DCI_FORMAT_1C                 = 3,
    FAPI_E_RESOURCE_ALLOCATION_TYPE_DCI_FORMAT_6_1A                 = 4,
    FAPI_E_RESOURCE_ALLOCATION_TYPE_DCI_FORMAT_6_1B                 = 5,
    FAPI_E_RESOURCE_ALLOCATION_TYPE_DCI_FORMAT_6_2                  = 6,
}FAPI_E_RESOURCE_ALLOCATION_TYPE;

// types
typedef enum
{
    FAPI_E_UE_TYPE_NON_LC_CE_UE                         = 0,
    FAPI_E_UE_TYPE_LC_CE_MODE_A_UE                      = 1,
    FAPI_E_UE_TYPE_LC_CE_MODE_B_UE                      = 2,
    FAPI_E_UE_TYPE_LAST                                 = 3,
}FAPI_E_UE_TYPE;
#define FAPI_IS_CATM_RNTI_TYPE(type)    (FAPI_E_UE_TYPE_NON_LC_CE_UE != (type))
typedef enum
{
    FAPI_E_PCH_MODE_NON_LC_CE_UE                        = 0,
    FAPI_E_PCH_MODE_LC_CE                               = 1,
    FAPI_E_PCH_MODE_LAST                                = 2,
}FAPI_E_PCH_MODE;
typedef enum
{
    FAPI_E_PAYLOAD_TYPE_CARRYING_SIB1_BR                = 0,
    FAPI_E_PAYLOAD_TYPE_CARRYING_SI_MESSAGE             = 1,
    FAPI_E_PAYLOAD_TYPE_CARRYING_OTHER                  = 2,
    FAPI_E_PAYLOAD_TYPE_LAST                            = 3,
}FAPI_E_PAYLOAD_TYPE;
typedef enum
{
    FAPI_E_MPDCCH_SET_SIZE_2_RBS                        = 2,
    FAPI_E_MPDCCH_SET_SIZE_4_RBS                        = 4,
    FAPI_E_MPDCCH_SET_SIZE_6_RBS                        = 6,
}FAPI_E_MPDCCH_SET_SIZE;
// RNTI Types (Valid for DCI format 1, 1A,2,2A:. 1 = C-RNTI, 2 = RA-RNTI, P-RNTI, or SI-RNTI, 3 = SPS-CRNTI)
typedef enum
{
    FAPI_E_C_RNTI           = 1,
    FAPI_E_RA_P_SI_RNTI     = 2,
    FAPI_E_SPS_CRNTI        = 3,
    FAPI_E_UNASSIGNED_RNTI_TYPE = 0xFFFFFFFF,
} FAPI_E_RNTI_TYPE;

// RNTI Types (Valid for DCI format 1, 1A,2,2A:. 1 = C-RNTI, 2 = RA-RNTI, P-RNTI, or SI-RNTI, 3 = SPS-CRNTI)
typedef enum
{
    FAPI_E_MPDCCH_RNTI_TYPE_TEMP_C_RNTI = 0,
    FAPI_E_MPDCCH_RNTI_TYPE_RA_RNTI     = 2,
    FAPI_E_MPDCCH_RNTI_TYPE_P_RNTI      = 3,
    FAPI_E_MPDCCH_RNTI_TYPE_OTHER_RNTI  = 4,
} FAPI_E_MPDCCH_RNTI_TYPE;
// RNTI Types (Valid for DCI format 6_0A and 6_0B)

// RNTI
typedef enum
{
    FAPI_E_RA_RNTI_S = 0x0001,
    FAPI_E_RA_RNTI_E = 0x000A,
    FAPI_E_C_RNTI_S  = 0x000B,
    FAPI_E_C_RNTI_E  = 0xFFF3,
    FAPI_E_M_RNTI    = 0xFFFD,
    FAPI_E_P_RNTI    = 0xFFFE,
    FAPI_E_SI_RNTI   = 0xFFFF,
} FAPI_E_RNTI_RANGE;

// DL Transmission Scheme types
typedef enum
{
    FAPI_E_TS_SINGLE_ANTENNA_PORT_0             = 0,    // TM1
    FAPI_E_TS_TX_DIVERSITY                      = 1,    // TM2
    FAPI_E_TS_LARGE_DELAY_CDD                   = 2,    // TM3
    FAPI_E_TS_CLOSED_LOOP_SPATIAL_MULTIPLEXING  = 3,    // TM4
    FAPI_E_TS_MULTI_USER_MIMO                   = 4,    // TM5
    FAPI_E_TS_CLOSED_LOOP_RANK_1_PRECODING      = 5,    // TM6
    FAPI_E_TS_SINGLE_ANTENNA_PORT_5             = 6,    // TM7
    FAPI_E_TS_SINGLE_ANTENNA_PORT_7             = 7,    // TM8, TM9, TM10
    FAPI_E_TS_SINGLE_ANTENNA_PORT_8             = 8,    // TM8, TM9, TM10
    FAPI_E_TS_DUAL_LAYER_TX_PORT_7_AND_8        = 9,    // TM8, TM9, TM10
    FAPI_E_TS_UP_TO_8_LAYER_TX                  = 10,   // TM9, TM10
}FAPI_E_TRANS_SCHEME_TYPE;

// DL Transmission Mode types
typedef enum
{
    FAPI_E_TRANSMISSION_MODE_0              = 0,    // TM0
    FAPI_E_TRANSMISSION_MODE_1              = 1,    // TM1
    FAPI_E_TRANSMISSION_MODE_2              = 2,    // TM2
    FAPI_E_TRANSMISSION_MODE_3              = 3,    // TM3
    FAPI_E_TRANSMISSION_MODE_4              = 4,    // TM4
    FAPI_E_TRANSMISSION_MODE_5              = 5,    // TM5
    FAPI_E_TRANSMISSION_MODE_6              = 6,    // TM6
    FAPI_E_TRANSMISSION_MODE_7              = 7,    // TM7
    FAPI_E_TRANSMISSION_MODE_8              = 8,    // TM8
    FAPI_E_TRANSMISSION_MODE_9              = 9,    // TM9
    FAPI_E_TRANSMISSION_MODE_10             = 10,   // TM10

    FAPI_E_TRANSMISSION_MODE_PARAM_MISSING  = 0xff, // NA - this field didn't exist in FAPI1.1 . it was introduced only in FAPI2.4
}FAPI_E_TRANS_MODE_TYPE;

// TX_REQ TLV Type (Tag options)
typedef enum
{
    FAPI_E_TLV_VALUE    = 0,
    FAPI_E_TLV_POINTER  = 1,
} FAPI_E_TX_REQ_TLV_TYPE;

// UL config PDU types
typedef enum
{
    FAPI_E_UL_ULSCH_PDU             = 0,
    FAPI_E_UL_ULSCH_CQI_RI_PDU      = 1,
    FAPI_E_UL_ULSCH_HARQ_PDU        = 2,
    FAPI_E_UL_ULSCH_CQI_HARQ_RI_PDU = 3,
    FAPI_E_UL_UCI_CQI_PDU           = 4,
    FAPI_E_UL_UCI_SR_PDU            = 5,
    FAPI_E_UL_UCI_HARQ_PDU          = 6,
    FAPI_E_UL_UCI_SR_HARQ_PDU       = 7,
    FAPI_E_UL_UCI_CQI_HARQ_PDU      = 8,
    FAPI_E_UL_UCI_CQI_SR_PDU        = 9,
    FAPI_E_UL_UCI_CQI_SR_HARQ_PDU   = 10,
    FAPI_E_UL_SRS_PDU               = 11,
    FAPI_E_UL_HARQ_BUFFER_PDU       = 12,
    FAPI_E_UL_ULSCH_UCI_CSI_PDU     = 13,
    FAPI_E_UL_ULSCH_UCI_HARQ_PDU    = 14,
    FAPI_E_UL_ULSCH_CSI_UCI_HARQ_PDU= 15,
    FAPI_E_UL_MAX_PDUS_NUM,

}FAPI_E_UL_CONFIG_PDU_TYPE;

// UL HI_DCI0 PDU types
typedef enum
{
    FAPI_E_UL_HI_PDU                = 0,
    FAPI_E_UL_DCI_UL_PDU            = 1,
    FAPI_E_UL_EPDCCH_DCI_UL_PDU     = 2,
    FAPI_E_UL_MPDCCH_DCI_UL_PDU     = 3,
}FAPI_E_HI_DCI0_PDU_TYPE;

// UL DCI FORMAT types
typedef enum
{
    FAPI_E_UL_DCI_0         = 0,
    FAPI_E_UL_DCI_3         = 1,
    FAPI_E_UL_DCI_3A        = 2,
    FAPI_E_UL_DCI_4         = 3,
    FAPI_E_UL_DCI_5         = 4,
    //---------------------------------------------------------
    // Release 13 support:
    FAPI_E_UL_DCI_6_0A      = 5,
    FAPI_E_UL_DCI_6_0B      = 6,
    //---------------------------------------------------------
}FAPI_E_UL_DCI_FORMAT_TYPE;

typedef enum
{
 FAPI_E_DCI_0_PAYLOAD_RUN_TIME_CASE_0 = 0, // cqi_csi_size =1 bit ,srs_flag =0 bit,res_alloc_flag = 0 bit
 FAPI_E_DCI_0_PAYLOAD_RUN_TIME_CASE_1 = 1, // cqi_csi_size =1 bit ,srs_flag =0 bit,res_alloc_flag = 1 bit
 FAPI_E_DCI_0_PAYLOAD_RUN_TIME_CASE_2 = 2, // cqi_csi_size =1 bit ,srs_flag =0 bit,res_alloc_flag = 1 bit
 FAPI_E_DCI_0_PAYLOAD_RUN_TIME_CASE_3 = 3, // cqi_csi_size =1 bit ,srs_flag =1 bit,res_alloc_flag = 1 bit
 FAPI_E_DCI_0_PAYLOAD_RUN_TIME_CASE_4 = 4, // cqi_csi_size =2 bit ,srs_flag =0 bit,res_alloc_flag = 0 bit
 FAPI_E_DCI_0_PAYLOAD_RUN_TIME_CASE_5 = 5, // cqi_csi_size =2 bit ,srs_flag =0 bit,res_alloc_flag = 1 bit
 FAPI_E_DCI_0_PAYLOAD_RUN_TIME_CASE_6 = 6, // cqi_csi_size =2 bit ,srs_flag =1 bit,res_alloc_flag = 0 bit
 FAPI_E_DCI_0_PAYLOAD_RUN_TIME_CASE_7 = 7, // cqi_csi_size =2 bit ,srs_flag =1 bit,res_alloc_flag = 1 bit
 }FAPI_E_DCI_0_FORMATE_RUN_TIME_CASES;


// FAPI Error Code
typedef enum
{
    FAPI_E_MSG_OK               = 0,
    FAPI_E_MSG_INVALID_STATE    = 1,
    FAPI_E_MSG_INVALID_CONFIG   = 2,
    FAPI_E_SFN_OUT_OF_SYNC      = 3,
    FAPI_E_MSG_PDU_ERR          = 4,
    FAPI_E_MSG_BCH_MISSING      = 5,
    FAPI_E_MSG_INVALID_SFN      = 6,
    FAPI_E_MSG_HI_ERR           = 7,
    FAPI_E_MSG_TX_ERR           = 8,

    // LBT error types will start at an offset of 100
    FAPI_E_LBT_REQ_START_OFFSET =                   100,
    FAPI_E_LBT_NO_PDU_IN_DL_REQ =                   FAPI_E_LBT_REQ_START_OFFSET,
    FAPI_E_LBT_TXOP_LESS_THAN_MIN_TXOP =            101,
    FAPI_E_LBT_NO_VALID_CONFIG_REQ_RECIEVED =       102,
    FAPI_E_LBT_EXTENDED_SFSFN_PASSES_END_SFSFN =    103,
    FAPI_E_LBT_SF_SFN_PASSED_END_SF_SFN =           104,
    FAPI_E_LBT_INVALID_TOPOLOGY =                   105,
    FAPI_E_LBT_TXOP_PASSED_MAX_VALUE =              106,
    FAPI_E_LBT_UNEXPECTED_DL_REQ =                  107,
    FAPI_E_LBT_DL_CONFIG_REQ_RECIEVED_IN_ILLEGAL_TIMING = 108,
    FAPI_E_LBT_OVERLAP =                            109,
    FAPI_E_LBT_DRS_PDU_NOT_SUPPORTED =              110,

    // vendor specific error types will start at an offset of 200
    FAPI_E_MSG_VSM_ERR_START_OFFSET =               200,
    FAPI_E_MSG_GLOB_PARAM_ERR   =                   FAPI_E_MSG_VSM_ERR_START_OFFSET, // vendor specific error type, for global params in a FAPI message.
    FAPI_E_N_PDU_LIMIT_SURPASSED=                   201, // vendor specific error type, PHY number of PDUs limitation was surpassed.
    FAPI_E_START_REQ_RECEIVED_BEFORE_HARD_SYNC=     202, // vendor specific error type, Start request received before hard sync was received
    FAPI_E_MULTIPLE_REQ_RECEIVED_IN_SAME_SF=        203, // vendor specific error type, more than one request recieved in same SF
    FAPI_E_CSI_RS_PDU_INVALID =                     204, // vendor specific error type, CSI-RS has not passed internal validation
    FAPI_E_PUCCH_INDICES_OVERLAP =                  205, // vendor specific error type, Illigal allocatin of pucch indices. probably measn that some indices overlap.
    FAPI_E_INVALID_CFI =                            206, // vendor specific error type, Invalid CFI parameter.
    FAPI_E_DL_SF_DROPED_BY_USER =                   207, // vendor specific error type, User has requested to drop the DL subframe from CLI bitmap
    FAPI_E_CSI_RS_INVALID_CONFIGURATION_GAP =       208, // Vendor specific error type, invalid CSI-RS configuration gap not according to DSP limitation
    FAPI_E_CSI_RS_UNSUPPORTED_SYMBOL =              209, // Vendor specific error type, unsupported symbol from configuration. We support only 8,9 and 10
    FAPI_E_CSI_RS_INVALID_NUM_OF_CONFIGURATIONS =   210, // Vendor specific error type, number of configurations is diffrent than 4. We only support 4 due to DSP limitations
    FAPI_E_CSI_RS_INVALID_CONFIG_OFFSET =           211, // Vendor specific error type, invalid offset from first RE. DSP supports only 0,1,2 for the 4 CSI-RS's
    FAPI_E_CSI_RS_INVALID_SF =                      212, // Vendor specific error type, invalid subframe. CSI-RS can't come in SF 0 or SF 5  with PSS/SSS/MIB
    FAPI_E_FORCE_DPD_SF_DROP =                      213, // vendor specific error type, User has requested to drop the DL subframe due to DPD force
    FAPI_E_INVALID_VSM_TAG =                        214, // Vendor specific error type, invalid vendor specific tag received.
    FAPI_E_INVALID_PBCH_PI_DUR =                    215, // Vendor specific error type, invalid vendor specific BCH Phich Duration.
    FAPI_E_INVALID_PBCH_CR_BW =                     216, // Vendor specific error type, invalid vendor specific BCH BW.
    FAPI_E_INVALID_PBCH_PI_RSC =                    217, // Vendor specific error type, invalid vendor specific BCH Phich Resource.

    // CAT_M PUSCH
    FAPI_E_HARQ_BUFFER_RELEASE_FAILURE  =           218, // Vendor Specific error type, in case we couldn't find any entry in PUSCH HASH Table.
    FAPI_E_NUM_CONNECTED_CATM_RNTIS_EXCEED_LIMIT =  219,
    FAPI_E_ULSCH_INVALID_REPETITION_NUM =           220,
    FAPI_E_PUSCH_DB_IS_FULL             =           221,

    FAPI_E_INVALID_UL_REQ_TDD_SF        =           222,
    FAPI_E_BCH_RECIEVED =                           223, // Vendor specific error type, Recieved BCH in LAA
}FAPI_E_ERROR_CODE;

// FAPI Sub Error Codes
typedef enum
{
    FAPI_E_FFS_ERR              = 0,
}FAPI_E_SUB_ERROR_CODE;

// VSM N_PDU_LIMIT_SURPASSED Sub Error Codes
typedef enum
{
    FAPI_E_VSM_PDU_LIMIT_DCI    = 0,
    FAPI_E_VSM_PDU_LIMIT_BCH    = 1,
    FAPI_E_VSM_PDU_LIMIT_MCH    = 2,
    FAPI_E_VSM_PDU_LIMIT_SCH    = 3,
    FAPI_E_VSM_PDU_LIMIT_PCH    = 4,
    FAPI_E_VSM_PDU_LIMIT_UCI    = 5,
    FAPI_E_VSM_PDU_LIMIT_SRS    = 6,
    FAPI_E_VSM_PDU_LIMIT_PRS    = 7,
    FAPI_E_VSM_PDU_LIMIT_HI     = 8,
    FAPI_E_VSM_PDU_LIMIT_CSI_RS = 9,
    FAPI_E_VSM_PDU_LIMIT_UCI_F1 = 10,
    FAPI_E_VSM_PDU_LIMIT_UCI_F2 = 11,
}FAPI_E_VSM_PDU_LIMIT_SUB_ERROR_CODE;


 typedef enum
 {
     FAPI_E_VSM_PUCCH_F1     = 0,
     FAPI_E_VSM_PUCCH_F2     = 1,
 }FAPI_E_VSM_PUCCH_INDICES_OVERLAP;

 // UL HARQ IND and HARQ Request FDD modes
 typedef enum
 {
     FAPI_E_HARQ_FDD_MODE_FORMAT_1B_1A  = 0,
     FAPI_E_HARQ_FDD_MODE_CHAN_SEL      = 1,
     FAPI_E_HARQ_FDD_MODE_FORMAT3       = 2,
 }FAPI_E_HARQ_FDD_MODE;

 // UL HARQ IND TDD modes
typedef enum
{
     FAPI_E_HARQ_TDD_IND_MODE_BUNDLING          = 0,
     FAPI_E_HARQ_TDD_IND_MODE_MULTIPLEXING      = 1,
     FAPI_E_HARQ_TDD_IND_MODE_SPECIAL_BUNDLING  = 2,
     FAPI_E_HARQ_TDD_IND_MODE_CHAN_SEL          = 3,
     FAPI_E_HARQ_TDD_IND_MODE_FORMAT3           = 4,
} FAPI_E_HARQ_IND_TDD_MODE;

 // UL HARQ REQ TDD modes
 typedef enum
 {
     FAPI_E_HARQ_TDD_REQ_MODE_BUNDLING          = 0,
     FAPI_E_HARQ_TDD_REQ_MODE_MULTIPLEXING      = 1,
     FAPI_E_HARQ_TDD_REQ_MODE_CHAN_SEL          = 2,
     FAPI_E_HARQ_TDD_REQ_MODE_FORMAT3           = 3,
 }FAPI_E_HARQ_REQ_TDD_MODE;

 typedef enum
 {
     FAPI_E_PA_MINUS_6_DB,
     FAPI_E_PA_MINUS_4p77_DB,
     FAPI_E_PA_MINUS_3_DB,
     FAPI_E_PA_MINUS_1p77_DB,
     FAPI_E_PA_0_DB,
     FAPI_E_PA_1_DB,
     FAPI_E_PA_2_DB,
     FAPI_E_PA_3_DB,
 }FAPI_E_PA;

 typedef enum
 {
     FAPI_PRS_CP_NORMAL = 0,
     FAPI_PRS_CP_EXTENDED = 1,
     FAPI_PRS_CP_MAX,
 }FAPI_PRS_CP_e;

//FAPI Release Capability Bits
typedef enum {
    FAPI_E_RELEASE_8_MASK  = 0x1,  // Bit0
    FAPI_E_RELEASE_9_MASK  = 0x2,  // Bit1
    FAPI_E_RELEASE_10_MASK = 0x4,  // Bit2
    FAPI_E_RELEASE_11_MASK = 0x8,  // Bit3
    FAPI_E_RELEASE_12_MASK = 0x10, // Bit4
    FAPI_E_RELEASE_13_MASK = 0x20, // Bit5
}FAPI_E_REL_CAPABILITY_MASK;

// PUCCH PFA Supported PUCCH Formats
typedef enum {
    FAPI_E_PUCCH_PFA_FORMAT1            = 0x00,
    FAPI_E_PUCCH_PFA_FORMAT1A1B_2A2B    = 0x01,
    FAPI_E_PUCCH_PFA_FORMAT_MAX
}FAPI_E_PUCCH_PFA_FORMAT;

//Indicated HARQ results
typedef enum {
    FAPI_E_AK           = 1,
    FAPI_E_NAK          = 2,
    FAPI_E_AK_NAK       = 3,
    FAPI_E_DTX          = 4,
    FAPI_E_AK_DTX       = 5,
    FAPI_E_NAK_DTX      = 6,
    FAPI_E_AK_NAK_DTX   = 7,
    FAPI_E_ANY          = FAPI_E_AK_NAK_DTX,
    FAPI_E_UNDEF        = 0xFF
} FAPI_E_HARQ_RESULT;

// LAA Multi carrier modes
typedef enum {
    FAPI_E_LAA_MULTI_CAR_MODE_A1_MASK = 0x1,  // Bit0
    FAPI_E_LAA_MULTI_CAR_MODE_A2_MASK = 0x2,  // Bit1
    FAPI_E_LAA_MULTI_CAR_MODE_B1_MASK = 0x4,  // Bit2
    FAPI_E_LAA_MULTI_CAR_MODE_B2_MASK = 0x8,  // Bit3
}FAPI_E_LAA_MULTI_CAR_CAPABILITY_MASK;

// LAA Multi carrier types
typedef enum
{
    FAPI_E_LAA_MULTI_CAR_TYPE_NONE  = 0,  // no multi carrier support
    FAPI_E_LAA_MULTI_CAR_TYPE_A1    = 1,  // Mode A1
    FAPI_E_LAA_MULTI_CAR_TYPE_A2    = 2,  // Mode A2
    FAPI_E_LAA_MULTI_CAR_TYPE_B1    = 3,  // Mode B1
    FAPI_E_LAA_MULTI_CAR_TYPE_B2    = 4,  // Mode B2
} FAPI_E_LAA_MULTI_CAR_TYPE;

// LAA Multi carrier Tx
typedef enum
{
    FAPI_E_LAA_MULTI_CAR_TX_MUTUAL_TRANS    = 0,  // Mutual transmission (self-deferral support for current carrier)
    FAPI_E_LAA_MULTI_CAR_TX_TRANS_ON_CH     = 1,  // transmit on channel access win (no self-deferral)
} FAPI_E_LAA_MULTI_CAR_TX;

// LAA Multi carrier Freeze
typedef enum
{
    FAPI_E_LAA_MULTI_CAR_FREEZE_NO_OTHER_TECH_NOT_GUARANTEED    = 0,  // absence of other technology isn��t guaranteed
    FAPI_E_LAA_MULTI_CAR_FREEZE_NO_OTHER_TECH_GUARANTEED        = 1,  // absence of other technology is guaranteed
} FAPI_E_LAA_MULTI_CAR_FREEZE;

/*********************************
 *  MAC-PHY Interface value
 *  declarations
 *********************************
*/
// PARAM.resp values
#define FAPI_MODULATION_MASK(modulation)    (1 << ((modulation / 2) - 1))
#define FAPI_DL_MODULATION_SUPPORT_MASK     (FAPI_MODULATION_MASK(FAPI_E_MOD_QPSK) | FAPI_MODULATION_MASK(FAPI_E_MOD_16QAM) | FAPI_MODULATION_MASK(FAPI_E_MOD_64QAM) | FAPI_MODULATION_MASK(FAPI_E_MOD_256QAM))
#define FAPI_UL_MODULATION_SUPPORT_MASK     (FAPI_MODULATION_MASK(FAPI_E_MOD_QPSK) | FAPI_MODULATION_MASK(FAPI_E_MOD_16QAM) | FAPI_MODULATION_MASK(FAPI_E_MOD_64QAM))
#define FAPI_UL_DL_BW_SUPPORT_MASK          (FAPI_E_BW_SUPPORT_MASK_25 | FAPI_E_BW_SUPPORT_MASK_50 | FAPI_E_BW_SUPPORT_MASK_75 | FAPI_E_BW_SUPPORT_MASK_100)
#define FAPI_PHY_ANT_CAPABILITY             (2)
#define FAPI_RELEASE_CAPABILITY             (FAPI_E_RELEASE_8_MASK | FAPI_E_RELEASE_9_MASK | FAPI_E_RELEASE_10_MASK)
#define FAPI_LAA_CAPABILITY_SUPPORT         (TRUE)
#define FAPI_LAA_CAP_PD_SENSING             (FALSE)
#define FAPI_LAA_CAP_MULTI_CARRIER_LBT_MASK (0)
#define FAPI_LAA_CAP_PARTIAL_SF             (FALSE)

// UL CQI/CSI Report Types
 typedef enum
 {
     FAPI_E_CSI_PERIODIC_REPORT  = 0,
     FAPI_E_CSI_APERIODIC_REPORT = 1,
 }FAPI_E_CSI_RPT_TYPE;

typedef enum {
    FAPI_E_BW1p4MHz  = 0,
    FAPI_E_BW3MHz    = 1,
    FAPI_E_BW5MHz    = 2,
    FAPI_E_BW10MHz   = 3,
    FAPI_E_BW15MHz   = 4,
    FAPI_E_BW20MHz   = 5,
} FAPI_E_CARRIER_BW;

typedef enum {
    FAPI_E_MAX_RB_NUM_NOT_CONFIGURED = 0,
    FAPI_E_MAX_RB_NUM_1_4MHz = 6,
    FAPI_E_MAX_RB_NUM_3MHz = 15,
    FAPI_E_MAX_RB_NUM_5MHz = 25,
    FAPI_E_MAX_RB_NUM_10MHz = 50,
    FAPI_E_MAX_RB_NUM_15MHz = 75,
    FAPI_E_MAX_RB_NUM_20MHz = 100,
} FAPI_E_MAX_RB_NUM;

 /*********************************
  *  Common header that is included
  *  at the beginning of all
  *  FAPI MAC-PHY messages
  *********************************
 */
typedef struct PACK_STRUCT FAPI_S_MSG_HDR {
     FAPI_UINT8             type;                   //Message type ID
     #ifdef NXP_PLATFORM
     FAPI_UINT8             msgVdrSpecFlag;                //Length of vendor-specific message body (bytes)
     #else
     FAPI_UINT8             len_ven;                //Length of vendor-specific message body (bytes)
     #endif
     FAPI_UINT16            len;                    //Length of vendor-specific message body (bytes)
 } FAPI_T_MSG_HDR;

typedef struct PACK_STRUCT FAPI_S_CONFIG_TLV {
    FAPI_UINT8                  tag;                //tag
    FAPI_UINT8                  length;             //Length (in bytes)
    FAPI_UINT16                 value;              //Value of tag parameter
}FAPI_T_CONFIG_TLV;

typedef struct PACK_STRUCT FAPI_S_CONFIG_REQ {
    FAPI_T_MSG_HDR          msg_hdr;                //Message header
    FAPI_UINT8              n_tlv;                  //Number of TLVs contained in the message body.
    FAPI_T_CONFIG_TLV       tlv[];
}FAPI_T_CONFIG_REQ;

typedef struct PACK_STRUCT FAPI_S_CONFIG_RSP {
    FAPI_T_MSG_HDR          msg_hdr;                //Message header
    FAPI_UINT8              error_code;             //see table 86
    FAPI_UINT8              n_tlv_invalid;          //Number of invalid or unsupported TLVs contained in the message body.
    FAPI_UINT8              n_tlv_missing;          //Number of missing TLVs contained in the message body. If the PHY is in the CONFIGURED state this will always be 0.
    FAPI_T_CONFIG_TLV       tlv[];                  //A list of invalid or unsupported TLVs �C each TLV is presented in its entirety.
                                                    // after the invalid TLVs there is a list of the missing TLV's
}FAPI_T_CONFIG_RSP;

typedef struct PACK_STRUCT FAPI_S_PARAM_REQ {
     FAPI_T_MSG_HDR         msg_hdr;                //Message header
 } FAPI_T_PARAM_REQ;

typedef struct PACK_STRUCT FAPI_S_PARAM_RSP {
     FAPI_T_MSG_HDR         msg_hdr;                //Message header
     FAPI_UINT8             error_code;             // Can contain one of two error messages: MSG_OK (message is OK), MSG_INVALID_STATE (The PARAM.request was recieved in the RUNNING state.
     FAPI_UINT8             n_tlv;                  //Number of TLVs contained in the message body.
     FAPI_T_CONFIG_TLV      tlv[];
 } FAPI_T_PARAM_RSP;

typedef struct PACK_STRUCT FAPI_S_START_REQ {
     FAPI_T_MSG_HDR         msg_hdr;                //Message header
 } FAPI_T_START_REQ;

typedef struct PACK_STRUCT FAPI_S_STOP_REQ {
     FAPI_T_MSG_HDR         msg_hdr;                //Message header
 } FAPI_T_STOP_REQ;

typedef struct PACK_STRUCT FAPI_S_STOP_IND {
     FAPI_T_MSG_HDR         msg_hdr;                //Message header
 } FAPI_T_STOP_IND;

// Subfram indication
typedef struct PACK_STRUCT FAPI_S_SF_IND {
    FAPI_T_MSG_HDR          msg_hdr;                //Message type ID
    FAPI_UINT32             sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
} FAPI_T_SF_IND;

typedef struct PACK_STRUCT FAPI_S_PDU {
    FAPI_UINT8              pdu_type;               //PDU type. Each pdu has its own type
    FAPI_UINT8              pdu_size;               // Size of the PDU control information (in bytes). This length value includes the 2 bytes required for the PDU type and PDU size parameters.
    FAPI_UINT8              pdu[];                  // The actual PDU structure
} FAPI_T_PDU;

typedef struct PACK_STRUCT FAPI_S_TRIGGER_REQ_PDU
{
    FAPI_UINT16 sfn;
    FAPI_UINT8  sf;
    FAPI_UINT8  io_index;
    FAPI_UINT16 bit_interval;
    FAPI_UINT32 pattern;
    FAPI_UINT32 start_time_offset;
}FAPI_T_TRIGGER_REQ_PDU;

typedef struct PACK_STRUCT FAPI_S_DPD_CFG_PDU
{
    FAPI_UINT32 valid_bitmap[4];
}FAPI_T_DPD_CFG_PDU;

typedef struct PACK_STRUCT FAPI_S_HARQ_THRESH_PDU
{
    FAPI_UINT32 harq_threshold;
}FAPI_T_HARQ_THRESH_PDU;

typedef struct PACK_STRUCT FAPI_S_PUCCH_PFA_INFO
{
    FAPI_UINT8 mantissa;
    FAPI_UINT8 exponent;
}FAPI_T_PUCCH_PFA_INFO;

typedef struct PACK_STRUCT FAPI_S_PUCCH_PFA_PDU
{
    FAPI_UINT8                    pucch_format;       //One of FAPI_E_PUCCH_PFA_FORMAT
    FAPI_T_PUCCH_PFA_INFO         pfa;
}FAPI_T_PUCCH_PFA_PDU;

typedef struct PACK_STRUCT FAPI_S_FORCE_DL_FULL_ALLOCATION_PDU
{
    FAPI_UINT8  force_dl_full_alloc;                //Forcing DL Full Allocation using DPD. Immediate action (Once received, forcing the new mode with no time limit). Value: 0...1
    FAPI_UINT8  padding[3];                         //Alignment Padding
}FAPI_T_FORCE_DL_FULL_ALLOCATION_PDU;

typedef struct PACK_STRUCT FAPI_S_PHY_INFRA_CFG_REQ {
     FAPI_T_MSG_HDR             msg_hdr;            //Message header
     FAPI_UINT16                sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
     FAPI_UINT16                length;             //The length of the uplink subframe configuration. Range 0...65535
     FAPI_UINT8                 n_pdu;              //The number of UL SCHs PDUs included in this message.
     FAPI_T_PDU                 pdu[];
} FAPI_T_PHY_INFRA_CFG_REQ;


// Table 4-17 : BCH PDU Release 8 parameters
typedef struct PACK_STRUCT FAPI_S_BCH_PDU_R8 {
    FAPI_UINT16                 length;             // The length (in bytes) of the associated MAC PDU, delivered in TX.request.
                                                    // This should be the actual length of the MAC PDU, which may not be a multiple of 32-bits.

    FAPI_UINT16                 pdu_idx;            // This is a count value which is incremented every time a
                                                    // BCH, MCH, PCH or DLSCH PDU is included in the DL_CONFIG.request message.
                                                    // This value is repeated in TX.request and associates the control information to the data.
                                                    // It is reset to 0 for every subframe.
                                                    // Range 0...65535

    FAPI_UINT16                 tp;                 // Offset to the reference signal power.
                                                    // value: 0...10000, representing -6 dB to 4 dB in 0.001 dB steps
} FAPI_T_BCH_PDU_R8;

// Table 4-16 : BCH PDU
typedef struct PACK_STRUCT FAPI_S_BCH_PDU {
    FAPI_T_BCH_PDU_R8           rel8;               // Release 8 attributes
} FAPI_T_BCH_PDU;

// Table 4-19 : MCH PDU Release 8 parameters
typedef struct PACK_STRUCT FAPI_S_MCH_PDU_R8 {
    FAPI_UINT16                 length;             // The length (in bytes) of the associated MAC PDU, delivered in TX.request.
                                                    // This should be the actual length of the MAC PDU, which may not be a multiple of 32-bits.
                                                    // A length of zero indicates that no MCH PDU is present and there is an empty MBSFN region in this subframe.
                                                    // In this case the remaining parameters for this PDU can be ignored

    FAPI_UINT16                 pdu_idx;            // This is a count value which is incremented every time a
                                                    // BCH, MCH, PCH or DLSCH PDU is included in the DL_CONFIG.request message.
                                                    // This value is repeated in TX.request and associates the control information to the data.
                                                    // It is reset to 0 for every subframe

    FAPI_UINT16                 rnti;               // The RNTI associated with the MCH
                                                    // value: FFFD

    FAPI_UINT8                  ra_type;            // This field is not used.

    FAPI_UINT32                 rb_coding;          // This field is not used.

    FAPI_UINT8                  modulation;         // value 2: QPSK
                                                    // value 4: 16QAM
                                                    // value 6: 64QAM
                                                    // value 8: 256QAM

    FAPI_UINT16                 tp;                 // Offset of MCH data and MBSFN-RS to the CRS reference signal power.
                                                    // value: 0 ? 10000, representing -6 dB to 4 dB in 0.001 dB steps.

    FAPI_UINT16                 mbsfn_area_id;      //Indicates MBSFN area ID, see [36.211] section 6.10.2. Value: 0...255
} FAPI_T_MCH_PDU_R8;

// Table 4-18 : MCH PDU
typedef struct PACK_STRUCT FAPI_S_MCH_PDU {
    FAPI_T_MCH_PDU_R8           rel8;               // Release 8 attributes
} FAPI_T_MCH_PDU;

typedef struct PACK_STRUCT FAPI_S_MCH_PDU_FAPI_VER_1_1_0 {
    FAPI_UINT16                 length;             // The length (in bytes) of the associated MAC PDU, delivered in TX.request.
                                                    // This should be the actual length of the MAC PDU, which may not be a multiple of 32-bits.

    FAPI_UINT16                 pdu_idx;            // This is a count value which is incremented every time a
                                                    // BCH, MCH, PCH or DLSCH PDU is included in the DL_CONFIG.request message.
                                                    // This value is repeated in TX.request and associates the control information to the data.
                                                    // It is reset to 0 for every subframe.
                                                    // Range 0...65535

    FAPI_UINT16                 rnti;               // The RNTI used for identifying the UE when receiving the PDU.
                                                    // Value: 1...65535

    FAPI_UINT8                  ra_type;            // Resource allocation type.
                                                    // 2 = type 2.

    FAPI_UINT32                 rb_coding;          // The encoding for the resource blocks.
                                                    // It's coding is dependent on whether resource allocation type 0, 1, 2 is in use.
                                                    // This should match the value sent in the DCI Format PDU which allocated this grant.

    FAPI_UINT8                  mod_type;           // value 2: QPSK
                                                    // value 4: 16QAM
                                                    // value 6: 64QAM

    FAPI_UINT16                 tp;                 // Offset to the reference signal power.
                                                    // Value: 0...10000, representing -6 dB to 4 dB in 0.001 dB steps
} FAPI_T_MCH_PDU_FAPI_VER_1_1_0;

// Table 4-29 : PCH PDU Release 8 parameters
typedef struct PACK_STRUCT FAPI_S_PCH_PDU_R8 {
    FAPI_UINT16                 length;             //The length (in bytes) of the associated MAC PDU, delivered in TX.request. This should be the actual length of the MAC PDU, which may not be a multiple of 32-bits.
    FAPI_UINT16                 pdu_idx;            //This is a count value which is incremented every time a BCH, MCH, PCH or DLSCH PDU is included in the DL_CONFIG.request message.
                                                    //This value is repeated in TX.request and associates the control information to the data. It is reset to 0 for every subframe. Range 0...65535
    FAPI_UINT16                 p_rnti;             //TThe P-RNTI associated with the paging. Value: 0xFFFE
    FAPI_UINT8                  ra_type;            //Resource allocation type. 2 = type 2.
    FAPI_UINT8                  vir_rb_flag;        //Type of virtual resource block used. This should match the value sent in the DCI formats: 1A,1B,1D, 0 = localized, 1 = distributed
    FAPI_UINT32                 rb_coding;          //The encoding for the resource blocks. It's coding is dependent on whether resource allocation type 0, 1, 2 is in use. This should match the value sent in the DCI Format PDU which allocated this grant
    FAPI_UINT8                  mcs;                //For PCH PDU only QPSK modulation is allowed. 0: QPSK
    FAPI_UINT8                  rv;                 //For PCH PDU only redundancy version 0 is allowed. Value: 0
    FAPI_UINT8                  n_tb;               //The number of transport blocks transmitted to this RNTI. Only 1 transport block is sent on the PCH per subframe. Value: 1
    FAPI_UINT8                  tb_2_code_swap;     //Reserved. This parameter is not used on the PCH transport channel.
    FAPI_UINT8                  trans_scheme;       //The MIMO mode used in the PDU. 0 = SINGLE_ANTENNA_PORT_0, 1= TX_DIVERSITY, 6 = SINGLE_ANTENNA_PORT_5.
    FAPI_UINT8                  n_layer;            //The number of layers used in transmission. Value: 1...4
    FAPI_UINT8                  codebook_idx;       //Reserved. This parameter is not used on the PCH transport channel.
    FAPI_UINT8                  ue_cat_cap;         //Reserved. This parameter is not used on the PCH transport channel.
    FAPI_UINT8                  pa;                 //The ratio of PDSCH EPRE to cell-specific RS EPRE among PDSCH REs in all the OFDM symbols not containing cell-specific RS in dB.
                                                    //0: -6dB, 1: -4.77dB, 2: -3dB, 3: -1.77dB, 4: 0dB, 5: 1dB, 6: 2dB, 7: 3dB
    FAPI_UINT16                 tp;                 //Offset to the reference signal power. Value: 0...10000, representing -6 dB to 4 dB in 0.001 dB steps
    FAPI_UINT8                  n_prb;              //Used with DCI 1A format. This should match the value sent in the TPC field of the DCI 1A PDU which allocated this grant. 0= N_PRB = 2, 1= N_PRB = 3
    FAPI_UINT8                  n_gap;              //Used in virtual resource block distribution; 0 = Ngap1, 1 = Ngap2
} FAPI_T_PCH_PDU_R8;

// Table 4-30 : PCH PDU Release 13 parameters
typedef struct PACK_STRUCT FAPI_S_PCH_PDU_R13 {
    FAPI_UINT8                  ue_mode;                  // 0: non LC/CE PCH;  1: LC/CE PCH
    FAPI_UINT16                 initial_transmission_sf;  //0-10239 (absolute sf) - in case of currect sf = 0xffff
} FAPI_T_PCH_PDU_R13;

// Table 4-28 PCU PDU
typedef struct PACK_STRUCT FAPI_S_PCH_PDU {
    FAPI_T_PCH_PDU_R8           rel8;               //Release 8 attributes
    FAPI_T_PCH_PDU_R13          rel13;              //Release 13 attributes
} FAPI_T_PCH_PDU;

// Table 4-10 : DCI DL PDU Release 8 parameters
typedef struct PACK_STRUCT FAPI_S_DCI_DL_PDU_REL_8 {
    FAPI_UINT8                  dci_format;         //Format of the DCI. 0 = 1, 1 = 1A, 2 = 1B, 3 = 1C, 4 = 1D, 5 = 2, 6 = 2A
    FAPI_UINT8                  cce_index;          //CCE index used to send the DCI. Value: 0...88
    FAPI_UINT8                  agg_level;          //The aggregation level used. Value: 1,2,4,8
    FAPI_UINT16                 rnti;               //The RNTI used for identifying the UE when receiving the PDU. Valid for all DCI formats. Value: 1...65535.
    FAPI_UINT8                  ra_type;            //Resource allocation type/header. Valid for DCI formats: 1,2,2A. 0=type 0, 1=type 1
    FAPI_UINT8                  vir_rb_flag;        //Type of virtual resource block used. Valid for DCI formats: 1A,1B,1D, 0 = localized, 1 = distributed
    FAPI_UINT32                 rb_coding;          //The encoding for the resource blocks. It's coding is dependent on whether resource allocation type 0, 1, 2 is in use.
    FAPI_UINT8                  mcs_1;              //The modulation and coding scheme for 1st transport block. Valid for DCI formats: 1,1A,1B,1C,1D ,2,2A. Value: 0...31
    FAPI_UINT8                  rv_1;               //The redundancy version for 1st transport block. Valid for DCI formats: 1,1A,1B,1C,1D ,2,2A. Value: 0...3
    FAPI_UINT8                  ndi_1;              //The new data indicator for 1st transport block. Valid for DCI formats: 1,1A,1B,1C,1D ,2,2A
    FAPI_UINT8                  tb_2_code_swap;     //Indicates the mapping of transport block to codewords. Valid for DCI formats: 2,2A. 0 = no swapping, 1 = swapped
    FAPI_UINT8                  mcs_2;              //The modulation and coding scheme for 2nd transport block. Valid for DCI formats: 2,2A. Value: 0...31
    FAPI_UINT8                  rv_2;               //The redundancy version for 2nd transport block. Valid for DCI formats: 2,2A. Value: 0...3
    FAPI_UINT8                  ndi_2;              //The new data indicator for 2nd transport block. Valid for DCI formats: 2,2A
    FAPI_UINT8                  harq_proc;          //HARQ process number. Valid for DCI formats: 1,1A,1B,1D,2,2A. Value: 0...15
    FAPI_UINT8                  tpmi;               //The codebook index to be used for precoding. Valid for DCI formats: 1B,1D. 2 ant_ports: 0...3, 4 ant_ports: 0...15
    FAPI_UINT8                  pmi;                //Confirmation for precoding. Valid for DCI formats: 1B. 0 = use precoding indicated in TPMI field, 1 = use precoding indicated in last PMI report on PUSCH
    FAPI_UINT8                  precode_info;       //Precoding information. Valid for DCI formats: 2,2A. 2 ant_ports: 0...7, 4 ant_ports: 0...63
    FAPI_UINT8                  tpc;                //Tx power control command for PUCCH. Valid for DCI formats: 1,1A,1B,1D,2,2A. Value: 0,1,2,3
    FAPI_UINT8                  dl_assign_idx;      //The downlink assignment index. Only used in TDD mode, value ignored for FDD. Valid for DCI formats: 1,1A,1B,1D,2,2A. Value: 1,2,3,4
    FAPI_UINT8                  n_gap;              //Used in virtual resource block distribution. Valid for DCI formats: 1A,1B,1C,1D. Value 0=n_gap1, 1=n_gap2.
    FAPI_UINT8                  tb_size_idx;        //The transport block size. Valid for DCI formats: 1C. value 0...31
    FAPI_UINT8                  dl_power_off;       //Indicates that PRACH procedure is initiated. Valid for DCI formats: 1A. Value: 0...1
    FAPI_UINT8                  alloc_prach_flag;   //Indicates that PRACH procedure is initiated. Valid for DCI formats: 1A. 0=false, 1=true.
    FAPI_UINT8                  preamble_idx;       //The preamble index to be used on the PRACH. Valid for DCI formats: 1A. Value: 0...63
    FAPI_UINT8                  prach_mask_idx;     //The mask index to be used on the PRACH. Valid for DCI formats: 1A. value 0...15
    FAPI_UINT8                  rnti_type;          //Valid for DCI format 1, 1A,2,2A:. 1 = C-RNTI, 2 = RA-RNTI, P-RNTI, or SI-RNTI, 3 = SPS-CRNTI
    FAPI_UINT16                 tp;                 //Offset to the reference signal power. Value: 0...10000, representing -6 dB to 4 dB in 0.001 dB steps
} FAPI_T_DCI_DL_PDU_R8;

// Table 4-11 : DCI DL PDU Release 9 parameters
typedef struct PACK_STRUCT FAPI_S_DCI_DL_PDU_R9 {
    FAPI_UINT8                  mcch_flag;          // Indicates if format 1C is being used to signal a MCCH change notification
                                                    // Valid for DCI formats 1C
                                                    // value: 0 = MCCH change notification field is not valid
                                                    // value: 1 = MCCH change notification field is valid

    FAPI_UINT8                  mcch_change_notif;  // MCCH Change Notification
                                                    // Valid for DCI format 1C
                                                    // value: 0->255

    FAPI_UINT8                  scramb_id;          // Indicates the scrambling identity value NSCID
                                                    // Valid for DCI format 2B
                                                    // value: 0,1
} FAPI_T_DCI_DL_PDU_R9;

// Table 4-12 : DCI DL PDU Release 10 parameters
typedef struct PACK_STRUCT FAPI_S_DCI_DL_PDU_R10 {
    FAPI_UINT8                  cross_car_schd_flag;    // Indicates if cross carrier scheduling has been enabled for the UE receiving this DCI.
                                                        // Valid for DCI formats 1,1A,1B, 1D,2,2A,2B,2C
                                                        // value: 0 = Carrier indicator field is not valid
                                                        // value: 1 = Carrier indicator field is valid

    FAPI_UINT8                  car_indicator;          // Serving Cell Index
                                                        // Valid for DCI formats 1,1A,1B,1D, 2,2A,2B,2C if the Cross-Carrier Scheduling flag is enabled
                                                        // value: 0->7

    FAPI_UINT8                  srs_flag;               // Indicates if the SRS request parameter is valid
                                                        // Valid for DCI formats 1A ,2B,2C
                                                        // value: 0 = SRS request field is not valid
                                                        // value: 1 = SRS request field is valid

    FAPI_UINT8                  srs_request;            // SRS request flag
                                                        // Valid for DCI formats 1A, 2B, 2C if the SRS flag is enabled.
                                                        // value: 0 = SRS not requested
                                                        // value: 1 = SRS requested

    FAPI_UINT8                  ant_p_scr_lrs;          // Indicates the Antenna port, scrambling identity value NSCID and number of layers
                                                        // Valid for DCI format 2C
                                                        // value: 0->7

    FAPI_UINT8                  payload_length;         // DCI payload length[bits]
    FAPI_UINT8                  n_dl_rb;                // BW of serving cell for which the DCI was scheduled for.
                                                        // This is valid for the case of cross carrier scheduling.
                                                        // For the case of a self-scheduling (cross carrier scheduling is not valid or Carrier indicator has value ��0��,
                                                        // the BW is the ��DL BW support�� as configured in configuration phase (params).
                                                        // Downlink channel bandwidth in resource blocks.
                                                        // See [10] section 5.6. Value: 6,15, 25, 50, 75, 100
} FAPI_T_DCI_DL_PDU_R10;

// Table 4-13 : DCI DL PDU Release 11 parameters
typedef struct PACK_STRUCT FAPI_S_DCI_DL_PDU_R11 {
    FAPI_UINT8                  harq_ack_res_offset;    // HARQ-ACK resource offset field is present only when this format is carried by EPDCCH.
                                                        // Valid for DCI formats 1, 1A, 1B, 1D, 1, 2A, 2, 2B, 2C, 2D
                                                        // value: 0->3

    FAPI_UINT8                  qcl;                    // PDSCH RE Mapping and Quasi-Co-Location Indicator - 2 bits as defined in [6] sections 7.1.9 and 7.1.10.
                                                        // Valid for DCI formats: 2D
} FAPI_T_DCI_DL_PDU_R11;

typedef struct PACK_STRUCT FAPI_S_DCI_DL_UL_DL_CFG_IND{
    FAPI_UINT8                  ul_dl_config_ind;       // UL/DL configuration index.
                                                        // value: 1->5
} FAPI_T_DCI_DL_UL_DL_CFG_IND;

// Table 4-14 : DCI DL PDU Release 12 parameters
typedef struct PACK_STRUCT FAPI_S_DCI_DL_PDU_R12 {
    FAPI_UINT8                  primary_cell_type;  // Indicates the type of the primary cell.
                                                    // Valid for DCI formats: 1,1A,1B,1D,2,2A,2B,2C.
                                                    // value: 0 = TDD
                                                    // value: 1 = FDD
                                                    // value: 2 = HD_FDD

    FAPI_UINT8                  ul_dl_config_flag;  // Indicates if format 1C is being used to signal UL/DL configuration.
                                                    // Valid for DCI formats 1C.
                                                    // value: 0 = UL/DL configuration field is not valid
                                                    // value: 1 = UL/DL configuration field is valid

    FAPI_UINT8                  num_ul_dl_config;   // Number of UL/DL configurations, I, as defined by [12] section 5.3.3.1.4

    FAPI_T_DCI_DL_UL_DL_CFG_IND ul_dl_config[];     // Used a ptr for casting using 'num_ul_dl_config' field
} FAPI_T_DCI_DL_PDU_R12;

// Table 4-15 : DCI DL PDU Release 13 parameters
typedef struct PACK_STRUCT FAPI_S_DCI_DL_PDU_R13 {
    FAPI_UINT8                  laa_end_partial_sf_flag;    // Indicates if DCI format 1C is being used to signal LAA end partial SF.
                                                            // value: 0 = LAA end partial SF configuration field is not valid and no LAA support
                                                            // value: 1 = LAA end partial SF configuration field is valid

    FAPI_UINT8                  laa_end_partial_sf_config;  // If DCI format 1C scrambled by CC-RNTI is used to signal end partial SF.
                                                            // this field contains LAA common information (4 bits used in [9] Table 13A-1
                                                            // for configuration of occupied OFDM symbols for current and next SF).

    FAPI_UINT8                  initial_lbt_sf;             // Indicates if the DCI PDU is prepared for full SF (regular) or for initial partial SF (2nd slot)
                                                            // according to [11] section 6.2.4 (if PDCCH) or 6.2.4A (if ePDCCH). v
                                                            // value: 0 = prepared for the case of a regular SF (higher layer parameter �� subframeStartPosition��=��s0��).
                                                            // value: 1 = prepared for the case of a partial SF (higher layer parameter �� subframeStartPosition��=��s07��).
                                                            // Valid for initial partial SF in LAA
    FAPI_UINT8                  codebook_size_determination_r13;// Indicates if the downlink assignment index parameter (DAI) is 4 bits
                                                                // 0 = DAI is 4 bits
                                                                // 1= DAI maybe 0 or 2 bits depending on other type of primary cell.
                                                                // Valid for DCI formats: 1,1A,1B,1D,2,2A,2B,2C

    FAPI_UINT8                  r13_dmrs_table_flag;            // Indicates if Release 13 DMRS table for be used.
                                                                // 0 = not used
                                                                // 1 = used
} FAPI_T_DCI_DL_PDU_R13;


// Table 4-9 : DCI DL PDU part A
typedef struct PACK_STRUCT FAPI_S_DCI_DL_PDU_A {
    FAPI_T_DCI_DL_PDU_R8        rel8;               // Release 8 attributes
    FAPI_T_DCI_DL_PDU_R9        rel9;               // Release 9 attributes
    FAPI_T_DCI_DL_PDU_R10       rel10;              // Release 10 attributes
    FAPI_T_DCI_DL_PDU_R11       rel11;              // Release 11 attributes
    FAPI_T_DCI_DL_PDU_R12       rel12;              // Release 12 attributes
} FAPI_T_DCI_DL_PDU_A;

// Table 4-9 : DCI DL PDU part B
typedef struct PACK_STRUCT FAPI_S_DCI_DL_PDU_B {
    FAPI_T_DCI_DL_PDU_R13       rel13;              // Release 13 attributes
} FAPI_T_DCI_DL_PDU_B;

typedef struct PACK_STRUCT FAPI_S_BF_VECTOR_VAL {
    FAPI_UINT16                 value;          //Beam forming vector element for physical antenna #i real 8 bits followed by imaginery 8 bits
} FAPI_T_BF_VECTOR_VAL;

// Table 4-22 : BfVectorType Structure
typedef struct PACK_STRUCT FAPI_S_BF_VECTOR_TYPE {
    FAPI_UINT8                  subband_idx;        //Index of subband for which the following beam forming vector is applied
    FAPI_UINT8                  n_antennas;     //Number of physical antennas
    FAPI_T_BF_VECTOR_VAL        bf_value[];     //Beam forming vector element for physical antenna #i real 8 bits followed by imaginery 8 bits
} FAPI_T_BF_VECTOR_TYPE;

typedef struct PACK_STRUCT FAPI_S_ETM_DLSCH_PDU_A {
    FAPI_UINT16                 length;             //The length (in bytes) of the associated MAC PDU, delivered in TX.request. This should be the actual length of the MAC PDU, which may not be a multiple of 32-bits.
    FAPI_UINT16                 pdu_idx;            //This is a count value which is incremented every time a BCH, MCH, PCH or DLSCH PDU is included in the DL_CONFIG.request message. This value is repeated in TX.request and associates the control information to the data. It is reset to 0 for every subframe. Range 0...65535
    FAPI_UINT16                 rnti;               //The RNTI used for identifying the UE when receiving the PDU. Valid for all DCI formats. Value: 1...65535.
    FAPI_UINT8                  ra_type;            //Resource allocation type/header. Valid for DCI formats: 1,2,2A. 0=type 0, 1=type 1
    FAPI_UINT8                  vir_rb_flag;        //Type of virtual resource block used. Valid for DCI formats: 1A,1B,1D, 0 = localized, 1 = distributed
    FAPI_UINT32                 rb_bitmap[4];       //RB allocation bitmap (32bit word * 4). for use in Test Mode.
    FAPI_UINT8                  modulation;         //2: QPSK,4: 16QAM,6: 64QAM, 8: 256QAM
    FAPI_UINT8                  rv;                 //HARQ redundancy version. This should match the value sent in the DCI Format PDU which allocated this grant. Value: 0...3.
    FAPI_UINT8                  tb;                 //The transport block transmitted to this RNTI. A value of 2 indicates this is the second transport block for either DCI format 2 or 2A. For other DCI values this field will always be 1. Value: 1...2
    FAPI_UINT8                  tb_2_code_swap;     //Indicates the mapping of transport block to codewords. Valid for DCI formats: 2,2A. 0 = no swapping, 1 = swapped
    FAPI_UINT8                  trans_scheme;       //The MIMO mode used in the PDU
    FAPI_UINT8                  n_layers;           //The number of layers used in transmission
    FAPI_UINT8                  n_subbands;         //Only valid when transmission scheme = 3, 4, 5. Defines the codebook used. When antenna port = 1: NA When antenna port = 2: 0..3 When antenna port = 4: 0..15
    FAPI_UINT8                  codebook_idx[];     //Only valid when transmission scheme = 3, 4, 5. Defines the number of subbands and codebooks used for PMI. If value=1 then a single PMI value is supplied which should be used over all RB. Value 0...13
} FAPI_T_ETM_DLSCH_PDU_A;

typedef struct PACK_STRUCT FAPI_S_BEAM_FORMING_INFO {
    FAPI_UINT8                  n_bf_prb;           //Number of PRBs that are treated as one subband
    FAPI_UINT8                  n_bf_vector;        //Number of beam forming vectors. One beam forming vector is specified for each subband
    FAPI_T_BF_VECTOR_TYPE       bf_vector[];        //Beam forming vectors
} FAPI_T_BEAM_FORMING_INFO;

typedef struct PACK_STRUCT FAPI_S_CSI_RS_NZP_CFG {
    FAPI_UINT8                  csi_rs_res_cfg;     // Indicates reference signal configuration for CSI-RS. See [11] table 6.10.5.2-1 and 6.10.5.2-2. Value  : 0 ? 31
} FAPI_T_CSI_RS_NZP_CFG;

// Table 4-21 : DLSCH PDU Release 8 parameters, part A
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_R8_A
{
    FAPI_UINT16                 length;         // The length (in bytes) of the associated MAC PDU, delivered in TX.request.
                                                // This should be the actual length of the MAC PDU, which may not be a multiple of 32-bits.

    FAPI_UINT16                 pdu_idx;        // This is a count value which is incremented every time a BCH, MCH, PCH or DLSCH PDU is included in the DL_CONFIG.request message.
                                                // This value is repeated in TX.request and associates the control information to the data.
                                                // It is reset to 0 for every subframe
                                                // Range 0 ? 65535

    FAPI_UINT16                 rnti;           // The RNTI associated with the UE
                                                // Value: 1 ? 65535.

    FAPI_UINT8                  ra_type;        // Resource allocation type
                                                // value 0 = type 0
                                                // value 1 = type 1
                                                // value 2 = type 2 (allocated by DCI format 1A, 1B or 1D)
                                                // value 3 = type 2 (allocated by DCI format 1C)
                                                // value 4 = type 2 (allocated by DCI format 6-1A)
                                                // value 5 = type UEModeB (allocated by DCI format 6-1B)

    FAPI_UINT8                  vir_rb_flag;    // Type of virtual resource block used.
                                                // This should match the value sent in the DCI Format 1A, 1B, 1D PDU which allocated this grant.
                                                // value 0 = localized
                                                // value 1 = distributed

    FAPI_UINT32                 rb_coding;      // The encoding for the resource blocks.
                                                // It's coding is dependent on whether resource allocation type 0, 1, 2 is in use.
                                                // This should match the value sent in the DCI Format PDU which allocated this grant.

    FAPI_UINT8                  modulation;     // value 2: QPSK
                                                // value 4: 16QAM
                                                // value 6: 64QAM
                                                // value 8: 256QAM

    FAPI_UINT8                  rv;             // HARQ redundancy version.
                                                // This should match the value sent in the DCI Format PDU which allocated this grant.
                                                // Value: 0 ? 3.

    FAPI_UINT8                  tb;             // The transport block transmitted to this RNTI.
                                                // A value of 2 indicates this is the second transport block for DCI format 2, 2A, 2B or 2C. For other DCI values this field will always be 1.
                                                // Value: 1 ? 2

    FAPI_UINT8                  tb_2_code_swap; // Indicates the mapping of transport block to codewords.
                                                // This should match the value sent in the DCI Format 2, 2A PDU which allocated this grant.
                                                // value 0 = no swapping
                                                // value 1 = swapped

    FAPI_UINT8                  trans_scheme;   // The MIMO mode used in the PDU
                                                // value 0: SINGLE_ANTENNA_PORT_0,
                                                // value 1: TX_DIVERSITY,
                                                // value 2: LARGE_DELAY_CDD,
                                                // value 3: CLOSED_LOOP_SPATIAL_MULTIPLEXING,
                                                // value 4: MULTI_USER_MIMO,
                                                // value 5: CLOSED_LOOP_RANK_1_PRECODING,
                                                // value 6: SINGLE_ANTENNA_PORT_5.
                                                // value 7: SINGLE_ANTENNA_PORT_7, added in Release 9
                                                // value 8: SINGLE_ANTENNA_PORT_8, added in Release 9
                                                // value 9: DUAL_LAYER_TX_PORT_7_AND_8, added in Release 9
                                                // value 10: UP_TO_8_LAYER_TX, added in Release 10

    FAPI_UINT8                  n_layers;       // The number of layers used in transmission
                                                // Value: 1 ? 8

    FAPI_UINT8                  n_subbands;     // Only valid when transmission scheme = 3, 4, 5.
                                                // Defines the number of subbands and codebooks used for PMI.
                                                // If value=1 then a single PMI value is supplied which should be used over all RB
                                                // Value 0 -> 13

    FAPI_UINT8                  codebook_idx[]; // Per n_subbands, Only valid when transmission scheme = 3, 4, 5.
                                                // Defines the codebook used.
} FAPI_T_DLSCH_PDU_R8_A;

// Table 4-21 : DLSCH PDU Release 8 parameters, part B
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_R8_B
{
    FAPI_UINT8                  ue_cat_cap;         // The UE capabilities category
                                                    // Value:1 ? 14

    FAPI_UINT8                  pa;                 // The ratio of PDSCH EPRE to cell-specific RS EPRE among PDSCH REs in all the OFDM symbols not containing cell-specific RS in dB.
                                                    // value 0: -6dB
                                                    // value 1: -4.77dB
                                                    // value 2: -3dB
                                                    // value 3: -1.77dB
                                                    // value 4: 0dB
                                                    // value 5: 1dB
                                                    // value 6: 2dB
                                                    // value 7: 3dB

    FAPI_UINT8                  del_pwr_off_idx;    // Delta power offset, value: 0..1,

    FAPI_UINT8                  n_gap;              // Used in virtual resource block distribution
                                                    // 0 = NGAP1
                                                    // 1 = NGAP2

    FAPI_UINT8                  n_prb;              // Used with DCI format 1A and RNTI=SI-RNTI or RA-RNTI.
                                                    // This should match the value sent in the TPC field of the DCI 1A PDU which allocated this grant.
                                                    // value 0: NPRB = 2
                                                    // value 1: NPRB = 3

    FAPI_UINT8                  trans_mode;         // The transmission mode associated with the UE
                                                    // value 1: Mode 1
                                                    // value 2: Mode 2
                                                    // value 3: Mode 3
                                                    // value 4: Mode 4
                                                    // value 5: Mode 5
                                                    // value 6: Mode 6
                                                    // value 7: Mode 7
                                                    // value 8: Mode 8
                                                    // value 9: Mode 9
                                                    // value 10: Mode 10

    FAPI_UINT8                  n_bf_prb;           // Number of PRBs that are treated as one subband

    FAPI_UINT8                  n_bf_vector;        // Number of beam forming vectors. One beam forming vector is specified for each subband

    FAPI_T_BF_VECTOR_TYPE       bf_vector[];        // Beam forming vectors
} FAPI_T_DLSCH_PDU_R8_B;

typedef struct PACK_STRUCT FAPI_T_DLSCH_PDU_R8_B_FAPI_VER_1_1_0 {
    FAPI_UINT8                  ue_cat_cap;         // The UE capabilities category
                                                    // Value:1 ? 5

    FAPI_UINT8                  pa;                 // The ratio of PDSCH EPRE to cell-specific RS EPRE among PDSCH REs in all the OFDM symbols not containing cell-specific RS in dB.
                                                    // value 0: -6dB
                                                    // value 1: -4.77dB
                                                    // value 2: -3dB
                                                    // value 3: -1.77dB
                                                    // value 4: 0dB
                                                    // value 5: 1dB
                                                    // value 6: 2dB
                                                    // value 7: 3dB

    FAPI_UINT8                  del_pwr_off_idx;    // Delta power offset, value: 0..1

    FAPI_UINT8                  n_gap;              // Used in virtual resource block distribution
                                                    // 0 = NGAP1
                                                    // 1 = NFAP2

    FAPI_UINT8                  n_prb;              // Used with DCI format 1A and RNTI=SI-RNTI or RA-RNTI.
                                                    // This should match the value sent in the TPC field of the DCI 1A PDU which allocated this grant.
                                                    // value 0: NPRB = 2
                                                    // value 1: NPRB = 3

    FAPI_UINT8                  n_bf_prb;           // Number of PRBs that are treated as one subband

    FAPI_UINT8                  n_bf_vector;        // Number of beam forming vectors. One beam forming vector is specified for each subband

    FAPI_T_BF_VECTOR_TYPE       bf_vector[];        // Beam forming vectors
} FAPI_T_DLSCH_PDU_R8_B_FAPI_VER_1_1_0;

// Table 4-23 : DLSCH PDU Release 9 parameters
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_R9
{
    FAPI_UINT8                  nscid;              // Used with DCI format 2B and 2C.
                                                    // value 0: NSCID=0
                                                    // value 1: NSCID=1
} FAPI_T_DLSCH_PDU_R9;

// Table 4-24 : DLSCH PDU Release 10 parameters, part A
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_R10_A
{
    FAPI_UINT8                  csi_rs_flag;            // Indicates if parameters related to CSI-RS are valid or not.
                                                        // CSI-RS is valid only for transmission mode 9.
                                                        // value 0: CSI-RS parameters are not valid
                                                        // value 1: CSI-RS parameters are valid

    FAPI_UINT8                  csi_res_conf_r10;       // This value is deprecated

    FAPI_UINT16                 csi_rs_cnf_bmap_r10;    // Bitmap of 16 bits. Encoding format of bitmap follows section 6.10.5.2 of 36.211

    FAPI_UINT8                  csi_rs_num_nzp_cfg;     // Indicates the number of Non-Zero power CSI-RS configurations.
                                                        // value 0 ? 1: for release 10
                                                        // value 0 ? 3: for release 11

    FAPI_T_CSI_RS_NZP_CFG       csi_rs_nzp_cfg[];       // For each CSI-RS configuration, CSI-RS resource config.
} FAPI_T_DLSCH_PDU_R10_A;

// Table 4-24 : DLSCH PDU Release 10 parameters, part B
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_R10_B
{
    FAPI_UINT8                  pdsch_start;            // Per UE starting OFDM symbol for the PDSCH, impacts the mapping of PDSCH to REs
                                                        // value 0: field is ignored and PDSCH starts according to the CFI
                                                        // value 1-4 (4 only in 1.4 MHz BW): value overriding the CFI
} FAPI_T_DLSCH_PDU_R10_B;

// Table 4-25 : DLSCH PDU Release 11 parameters
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_R11
{
    FAPI_UINT8                  dmrs_config_flag;           // Indicates if the DMRS Config parameter is valid.
                                                            // 0 = not used, 1= enabled

    FAPI_UINT16                 dmrs_scrambling;            // The scrambling identity for UE specific reference signals.
                                                            // Value: 0 ? 503

    FAPI_UINT8                  csi_config_flag;            // Indicates if the CSI Config parameter is valid.
                                                            // 0 = not used, 1= enabled

    FAPI_UINT16                 csi_scrambling;             // The scrambling identity for CSI.
                                                            // Value: 0 ? 503

    FAPI_UINT8                  pdsch_re_map_flag;          // Indicates if the PDSCH RE parameters are valid.
                                                            // 0 = not used, 1= enabled

    FAPI_UINT8                  pdsch_re_map_ant_ports;     // Indicates number of antennas used for PDSCH RE mapping.
                                                            // Value: 1, 2, 4

    FAPI_UINT8                  pdsch_re_map_freq_shift;    // Indicates the frequency shift used for PDSCH RE mapping.
                                                            // Value: 0 ? 5
} FAPI_T_DLSCH_PDU_R11;

// Table 4-26 : DLSCH PDU Release 12 parameters
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_R12
{
    FAPI_UINT8                  altCQI_table_r12;           // altCQI-Table-r12 is indicative of using an alternative MCS table for UEs supporting 256QAM.
                                                            // This is taken into account for calculation of soft buffer size for the transport block
                                                            // Value: 0-1

    FAPI_UINT8                  max_layers;                 // Maximal number of negotiated / configured layers for a UE,
                                                            // used for the calculation of soft buffer size for the transport block
                                                            // Value: 1-8

    FAPI_UINT8                  n_dl_harq;                  // M(DL_HARQ) in section 5.1.4.1.1 in 36.212
} FAPI_T_DLSCH_PDU_R12;

// Table 4-27 : DLSCH PDU Release 13 parameters
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_R13
{
    FAPI_UINT8                  DwPTS_symbols;              // Valid if DCI format 1C is being used to signal LAA end partial SF.
                                                            // Indicates the number of starting symbols according to 36.213 Table  13-A-1.
                                                            // Values: 3, 6, 9, 10, 11, 12, 14

    FAPI_UINT8                  init_lbt_sf;                // Indicates if DLSCH is prepared for full SF (regular) or for initial partial SF (2nd slot) according to 36.211 Section 6.4.
                                                            // value 0 = prepared for the case of a regular SF (higher layer parameter �� subframeStartPosition��=��s0��)
                                                            // value 1 = prepared for the case of a partial SF (higher layer parameter �� subframeStartPosition��=��s07��)
                                                            // Valid for initial partial SF in LAA

    FAPI_UINT8                  ue_type;                    // value 0: non LC/CE UE
                                                            // value 1: LC/CE CEModeA UE
                                                            // value 2: LC/CE CEModeB UE

    FAPI_UINT8                  payload_type;               // value 0: PDSCH carrying SIB1-BR
                                                            // value 1: PDSCH carrying SI message (except for SIB1-BR or PCH)
                                                            // value 2: PDSCH carrying other.
                                                            // Valid if UE Type is 1 or 2

    FAPI_UINT16                 initial_transmission_sf;    // Absolute Sub-Frame  of the initial transmission.
                                                            // Value: 0 ? 10239. Value: 0xFFFF current absolute SF.
                                                            // Valid if UE Type is 1 or 2
    FAPI_UINT8                  r13_dmrs_table_flag;            // Indicates if Release 13 DMRS table for be used.
                                                                // 0 = not used
                                                                // 1 = used
} FAPI_T_DLSCH_PDU_R13;

// Table 4-20 : DLSCH PDU part A
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_A {
    FAPI_T_DLSCH_PDU_R8_A       rel8_A;         // Release 8 attributes, part A
} FAPI_T_DLSCH_PDU_A;

// Table 4-20 : DLSCH PDU part B
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_B {
    FAPI_T_DLSCH_PDU_R8_B       rel8_B;         // Release 8 attributes, part B
} FAPI_T_DLSCH_PDU_B;

// Table 4-20 : DLSCH PDU part C
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_C {
    FAPI_T_DLSCH_PDU_R9         rel9;           // Release 9 attributes
    FAPI_T_DLSCH_PDU_R10_A      rel10_A;        // Release 10 attributes, part A
} FAPI_T_DLSCH_PDU_C;

// Table 4-20 : DLSCH PDU part D
typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_D {
    FAPI_T_DLSCH_PDU_R10_B      rel10_B;        // Release 10 attributes, part B
    FAPI_T_DLSCH_PDU_R11        rel11;          // Release 11 attributes
    FAPI_T_DLSCH_PDU_R12        rel12;          // Release 12 attributes
    FAPI_T_DLSCH_PDU_R13        rel13;          // Release 13 attributes
} FAPI_T_DLSCH_PDU_D;

typedef struct PACK_STRUCT FAPI_S_DLSCH_PDU_B_REL_8 {
    FAPI_UINT8                  ue_cat_cap;         //The UE capabilities category. Value: 1...5
    FAPI_UINT8                  pa;             //The ratio of PDSCH EPRE to cell-specific RS EPRE among PDSCH REs in all the OFDM symbols not containing cell-specific RS in dB.
    FAPI_UINT8                  del_pwr_off_idx;    //Delta power offset, value: 0..1
    FAPI_UINT8                  n_gap;          //Used in virtual resource block distribution. Valid for DCI formats: 1A,1B,1C,1D. Value 0=n_gap1, 1=n_gap2.
    FAPI_UINT8                  n_prb;          //Used with DCI format 1A and RNTI=SI-RNTI or RA-RNTI. This should match the value sent in the TPC field of the DCI 1A PDU which allocated this grant.Value: 0: NPRB = 2,  1: NPRB = 3
} FAPI_T_DLSCH_PDU_B_REL_8;

#define FAPI_INVALID_DATA_START_R10 (0xFF)

// Table 4-34 : CSI-RS PDU Release 10
typedef struct PACK_STRUCT FAPI_S_CSI_RS_PDU_R10 {
    FAPI_UINT8                  ant_port_cnt;           // Indicates number of antennas used for transmission of CSI reference signal.
                                                        // Value: 1, 2, 4, 8

    FAPI_UINT8                  res_cfg ;               // This value is deprecated

    FAPI_UINT16                 tp;                     // Offset to the reference signal power.
                                                        // Value: 0 ? 10000, representing -6 dB to 4 dB in 0.001 dB steps.

    FAPI_UINT16                 zr_tx_pw_res_cfg_bmp;   // Bitmap of 16 bits. Encoding format of bitmap follows section 6.10.5.2 of 36.211

    FAPI_UINT8                  num_nzp_cfg;            // Indicates the number of Non-Zero power CSI-RS configurations.
                                                        // Value: 0 ? 1 for release 10
                                                        // Value: 0 ? 3 for release 11

    FAPI_T_CSI_RS_NZP_CFG       nzp_cfg[];
} FAPI_T_CSI_RS_PDU_R10;

// Table 4-33 : CSI-RS PDU
typedef struct PACK_STRUCT FAPI_S_CSI_RS_PDU {
    FAPI_T_CSI_RS_PDU_R10       rel10;
} FAPI_T_CSI_RS_PDU;

// Table 4-32 : PRS PDU Release 9 parameters
typedef struct PACK_STRUCT FAPI_S_PRS_PDU_R9 {
    FAPI_UINT16                 tp;                 //  Offset to the reference signal power.  Value: 0 ? 10000, representing -6 dB to 4 dB in 0.001 dB steps.
    FAPI_UINT8                  prs_bw;             // PRS bandwidth in resource blocks. Value: 6,15,25,50,75,100.
    FAPI_UINT8                  prs_cp;             // The cyclic prefix used for PRS transmission. Value: 0 = Normal cyclic prefix, 1 = extended cyclic prefix.
    FAPI_UINT8                  prs_muting;         // PRS muting dictates if PRS REs are vacant (prsMutingInfo-r9 indicates the SF occasions).Value: 0 = no muting (PRS REs contain PRS with Transmission power), 1 = muting (PRS REs with no signal)
}FAPI_T_PRS_PDU_R9;

// Table 4-31 : PRS PDU
typedef struct PACK_STRUCT FAPI_S_PRS_PDU {
    FAPI_T_PRS_PDU_R9           rel9;
}FAPI_T_PRS_PDU;

// Table 4-7 and 4-8 : DL config request message and body
typedef struct PACK_STRUCT FAPI_S_DL_CONFIG_REQ {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                 length;             //The length of the downlink subframe configuration. Range 0...65535
    FAPI_UINT8                  n_pdcch_symb;       //The number of OFDM symbols for the PDCCH. Range 0...4
    FAPI_UINT8                  n_dci;              //The number of DCI PDUs included in this message. Range 0...255
    FAPI_UINT16                 n_pdu;              //Number of PDUs that are included in this message. Range 0...514
    FAPI_UINT8                  n_pdsch_rnti;       //Number of unique RNTIs sent on the PDSCH.
                                                    //- a PCH PDU will have an unique RNTI and should be included in this value
                                                    //- a DLSCH PDU can be one transport block sent to a UE with an unique RNTI. This RNTI should be included in this value
                                                    //- a DLSCH PDU can be one of two transport blocks sent to a UE.
                                                    //  In this case the two DLSCH PDUs will share the same RNTI. Only one RNTI should be included in this value.
    FAPI_UINT16                 trans_power_pcfich; //Offset to the reference signal power. Value: 0...10000, representing -6 dB to 4 dB in 0.001 dB steps.
    FAPI_T_PDU                  dl_pdu[];
} FAPI_T_DL_CONFIG_REQ;

typedef struct PACK_STRUCT FAPI_S_CSI_RS_RES_CFG_R11 {
    FAPI_UINT8                  res_cfg_r11;
} FAPI_T_CSI_RS_RES_CFG_R11;

typedef struct PACK_STRUCT FAPI_S_CSI_RS_R11 {
    FAPI_UINT8                  num_res_cfg_r11;        //Indicates number of CSI-RS configurations. Values: 0...2
    FAPI_T_CSI_RS_RES_CFG_R11   res_cfg_r11[];          // Release 11 CSI_RS configurations
} FAPI_T_CSI_RS_R11;

typedef struct PACK_STRUCT FAPI_S_EPDCCH_PRB_IDX{
    FAPI_UINT8                  prb_idx;            //PRB index. Value: 0 ? 99.
} FAPI_T_EPDCCH_PRB_IDX;

typedef struct PACK_STRUCT FAPI_S_EPDCCH_DL_DCI_R11_A{
    FAPI_UINT8                  res_assign_flag;    //Type of virtual resource block used. Value: 0 = localized, 1 = distributed
    FAPI_UINT16                 epdcch_id;          //EPDCCH index- used for the scrambler initiation. The DMRS scrambling sequence initialization parameter   defined in [11] section 6.10.3A.1. Value: 0 ? 503
    FAPI_UINT8                  start_symb;         //Indicates the OFDM starting symbol for any EPDCCH and PDSCH. Values: 1 ? 4.
    FAPI_UINT8                  num_prb;            //Number of PRBs allocated for EPDCCH. Value: 2, 4, 8.
    FAPI_T_EPDCCH_PRB_IDX       prb_idx[];
} FAPI_T_EPDCCH_DL_DCI_R11_A;

typedef struct PACK_STRUCT FAPI_S_EPDCCH_DL_DCI_R11_B{
    FAPI_T_BEAM_FORMING_INFO    bf_vector;
} FAPI_T_EPDCCH_DL_DCI_R11_B;

typedef struct PACK_STRUCT FAPI_S_EPDCCH_DL_DCI_R13{
    FAPI_UINT8                  DwPTS_symbols;      // Valid if DCI format 1C is being used to signal LAA end partial SF. Indicates the number of starting symbols according to [9] table 13-A-1. Values: 3, 6, 9, 10, 11, 12, 14
    FAPI_UINT8                  init_lbt_sf;        // Indicates if DLSCH is prepared for full SF (regular) or for initial partial SF (2nd slot) according to [11] section 6.8A.Value: 0 = prepared for the case of a regular SF (higher layer parameter �� subframeStartPosition��=��s0��), 1 = prepared for the case of a partial SF (higher layer parameter �� subframeStartPosition��=��s07��). Valid for initial partial SF in LAA
} FAPI_T_EPDCCH_DL_DCI_R13;

typedef struct PACK_STRUCT FAPI_S_EPDCCH_DL_DCI_A {
    FAPI_T_EPDCCH_DL_DCI_R11_A  rel11_a;            // Release 11 attributes (a)
} FAPI_T_EPDCCH_DL_DCI_A;

typedef struct PACK_STRUCT FAPI_S_EPDCCH_DL_DCI_B {
    FAPI_T_EPDCCH_DL_DCI_R11_A  rel11_b;            // Release 11 attributes (b)
} FAPI_T_EPDCCH_DL_DCI_B;

typedef struct PACK_STRUCT FAPI_S_EPDCCH_DL_DCI_C {
    FAPI_T_EPDCCH_DL_DCI_R13    rel13;              // Release 13 attributes
} FAPI_T_EPDCCH_DL_DCI_C;

typedef struct PACK_STRUCT FAPI_S_MPDCCH_DL_PDU {
    FAPI_UINT8                  mpdcch_narrowband;              //Narrowband index 0..15
    FAPI_UINT8                  n_rbs_per_set;                          //num of PRB pairs: 2/4/6
    FAPI_UINT8                  resource_block_assignment;      //Combinational index r as defined in 36.213 section 9.1.4.4. values: 0-14
    FAPI_UINT8                  transmission_type;              //0 - localized; 1 -distributes
    FAPI_UINT8                  start_symbol;                   //Values:1-4
    FAPI_UINT8                  ecce_index;                     //ECCE index used to send the DCI values: 0-22
    FAPI_UINT8                  aggregation_level;              //aggregation level: 2/4/8/16/24
    FAPI_UINT8                  rnti_type;                      //0-temporary C-RNTI; 2 - RA-RNTI; 3 - P_RNTI; 4 - other
    FAPI_UINT16                 rnti;                           //The RNTI used for identifying the UE.
    FAPI_UINT8                  ce_mode;                        //0 - legacy; 1 - mode A ; 2 - mode B
    FAPI_UINT16                 dmrs_scrambling_init;           //The DMRS scrambling sequnce initialization as defined in 36.211 section 6.10.3A.1
    FAPI_UINT16                 initial_transmission_sf;        //Values:0-10239
    FAPI_UINT16                 transmission_power;             //Offset to the reference signal power
    FAPI_UINT8                  dci_format;                     //Format of the DCI. 0 = 6-1A; 1 = 6-1B; 2 = 6-2;
    FAPI_UINT16                 resource_block_coding;          //Encoding for the resource block
    FAPI_UINT8                  mcs;                            //Modulation and coding scheme
    FAPI_UINT8                  repetition_number;              //repetition number
    FAPI_UINT8                  rv;                             //Redundency version
    FAPI_UINT8                  ndi;                            //New daya indicator
    FAPI_UINT8                  harq_process;                   //HARQ process number- valid for DCI formats:6-1A, 6-1B
    FAPI_UINT8                  tpmi_length;                    //Length of TPMI field in units of bits
    FAPI_UINT8                  tpmi;                           //codebook index
    FAPI_UINT8                  pmi_flag;                       //indicates if PMI field is present
    FAPI_UINT8                  pmi;                            //confirmation for precoding
    FAPI_UINT8                  harq_resource_offset;           //HARQ-ACK resource offset
    FAPI_UINT8                  dci_subframe_repetition_number; //indicates the number of MPDCCH repetitions
    FAPI_UINT8                  tpc;                            //TX power control command for PUCCH
    FAPI_UINT8                  dai_length;                     //downlink assignment index length - 0/2/4
    FAPI_UINT8                  dai;                            //downlink assignment index
    FAPI_UINT8                  allocate_prach_flag;            //indicates that PRACH procedure is initiated
    FAPI_UINT8                  preamble_index;                 //Preamble index to be used on the PRACH
    FAPI_UINT8                  prach_mask_index;               //the mask index to be used on the PRACH
    FAPI_UINT8                  starting_ce_level;              //PRACH starting CE level
    FAPI_UINT8                  srs_request;                    //SRS request flag
    FAPI_UINT8                  antenna_port_and_scrambling_identity_flag;//Indicated the antenna port and scrambling identity exists
    FAPI_UINT8                  antenna_port_and_scrambling_identity;//Indicated the antenna port and scrambling identity value
    FAPI_UINT8                  freq_hopping_enabled;           //Indicated if hoppong is being is used
    FAPI_UINT8                  paging_or_direct_indication_flag;   //valid for DCI format 6-2
    FAPI_UINT8                  direct_indication_data;         //valid for DCI format 6-2
    FAPI_UINT8                  dci_length;                     //The total DCI length including padding bits
    FAPI_UINT8                  n_tx_antenna_ports;             //number of TX physical antenna ports
    FAPI_UINT16                 precoding_value[];              //Precoding element for physical antenna #i 8 bits - real ; followed by imaginarry 8 bits
} FAPI_T_MPDCCH_DL_PDU;

//Downlink data
typedef struct PACK_STRUCT FAPI_S_TLV {
    FAPI_UINT16                 tag;                //Range 0...1. 0: Payload is carried directly in the value field, 1: Pointer to payload is in the value field
    FAPI_UINT16                 length;             //Length of the actual payload in bytes, without the padding bytes
    FAPI_UINT32                 *value;             //Always a multiple of 32-bits. Tag=0: Only the most significant bytes of the size indicated by length field are valid. Remaining bytes are zero padded to the nearest 32-bit boundary. Tag=1: Pointer to the payload. Occupies 32-bits
} FAPI_T_TLV;

typedef struct PACK_STRUCT FAPI_S_TX_REQ_PDU{
    FAPI_UINT16                 pdu_length;         //The total length (in bytes) of the PDU description and PDU data, without the padding bytes.
    FAPI_UINT16                 pdu_idx;            //This is a count value which starts from 0. It is incremented for each BCH, MCH, PCH or DLSCH PDU. This value was included in TX.request and associates the data to the control information. It is reset to 0 for every subframe. Range 0...65535
    FAPI_UINT32                 n_tlv;              //The number of TLVs describing the data of the transport block.
    FAPI_T_TLV                  tlv[];              //Always a multiple of 32-bits.
 } FAPI_T_TX_REQ_PDU;

typedef struct PACK_STRUCT FAPI_S_TX_REQ{
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023
    FAPI_UINT16                 n_pdu;              //Number of PDUs that are included in this message.
    FAPI_T_TX_REQ_PDU           pdu[];
 } FAPI_T_TX_REQ;

// Table 4-44 : ULSCH PDU Release 8 parameters
typedef struct PACK_STRUCT FAPI_S_ULSCH_PDU_R8 {
    FAPI_UINT32                 handle;             // An opaque handling returned in the RX.indication

    FAPI_UINT16                 size;               // The size of the ULSCH PDU in bytes as defined by the relevant UL grant.
                                                    // The size can be 0 if UCI over ULSCH without data is configured.
                                                    // The size of CQI/RI/HARQ are not added to this element.

    FAPI_UINT16                 rnti;               // The RNTI used for identifying the UE when receiving the PDU.
                                                    // Value: 1...65535

    FAPI_UINT8                  rb_start;           // The starting resource block for this ULSCH allocation.
                                                    // This should match the value sent in the DCI Format 0 PDU which allocated this grant.
                                                    // Value: 0...99

    FAPI_UINT8                  n_rb;               // The number of resource blocks allocated to this ULSCH grant.
                                                    // This should match the value sent in the DCI Format 0 PDU which allocated this grant.
                                                    // Value: 1...100

    FAPI_UINT8                  mod_type;           // value 2: QPSK
                                                    // value 4: 16QAM
                                                    // value 6: 64QAM

    FAPI_UINT8                  cyc_shift_2_dmrs;   // The 2nd cyclic shift for DMRS assigned to the UE in the ULSCH grant.
                                                    // This should match the value sent in the DCI Format 0 PDU which allocated this grant.
                                                    // Value: 0...7

    FAPI_UINT8                  freq_hop_enable;    // Indicates if hopping is being used.
                                                    // This should match the value sent in the DCI Format 0 PDU which allocated this grant.
                                                    // value 0: no hopping
                                                    // value 1: hopping enabled

    FAPI_UINT8                  freq_hop_bits;      // The frequency hopping bits.
                                                    // This should match the value sent in the DCI Format 0 PDU which allocated this grant.
                                                    // Value: 0...3

    FAPI_UINT8                  ndi;                // Specify whether this received PUSCH is a new transmission from UE.
                                                    // This should match the value sent in the DCI Format 0 PDU which allocated this grant

    FAPI_UINT8                  rv;                 // Redundancy version.
                                                    // Value: 0...3

    FAPI_UINT8                  harq_proc_num;      // HARQ Process number.
                                                    // TDD: 0...13
                                                    // FDD: 0...15

    FAPI_UINT8                  ul_tx_mode;         // value 0: SISO/SIMO
                                                    // value 1: MIMO

    FAPI_UINT8                  curr_tx_nb;         // The current HARQ transmission count of this transport block.
                                                    // Valid if frequency hopping enabled.

    FAPI_UINT8                  n_srs;              // Indicates if the resource blocks allocated for this grant overlap with the SRS configuration.
                                                    // value 0: no overlap
                                                    // value 1: overlap
} FAPI_T_ULSCH_PDU_R8;

// Table 4-45 : ULSCH PDU Release 10 parameters
typedef struct PACK_STRUCT FAPI_S_ULSCH_PDU_R10 {
    FAPI_UINT8                  ra_type;                //Resource allocation type
                                                        // value 0: type 0
                                                        // value 1: type 1

    FAPI_UINT32                 rb_coding;              // Used for Resource Allocation type 1  The encoding for the resource blocks when resource allocation type is selected.
                                                        // This should match the value sent in the DCI Format PDU which allocated this grant.

    FAPI_UINT8                  tb_blocks;              // The transport block transmitted from this RNTI.
                                                        // Added in Release 10
                                                        // A value of 2 indicates this is the second transport block for DCI format 4.
                                                        // For other DCI values this field will always be 1.
                                                        // Value: 1 -> 2

    FAPI_UINT8                  transmission_scheme;    //The MIMO mode used in the PDU See [6] section 8.0.
                                                        // value 0: SINGLE_ANTENNA_PORT_10
                                                        // value 1: CLOSED_LOOP_SPATIAL_MULTIPLEXING
                                                        // added in Release 10

    FAPI_UINT8                  num_layers;             // The number of layers used in transmission
                                                        // Value: 1 -> 4

    FAPI_UINT8                  codebook_index ;        // The codebook used for precoding  Only valid when transmission scheme = 1
                                                        // Defines the codebook used. When antenna port = 1: NA When antenna port = 2: 0..5     When antenna port = 4: 0..23

    FAPI_UINT8                  disable_seq_hop_flag;   // Indicates if any configured group hopping should be disabled for this UE.
                                                        // value 0: Any configured sequence hopping not disabled
                                                        // value 1: Any configured sequence hopping disabled
} FAPI_T_ULSCH_PDU_R10;

// Table 4-46 : ULSCH PDU Release 11 parameters
typedef struct PACK_STRUCT FAPI_S_ULSCH_PDU_R11 {
    FAPI_UINT8                  virt_cell_id_en_flag;   // Indicates if virtual cell is being used and nPUSCH identity is valid.
                                                        // Value: 0 = not used, 1= enabled

    FAPI_UINT16                 nPusch_identity;        // Virtual cell ID for initialization of group hopping, sequence hopping and sequence shift pattern of PUSCH DMRS.
                                                        // Valid if virtual cell ID is enabled.
                                                        // Value: 0 ? 509

    FAPI_UINT8                  dmrs_config_flag;       // Indicates if the PUSC DMRS config is valid.
                                                        // value 0: not used
                                                        // value 1: enabled

    FAPI_UINT16                 nDmrs_csh_identity;     // Virtual cell ID for initialization of cyclic shift hopping of PUSCH DMRS.
                                                        // Valid if DMRS Config flag is enabled.
                                                        // Value: 0 ? 509
} FAPI_T_ULSCH_PDU_R11;

// Table 4-47 : ULSCH PDU Release 13 parameters
typedef struct PACK_STRUCT FAPI_S_ULSCH_PDU_R13 {
    FAPI_UINT8                  ue_type;                    // value 0: non LC/CE user
                                                            // value 1: LC/CE mode A
                                                            // value 2: LC/CE mode B

    FAPI_UINT16                 total_num_of_repetition;    // value 1-2048
                                                            // value 1: single allocation; overall expeted repetition

    FAPI_UINT16                 repetition_number;          // value 1-2048
                                                            // value 1: single allocation; current transmission number

    FAPI_UINT16                 initial_transmission_sf;    // value 0-10239 (absolute sf) - in case of currect sf = 0xffff

    FAPI_UINT8                  empty_symbols_for_retuning; // Indicates the symbols that are left empty due to retuning
} FAPI_T_ULSCH_PDU_R13;

// Table 4-43 : ULSCH PDU
typedef struct PACK_STRUCT FAPI_S_ULSCH_PDU {
    FAPI_T_ULSCH_PDU_R8     rel8;
 #ifndef NXP_PLATFORM
    FAPI_T_ULSCH_PDU_R10    rel10;
    FAPI_T_ULSCH_PDU_R11    rel11;
    FAPI_T_ULSCH_PDU_R13    rel13;
 #endif
} FAPI_T_ULSCH_PDU;

typedef struct PACK_STRUCT FAPI_S_PMI_RI_PR_RPT{
    FAPI_UINT8    dl_cqi_pmi_ri_size;   //The size of the DL CQI/PMI/RI in bits.    Value: 0 ? 255
    FAPI_UINT8    control_type;         // value 0: CQI/PMI
                                        // value 1: RI

    FAPI_UINT16 dl_cqi_pmi_size_2;
}FAPI_T_PMI_RI_PR_RPT;

typedef struct PACK_STRUCT  FAPI_S_RI_DL_PMI_RI_CC_RPT {
     FAPI_UINT8 ri_size;                           // The size of RI in bits   Value:1 ? 3
     FAPI_UINT8 dl_cqi_pmi_size[];                 //  The size of the DL CQI/PMI in bits in case of this RI value. Value: 0 ? 255
}FAPI_T_RI_DL_PMI_RI_CC_RPT;

typedef struct PACK_STRUCT FAPI_S_PMI_RI_APR_RPT{
    FAPI_UINT8    num_cc;                          // The number of CC in the aperiodic report  Value: 1 ? 5
    FAPI_T_RI_DL_PMI_RI_CC_RPT cc_rpt[]; //ri size and dl_cqi_pmi_size per CC

}FAPI_T_PMI_RI_APR_RPT;

typedef struct PACK_STRUCT FAPI_S_ULSCH_CQI_RI_INFO {
    FAPI_UINT8              rpt_type;            // Type of CSI report  0 = periodic report 1 = aperiodic report
    FAPI_UINT8              delta_off_cqi;       //Delta offset for CQI. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...15
    FAPI_UINT8              delta_off_ri;        //Delta offset for RI. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...15
    FAPI_UINT8              pmi_ri_rpt[];        // periodic report  and aperiodic reports are defined for release r9 ,10
} FAPI_T_ULSCH_CQI_RI_INFO;

typedef struct PACK_STRUCT FAPI_S_ULSCH_CQI_RI_INFO_R8 {
    FAPI_UINT8              dl_cqi_pmi_size_rank1;  //The size of the DL CQI/PMI in bits in case of rank 1 report. Value: 0...255
    FAPI_UINT8              dl_cqi_pmi_size_rank_g1;//The size of the DL CQI/PMI in bits in case of rank>1 report. Value: 0...255, In case of periodic report rank=1 and rank>1 size should be the same
    FAPI_UINT8              ri_size;                //The size of RI in bits. Value: 1...2,  0 in case of periodic report
    FAPI_UINT8              delta_off_cqi;          //Delta offset for CQI. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...15
    FAPI_UINT8              delta_off_ri;           //Delta offset for RI. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...15
} FAPI_T_ULSCH_CQI_RI_INFO_R8;

typedef struct PACK_STRUCT FAPI_S_ULSCH_HARQ_INFO_R10 {
    FAPI_UINT8                  harq_size;          //The size of the ACK/NACK in bits. Value: 1...2
    FAPI_UINT8                  delta_off_harq;     //Delta offset for HARQ. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...15
#ifdef NXP_PLATFORM
    FAPI_UINT8                  NBundle:7;  // extended by AC for bundling
    FAPI_UINT8                  ack_nack_mode:1;  
#else
    FAPI_UINT8                  ack_nack_mode;      //The format of the ACK/NACK response expected. For TDD only. 0 = BUNDLING, 1 = MULTIPLEXING
#endif
} FAPI_T_ULSCH_HARQ_INFO_R10;

typedef struct PACK_STRUCT FAPI_S_ULSCH_HARQ_INFO_R13 {
    FAPI_UINT16                 harq_size_2;
    FAPI_UINT8                  delta_offset_harq_2;
} FAPI_T_ULSCH_HARQ_INFO_R13;


typedef struct PACK_STRUCT FAPI_S_ULSCH_HARQ_INFO {
    FAPI_T_ULSCH_HARQ_INFO_R10  rel10;
 #ifndef NXP_PLATFORM
    FAPI_T_ULSCH_HARQ_INFO_R13  rel13;
 #endif
} FAPI_T_ULSCH_HARQ_INFO;

typedef struct PACK_STRUCT FAPI_S_ULSCH_INIT_TRANS_PARAM {
    FAPI_UINT8                  n_srs_init;         //0 = last OFDM symbol is not punctured, 1 = last OFDM symbol is punctured.
    FAPI_UINT8                  n_rb_init;          //The number of resource blocks used in the initial transmission of this transport block. Value: 1...100
} FAPI_T_ULSCH_INIT_TRANS_PARAM;

// Table 4-48 : ULSCH_CQI_RI_PDU
typedef struct PACK_STRUCT FAPI_S_ULSCH_CQI_RI_PDU {
    FAPI_T_ULSCH_PDU                ulsch_pdu;
    FAPI_T_ULSCH_CQI_RI_INFO        cqi_ri_info;
    FAPI_T_ULSCH_INIT_TRANS_PARAM   init_trans_param;
} FAPI_T_ULSCH_CQI_RI_PDU;

// Table 4-48 : ULSCH_CQI_RI_PDU for REL 8
typedef struct PACK_STRUCT FAPI_S_ULSCH_CQI_RI_PDU_REL_8 {
    FAPI_T_ULSCH_PDU_R8             ulsch_pdu;
    FAPI_T_ULSCH_CQI_RI_INFO_R8     cqi_ri_info;
    FAPI_T_ULSCH_INIT_TRANS_PARAM   init_trans_param;
} FAPI_T_ULSCH_CQI_RI_PDU_REL_8;

typedef struct PACK_STRUCT FAPI_S_ULSCH_HARQ_PDU_REL_8 {
    FAPI_T_ULSCH_PDU_R8             ulsch_pdu;
    FAPI_T_ULSCH_HARQ_INFO_R10      harq_info;
    FAPI_T_ULSCH_INIT_TRANS_PARAM   init_trans_param;
} FAPI_T_ULSCH_HARQ_PDU_REL_8;


// Table 4-49 : ULSCH_HARQ_PDU
typedef struct PACK_STRUCT FAPI_S_ULSCH_HARQ_PDU {
    FAPI_T_ULSCH_PDU                ulsch_pdu;
    FAPI_T_ULSCH_HARQ_INFO          harq_info;
    FAPI_T_ULSCH_INIT_TRANS_PARAM   init_trans_param;
} FAPI_T_ULSCH_HARQ_PDU;


typedef struct PACK_STRUCT FAPI_S_ULSCH_CQI_HARQ_RI_PDU_REL_8 {
    FAPI_T_ULSCH_PDU_R8             ulsch_pdu;
    FAPI_T_ULSCH_CQI_RI_INFO_R8     cqi_ri_info;
    FAPI_T_ULSCH_HARQ_INFO_R10      harq_info;
    FAPI_T_ULSCH_INIT_TRANS_PARAM   init_trans_param;
} FAPI_T_ULSCH_CQI_HARQ_RI_PDU_REL_8;

typedef struct PACK_STRUCT FAPI_S_UCI_HARQ_INFO_R10 {
    FAPI_UINT8                  harq_size;          //The size of the ACK/NACK in bits. Value: 1 ? 10   Values greater than 2 were added in Release 10
    FAPI_UINT8                  ack_nack_mode;      //The format of the ACK/NACK response expected. 0 = Format 1a/1b    1 = Channel Selection, added in Release 10  2 = Format 3, added in Release 10
    FAPI_UINT8                  n_pucch_res;        //The number of PUCCH resources associated with the ACK/NACK response   See [6] section 10.1    Value: 1 ? 4    If the HARQ are transmitted on two antenna ports then the resource for the second antenna is in n_PUCCH_1_1
    FAPI_UINT16                 n_pucch_1_0;        //The PUCCH Index value for ACK/NACK HARQ resource 0    Value: 0 ? 2047 (ACK_NACK mode = 0 or 1)    Value: 0 ? 549 (ACK_NACK mode = 2)
    FAPI_UINT16                 n_pucch_1_1;        //HARQ resource 1   Value: 0 ? 2047 (ACK_NACK mode = 0 or 1)    Value: 0 ? 549 (ACK_NACK mode = 2)
    FAPI_UINT16                 n_pucch_1_2;        //HARQ resource 2   Value:  0 ? 2047 (ACK_NACK mode = 1)
    FAPI_UINT16                 n_pucch_1_3;        //HARQ resource 3   Value: 0 ? 2047 (ACK_NACK mode = 1)
} FAPI_T_UCI_HARQ_INFO_R10;

typedef struct PACK_STRUCT FAPI_S_UCI_HARQ_INFO_R11 {
    FAPI_UINT8                  num_ant_ports;      //The number of antenna ports used by the UE transmit. Value: 1->2. See [9] section 10.1.3.2.1 for two antenna port transmission for format 1b with channel selection, and Section 10.1.3.2.2 for two antenna port transmission for format 3.
    FAPI_UINT16                 n_pucch_2_0;        //The PUCCH Index value for ACK/NACK HARQ resource 4 on antenna port 1. Value: 0 ? 2047 (ACK_NACK mode = 2). Value: 0 ? 549 (ACK_NACK mode = 3)
    FAPI_UINT16                 n_pucch_2_1;        //HARQ resource 5. Value: 0 ? 2047 (ACK_NACK mode = 2)
    FAPI_UINT16                 n_pucch_2_2;        //HARQ resource 6. Value:  0 ? 2047 (ACK_NACK mode = 2)
    FAPI_UINT16                 n_pucch_2_3;        //HARQ resource 7. Value: 0 ? 2047 (ACK_NACK mode = 2)
} FAPI_T_UCI_HARQ_INFO_R11;

typedef struct PACK_STRUCT FAPI_S_UCI_HARQ_INFO_R13 {
    FAPI_UINT16                 harq_size_2;
    FAPI_UINT8                  starting_prb;
    FAPI_UINT8                  n_prb;
    FAPI_UINT8                  cdm_index;
    FAPI_UINT8                  n_srs;
} FAPI_T_UCI_HARQ_INFO_R13;

typedef struct PACK_STRUCT FAPI_S_UCI_HARQ_FDD_INFO_REL_8 {
    FAPI_UINT16                 pucch_idx;          //The PUCCH Index value for ACK/NACK. Value: 0...2047
    FAPI_UINT8                  harq_size;          //The size of the ACK/NACK in bits. Value: 1...2
} FAPI_T_UCI_HARQ_FDD_INFO_REL_8;

typedef struct PACK_STRUCT FAPI_S_UCI_HARQ_INFO {
 #ifdef NXP_PLATFORM
 #ifdef TFU_TDD
    FAPI_T_UCI_HARQ_INFO_R10    rel10;
 #else
    FAPI_T_UCI_HARQ_FDD_INFO_REL_8 rel8;
 #endif
 #else
    FAPI_T_UCI_HARQ_INFO_R10    rel10;
    FAPI_T_UCI_HARQ_INFO_R11    rel11;
    FAPI_T_UCI_HARQ_INFO_R13    rel13;
 #endif
} FAPI_T_UCI_HARQ_INFO;



typedef struct PACK_STRUCT FAPI_S_UCI_HARQ_TDD_INFO_REL_8  {
    FAPI_UINT8                  harq_size;          //Size of the ACK/NACK in bits. Values greater than 4 were added in Release 10  Value 1..20
                                                    //For Special Bundling this is the expected number of ACK/NACK responses (UDAI + NSPS). Value: 0...9
    FAPI_UINT8                  ack_nack_mode;      //The format of the ACK/NACK response expected. For TDD only.  0 = BUNDLING  1 = MULTIPLEXING   2 = Format 1b with channel selection  3 = Format 3
    FAPI_UINT8                  n_pucch_res;        //The number of PUCCH resources associated with the ACK/NACK response   See [6] section 10.1    Value: 1 ? 4    If the HARQ are transmitted on two antenna ports then the resource for the second antenna is in n_PUCCH_1_1
    FAPI_UINT16                 n_pucch_1_0;        //HARQ resource 0   Value: 0 ? 2047 (ACK_NACK mode = 0, 1 or 2)     Value: 0 ? 549 (ACK_NACK mode = 3)
    FAPI_UINT16                 n_pucch_1_1;        //HARQ resource 1   Value: 0 ? 2047 (ACK_NACK mode = 0, 1 or 2)     Value: 0 ? 549 (ACK_NACK mode = 3)
    FAPI_UINT16                 n_pucch_1_2;        //HARQ resource 2, value:  0 ? 2047 (ACK_NACK mode =  1 or 2)
    FAPI_UINT16                 n_pucch_1_3;        //HARQ resource 3, value: 0 ? 2047 (ACK_NACK mode =  1 or 2)
} FAPI_T_UCI_HARQ_TDD_INFO_REL_8 ;

typedef struct PACK_STRUCT FAPI_S_UCI_CQI_INFO_R8 {
    FAPI_UINT16                 pucch_idx;          //The PUCCH Index value, n_pucch(2). Value: 0...1184 ,1185 is for rel8
    FAPI_UINT8                  dl_cqi_pmi_size;    //The size of the DL CQI/PMI in bits. Value: 0...255
} FAPI_T_UCI_CQI_INFO_R8;

typedef struct PACK_STRUCT FAPI_S_UCI_CQI_INFO_R10 {
    FAPI_UINT8                  n_pucch_res;        //A value of 2 indicates that the UE is configured to transmit on two antenna ports Value: 1 ? 2
    FAPI_UINT16                 pucch_idx_p1 ;      // The PUCCH index value    for antenna port P1     Only valid when Number of PUCCH resources is 2.Value: 0 ? 1184
} FAPI_T_UCI_CQI_INFO_R10;

typedef struct PACK_STRUCT FAPI_S_UCI_CQI_INFO_R13 {
    FAPI_UINT8                  csi_mode;
    FAPI_UINT16                 dl_cqi_pmi_size_2;
    FAPI_UINT8                  starting_prb;
    FAPI_UINT8                  n_prb;
    FAPI_UINT8                  cdm_index;
    FAPI_UINT8                  n_srs;
} FAPI_T_UCI_CQI_INFO_R13;


typedef struct PACK_STRUCT FAPI_S_UCI_CQI_INFO {
    FAPI_T_UCI_CQI_INFO_R8      rel8;
 #ifndef NXP_PLATFORM
    FAPI_T_UCI_CQI_INFO_R10     rel10;
    FAPI_T_UCI_CQI_INFO_R13     rel13;
 #endif
} FAPI_T_UCI_CQI_INFO;


typedef struct PACK_STRUCT FAPI_S_UCI_SR_INFO_R8 {
    FAPI_UINT16                 pucch_idx;          //The PUCCH Index value, n_pucch(1).. Value: 0...2047
} FAPI_T_UCI_SR_INFO_R8;

typedef struct PACK_STRUCT FAPI_S_UCI_SR_INFO_R10 {
    FAPI_UINT8                  n_pucch_res;         //A value of 2 indicates that the UE is configured to transmit on two antenna ports Value: 1 ? 2
    FAPI_UINT16                 pucch_idx_p1;       //The PUCCH Index value for antenna port P1. Only valid when Two Antenna Port Activated is True.  Value: 0 ? 2047
} FAPI_T_UCI_SR_INFO_R10;

typedef struct PACK_STRUCT FAPI_S_UCI_SR_INFO {
    FAPI_T_UCI_SR_INFO_R8       rel8;
 #ifndef NXP_PLATFORM
    FAPI_T_UCI_SR_INFO_R10      rel10;
#endif
} FAPI_T_UCI_SR_INFO;

//Note: This struct should be expected after: FAPI_T_UCI_CQI_PDU, FAPI_T_UCI_SR_PDU, FAPI_T_UCI_HARQ_PDU
typedef struct PACK_STRUCT FAPI_S_UCI_REL_13_PDU {
    FAPI_UINT8                  ue_type;                  // 0 - non LC/CE user ; 1 - LC/CE mode A ' 2 - LC/CE mode B
    FAPI_UINT8                  empty_symbols_for_retuning;  //indicates the symbols that are left empty due to retuning
    FAPI_UINT16                 total_num_of_repetition;  //1-32 ; 1 - single allocation; overall expeted repetition
    FAPI_UINT16                 repetition_number;        //1-32 ; 1 - single allocation; current transmission number
}FAPI_T_UCI_REL_13_PDU;


typedef struct PACK_STRUCT FAPI_S_UE_INFORMATION_R8 {
    FAPI_UINT32                 handle;             // An opaque handling returned in the relevant indication message.
    FAPI_UINT16                 rnti;               // The RNTI used for identifying the UE when receiving the PDU.See [5] section 7.1. Value: 1 ? 65535.
} FAPI_T_UE_INFORMATION_R8;

typedef struct PACK_STRUCT FAPI_S_UE_INFORMATION_R11 {
    FAPI_UINT8                  virt_cell_id_en_flag;//Indicates if virtual cell is being used and nPUCCH identity is valid. Value: 0 = not used, 1= enabled
    FAPI_UINT16                 nPUCCH_idnetity;     //Virtual cell ID for initialization of base sequence and cyclic shift hopping of PUCCH. See [11] section 5.5.1.5. Valid if virtual cell ID is enabled. Value: 0 ? 503
} FAPI_T_UE_INFORMATION_R11;

typedef struct PACK_STRUCT FAPI_S_UE_INFORMATION_R13 {
    FAPI_UINT8                  ue_type;            // Value: 0: non LC/CE UE, 1: LC/CE CEModeA UE, 2: LC/CE CEModeB UE
    FAPI_UINT8                  empty_symbols;      // Indicates the symbols that are left empty due to eMTC retuning. Value: Bitmap of 2 bits. A bit value of  1 indicates the symbol is empty. A bit value of  0 indicates the symbol is not empty. bit[0] configures symbol 13. bit[1] configures symbol 0
    FAPI_UINT16                 total_num_of_repetition;// Value: 1 ? 32 . Value 1 indicates single allocation
    FAPI_UINT16                 repetition_number;  // Current transmission number. Value: 1 ? 32
} FAPI_T_UE_INFORMATION_R13;

typedef struct PACK_STRUCT FAPI_S_UE_INFORMATION {
    FAPI_T_UE_INFORMATION_R8    rel8;               // Release 8 attributes
 #ifndef NXP_PLATFORM
    FAPI_T_UE_INFORMATION_R11   rel11;              // Release 11 attributes
    FAPI_T_UE_INFORMATION_R13   rel13;              // Release 13 attributes
 #endif
} FAPI_T_UE_INFORMATION;

// Table 4-60 : UCI_CQU PDU
typedef struct PACK_STRUCT FAPI_S_UCI_CQI_PDU {
    FAPI_T_UE_INFORMATION       ue_info;
    FAPI_T_UCI_CQI_INFO         cqi_info;
} FAPI_T_UCI_CQI_PDU;

// Table 4-61 : UCI_SR PDU
typedef struct PACK_STRUCT FAPI_S_UCI_SR_PDU {
    FAPI_T_UE_INFORMATION       ue_info;
    FAPI_T_UCI_SR_INFO          sr_info;
} FAPI_T_UCI_SR_PDU;

// Table 4-62 : UCI_HARQ PDU
typedef struct PACK_STRUCT FAPI_S_UCI_HARQ_PDU {
    FAPI_T_UE_INFORMATION       ue_info;
    FAPI_UINT8                  harq_info[];
} FAPI_T_UCI_HARQ_PDU;

typedef struct PACK_STRUCT FAPI_S_UCI_SR_HARQ_PDU {
    FAPI_T_UE_INFORMATION       ue_info;
    FAPI_T_UCI_SR_INFO          sr_info;
    FAPI_UINT8                  harq_info[];
} FAPI_T_UCI_SR_HARQ_PDU;

typedef struct PACK_STRUCT FAPI_S_UCI_SR_HARQ_PDU_REL_8 {
    FAPI_T_UE_INFORMATION_R8    ue_info;
    FAPI_T_UCI_SR_INFO_R8       sr_info;
    FAPI_UINT8                  harq_info[];
} FAPI_T_UCI_SR_HARQ_PDU_REL_8;

typedef struct PACK_STRUCT FAPI_S_UCI_CQI_HARQ_PDU {
    FAPI_T_UE_INFORMATION       ue_info;
    FAPI_T_UCI_CQI_INFO         cqi_info;
    FAPI_UINT8                  harq_info[];
} FAPI_T_UCI_CQI_HARQ_PDU;

typedef struct PACK_STRUCT FAPI_S_UCI_CQI_HARQ_PDU_REL_8 {
    FAPI_T_UE_INFORMATION_R8    ue_info;
    FAPI_T_UCI_CQI_INFO_R8      cqi_info;
    FAPI_UINT8                  harq_info[];
} FAPI_T_UCI_CQI_HARQ_PDU_REL_8;

typedef struct PACK_STRUCT FAPI_S_UCI_CQI_SR_PDU {
    FAPI_T_UE_INFORMATION       ue_info;
    FAPI_T_UCI_CQI_INFO         cqi_info;
    FAPI_T_UCI_SR_INFO          sr_info;
} FAPI_T_UCI_CQI_SR_PDU;

typedef struct PACK_STRUCT FAPI_S_UCI_CQI_SR_PDU_REL_8 {
    FAPI_T_UE_INFORMATION_R8    ue_info;
    FAPI_T_UCI_CQI_INFO_R8      cqi_info;
    FAPI_T_UCI_SR_INFO_R8       sr_info;
} FAPI_T_UCI_CQI_SR_PDU_REL_8;

typedef struct PACK_STRUCT FAPI_S_UCI_CQI_SR_PDU_HARQ_REL_8 {
    FAPI_T_UE_INFORMATION_R8    ue_info;
    FAPI_T_UCI_CQI_INFO_R8      cqi_info;
    FAPI_T_UCI_SR_INFO_R8       sr_info;
    FAPI_UINT8                  harq_info[];
} FAPI_T_UCI_CQI_SR_PDU_HARQ_REL_8;

typedef struct PACK_STRUCT FAPI_S_UCI_CQI_SR_HARQ_PDU {
    FAPI_T_UE_INFORMATION       ue_info;
    FAPI_T_UCI_CQI_INFO         cqi_info;
    FAPI_T_UCI_SR_INFO          sr_info;
    FAPI_UINT8                  harq_info[];
} FAPI_T_UCI_CQI_SR_HARQ_PDU;

typedef struct PACK_STRUCT FAPI_S_SRS_PDU_R8 {
    FAPI_UINT32                 handle;             //An opaque handling returned in the SRS.indication
    FAPI_UINT16                 size;               //The size of the PDU in bytes.
    FAPI_UINT16                 rnti;               //The RNTI used for identifying the UE when receiving the PDU. Value: 1...65535
    FAPI_UINT8                  srs_bw;             //SRS Bandwidth. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...3
    FAPI_UINT8                  freq_domain_pos;    //Frequency-domain position, N_RRC This value is fixed for a UE and allocated in RRC connection setup. Value: 0...23
    FAPI_UINT8                  srs_hop_bw;         //Configures the frequency hopping on the SRS. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...3
    FAPI_UINT8                  trans_comb;         //Configures the frequency location of the SRS. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...1
    FAPI_UINT16                 srs_config_idx;     //Defines the periodicity and subframe location of the SRS. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...1023
    FAPI_UINT8                  sound_ref_cyc_shift;//Configures the SRS sequence generation. This value is fixed for a UE and allocated in RRC connection setup. Value: 0...7
} FAPI_T_SRS_PDU_R8;

typedef struct PACK_STRUCT FAPI_S_SRS_PDU_R10 {
    FAPI_UINT8                  ant_port            ;// Defines the number of antenna ports used by the UE for the SRS. This value is fixed for a UE and allocated in RRC connection setup.     0 = 1 antenna port  1 = 2 antenna ports 2 = 4 antenna ports
} FAPI_T_SRS_PDU_R10;

typedef struct PACK_STRUCT FAPI_S_SRS_PDU_R13 {
    FAPI_UINT8                  num_of_combs;
    // ????
} FAPI_T_SRS_PDU_R13;

typedef struct PACK_STRUCT FAPI_S_SRS_PDU {
    FAPI_T_SRS_PDU_R8        rel8;
 #ifndef NXP_PLATFORM
    FAPI_T_SRS_PDU_R10       rel10;
    FAPI_T_SRS_PDU_R13       rel13;
 #endif
} FAPI_T_SRS_PDU;

typedef struct PACK_STRUCT FAPI_S_HARQ_BUFFER_PDU {
    FAPI_T_UE_INFORMATION       ue_info;
} FAPI_T_HARQ_BUFFER_PDU;

typedef struct PACK_STRUCT FAPI_S_ULSCH_UCI_CSI_PDU{
 FAPI_T_ULSCH_PDU               ulsch_pdu;
 FAPI_T_UCI_CQI_INFO            csi_info;          // CSI structrure is same as CQI
}FAPI_T_ULSCH_UCI_CSI_PDU;

typedef struct PACK_STRUCT FAPI_S_ULSCH_UCI_HARQ_PDU
{
    FAPI_T_ULSCH_PDU               ulsch_pdu;
    FAPI_UINT8                     harq_info[];
}FAPI_T_ULSCH_UCI_HARQ_PDU;

typedef struct PACK_STRUCT FAPI_S_ULSCH_CSI_UCI_HARQ_PDU{
    FAPI_T_ULSCH_PDU               ulsch_pdu;
    FAPI_T_ULSCH_CQI_RI_INFO       csi_info;
    FAPI_UINT8                     harq_info[];
}FAPI_T_ULSCH_CSI_UCI_HARQ_PDU;

// Table 4-41 + 4-42 UL Config request
typedef struct PACK_STRUCT FAPI_S_UL_CONFIG_REQ {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                 length;             //The length of the uplink subframe configuration. Range 0...65535
    FAPI_UINT8                  n_pdu;              //The number of UL SCHs PDUs included in this message.
    FAPI_UINT8                  rach_prach_frq_res; //If semi-static information is held in the MAC For FDD:
                                                    //0-No RACH in this subframe,1-RACH present in this subframe.
                                                    //For TDD: Bits 0:5 indicate which RACH frequency resources are used in this subframe, see [8] section 5.7.1.
                                                    //0-This RACH frequency index is not used 1-This RACH frequency index is used.
                                                    //If semi-static information is held in the PHY this parameter is ignored
    FAPI_UINT8                  srs_present;        //If semi-static information is held in the MAC:  0-No SRS in this subframe, 1-SRS present in this subframe. If semi-static information is held in the PHY this parameter is ignored.
    FAPI_T_PDU                  ul_pdu[];
} FAPI_T_UL_CONFIG_REQ;

typedef struct PACK_STRUCT FAPI_S_HI_PDU_R8 {
    FAPI_UINT8                  rb_start;           //This value is the starting resource block assigned to the ULSCH grant associated with this HI response. It should match the value sent in the DCI format 0 which allocated the ULSCH grant. Value: 0...100
    FAPI_UINT8                  cyc_shift_2_dmrs;   //This value is the 2nd cyclic shift for DMRS assigned to the ULSCH grant associated with this HI response. It should match the value sent in the DCI format 0 which allocated the ULSCH grant. Value: 0...7
    FAPI_UINT8                  hi_value;           //The PHICH value which is sent on the resource. 0=HI_NACK, 1= HI_ACK
    FAPI_UINT8                  i_phich;            //Is used in the calculation of the PHICH location. For TDD only. 1 = TDD subframe configuration 0 is used and the ULSCH grant associated with this HI was received in subframe 4 or 9, 0 = in all other cases
    FAPI_UINT16                 trans_power;        //Offset to the reference signal power. Value: 0...10000, representing -6 dB to 4 dB in 0.001 dB steps.
} FAPI_T_HI_PDU_R8;

typedef struct PACK_STRUCT FAPI_S_HI_PDU_R10 {
    FAPI_UINT8                  flag_tb2;           //Indicates is HI is present for a second transport block 0 = HI is not present 1 = HI is present
    FAPI_UINT8                  hi_value2;          //The PHICH value for a second transport block. 0: HI_NACK1: HI_ACK
} FAPI_T_HI_PDU_R10;

// Table 4-92 : HI PDU
typedef struct PACK_STRUCT FAPI_S_HI_PDU {
    FAPI_T_HI_PDU_R8            rel8;
    FAPI_T_HI_PDU_R10           rel10;
} FAPI_T_HI_PDU;

typedef struct PACK_STRUCT FAPI_S_DCI_UL_PDU_R8 {
    FAPI_UINT8                  dci_format;         //Format of the DCI. 0 = 0, 1 = 3, 2 = 3A
    FAPI_UINT8                  cce_idx;            //CCE index used to send the DCI. Value: 0...88
    FAPI_UINT8                  agg_level;          //The aggregation level used. Value: 1,2,4,8
    FAPI_UINT16                 rnti;               //The RNTI used for identifying the UE when receiving the PDU, Valid for all DCI formats. Value: 1...65535
    FAPI_UINT8                  rb_start;           //The starting resource block for this ULSCH allocation. Valid for DCI format 0. Value: 0...100
    FAPI_UINT8                  n_rb;               //The number of resource blocks allocated to this ULSCH grant. Valid for DCI format 0. Value: 0...100
    FAPI_UINT8                  mcs_1;              //The modulation and redundancy version.  Valid for DCI format 0. Value: 0...31
    FAPI_UINT8                  cyc_shift_2_dmrs;   //The 2nd cyclic shift for DMRS assigned to the UE in the ULSCH grant. Valid for DCI format 0. Value: 0...7
    FAPI_UINT8                  freq_enable;        //Indicates if hopping is being used. Valid for DCI format 0. 0 = no hopping, 1= hopping enabled
    FAPI_UINT8                  freq_hop_bits;      //The frequency hopping bits. Valid for DCI format 0. Value: 0...3
    FAPI_UINT8                  ndi_1;              //The new data indicator for the transport block. Valid for DCI format 0
    FAPI_UINT8                  ue_tx_ant_select;   //Indicates how the CRC is calculated on the PDCCH. Valid for DCI format 0. 0 = Not configured, 1 = Configured and using UE port 0, 2 = Configured and using UE port 1.
    FAPI_UINT8                  tpc;                //Tx power control command for PUSCH. Valid for DCI format 0. Value: 0,1,2,3
    FAPI_UINT8                  cqi_csi_req;        //Aperiodic CQI request flag Valid for DCI formats 0,4 In Release 10 the size of this field became flexible and depends on the Size of CQI/CSI field in the Release 10 parameter structure.  If this field is 1 bit                               0 = Aperiodic CQI/CSI not requested 1 = Aperiodic CQI/CSI requested Else if this field is 2 bits Value: 0,1,2,3
    FAPI_UINT8                  ul_idx;             //UL index. Valid for TDD mode only. Valid for DCI format 0. Value: 0,1,2,3
    FAPI_UINT8                  dl_assign_idx;      //DL assignment index. Valid for TDD mode only. Valid for DCI format 0. Value: 1,2,3,4
    FAPI_UINT32                 tpc_bitmap;         //TPC commands for PUCCH and PUSCH. Valid for DCI formats: 3,3A
    FAPI_UINT16                 tp;                 //Offset to the reference signal power.value: 0 ? 10000, representing -6 dB to 4 dB in 0.001 dB steps.
} FAPI_T_DCI_UL_PDU_R8;

typedef struct PACK_STRUCT FAPI_S_DCI_UL_PDU_R10 {
    FAPI_UINT8                  cros_car_sch_flag;  //valid for DCI formats 0,4 0 = Carrier indicator field is not valid 1 = Carrier indicator field is valid
    FAPI_UINT8                  car_ind;            //Serving Cell Index Valid for DCI formats 0,4 if the Cross-Carrier Scheduling flag is enabled  Value: 0->7
    FAPI_UINT8                  cqi_csi_size;       //Indicates the size of the CQI/CSI request field Valid for DCI format 0,4 0 = 1 bit 1 = 2 bits
    FAPI_UINT8                  srs_flag;           // Indicates if the SRS request parameter is present. Valid for DCI format 0 0 = SRS request field is not present 1 = SRS request field is present
    FAPI_UINT8                  srs_req;             //SRS request Valid for DCI formats 0,4 under the following conditions DCI format 0: If the SRS flag field indicates this parameter is valid 0 = SRS not requested 1= SRS requested  DCI format 4: The encoding follows [6] section 8.2
    FAPI_UINT8                  res_alloc_flag;     //Indicates if the Resource Allocation Type parameter is Valid for DCI format 0  0 = Resource Allocation Type field is not valid and resource allocation type 0 is used 1 = Resource Allocation Type field is valid
    FAPI_UINT8                  res_alloc_type;     // Resource allocation type/header. Valid for DCI formats 0,4 under the following conditions DCI format 0: If the Resource Allocation flag field indicates this parameter is valid.  DCI format 4: Always valid  0=type 0 1=type 1
    FAPI_UINT32                 rb_coding;          //The encoding for the resource blocks. It's coding is dependent on whether resource allocation type 0, 1 is in use and signalled for DCI formats 0,4 For DCI format 0 this field is valid when resource allocation type 1 is signalled. For DCI format 4 this field is always valid. See [6] section 8.1 for the encoding used for each allocation type.
    FAPI_UINT8                  mcs_2;              //The modulation and redundancy version for the second transport block See [6] section 8.6. Valid for DCI format 4  Value: 0 ? 31
    FAPI_UINT8                  nd_ind2;            //The new data indicator for the second transport block Valid for DCI format 4
    FAPI_UINT8                  n_ant_ports ;       // Defines number of antenna ports for this ULSCH allocation Value: 0 = 1 antenna port 1 = 2 antenna ports 2 = 4 antenna ports
    FAPI_UINT8                  tpmi;               //The codebook index to be used for precoding Valid for DCI format 4  2 antenna_ports: 0 ? 7 4 antenna_ports: 0 ? 63
    FAPI_UINT8                  payload_length;     //DCI payload length[bits]
    FAPI_UINT8                  n_ul_rb;            //BW of serving cell for which the DCI was scheduled for. This is valid for the case of cross carrier scheduling, for the case of a self-scheduling (cross carrier scheduling is not valid or Carrier indicator has value ��0��, the BW is the ��DL BW support�� as configured in configuration phase (params). Uplink channel bandwidth in resource blocks. See [10] section 5.6. Value: 6,15, 25, 50, 75, 100
} FAPI_T_DCI_UL_PDU_R10;

typedef struct PACK_STRUCT FAPI_S_DCI_UL_PDU_R12 {
    FAPI_UINT8                  pscch_resource;     //6-bits describing the resource blocks for transmitting PSCCH, see [9] section 14.2.1. Valid for DCI format 5
    FAPI_UINT8                  time_resource_pattern;//7-bits describing the time resource pattern index, see [9] section 14.1.1. Valid for DCI format 5/SCI format 0
} FAPI_T_DCI_UL_PDU_R12;

// Table 4-95 : DCI UL PDU
typedef struct PACK_STRUCT FAPI_S_DCI_UL_PDU {
    FAPI_T_DCI_UL_PDU_R8        rel8;               //Release 8 attributes
    FAPI_T_DCI_UL_PDU_R10       rel10;              //Release 10 attributes
    FAPI_T_DCI_UL_PDU_R12       rel12;              //Release 12 attributes
} FAPI_T_DCI_UL_PDU;

typedef struct PACK_STRUCT FAPI_S_HI_DCI0_REQ {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT8                  n_dci;              //Number of DCI PDUs included in this message
    FAPI_UINT8                  n_hi;               //Number of HI PDUs included in this message
    FAPI_T_PDU                  pdu[];
} FAPI_T_HI_DCI0_REQ;

typedef struct  MPDCCH_UL_PRE_CODE_VAL_S
{
    FAPI_UINT16                precode_val;
} MPDCCH_UL_PRE_CODE_VAL_T;

// Table 4-119 : MPDCCH DCI UL PDU Release 13 parameters
typedef struct PACK_STRUCT FAPI_S_MPDCCH_UL_DCI_R13 {
    FAPI_UINT8                  mpdcch_narrowband;              //Narrowband index 0..15
    FAPI_UINT8                  n_rbs_per_set;                  //num of PRB pairs: 2/4/6
    FAPI_UINT8                  resource_block_assignment;      //Combinational index r as defined in 36.213 section 9.1.4.4. values: 0-14
    FAPI_UINT8                  transmission_type;              //0 - localized; 1 -distributes
    FAPI_UINT8                  start_symbol;                   //Values:1-4
    FAPI_UINT8                  ecce_index;                     //ECCE index used to send the DCI values: 0-22
    FAPI_UINT8                  aggregation_level;              //aggregation level: 2/4/8/16/24
    FAPI_UINT8                  rnti_type;                      //0-temporary C-RNTI; 2 - RA-RNTI; 3 - P_RNTI; 4 - other
    FAPI_UINT16                 rnti;                           //The RNTI used for identifying the UE.
    FAPI_UINT8                  ce_mode;                        //0 - legacy; 1 - mode A ; 2 - mode B
    FAPI_UINT16                 dmrs_scrambling_init;           //The DMRS scrambling sequnce initialization as defined in 36.211 section 6.10.3A.1
    FAPI_UINT16                 initial_transmission_sf;        //Values:0-10239
    FAPI_UINT16                 transmission_power;             //Offset to the reference signal power
    FAPI_UINT8                  dci_format;                     //Format of the DCI. 0 = 6-1A; 1 = 6-1B; 2 = 6-2;
    FAPI_UINT8                  resource_block_start;           //The starting resource block for ULSCH allocation
    FAPI_UINT8                  n_rbs;                          //Number of RBs allocated by this grant
    FAPI_UINT8                  mcs;                            //Modulation and coding scheme
    FAPI_UINT8                  repetition_number;              //repetition number
    FAPI_UINT8                  freq_hopping_enabled;           //Indicated if hoppong is being is used
    FAPI_UINT8                  ndi;                            //New daya indicator
    FAPI_UINT8                  harq_process;                   //HARQ process number- valid for DCI formats:6-1A, 6-1B
    FAPI_UINT8                  rv;                             //Redundency version
    FAPI_UINT8                  tpc;                            //TX power control command for PUCCH
    FAPI_UINT8                  csi_request;                    //aperiodic CSI request flag
    FAPI_UINT8                  ul_index;                       //UL index. valid for TDD only
    FAPI_UINT8                  dai_presence;                   //Indicates if DL assingment index field is present in the DCI
    FAPI_UINT8                  dai;                            //downlink assignment index
    FAPI_UINT8                  srs_request;                    //SRS request flag
    FAPI_UINT8                  dci_subframe_repetition_number; //indicates the number of MPDCCH repetitions
    FAPI_UINT32                 tpc_bitmap;                     //TPC bitmap for DCI_3/DCI_3A
    FAPI_UINT8                  dci_length;                     //The total DCI length including padding bits
    FAPI_UINT8                  n_tx_antenna_ports;             //number of TX physical antenna ports
    MPDCCH_UL_PRE_CODE_VAL_T    precoding_value[];              //Precoding element for physical antenna #i 8 bits - real ; followed by imaginarry 8 bits
} FAPI_T_MPDCCH_UL_DCI_R13;

// Table 4-100 : MPDCCH DCI UL PDU
typedef struct PACK_STRUCT FAPI_S_MPDCCH_UL_DCI {
    FAPI_T_MPDCCH_UL_DCI_R13    rel13;      // Release 13 attributes
} FAPI_T_MPDCCH_UL_DCI;

// Table 4-145 : RX UE Information
typedef struct PACK_STRUCT FAPI_S_RX_UE_INFORMATION {
    FAPI_UINT32                 handle;             // The handle received in the UL_CONFIG.request.

    FAPI_UINT16                 rnti;               // The RNTI passed to the PHY in a UL_CONFIG.request
                                                    // Value: 1 -> 65535
} FAPI_T_RX_UE_INFORMATION;

typedef struct PACK_STRUCT FAPI_S_UL_CQI_INFORMATION {
    FAPI_UINT8                  ul_cqi;             // SNR
                                                    // Value: 0-255, representing -64dB to 63.5dB, with 0.5dB step size.

    FAPI_UINT8                  channel;            // The channel to which this measurement refers
                                                    // 0 = PUCCH
                                                    // 1 = PUSCH
} FAPI_T_UL_CQI_INFORMATION;

typedef struct PACK_STRUCT FAPI_S_RX_ULSCH_IND_PDU_R8 {
#if (FAPI_VER_NUM == FAPI_VER_NUM_1_1_0)
    FAPI_UINT32                 handle;             //The handle received in the ULSCH PDU.
    FAPI_UINT16                 rnti;               //The RNTI passed to the PHY in a DL_CONFIG.request ULSCH PDU. Value: 1...65535
#endif
    FAPI_UINT16                 length;             //Length of PDU in bytes.
    FAPI_UINT16                 data_offset;        //Gives the PDU#i data address offset from the beginning of the 'Number of PDUs' field. An offset of 0 indicates a CRC or decoding error.
    FAPI_UINT8                  ul_cqi;             //SNR. Value: 0-255, representing -64dB to 63.5dB, with 0.5dB step size
    FAPI_UINT16                 t_a;                //The timing advance measured for this PDU and UE. Value: T_A from 0 to 1282
} FAPI_T_RX_ULSCH_IND_PDU_R8;

typedef struct PACK_STRUCT FAPI_S_RX_ULSCH_IND_PDU_R9 {
    FAPI_UINT16                 t_a_r9;             //Timing advance used for positioning.   See [12] section 5.2.4 and [13] section 10.3.1.
} FAPI_T_RX_ULSCH_IND_PDU_R9;

typedef struct PACK_STRUCT FAPI_S_RX_ULSCH_IND_PDU {
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
   FAPI_T_RX_UE_INFORMATION        rx_ue_info;
#endif
   FAPI_T_RX_ULSCH_IND_PDU_R8      rel8;
   FAPI_T_RX_ULSCH_IND_PDU_R9      rel9;
} FAPI_T_RX_ULSCH_IND_PDU;


typedef struct PACK_STRUCT FAPI_S_RX_ULSCH_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                 n_pdu;              //Number of PDUs included in this message
    FAPI_T_RX_ULSCH_IND_PDU                  pdu[];
} FAPI_T_RX_ULSCH_IND;

typedef struct PACK_STRUCT FAPI_S_RX_ULSCH_IND_DATA {
    FAPI_UINT8                  *data;             // The actual data of the ULSCH
} FAPI_T_RX_ULSCH_IND_DATA;


typedef struct PACK_STRUCT FAPI_S_TDD_HARQ_DATA_INFO {
    FAPI_UINT8                  value_0;            //Number of ACK among multiple ACK/NACK responses.
                                                    //Valid for BUNDLING,SBUNDLING,MULTIPLEXING ,CHANNEL SELECTION,FORTMATE


 } FAPI_T_TDD_HARQ_DATA_INFO;

typedef struct PACK_STRUCT FAPI_S_HARQ_TDD_DATA_BUNDLING_REL_8 {
     FAPI_UINT8                 value_0;            //Indicates HARQ results. Range 1...7
                                                     // 1 = ACK, 2 = NACK, 3 = ACK or NACK, 4 = DTX
                                                     // 5 = ACK or DTX, 6 = NACK or DTX, 7 = ACK or NACK or DTX
     FAPI_UINT8                 value_1;            //Indicates HARQ results. Range 1...7, see above.
} FAPI_T_HARQ_TDD_DATA_BUNDLING_REL_8;

typedef struct PACK_STRUCT FAPI_S_HARQ_TDD_DATA_SBUNDLING_REL_8 {
     FAPI_UINT8                 value_0;            //Number of ACK among multiple ACK/NACK responses.
                                                     //0 = 0 or None (UE detect at least one DL assignment is missed)
                                                     // 1 = 1 or 4 or 7 ACKs reported
                                                     // 2 = 2 or 5 or 8 ACKs reported
                                                     // 3 = 3 or 6 or 9 ACKs reported
                                                     // 4 = DTX (UE did not transmit anything)
} FAPI_T_HARQ_TDD_DATA_SBUNDLING_REL_8;

typedef struct PACK_STRUCT FAPI_S_HARQ_TDD_DATA_MULTIPLEXING_REL_8 {
     FAPI_UINT8                 value_0;            //Indicates HARQ results. Range 1...7
                                                     // 1 = ACK, 2 = NACK, 3 = ACK or NACK, 4 = DTX
                                                     // 5 = ACK or DTX, 6 = NACK or DTX, 7 = ACK or NACK or DTX
     FAPI_UINT8                 value_1;            //Indicates HARQ results. Range 1...7, see above.
     FAPI_UINT8                 value_2;            //Indicates HARQ results. Range 1...7, see above.
     FAPI_UINT8                 value_3;            //Indicates HARQ results. Range 1...7, see above.
} FAPI_T_HARQ_TDD_DATA_MULTIPLEXING_REL_8;

typedef struct PACK_STRUCT FAPI_S_HARQ_TDD_IND_PDU {
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
    FAPI_T_RX_UE_INFORMATION        rx_ue_info;
#else
    FAPI_UINT32                 handle;             //The handle received in the ULSCH PDU or UCI PDU.
    FAPI_UINT16                 rnti;               //The RNTI passed to the PHY in a DL_CONFIG.request ULSCH PDU. Value: 1...65535
#endif
    FAPI_UINT8                  mode;               //The format of the ACK/NACK response expected. The bundling and multiplexing options are passed to the PHY in an uplink subframe configuration PDU.
                                                    //If the ACK/NACK is combined with either CQI or SR information then a special ACK/NACK encoding is used which reports the number of ACKs,
                                                    //rather than providing specific ACK/NACK values. This is identified separately and called SPECIAL_BUNDLING in this API. 0 = BUNDLING, 1 = MULTIPLEXING
    #ifdef NXP_PLATFORM
    FAPI_UINT8                 n_ack_nack;
    #else
    FAPI_UINT16                 n_ack_nack;         //The number of ACK/NACK results reported for this UE. Value: 1...4
    #endif                                                //For Special Bundling this is the expected number of ACK/NACK responses (UDAI + NSPS). Value: 0...9
    FAPI_T_TDD_HARQ_DATA_INFO   harq_data[];        //The format of the data is dependent on the HARQ mode; BUNDLING, MULTIPLEXING, or SPECIAL BUNDLING.

} FAPI_T_HARQ_TDD_IND_PDU;


typedef struct PACK_STRUCT FAPI_S_HARQ_TDD_IND_PDU_REL_8 {
    FAPI_UINT32                 handle;             //The handle received in the ULSCH PDU or UCI PDU.
    FAPI_UINT16                 rnti;               //The RNTI passed to the PHY in a DL_CONFIG.request ULSCH PDU. Value: 1...65535
    FAPI_UINT8                  mode;               //The format of the ACK/NACK response expected. The bundling and multiplexing options are passed to the PHY in an uplink subframe configuration PDU.
                                                    //If the ACK/NACK is combined with either CQI or SR information then a special ACK/NACK encoding is used which reports the number of ACKs,
                                                    //rather than providing specific ACK/NACK values. This is identified separately and called SPECIAL_BUNDLING in this API. 0 = BUNDLING, 1 = MULTIPLEXING
    FAPI_UINT8                  n_ack_nack;         //The number of ACK/NACK results reported for this UE. Value: 1...4
                                                    //For Special Bundling this is the expected number of ACK/NACK responses (UDAI + NSPS). Value: 0...9
    FAPI_UINT8                  harq_data[];        //The format of the data is dependent on the HARQ mode; BUNDLING, MULTIPLEXING, or SPECIAL BUNDLING.

} FAPI_T_HARQ_TDD_IND_PDU_REL_8;

typedef struct PACK_STRUCT FAPI_S_HARQ_TDD_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                 n_harq;             //Number of HARQs included in this message.
    FAPI_T_HARQ_TDD_IND_PDU     pdu[];
} FAPI_T_HARQ_TDD_IND;

typedef struct PACK_STRUCT FAPI_S_HARQ_TDD_IND_REL_8 {
    FAPI_T_MSG_HDR                  msg_hdr;            //Message header
    FAPI_UINT16                     sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                     n_harq;             //Number of HARQs included in this message.
    FAPI_T_HARQ_TDD_IND_PDU_REL_8   pdu[];
} FAPI_T_HARQ_TDD_IND_REL_8;

typedef struct PACK_STRUCT FAPI_S_HARQ_FDD_IND_PDU {
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
    FAPI_T_RX_UE_INFORMATION        rx_ue_info;
#else
    FAPI_UINT32                 handle;             //The handle received in the ULSCH PDU or UCI PDU.
    FAPI_UINT16                 rnti;               //The RNTI passed to the PHY in an uplink subframe configuration PDU. Value: 1...65535
#endif
    FAPI_UINT8                  mode;
    FAPI_UINT16                 n_ack_nack;
    FAPI_UINT8                  harq_tb_n[];
} FAPI_T_HARQ_FDD_IND_PDU;

typedef struct PACK_STRUCT FAPI_S_HARQ_FDD_IND_PDU_REL_8 {
    FAPI_UINT32                 handle;             //The handle received in the ULSCH PDU or UCI PDU.
    FAPI_UINT16                 rnti;               //The RNTI passed to the PHY in an uplink subframe configuration PDU. Value: 1...65535
    FAPI_UINT8                  harq_tb1;           //HARQ feedback of 1st TB. Range 1...7
                                                    // 1 = ACK, 2 = NACK, 3 = ACK or NACK, 4 = DTX,
                                                    // 5 = ACK or DTX,  6 = NACK or DTX, 7 = ACK or NACK or DTX
    FAPI_UINT8                  harq_tb2;           //HARQ feedback of 2nd TB. Range 1...7
                                                    // 1 = ACK, 2 = NACK, 3 = ACK or NACK, 4 = DTX,
                                                    // 5 = ACK or DTX,  6 = NACK or DTX, 7 = ACK or NACK or DTX
} FAPI_T_HARQ_FDD_IND_PDU_REL_8;


typedef struct PACK_STRUCT FAPI_S_HARQ_FDD_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                 n_harq;             //Number of HARQs included in this message.
    FAPI_T_HARQ_FDD_IND_PDU     pdu[];
} FAPI_T_HARQ_FDD_IND;

typedef struct PACK_STRUCT FAPI_S_HARQ_FDD_IND_REL_8 {
    FAPI_T_MSG_HDR                  msg_hdr;            //Message header
    FAPI_UINT16                     sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                     n_harq;             //Number of HARQs included in this message.
    FAPI_T_HARQ_FDD_IND_PDU_REL_8   pdu[];
} FAPI_T_HARQ_FDD_IND_REL_8;

typedef struct PACK_STRUCT FAPI_S_CRC_IND_PDU {
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
    FAPI_T_RX_UE_INFORMATION        rx_ue_info;
#else
    FAPI_UINT32                 handle;             //The handle received in the ULSCH PDU.
    FAPI_UINT16                 rnti;               //The RNTI passed to the PHY in an uplink subframe configuration PDU.. Value: 1...65535
#endif
    FAPI_UINT8                  crc_flag;           //A flag indicating if a CRC error was detected. 0=CRC_CORRECT, 1=CRC_ERROR
} FAPI_T_CRC_IND_PDU;

typedef struct PACK_STRUCT FAPI_S_CRC_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                 n_crc;              //Number of CRCs included in this message.
    FAPI_T_CRC_IND_PDU          pdu[];
} FAPI_T_CRC_IND;

typedef struct PACK_STRUCT FAPI_S_RX_SR_IND_PDU {
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
    FAPI_T_RX_UE_INFORMATION        rx_ue_info;
    FAPI_T_UL_CQI_INFORMATION       ul_cqi_info;
#else
    FAPI_UINT32                 handle;             //The handle received in the UCI PDU.
    FAPI_UINT16                 rnti;               //The RNTI identifying the UE. For semi-static information held in the MAC this will be the value passed to the PHY in a UL_CONFIG.request SR PDU. Value: 0...65535
#endif
} FAPI_T_RX_SR_IND_PDU;

typedef struct PACK_STRUCT FAPI_S_RX_SR_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                 n_sr;               //Number of SRs included in this message.
    FAPI_T_RX_SR_IND_PDU        pdu[];
} FAPI_T_RX_SR_IND;

typedef struct PACK_STRUCT FAPI_S_RX_CQI_IND_DATA {
    FAPI_UINT8                  *cqi_data;
} FAPI_T_RX_CQI_IND_DATA;
typedef struct PACK_STRUCT FAPI_S_RX_RI_TA_PER_CC_RPT{
    FAPI_UINT8                  ri;                 //The rank indication reported by the UE on PUSCH for aperiodic CSI.    Value: 0..8 0 = RI not received 1.. 8 = RI value in Release 10  1..3 = RI value in Release 9
}FAPI_T_RX_RI_TA_PER_CC_RPT;

typedef struct PACK_STRUCT FAPI_S_RX_CQI_IND_PDU_A {
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
    FAPI_T_RX_UE_INFORMATION        rx_ue_info;
#else
    FAPI_UINT32                 handle;             //The handle received in the ULSCH PDU or UCI PDU
    FAPI_UINT16                 rnti;               //The RNTI identifying the UE. For semi-static information held in the MAC this will be the value passed to the PHY in a UL_CONFIG.request CQI PDU. Value: 1...65535
#endif
    FAPI_UINT16                 length;             //Length of PDU in bytes.
    FAPI_UINT16                 data_off;           //Gives the PDU#i data address offset from the beginning of the 'Number of PDUs' field. An offset of 0 indicates a CRC or decoding error, or only RI received on PUSCH.
    FAPI_UINT8                  ul_cqi;             //SNR. Value: 0-255, representing -64dB to 63.5dB, with 0.5dB step size.
    FAPI_UINT8                  n_cc;                //Value 1...5
    FAPI_T_RX_RI_TA_PER_CC_RPT  cc_rpt[];
} FAPI_T_RX_CQI_IND_PDU_A;

typedef struct PACK_STRUCT FAPI_S_RX_CQI_IND_PDU_B {
    FAPI_UINT16                 t_a;                //The timing advance measured for this PDU and UE. Value: T_A from 0 to 1282
    FAPI_UINT16                 t_a_r9;             //Timing advance used for positioning. See [12] section 5.2.4 and [13] section 10.3.1. Value:   0 ? 2047 (measured in steps of 2Ts) 2048 ? 7690 (measured in steps of 8Ts)
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
    FAPI_T_UL_CQI_INFORMATION       ul_cqi_info;
#endif
} FAPI_T_RX_CQI_IND_PDU_B;

typedef struct FAPI_S_RX_CQI_IND_PDU {
    FAPI_T_RX_CQI_IND_PDU_A  pdu_a;
    FAPI_T_RX_CQI_IND_PDU_B  pdu_b;
} FAPI_T_RX_CQI_IND_PDU;

typedef struct PACK_STRUCT FAPI_S_RX_CQI_IND_PDU_REL_8 {
    FAPI_UINT32                 handle;             //The handle received in the ULSCH PDU or UCI PDU
    FAPI_UINT16                 rnti;               //The RNTI identifying the UE. For semi-static information held in the MAC this will be the value passed to the PHY in a UL_CONFIG.request CQI PDU. Value: 1...65535
    FAPI_UINT16                 length;             //Length of PDU in bytes.
    FAPI_UINT16                 data_off;           //Gives the PDU#i data address offset from the beginning of the 'Number of PDUs' field. An offset of 0 indicates a CRC or decoding error, or only RI received on PUSCH.
    FAPI_UINT8                  ul_cqi;             //SNR. Value: 0-255, representing -64dB to 63.5dB, with 0.5dB step size.
    FAPI_UINT8                  ri;                 //The rank indication reported by the UE on PUSCH. Value: 0...4. 0 = RI not received, 1..4 = RI value
    FAPI_UINT16                 t_a;                //The timing advance measured for this PDU and UE. Value: T_A from 0 to 1282
} FAPI_T_RX_CQI_IND_PDU_REL_8;

typedef struct PACK_STRUCT FAPI_S_RX_CQI_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                 n_pdu;              //Number of PDUs included in this message
    FAPI_T_RX_CQI_IND_PDU       pdu[];
}FAPI_T_RX_CQI_IND;

typedef struct PACK_STRUCT FAPI_S_RX_CQI_IND_REL_8 {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT16                 n_pdu;              //Number of PDUs included in this message
    FAPI_T_RX_CQI_IND_PDU_REL_8  pdu[];
}FAPI_T_RX_CQI_IND_REL_8;

typedef struct PACK_STRUCT FAPI_S_RACH_IND_PRE_R8 {
    FAPI_UINT16                 rnti;               //The RA-RNTI value. Value: 1...65535
    FAPI_UINT8                  preabmle;           //The detected preamble. Value: 0...63
    FAPI_UINT16                 t_a;                //The measured timing advance for the preamble. Value:0...1282
} FAPI_T_RACH_IND_PRE_R8;

typedef struct PACK_STRUCT FAPI_S_RACH_IND_PRE_R9 {
    FAPI_UINT16                 t_a_r9;             //Timing advance used for positioning.  See [12] section 5.2.4 and [13] section 10.3.1.         Value:  0 ? 2047 (measured in steps of 2Ts) 2048 ? 7690 (measured in steps of 8Ts)
} FAPI_T_RACH_IND_PRE_R9;

typedef struct PACK_STRUCT FAPI_S_RACH_IND_PRE_R13 {
    FAPI_UINT8                  resource_type;     //Indicates if this indication is related to Cat-M UE and in which CE level. Value: 0 �C non LC/CE RACH, 1 �C LC/CE RACH CE level 0, 2 �C LC/CE RACH CE level 1, 3 �C LC/CE RACH CE level 2, 4 �C LC/CE RACH CE level 3
} FAPI_T_RACH_IND_PRE_R13;

typedef struct PACK_STRUCT FAPI_S_RACH_IND_PRE {
    FAPI_T_RACH_IND_PRE_R8  rel8;
    FAPI_T_RACH_IND_PRE_R9  rel9;
    FAPI_T_RACH_IND_PRE_R13 rel13;
} FAPI_T_RACH_IND_PRE;

typedef struct PACK_STRUCT FAPI_S_RACH_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT8                  n_pre;              //Number of RACH preambles
    FAPI_UINT8                      preamble[];
} FAPI_T_RACH_IND;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_UE_RB {
    FAPI_UINT8                  snr;                //Field size dependent on configured bandwidth.
                                                    //SNR for RBs, each RBs report one SNR.
                                                    //Value: 0-255, representing -64dB to 63.5dB, with 0.5dB step size.
} FAPI_T_SRS_IND_UE_RB;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_UE_R8 {
#if (FAPI_VER_NUM == FAPI_VER_NUM_1_1_0)
    FAPI_UINT32                 handle;             //The handle received in the SRS PDU.
    FAPI_UINT16                 rnti;               //The RNTI passed to the PHY in an uplink subframe configuration PDU
#endif
    FAPI_UINT16                 dopp_est;           //FFS. Value: 0...255
    FAPI_UINT16                 t_a;                //The timing advance measured for the UE. Value:0...1282
    FAPI_UINT8                  n_rb;               //Number of resource blocks to be reported for this UE
    FAPI_UINT8                  rb_start;           //The starting point of the RBs to be reported
    FAPI_T_SRS_IND_UE_RB        rb[];
} FAPI_T_SRS_IND_UE_R8;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_UE_R9{
    FAPI_UINT16                 t_a_r9;             //Timing advance used for positioning.  See [12] section 5.2.4 and [13] section 10.3.1.         Value:  0 ->2047 (measured in steps of 2Ts) 2048 ?->7690 (measured in steps of 8Ts)
}FAPI_T_SRS_IND_UE_R9;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_UE_R10_TDD{
    FAPI_UINT8                  upPts_symbol;       //Indicates symbol where SRS was received. Only valid if the SRS was received in subframe 1 or 6. Value: 0 = symbol 0, 1 = symbol 1
}FAPI_T_SRS_IND_UE_R10_TDD;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_UE_R11{
    FAPI_UINT16                 ul_rtoa;            //UL relative time of arrival used for network based positioning. See [15] section 5.2.8 and [22] section 8. Value: 0 ? 4800 (measured in steps of 2Ts)
}FAPI_T_SRS_IND_UE_R11;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_SUBBAND_IDX{
    FAPI_UINT8                  subband_idx;        //Index of subband for which the following channel coefficient is applied
} FAPI_T_SRS_IND_SUBBAND_IDX;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_PHYS_ANT{
    FAPI_UINT16                 channel;            //Averaged channel coefficient in a subband for physical antenna #i, real 8 bits followed by imaginary 8 bits
} FAPI_T_SRS_IND_PHYS_ANT;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_CH_MEAS_TDD{
    FAPI_UINT8                  num_prb_per_subband;//Number of PRBs that are treated as one subband
    FAPI_UINT8                  num_of_subbands;    //Defines the number of subbands used for channel feedback. Value 0 -> 13
    FAPI_UINT8                  num_antennas;       //Number of physical antennas
    FAPI_T_SRS_IND_SUBBAND_IDX  subband[];
} FAPI_T_SRS_IND_CH_MEAS_TDD;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_UE_FDD{
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
    FAPI_T_RX_UE_INFORMATION        rx_ue_info;
#endif
    FAPI_T_SRS_IND_UE_R8        rel8;
    FAPI_T_SRS_IND_UE_R9        rel9;
    FAPI_T_SRS_IND_UE_R11       rel11;
}FAPI_T_SRS_IND_UE_FDD;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_UE_TDD_A{
#if (FAPI_VER_NUM >= FAPI_VER_NUM_3_0_6)
    FAPI_T_RX_UE_INFORMATION        rx_ue_info;
#endif
    FAPI_T_SRS_IND_UE_R8        rel8;
    FAPI_T_SRS_IND_UE_R9        rel9;
    FAPI_T_SRS_IND_UE_R10_TDD   rel10;
    FAPI_T_SRS_IND_CH_MEAS_TDD  srs_channel_meas;
}FAPI_T_SRS_IND_UE_TDD_A;

typedef struct PACK_STRUCT FAPI_S_SRS_IND_UE_TDD_B{
    FAPI_T_SRS_IND_UE_R11       rel11;
}FAPI_T_SRS_IND_UE_TDD_B;


typedef struct PACK_STRUCT FAPI_S_SRS_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT16                 sf_sfn;             //[15:4] SFN, range 0..1023, [3:0] SF, range 0...9
    FAPI_UINT8                  n_ue;               //Number of UEs contributing to the uplink SRS
    FAPI_UINT8                  ue[];
} FAPI_T_SRS_IND;

//Invalid Vendor Specific Tag Error Code.
typedef struct PACK_STRUCT FAPI_S_INVALID_VSM_TAG_ERR {
    FAPI_UINT16     invalid_tag;                    //The Invalid VSM TAG value received in the message.
} FAPI_T_INVALID_VSM_TAG_ERR;

//SFN_OUT_OF_SYNC and MSG_INVALID_SFN Error Codes.
typedef struct PACK_STRUCT FAPI_S_SFN_ERR {
    FAPI_UINT16     received_sfn_sf;                //The SFN/SF value received in the message.
    FAPI_UINT16     expected_sfn_sf;                //The SFN/SF value the PHY was expecting to receive in the message.
} FAPI_T_SFN_ERR;

//MSG_PDU_ERR Error Code.
typedef struct PACK_STRUCT FAPI_S_MSG_PDU_ERR {
    FAPI_UINT8      sub_error_code;                 //The Sub Error Code for this message.
    FAPI_UINT8      direction;                      //Indicates if this error was in a DL subframe configuration or an UL subframe configuration.
                                                    //0 = DL, 1 = UL
    FAPI_UINT16     rnti;                           //The RNTI in the received PDU. If the error occured in a MCH, or BCH, PDU this value is set to 0.
    FAPI_UINT8      pdu_type;                       //The PDU Type parameter specified in both DL subframe configuration and UL subframe configuration.
} FAPI_T_MSG_PDU_ERR;

//MSG_HI_ERR Error Code.
typedef struct PACK_STRUCT FAPI_S_MSG_HI_ERR {
    FAPI_UINT8      sub_error_code;                 //The Sub Error Code for this message.
    FAPI_UINT8      phich_lowest_ul_rb_index;       //The PHICH RB Index parameters specified in each HI PDU.
} FAPI_T_MSG_HI_ERR;

//MSG_TX_ERR Error Code.
typedef struct PACK_STRUCT FAPI_S_MSG_TX_ERR {
    FAPI_UINT8      sub_error_code;                 //The Sub Error Code for this message.
    FAPI_UINT16     pdu_index;                      //The PDU index parameter specified for each PDU.
} FAPI_T_MSG_TX_ERR;

//GLOB_PARAM_ERR Error Code.
typedef struct PACK_STRUCT FAPI_S_MSG_GLOB_PARAM_ERR {
    FAPI_UINT8      sub_error_code;                 //The Sub Error Code for this message.
//  FAPI_UINT8      direction;                      //Indicates if this error was in a DL subframe configuration or an UL subframe configuration.
    FAPI_UINT8      padding;
} FAPI_T_MSG_GLOB_PARAM_ERR;

//N_PDU_LIMIT_SURPASSED Error Code.
typedef struct PACK_STRUCT FAPI_S_N_PDU_LIMIT {
    FAPI_UINT8      sub_error_code;                 //The Sub Error Code for this message.
    FAPI_UINT8      received_val;                   //Number of PDUs received.
    FAPI_UINT8      limit;                          //PHYs maximum number of accepted PDUs for this channel.
    FAPI_UINT8      padding[3];
} FAPI_T_N_PDU_LIMIT;

//Unable to free HARQ_BUFFER Error Code.
typedef struct PACK_STRUCT FAPI_S_HARQ_BUFFER_RELEASE_FAILURE {
    FAPI_UINT32     handle;                         //An opaque handling
    FAPI_UINT16     rnti;                           //The RNTI used for identifying the UE for which the HARQ buffer sohuld be released (1->65535)
    FAPI_UINT8      padding[2];
} FAPI_T_N_HARQ_BUFFER_RELEASE_FAILURE;

//Unable to find in PUSCH HASH Table RNTI with repetition number > 1
typedef struct PACK_STRUCT FAPI_S_ULSCH_INVALID_REPETITION_NUM {
    FAPI_UINT16     rnti;
    FAPI_UINT16     repetition_num;
    FAPI_UINT16     padding[2];
} FAPI_T_ULSCH_INVALID_REPETITION_NUM;

//N_PDU_LIMIT_SURPASSED Error Code.
typedef struct PACK_STRUCT FAPI_S_PUCCH_INDICES_OVERLAP {
    FAPI_UINT16     received_requests;              //number of received request for this format.
    FAPI_UINT16     subframe_num;                   //The subframe with the miss match..
    FAPI_UINT32     rnti;                           //pucch format.
    FAPI_UINT32     pucch_index;
} FAPI_T_PUCCH_INDICES_OVERLAP;

//FAPI_E_INVALID_CFI Error Code.
typedef struct PACK_STRUCT FAPI_S_INVALID_CFI {
    FAPI_UINT16     invalid_cfi;                    //cfi recieved from the MAC.
    FAPI_UINT16     max_valid_cfi;                  //Max valid CFI
} FAPI_T_INVALID_CFI;

//FAPI_E_CSI_RS_INVALID_CONFIGURATION_GAP
typedef struct PACK_STRUCT FAPI_S_CSI_RS_INVALID_CFG_GAP {
    FAPI_UINT8      invalid_gap;                    // recieved gap from configurations
    FAPI_UINT8      expected_gap;                   // Expected Gap from DSP limitation
    FAPI_UINT16     subcarrier_idx;                 // The subcarrier where the error is
}FAPI_T_CSI_RS_INVALID_CFG_GAP;

//FAPI_E_CSI_RS_UNSUPPORTED_SYMBOL
typedef struct PACK_STRUCT FAPI_S_CSI_RS_UNSUPPORTED_SYMBOL {
    FAPI_UINT16     recieved_symbol;                    // recieved symbol from configuration
    FAPI_UINT16     expected_symbol;                    // expected symbol from configuration
    FAPI_UINT32     frame_duplexing;                    // current frame duplexing
}FAPI_T_CSI_RS_UNSUPPORTED_SYMBOL;

//FAPI_E_CSI_RS_INVALID_NUM_OF_CONFIGURATIIONS
typedef struct PACK_STRUCT FAPI_S_CSI_RS_INVALID_NUM_CFG {
    FAPI_UINT16     num_of_cfg;                 // recieved number of configurations
    FAPI_UINT16     max_num_of_cfg;             // max number of configurations
}FAPI_T_CSI_RS_INVALID_NUM_CFG;

//FAPI_E_CSI_RS_INVALID_CONFIG_OFFSET
typedef struct PACK_STRUCT FAPI_S_CSI_RS_INVALID_CFG_OFFSET {
    FAPI_UINT16     cfg_offset;                 // recieved offset from first RE
    FAPI_UINT16     max_cfg_offset;             // max offset from first RE
}FAPI_T_CSI_RS_INVALID_CFG_OFFSET;

//FAPI_E_CSI_RS_INVALID_SF
typedef struct PACK_STRUCT FAPI_S_CSI_RS_INVALID_SF {
    FAPI_UINT8      subframe_num;               // subframe number
    FAPI_TBOOL      is_special_sf;              // is this a special subframe. True/False
    FAPI_UINT16     reserved;
}FAPI_T_CSI_RS_INVALID_SF;

//FAPI_T_FORCE_DPD_SF_DROP Error Code.
//dpd_status should be taken from enum FAPI_DL_DPD_SF_STATUS_t on FAPI_DL_api.h
typedef struct PACK_STRUCT FAPI_S_FORCE_DPD_SF_DROP {
    FAPI_UINT16     sfn_sf;                         //sfn_sf
    FAPI_UINT16     dpd_status;                     //dpd_status
} FAPI_T_FORCE_DPD_SF_DROP;



//ERROR.indication message
typedef struct PACK_STRUCT FAPI_S_ERROR_IND {
    FAPI_T_MSG_HDR              msg_hdr;            //Message header
    FAPI_UINT8                  msg_id;             //Indicate which message received by the PHY has an error.
    FAPI_UINT8                  error_code;         //The error code.
                                                    //If the value is MSG_PDU_ERR then more detailed error information is included.
    FAPI_UINT8                  error_info[];       //Error information
} FAPI_T_ERROR_IND;

 typedef enum
 {
     FAPI_E_DL          = 0,
     FAPI_E_UL_16QAM    = 1,
     FAPI_E_UL_64QAM    = 2,
     FAPI_E_INVALID
 }FAPI_E_MODULATION;
#ifdef __cplusplus
}
#endif
#endif // _FAP_API_INTERNAL_H_

/*
 * -----------------------------------------------------------
 * End of file
 * -----------------------------------------------------------
 */


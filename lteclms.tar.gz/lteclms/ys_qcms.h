/*
                    IMPORTANT LIMITATION(S) ON USE
                    
This files include the QC platform common define
for Krait and Hexagon interface.
     

    
 
**********************************************************************/

#ifndef __YS_QCMSG_H__
#define __YS_QCMSG_H__
#ifdef QCBC_PLATFORM
#include "fapiApiInternal.h"

/****const variable define*****/
#define YS_TQ_SIZE 10
#define YS_MAX_TX_PERSF 10
#define BCH_PAYLOAD_SIZE_BITS  (24)
#define BCH_PAYLOAD_SIZE_BYTES ((BCH_PAYLOAD_SIZE_BITS)/8)
//fortest
//#define  MAX_SEND_LEN 9470
#define  MAX_SEND_LEN 19000

#define  MSGID_TOOLONG 0x2E

#define  MSGID_LINKTEST_REQ 0x2D
#define  MSGID_LINKTEST_RSP 0x2C
#define TIME_ADVANCE_QC  0
#define  MAX_ANCHOR_NUM  8
#define YS_LTE_MAX_CELLS     2      

#define GET_TIME_INFO(timeInfo, sf_sfn) (timeInfo.sfn = sf_sfn >>4, timeInfo.subframe = sf_sfn & 0xF)

/*** structure define ********/
/*
  Ys layer timer related function
*/
typedef struct _ysStCb
{
	CmTqCp		 tmrTqCp;
	CmTqType 	 tmrTq[YS_TQ_SIZE];
	CmTimer		 tmr;
}YsStCb;
PUBLIC  YsStCb         ysStCb;
typedef enum ysTmr 
{
   YS_TMR_PARREQ_TMROUT0 = 0,
   YS_TMR_PARREQ_TMROUT1,
   YS_TMR_CONFREQ_TMROUT0,
   YS_TMR_CONFREQ_TMROUT1,
   YS_TMR_STARTREQ_TMROUT0,
   YS_TMR_STARTREQ_TMROUT1,
   YS_TMR_PARREQ_TMROUT6,
   YS_TMR_PARREQ_TMROUT7,
   YS_TMR_NUM,
}ysTimer;

typedef struct YSQcTmrCb
{
	S32  remainTicks;
	U32  evntTmr;
	U32  tmrDual;
	U8   validFlag;
}YSQcTmrCb_S;


typedef struct ysQcPhyLstCp
{
	FAPI_T_MSG_HDR*   msg[YS_MAX_TX_PERSF];
	U32               count;
} YsQcPhyLstCp;

typedef struct PACK_STRUCT FAPI_S_LONGMSG_HDR {
     FAPI_UINT8             type;                   //Message type ID
     FAPI_UINT8             sequence:4;
     FAPI_UINT8             totalSeg:2;                //
     FAPI_UINT8           	currSeg:2;                //
     FAPI_UINT16            len;                    //Length of vendor-specific message body (bytes)
} FAPI_T_LONGMSG_HDR;

typedef struct QcDlMsgInfo
{
    U8                ctrInfoRdy;
    U8                ctrArrved;
    TfuCntrlReqInfo*  pCntrlReqInfo;	
    U8                datInfoRdy;
    U8                datArrved;
    TfuDatReqInfo*    pDatReqInfo;
} QcDlMsgInfoS;

#ifdef NXP_PLATFORM
typedef struct NxpShareMemInfo
{
    U32          size;
    U32          offset;
    U32          Paddress;
    U32          Vaddress;
} NxpShareMemInfoS;
#endif
typedef struct QcUlMsgInfo
{   
    U8              receivedSrNum;
    FAPI_T_MSG_HDR* pSrInd[MAX_ANCHOR_NUM];
    U8              receivedCqiNum;
    FAPI_T_MSG_HDR* pCqiInd[MAX_ANCHOR_NUM];
    U8              receivedUlschNum;
    FAPI_T_MSG_HDR* pUlschInd[MAX_ANCHOR_NUM];
    U8              receivedCrcNum;
    FAPI_T_MSG_HDR* pCrcInd[MAX_ANCHOR_NUM];
    U8              receivedHarqNum;
    FAPI_T_MSG_HDR* pHarqInd[MAX_ANCHOR_NUM];
} QcUlMsgInfoS;

#if 0
typedef struct ysAnChorInfo
{
   Pst            lmPst;            /* Layer manager post structure. */
   U16            enbaId;  
   U32            fapiHenbAPort;   //shoube be sent to dnode
   U32            fapiHenbAIp;      //shoube be sent to dnode
   U8             plfrmType;    //0:QC platform;1:Intel  
   U8             status;
}ysAnChorInfoS;


typedef struct QcAnchorInfo
{
	ysAnChorInfoS AnchorInfo[MAX_ANCHOR_NUM];
	U8            attachedAnchorNum;
	U8            activedAnchorNum;
}QcAnchorInfoS;
#endif
/*********************************
 *  Carrier BW options
 *********************************/
typedef enum {
	DAN_E_ANT_BW1p4MHz	= 0L,
	DAN_E_ANT_BW3MHz	= 1L,
	DAN_E_ANT_BW5MHz	= 2L,
	DAN_E_ANT_BW10MHz	= 3L,
	DAN_E_ANT_BW15MHz	= 4L,
	DAN_E_ANT_BW20MHz	= 5L,
} DAN_E_CARRIER_BW;

extern PUBLIC U8 ysqcTddUlDlSubfrmTbl[7][10];

/******function declare****************/
extern int ipc_sendMsgbyIpcHigh(char *data, const int len, const int carrierId);
S16 ys_qcSendParReq();
PUBLIC S16 ysActvTmr(Ent ent,Inst  inst);
PUBLIC Void ys_PrcTmrExpiry(Ptr cb,S16 tmrEvnt);
void ys_qcRachIndHdl(FAPI_T_MSG_HDR* pstrQcMsgHdr);
void ys_qcsendLintTestReq(const int carrierId);

extern S16 ys_qcPrcCntrlReq(YsCellCb *cellCb, TfuCntrlReqInfo *cntrlReq);
extern S16 ys_qcPrcDataReq(YsCellCb *cellCb,TfuDatReqInfo* datReq);
extern S16 ys_qcUlmPrcRecpReq(YsCellCb *cellCb, TfuRecpReqInfo *recpReq);
void ys_qcPrcSrsInd(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId);
S16 ys_qcRxDlCqiHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId);
void ys_qcHarqIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId);
void ys_qcRxSrIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId);
void ys_qcCrcIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId);
void ys_qcRxUlschIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId);
void ys_qcRachIndHndl(FAPI_T_MSG_HDR* pMsgHdr, const int carrierId);
S16  ys_qcSendtoPhy(char *data, const int len, const int carrierId);
U8 ys_qcGetDciSize( U16 duplexing, DAN_E_CARRIER_BW bandwidth_index, U32 dci_format, U8 associated_UL, U8 carrirer_ind_flag,
                          U16 csi_req_size,U8 srs_reqflag,U8 less_ul_rbs, U16 tm , U8 ulDl);
void ys_qcsendEmptyDlConfigReq(U16 frame, U8 subframe,const int carrierId);
void ys_qcsendEmptyUlConfigReq(U16 frame, U8 subframe,const int carrierId);

#endif
#endif

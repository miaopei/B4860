/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************

     Name:     LTE MAC Convergence Layer

     Type:     C source file

     Desc:     C source code for lower interface of Convergence Layer

     File:     ys_ms_linf.c

     Sid:      yw_ms_inf.c@@/main/TeNB_Main_BR/5 - Mon Aug 11 16:42:38 2014

     Prg:      mraj

**********************************************************************/

#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_FILE_ID=253;
static int RLOG_MODULE_ID=1;

/* Piece of Code taken from MSPD Convergence layer and modified according TeNB needs */

extern unsigned int rgl_DCI0Cnt;

#include "envopt.h"        /* environment options */
#include <stdlib.h>

#ifdef TENB_RTLIN_CHANGES

/* header include files -- defines (.h) */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_lte.h"
#include "ctf.h"           /* CTF defines */
#include "lys.h"           /* layer management defines for LTE-CL */
#include "tfu.h"
#include "ys_ms.h"         /* defines and macros for CL */
#include "ys_ms_err.h"        /* YS error defines */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"
#include "ctf.x"           /* CTF types */
#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"


#ifdef MLOG_XEON
#include "mlog_com.h"
#endif

/* Silicon Includes */
#ifdef INTEL_ALLOC_WLS_MEM
#include "wls_lib.h"
#endif
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "resultcodes.h"
#include "apidefs.h"
#endif
#ifdef TENB_RTLIN_CHANGES
#ifndef XEON_SPECIFIC_CHANGES
#include "ctrlmsg.h"
#endif
#else
#include "appinit.h"
#endif /*TENB_RTLIN_CHANGES*/

#include "ys_ms.x"            /* typedefs for CL */


#define YS_RX_TASK_PRIORITY   99         /* Taken from mspd test mac */
#define YS_RX_TASK_POLICY     SCHED_FIFO /* Taken from mspd test mac */

#ifdef INTEL_ALLOC_WLS_MEM

extern U8 gMeasSubframe;
typedef struct _tagZBC_LIST_ITEM
{
	void         *pMsg;
	U32           MsgSize;
} _ZBC_LIST_ITEM, *_PZBC_LIST_ITEM;


void *ysWlsVaToPa(void * ptr)
{
    return (void *)WLS_VA2PA(mtGetWlsHdl(), ptr);
}

void *ysWlsPaToVa(void * ptr)
{
    return WLS_PA2VA(mtGetWlsHdl(), (PTR)ptr);
}

//static int yscount;
void * ysAllocWlsBuffer()
{
   Data  *data;
   SGetSBufWls(0, 0, &data, YS_WLS_BFR_SZ);

   RETVALUE((void *)data);

}

PUBLIC S16 ysFreeWlsBuffer(void *bfr)
{
   S16  ret = ROK;
   ret = SPutSBufWls(0, 0, (Data *)bfr, YS_WLS_BFR_SZ);

   RETVALUE(ret);
}

int  ysWlsReady(void)
{
    int ret = 0;
    ret = WLS_Ready(mtGetWlsHdl());

    return ret;
}


int ysWlsAddNBlocksToUl(U32 blkNumsToAdd)
{
    void * pMsg;

    while(blkNumsToAdd)
    {
       blkNumsToAdd--;
       pMsg = (void *)ysAllocWlsBuffer();
       WLS_EnqueueBlock(mtGetWlsHdl(),(PTR)ysWlsVaToPa(pMsg));
    }

    RETVALUE(ROK);
}


int ysWlsAddBlocksToUl(void)
{
    int ret = 0;

    void * pMsg = (void *)ysAllocWlsBuffer();

    if(pMsg) {
        /* allocate blocks for UL transmittion */
        while(WLS_EnqueueBlock(mtGetWlsHdl(),(PTR)ysWlsVaToPa(pMsg))){
              ret++;

              pMsg = (void *)ysAllocWlsBuffer();
              if(!pMsg)
                break;
        }

        // free not enqueued block
        if(pMsg)
            ysFreeWlsBuffer((void *)pMsg);
    }

    return ret;
}


int ysWlsWait(void)
{
    int ret = 0;
    ret = WLS_Wait(mtGetWlsHdl());

    return ret;
}


unsigned int  ysWlsRecv (unsigned long* data, unsigned short *msgType,
                       unsigned short* flags)
{
    unsigned int msgSize = 0;

    *data = (unsigned long) WLS_Get(mtGetWlsHdl(), &msgSize, msgType, flags);

    return msgSize;
}

int   wlsTrCnt = 0;

int ysWlsPut(void* pMsg, unsigned int MsgSize, unsigned short MsgTypeID,
                                                 unsigned short flags)
{
    int ret = 0;
    wlsTrCnt++;
#ifdef MSPD_MLOG_NEW
    U32  tP = 0;
    static int BlkId = 1;
#endif

#ifdef MSPD_MLOG_NEW
    if(flags == WLS_SG_FIRST)
    {
      BlkId++; 
    }
#endif

    if(wlsTrCnt > 100)
    {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"wlsTrCnt is high ******[%d] \n",wlsTrCnt); 
      RLOG1(L_DEBUG,"wlsTrCnt is high ****** %d", wlsTrCnt);
    }  

#ifdef MSPD_MLOG_NEW
    tP = GetTIMETICK();
#endif

    ret = WLS_Put(mtGetWlsHdl(), (PTR)pMsg, MsgSize, MsgTypeID, flags);

#ifdef MSPD_MLOG_NEW
     MLogTask(PID_CL_WLS_MSG, RESOURCE_LARM, tP, GetTIMETICK());
     {
        U32 mlogVars[10], mlogVarsCnt = 0;
        mlogVars[mlogVarsCnt++] = 0xDEADBEEF;
        mlogVars[mlogVarsCnt++] = (U32)(BlkId);
        mlogVars[mlogVarsCnt++] = (U32)(MsgSize);
        mlogVars[mlogVarsCnt++] = (U32)(MsgTypeID);
        mlogVars[mlogVarsCnt++] = (U32)(flags);
        MLogAddVariables((U32)mlogVarsCnt, (U32 *)mlogVars, tP);
     }
#endif

    return ret;
}

#endif /* INTEL_ALLOC_WLS_MEM */

#ifndef RGL_SPECIFIC_CHANGES
#if defined (TL_ALLOC_ICC_MEM) && !defined (INTEL_ALLOC_WLS_MEM)
PRIVATE Bool ysMsLimPhyPrcMsg(U8 msgType,  Ptr msg)
{
   Bool ret;
   switch(msgType)
   {
      case PHY_TXSTART_IND:
      case PHY_RXSDU_IND:
      case PHY_RXEND_IND:
      case PHY_INIT_IND:
      case PHY_START_CONF:
      {
         ret = TRUE;
      }
      break;
      case PHY_RXSTART_CONF:
      {
         PINITIND rxStartCnf = (PINITIND)msg;
         if(rxStartCnf->status != 0)
         {
            ysMsUtlPrntErrInfo(rxStartCnf->status);
         }
         ret = FALSE; 
      }
      break;
      case PHY_RXSTATUS_IND: 
      {
         PRXSTATUSIND     pRxStatusInd = (PRXSTATUSIND)msg;
         if ((pRxStatusInd->eventNumber != 0) && 
            ((pRxStatusInd->statusType == PRACH_RESULT) ||
              pRxStatusInd->statusType == CQIRIHI_RESULT)) 
         {
            ret = TRUE;
         }
         else
         {
            ret = FALSE;
         }
      }
      break;
/* LTE_UNLICENSED */
      case PHY_ERROR_IND:
         {
            ret = FALSE;
            break;
         }

      default:
            ret = FALSE;
   } /* Switch  msgType */
/* LTE_UNLICENSED */
   if ((ret == FALSE) && ((msgType != PHY_RXSTATUS_IND) && (msgType !=4)) && (msgType != PHY_ERROR_IND))
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"SPstTsk avoided for %d\n", msgType);
      RLOG1(L_DEBUG,"SPstTsk avoided for %d", msgType);
      mtStopHndlr();
      exit(0);
   }
   RETVALUE(ret);
}

PRIVATE Bool ysIsPstRequired(U32 size, Void *msg)
{
   U32          isList;   
   PGENMSGDESC  pMsgDesc;
   Bool         ret;

   if (msg == NULLP)
   {
      RLOG0(L_ERROR,"ysIsPstRequired : Empty msg received");
      RETVALUE(FALSE);
   }

   isList = (((MSGHEADER *)msg)->msgID == PHY_LTE_MSG_LIST);

   if (!isList)
   {
      pMsgDesc = (PGENMSGDESC) MsgGetDataOffset((PTR)msg);
      ret = ysMsLimPhyPrcMsg(pMsgDesc->msgType, pMsgDesc);
      if (FALSE == ret)
      {
         ysFreePhyMsg(msg);
      }
   }
   else
   {
#if 0
#else
      ret = TRUE;
#endif
   } /* else - not islist */

   RETVALUE (ret);
}

PRIVATE Void ysSendRcvdPhyMsgToMainThrd(U32 size, Void *msg)
{
   Buffer   *mBuf = NULLP;
   if ((ysIsPstRequired(size, msg)) == TRUE)
   {
      if (SGetMsg(ysCb.ysInit[0].region, ysCb.ysInit[0].pool, &mBuf) != ROK)
      {
         STKLOG(STK_MD_YS,STK_LOG_ERR,"error: SGetMsg failed in %s\n", __func__);
         return;
      }
      cmPkPtr(msg, mBuf);
      SPkU32(size, mBuf);
      SPstTsk(&ysCb.clPst, mBuf);
   }
}
#endif
#endif

#ifdef MLOG_XEON
PUBLIC U32  mlogTimeRef=0;
#endif

PUBLIC Void ysMtTskHdlr(Void)
{
   register U32 get;
#if !defined (INTEL_ALLOC_WLS_MEM)
   get = tlCheckRecv(ysCb.tlHndl);
   while(get--) /* process the number of received messages */
   {
      Void *buffer = tlAlloc(ysCb.tlHndl);//ysAllocPhyMsg();
      tlRecv(ysCb.tlHndl, buffer);
      if(tlIsDataBelong(NULLP, buffer))
      {
         U32       isList = ((MSGHEADER *)buffer)->msgID == PHY_LTE_MSG_LIST;
         
#ifdef DEBUGP         
         MSGHEADER *hdr = (MSGHEADER *)buffer;
         if (!(hdr->control & CTRL_BYPASS))
         {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"%s: error: Invalid msg from PHY\n", __func__);
            RETVOID;
         }
#endif         
      
         ysReceivePHYMsg(isList, (PTR)buffer);
      }
#ifdef DEBUGP      
      else
      {
         STKLOG(STK_MD_YS,STK_LOG_ERR,"Invalid Message Received \n");
         /* TODO Release buffer */
      }
#endif      
   }
#else
   U32             l1MsgNum;
   //static U32      phyEnqPendMsgCnt = 0;
   U16         msgType = 0;
   U16         flags = 0;
   Void        *buffer;
   PMAC2PHY_QUEUE_EL pElm   = NULL;
   PMAC2PHY_QUEUE_EL pFirst = NULL;
   PMAC2PHY_QUEUE_EL pPrev  = NULL;
   U32         isList = 1;

#ifdef MLOG_XEON
   MLogTask(0, 20, mlogTimeRef, tlMlogTick());
#endif

   //ysDbgUpdateTS(1);
#if 0  /* ANOOP:: Added this to postpone Enqueue blocks later part of TTI processing */
   if(phyEnqPendMsgCnt)
   {
      ysWlsAddNBlocksToUl(phyEnqPendMsgCnt);
      phyEnqPendMsgCnt = 0;
   }
#endif

   CM_MEAS_TIME(gMeasSubframe, CM_DBG_MAC_TTI_IND, CM_DBG_WLS_WAIT);                                          
   get = ysWlsWait();
   CM_RESET_TIME(((gMeasSubframe+1)%10));
   CM_GET_TIME_REF(((gMeasSubframe+1)%10), CM_DBG_MAC_TTI_IND);

#ifdef MLOG_XEON
   mlogTimeRef  = tlMlogTick();
#endif



   l1MsgNum = get;
   //phyEnqPendMsgCnt = l1MsgNum;

   pFirst = NULL;
   pPrev  = NULL;

   while(get) // gather list
   {

       ysWlsRecv((void *)&buffer, &msgType, &flags);

       if (pFirst == 0)
         pFirst = buffer;

       buffer =  ysWlsPaToVa(buffer);

       pElm = (PMAC2PHY_QUEUE_EL) buffer;

       //pPhyMsg = (PGENMSGDESC) (pElm + 1);

       if(pPrev)
          pPrev->Next = ysWlsVaToPa(pElm);// Physical

       pPrev = pElm;

       get--;
   }

   if(l1MsgNum) {
   //ysDbgUpdateTS(2);
       CM_MEAS_TIME(((gMeasSubframe+1)%10), CM_DBG_MAC_TTI_IND, CM_DBG_PHY_RECV);
       CM_ADD_INFO(((gMeasSubframe+1)%10),CM_DBG_PHY_RECV, l1MsgNum);
       ysWlsAddNBlocksToUl(l1MsgNum);
       CM_MEAS_TIME(((gMeasSubframe+1)%10), CM_DBG_MAC_TTI_IND, CM_DBG_ADD_PHY_BLK);
       CM_STR_INFO_SET(((gMeasSubframe+1)%10));
       CM_MEM_SET_INDEX(((gMeasSubframe+1)%10));
       // send to MAC
       pElm->Next = 0;

       ysReceivePHYMsg(isList, (PTR)pFirst);
   //ysDbgUpdateTS(3);
   }

#endif
   RETVOID;
} /* ysMtTskHdlr */

#ifndef XEON_SPECIFIC_CHANGES

PUBLIC Void ysMtRcvPhyMsg(U32 msgCount)
{
   PRIVATE U8 _buffer[MSG_MAXSIZE+32];
   Void *buffer = (Void *)((((U32)&_buffer[31]) >> 5) << 5);
   U32 msgSize;
   while(msgCount--) /* process the number of received messages */
   {
      msgSize = tlRecv(ysCb.tlHndl, buffer);
      if(msgSize == 0)
      {
         /* No further messages */
         STKLOG(STK_MD_YS,STK_LOG_ERR,"%s: error: Invalid msgSize(0) from PHY\n", __func__);
         break;
      }
      U32       isList = ((MSGHEADER *)buffer)->msgID == PHY_LTE_MSG_LIST;

#ifdef DEBUGP         
      MSGHEADER *hdr = (MSGHEADER *)buffer;
      if (!(hdr->control & CTRL_BYPASS))
      {
         STKLOG(STK_MD_YS,STK_LOG_ERR,"%s: error: Invalid msg from PHY\n", __func__);
         RETVOID;
      }
#endif         

      ysReceivePHYMsg(isList, (PTR)buffer);
   }
   RETVOID;
}

PUBLIC Void ysMtReadPhyMsg(Void)
{
   U32 msgSize;
   while(1)
   {
      Void *buffer = tlAlloc(ysCb.tlHndl);//ysAllocPhyMsg();
      
      msgSize = tlRecv(ysCb.tlHndl, buffer);


      if(msgSize == 0)
      {/* No further messages */
         tlFree(ysCb.tlHndl,buffer);
         break;
      }else
      {/* Process the msg */

         if(tlIsDataBelong(NULLP, buffer))
         {
            U32       isList = ((MSGHEADER *)buffer)->msgID == PHY_LTE_MSG_LIST;

#ifdef DEBUGP         
            MSGHEADER *hdr = (MSGHEADER *)buffer;
            if (!(hdr->control & CTRL_BYPASS))
            {
               STKLOG(STK_MD_YS,STK_LOG_ERR,"%s: error: Invalid msg from PHY\n", __func__);
               RETVOID;
            }
#endif
            ysReceivePHYMsg(isList, (PTR)buffer);
         }
         else
         {
            STKLOG(STK_MD_YS,STK_LOG_ERR,"\nInvalid Message Received  hndl %p\n",ysCb.tlHndl);
            /* TODO Release buffer */
         }
      }
      msgSize = 0;
   }
   RETVOID;
}

PUBLIC Void ysPhyMsgRxTsk(Void)
{
    S32 get;

    while (1)
    {
#ifdef XXX_TASK_MEAS
       VOLATILE U32     startTime = 0;
#endif
       get = tlCheckRecv(ysCb.tlHndl); /* blocks */
       /*starting Task*/
       SStartTask(&startTime, PID_PHY_RCVR_THRD);
       while (get-- >= 1)
       {
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
          Void *buffer = ysAllocPhyMsg(YS_MS_MAX_MEM_SIZE);
#else
          Void *buffer = ysAllocPhyMsg();
#endif
          STKLOG(STK_MD_YS,STK_LOG_INFO,"334: calling ysAllocPhyMsg function \n");
#ifdef TL_ALLOC_ICC_MEM
          U32 size = tlRecv(ysCb.tlHndl, buffer);
          /*print_dbg(" get =%d", get);*/
          /*print_dbg(" buffer 0x%X, size%d", buffer, size);*/
          if (!size)
#endif
          {
             STKLOG(STK_MD_YS,STK_LOG_ERR," Zero size buffer received\n");
          }
#if defined (TL_ALLOC_ICC_MEM) && !defined (INTEL_ALLOC_WLS_MEM)
          ysSendRcvdPhyMsgToMainThrd(size, buffer);
#else
             YsLiMsgHandler(NULL, buffer);
#endif
       }
       /*stopping Task*/
       SStopTask(startTime, PID_PHY_RCVR_THRD);
       /*usleep(40);*/
    }
    RETVOID;
}
#endif

#ifndef RGL_SPECIFIC_CHANGES

#define RoundUp32(x)            (((x)+3)&(~3)) /* taken from mspd */

/* This func taken from mspd */
PRIVATE Void ysMsgAppendU32(PMSGHEADER msg, U16 paramID, U32 paramData)
{
    PPARAMHEADER ptr = (PPARAMHEADER) &msg->param[RoundUp32(msg->length) / sizeof(U32)];

    ptr->paramID = paramID;
    ptr->length = sizeof(U32);      // Use real length
    ptr->data[0] = paramData;

    msg->length = RoundUp32(msg->length) + sizeof(PARAMHEADER);
    return;
}
#endif

#if ((defined (TL_ALLOC_ICC_MEM)) && !(defined (INTEL_ALLOC_WLS_MEM)))
Void   *ShmIccHdl;

/*
 * @param size Size of data chunk
 * @param data Pointer to the data
 */
PRIVATE U32 ysMsTxRxVecPreDesc(U32 *zbcApi, U32 *idx, PMAC2PHY_QUEUE_EL crnt)
{
   U8 indx =  0; 

   if(crnt->MessageType == PHY_TXSTART_REQ) 
   {
      PDLSUBFRDESC pDlSubFrm =(PDLSUBFRDESC )(((U8 *)(crnt + 1)) + sizeof(GENMSGDESC));
      U32 dlSubFrmInc = (U32)pDlSubFrm;
      //ULCh + header
      //TXSTART_REQ + DLChannelDesp
      if(pDlSubFrm->numberofChannelDescriptors > pDlSubFrm->numCtrlChannels)
      {
         indx = pDlSubFrm->numberofChannelDescriptors - pDlSubFrm->numCtrlChannels;
      }

      zbcApi[(*idx)++] = (U32)TL_VA2PA(ysCb.ysIccHdl,(void *)crnt);
      zbcApi[(*idx)++] = ((U32 )(&pDlSubFrm->dlCh[indx]) - (U32)crnt);

      //DCIChDesp
      if(pDlSubFrm->numCtrlChannels > 0)
      {
         zbcApi[(*idx)++] = (U32)TL_VA2PA(ysCb.ysIccHdl, (void *)(dlSubFrmInc + pDlSubFrm->offsetDCIChannels));
         zbcApi[(*idx)++] = pDlSubFrm->numCtrlChannels * sizeof(DCICHANNELDESC);
      }

      //PWRCTL 
      if(pDlSubFrm->offsetPowerCtrl > 0)
      {
         zbcApi[(*idx)++] = (U32)TL_VA2PA(ysCb.ysIccHdl, (void *)(dlSubFrmInc + pDlSubFrm->offsetPowerCtrl));
         zbcApi[(*idx)++] = sizeof(DLCMNTXPWRCTL);
      }
   }
   else if(crnt->MessageType == PHY_RXSTART_REQ)
   {
      PULSUBFRDESC pUlSubFrm = (PULSUBFRDESC )(((U8 *)(crnt + 1)) + sizeof(GENMSGDESC));
      U32 ulSubFrmInc = (U32)pUlSubFrm;

      //Header + UlCh
      if(pUlSubFrm->numberofChannelDescriptors > pUlSubFrm->numberOfCtrlChannelDescriptors)
      {
         indx = pUlSubFrm->numberofChannelDescriptors - pUlSubFrm->numberOfCtrlChannelDescriptors;
      }
      zbcApi[(*idx)++] = (U32)TL_VA2PA(ysCb.ysIccHdl,(void *)crnt);
      zbcApi[(*idx)++] = ((U8 *)&pUlSubFrm->ulCh[indx] - (U8 *)crnt);

      //UlCtlCh 
      if(pUlSubFrm->numberOfCtrlChannelDescriptors > 0)
      {
         zbcApi[(*idx)++] = (U32)TL_VA2PA(ysCb.ysIccHdl, (void *)(ulSubFrmInc + pUlSubFrm->offsetULCtrlChannels));
         zbcApi[(*idx)++] = pUlSubFrm->numberOfCtrlChannelDescriptors * sizeof(ULCTRLCHDESC);
      }

      //SRS Info
      if(pUlSubFrm->offsetsrsInfo > 0)
      {
         zbcApi[(*idx)++] = (U32)TL_VA2PA(ysCb.ysIccHdl, (void *)(ulSubFrmInc + pUlSubFrm->offsetsrsInfo));
         zbcApi[(*idx)++] = sizeof(SRSDED);
      }

      //Rach Control Structure
      if(pUlSubFrm->offsetRachCtrlStruct > 0)
      {
         zbcApi[(*idx)++] = (U32)TL_VA2PA(ysCb.ysIccHdl, (void *)(ulSubFrmInc + pUlSubFrm->offsetRachCtrlStruct));
         zbcApi[(*idx)++] = sizeof(RACHCTRL);
      }
   }
   else if(crnt->MessageType == PHY_BATCH_MSG_REQ)
   {
      PTXSDUREQ  txSduReq = (PTXSDUREQ)(crnt + 1);
      PZBCAPI pZbcApi = NULLP;
      S16 numBlocks = crnt->NumMessageInBlock;
      
      if(numBlocks == 0)
      {
         if(txSduReq)
            STKLOG(STK_MD_YS,STK_LOG_INFO,"[HK]- txSduReq->msgType:%d, txSduReq->channelType:%d, pTxSdu:%p,msgLen:%d\n",
                  txSduReq->msgType, txSduReq->channelType,(void *) txSduReq->pTxSdu, txSduReq->msgLen);
         else
            STKLOG(STK_MD_YS,STK_LOG_ERR,"[HK]- txSduReq is NULL \n");

      }

      do{
         numBlocks--;
#ifndef EMTC_ENABLE
         if((txSduReq->msgType == PHY_TXSDU_REQ) && 
               (txSduReq->channelType != PDCCH))
#else
         if((txSduReq->msgType == PHY_TXSDU_REQ) && 
                (txSduReq->channelType != PDCCH) && 
               (txSduReq->channelType != MPDCCH))
#endif
         {
            pZbcApi =  (PZBCAPI)(txSduReq + 1);
            while((pZbcApi->msgPtr != NULL) && 
                  (pZbcApi->msgSize != 0))
            {
               zbcApi[(*idx)++] =(PTR) pZbcApi->msgPtr;

               /* Cache cleaning only the header(RLC/MAC/PDCP) of the TB:
                  The PDCP header remains constant irrespective of the size
                   of the data packet pumped.
                  The RLC header varies based on the buffer occupancy and the
                   grant allocated by the scheduler.
                  The MAC header varies based on the number of MAC control
                    elements and the number of logical channels carrying
                     the data in that TTI for a UE.
                  So only the RLC header size is directly dependent on the
                   size of actual data transmitted.
                  When eNB is pumped with 100Mbps of data traffic with 64bytes of
                   packet length of the RLC header is 50bytes. so if the dBlk
                   size is > 64 then it is assumed to be data packet(clean only 32 bytes)
                   else it is treated as RLC/MAC subheaders(clean complete message size).
                  With this assumption the logic is implemented. 
                  Need to implement the logic for contorl signalling messages and NULL 
                    ciphering.
               */
               {
                  zbcApi[(*idx)++] =  pZbcApi->msgSize;
               }
               pZbcApi++;
               if((*idx) >= YS_MS_MAX_ZBC_API_POINT)
               {
                  stop_printf("Array out of bound %lu \n", *idx);
               }
            }
         }
         txSduReq = (PTXSDUREQ)((U8 *)txSduReq + crnt->AlignOffset);
      }while(numBlocks > 0);

      zbcApi[(*idx)++] = (U32)TL_VA2PA(ysCb.ysIccHdl,(void *)crnt);
      zbcApi[(*idx)++] = sizeof(MAC2PHY_QUEUE_EL) + crnt->MessageLen;
   }
   else 
   {
      zbcApi[(*idx)++] = (U32)TL_VA2PA(ysCb.ysIccHdl,(void *)crnt);
      zbcApi[(*idx)++] = sizeof(MAC2PHY_QUEUE_EL) + crnt->MessageLen;
   }

   if(*idx >= YS_MS_MAX_ZBC_API_POINT)
   {
      stop_printf("505: Array out of bound\n");
   }
   RETVALUE(ROK);
}
#elif (defined (INTEL_ALLOC_WLS_MEM))

typedef struct _gblZbcApi
{
   Void          *ptr;
   unsigned long msgSz;
}GblZbcApi;

GblZbcApi gblZbcApi[YS_MS_MAX_ZBC_API_POINT] = {{0},{0}};


PUBLIC S16 ysSendZBCBlocks(unsigned short flags, int *nZbcBlocks)
{
    int ret = 0;
    int n = *nZbcBlocks;
    unsigned short list_flags = flags;
    int     idx = 0;

    //printf("ZBC**\n");

    while(n--){
        if (n == 0 && list_flags == WLS_SG_LAST )
    	   flags = WLS_SG_LAST;
    	else
    	   flags = WLS_SG_NEXT;

        //printf("SZ(%d)\n", gblZbcApi[idx].msgSz);
        ret = ysWlsPut(gblZbcApi[idx].ptr, gblZbcApi[idx].msgSz, 30 /*PHY_ZBC_BLOCK_REQ*/,
                                                                   flags);
        if (ret != 0)
        {
            RETVALUE(RFAILED);
        }
        idx++;
    }

    RETVALUE(ROK);
}

int ysIsSduZbcBlock(PGENMSGDESC pMsgHeader, int *nZbcBlocks, U16 alignOffset, U16 numMsgInBlk)
{
    int idx = 0;

    if(pMsgHeader->msgType == PHY_TXSDU_REQ){
        PTXSDUREQ pTxSdu = (PTXSDUREQ) pMsgHeader;
        if (pTxSdu->channelType != PDCCH){
          while(numMsgInBlk)
          {
            //printf("\n ############ Channel type: %d\n", pTxSdu->channelType);
            numMsgInBlk--;
            _PZBC_LIST_ITEM pZbcItem = (_PZBC_LIST_ITEM ) (pTxSdu + 1);
            while (pZbcItem->pMsg){
               gblZbcApi[idx].ptr   = pZbcItem->pMsg;
               gblZbcApi[idx].msgSz = pZbcItem->MsgSize;
               //printf("Message PTR (%llx), Message SZ(%d)\n", gblZbcApi[idx].ptr, gblZbcApi[idx].msgSz);
               idx++;

                (*nZbcBlocks)++;
                pZbcItem++;
            }
            pTxSdu = (PTXSDUREQ)((U8 *)pTxSdu + alignOffset);
           }
            RETVALUE(1);
        }
    }
    RETVALUE(0);
}



PUBLIC S16 ysWlsSendMsgToPhy(void  *data)
{
    S16                                 ret = ROK;
    PMAC2PHY_QUEUE_EL pCurrMsg          = NULL;
    PMAC2PHY_QUEUE_EL pListElem         = NULL;
    PHIADCIULMSGDESC                    pDci0HiVector;

    PGENMSGDESC pMsgHeader;
    U16         flags;
    S32         nZbcBlocks = 0;
    //U32         wlsMsgCnt;

    wlsTrCnt = 0;
    //wlsMsgCnt = 1;

    if (data != NULL)
    {
        //pListElem = (PMAC2PHY_QUEUE_EL)ysWlsPaToVa((PTR)data);
        pListElem = (PMAC2PHY_QUEUE_EL)((PTR)data);

        pCurrMsg = pListElem;

        if(pCurrMsg->Next)
        {
            flags = WLS_SG_FIRST;
            while (pCurrMsg)
            {
                // only batch mode

                if(pCurrMsg->MessageType == PHY_TXHIADCIUL_REQ)
                {
                     pDci0HiVector = (PHIADCIULMSGDESC)(pCurrMsg + 1);
                     if(pDci0HiVector->numDciUlSdus)
                       rgl_DCI0Cnt++;
                }
                   
                //ysDbgUpdatePHYMsg(wlsMsgCnt);
                //wlsMsgCnt = wlsMsgCnt << 1;
                  
                pMsgHeader = (PGENMSGDESC) (pCurrMsg + 1);
                if (pCurrMsg->Next)
                {   // FIRST/NEXT list element
                    pCurrMsg->Next = ysWlsVaToPa(pCurrMsg->Next);
                    ret = ysWlsPut(ysWlsVaToPa(pCurrMsg),
                                   pCurrMsg->MessageLen +
                                   sizeof(MAC2PHY_QUEUE_EL),
                                   pMsgHeader->msgType, flags );
                    if (ret != 0)
                    {
                        RETVALUE(RFAILED);
                    }

                    nZbcBlocks = 0;
                    if(ysIsSduZbcBlock(pMsgHeader, &nZbcBlocks,
                                       pCurrMsg->AlignOffset,
                                       pCurrMsg->NumMessageInBlock))
                    { // ZBC blocks
                        ret = ysSendZBCBlocks(flags, &nZbcBlocks);
                        if (ret != 0)
                        {
                           RETVALUE(RFAILED);
                        }
                    }

                    pCurrMsg = ysWlsPaToVa(pCurrMsg->Next);
                }
                else /* pCurrMsg->Next */
                {  // LAST
                    int isZbcBlk = 0;

                    flags = WLS_SG_NEXT;
                    nZbcBlocks = 0;

                    isZbcBlk = ysIsSduZbcBlock(pMsgHeader, &nZbcBlocks,
                                               pCurrMsg->AlignOffset,
                                               pCurrMsg->NumMessageInBlock);
                    if(!isZbcBlk)
                      flags = WLS_SG_LAST;

                    ret = ysWlsPut(ysWlsVaToPa(pCurrMsg),
                                 pCurrMsg->MessageLen +
                                 sizeof(MAC2PHY_QUEUE_EL),
                                 pMsgHeader->msgType, flags );
                    if (ret != 0)
                    {
                        RETVALUE(RFAILED);
                    }


                    if(isZbcBlk)
                    { // ZBC blocks
                        flags = WLS_SG_LAST;
                        ret = ysSendZBCBlocks(flags, &nZbcBlocks);
                        if (ret != 0)
                        {
                            RETVALUE(RFAILED);
                        }
                    }
                    pCurrMsg = NULL;
                }  /* pCurrMsg->Next */

                flags = WLS_SG_NEXT;
            }
        }
        else // one block
        {
            pMsgHeader = (PGENMSGDESC) (pCurrMsg + 1);
            if(ysIsSduZbcBlock(pMsgHeader, &nZbcBlocks,
                               pCurrMsg->AlignOffset,
                               pCurrMsg->NumMessageInBlock))
            {
                RETVALUE(RFAILED);
            }

            ret = ysWlsPut(ysWlsVaToPa(pCurrMsg),
                           pCurrMsg->MessageLen +
                           sizeof(MAC2PHY_QUEUE_EL),pMsgHeader->msgType, 0);
            if (ret != 0) {
                RETVALUE(RFAILED);
            }
        }
    }

    RETVALUE(ret);
}
#endif

#ifdef PHY_API_DEBUG
MAC2PHY_QUEUE_EL       logMac2Phy[4096];
U32         idxMac2Phy = 0;
#endif
PUBLIC U32 ysSendMsgToPhy(U32 size, PMAC2PHY_QUEUE_EL data)
{
#ifdef PHY_API_DEBUG	
   {
      MAC2PHY_QUEUE_EL   *crnt = data;
      while (crnt != NULLP)
      {
         if (crnt->MessageType == PHY_TXSDU_REQ)
         {
            PTXSDUREQ	txSduReq = (PTXSDUREQ)ysGetStackPtr(crnt->MessagePtr);
            MSPD_DBG("PHY %p Msg = 0x%x Len = %lu ch = %u.%u\n", (void *)crnt, crnt->MessageType, crnt->MessageLen, txSduReq->channelType, txSduReq->chanId);
         }
         else
         {
            MSPD_DBG("PHY %p Msg = 0x%x Len = %lu\n", (void *)crnt, crnt->MessageType, crnt->MessageLen);
         }
         logMac2Phy[idxMac2Phy] = *crnt;
         idxMac2Phy = (idxMac2Phy + 1) & (4096-1);
         if (crnt->MessagePtr)
         {
            logMac2Phy[idxMac2Phy] = *(PMAC2PHY_QUEUE_EL)ysGetStackPtr(crnt->MessagePtr);
            idxMac2Phy = (idxMac2Phy + 1) & (4096-1);
         }
         crnt = crnt->Next;
      }
   }
#endif
   /* Since we always send everything as a list, fill up the predetermined header
    * info, and link to the list */
#if !defined (INTEL_ALLOC_WLS_MEM)
   MSGHEADER *hdr = (MSGHEADER *)tlAlloc(ysCb.tlHndl);
#ifdef TL_ALLOC_ICC_MEM
   U32 zbcApi[YS_MS_MAX_ZBC_API_POINT] = {0};//Range is temporary
   U32 idx = 0;
#endif
#endif

#ifndef RGL_SPECIFIC_CHANGES


   if(hdr)
      *hdr = ysCb.phymsgHdr;
#else
   if(data)
   {
#endif
      /*Updating header for NMM Messages */   
#ifndef RGL_SPECIFIC_CHANGES
      if(data->MessageType >= NMM_START && data->MessageType <= NMM_CMD)
      {
         hdr->control = 0x10000004;
         hdr->type = 1;
         hdr->dstID=0x8031;
         hdr->msgID=0x5150;
      }

   /* Fill param */
   ysMsgAppendU32(hdr, PHY_QUE_HDR_PARAM_ID, (U32)ysGetPhyPtr(data));
#endif

#ifndef INTEL_ALLOC_WLS_MEM
#ifdef TL_ALLOC_ICC_MEM
   ShmIccHdl = ysCb.ysIccHdl;

   if(!TL_IsIccV(ysCb.ysIccHdl, (unsigned long) data))
   {
     stop_printf("Data is not IccV %p MessageType %d ", data, ((MAC2PHY_QUEUE_EL *)data)->MessageType);
   }
#endif

   /* Set up other physical pointers */
   {
      MAC2PHY_QUEUE_EL   *crnt, *next;
      crnt = (MAC2PHY_QUEUE_EL *)data;
      while (crnt->Next)
      {
         next = crnt->Next;
         crnt->Next = (MAC2PHY_QUEUE_EL *)ysGetPhyPtr(next);
         
#ifdef TL_ALLOC_ICC_MEM
         if(!TL_IsIccV(ysCb.ysIccHdl, (unsigned long) crnt))
         {   
            stop_printf("crnt is not IccV %p MessageType %d ",(void *)crnt ,crnt->MessageType);
         }
         ysMsTxRxVecPreDesc(&zbcApi[0], &idx, crnt);
#endif
         
         crnt = next;
      }

#ifdef TL_ALLOC_ICC_MEM
      if (!crnt->Next)
      {
         if(!TL_IsIccV(ysCb.ysIccHdl, (unsigned long) crnt))
         {   
            stop_printf("crnt is not IccV %p MessageType %d ", (void *)crnt, crnt->MessageType);
         }
         ysMsTxRxVecPreDesc(&zbcApi[0], &idx, crnt);
      } 

      if(idx > 0)
      {
          zbcApi[idx++] = 0;
          zbcApi[idx++] = 0;
/* klocworks fix: verify the value >600  */          
         if(idx > YS_MS_MAX_ZBC_API_POINT)
         {
            stop_printf("Before cache Clean Array out of bound %lu\n", idx);
         }
          TL_CacheClean(ysCb.ysIccHdl, (PZBC_LIST_ITEM) zbcApi);
      }
#endif
   }



   return tlSend(NULLP, size, hdr);
#else
      ysWlsSendMsgToPhy(data);
   }
#endif
   RETVALUE(SUCCESS);
}

#ifdef SPLIT_RLC_DL_TASK
extern Pst phyRcvPst;
extern Buffer *phyRcvThreadMBuf[];
EXTERN Bool g_ys_DC;
PUBLIC Void ysMtPollPhyMsg(/*U8 region*/)
{
   if(TRUE == g_ys_DC)
   {
     receiveQCPhyMsgNewDC();
   }
   else
   {
   //#ifdef NXP_PLATFORM
     receiveNXPPhyMsgNew();
   //#else
     //receiveQCPhyMsgNew();
   //#endif
   }
   return;
#if 0   
   phyRcvPst.intfVer = tlCheckRecv(ysCb.tlHndl);
   if (++phyRcvPst.selector >= YS_NUM_SUB_FRAMES)
      phyRcvPst.selector = 0;

   /* lichangwu, 2017-10-20, I find: if target thread slowly, will be coredump !!! */
   /* lichangwu, 2017-10-30, coredump again! so extend to 10 mBufs for loop!! */
   if (ROK != SPstTsk(&phyRcvPst,phyRcvThreadMBuf[phyRcvPst.selector]))
   {
      printf("\n CL Self Post Failed....\n");
   }

   /* POST a message to MAC thread to read the phy msgs */
   RETVOID;
#endif   
}
#endif

PUBLIC S16 ysPhyCommInit()
{
#ifdef NXP_PLATFORM
   return ipc_init_nxp(1);

#else
   return ipc_init();
#endif
}


#ifndef RGL_SPECIFIC_CHANGES
S16 ysSendNmMsgToPhy (Event event, Buffer * mBuf)
{

   PMAC2PHY_QUEUE_EL pElem;
   Void * nmmRequestMessage = NULLP;
   MsgLen  msgLen;

#ifdef ERRCLASS
   if(NULLP == mBuf)
   {
      RLOG0(L_ERROR," Incorrect Parameter passed as mBuf is NULL");
      RETVALUE(RFAILED);
   }
#endif

#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      RLOG0(L_ERROR," Failed to Get MactoPhy element ");
      RETVALUE(RFAILED);
   }

   /*This is done as we need to get the message len for SCpyMsgFix*/
   SFndLenMsg(mBuf,&msgLen);
   pElem->MessageLen = msgLen;

   /*Get Shared memory to send message to phy*/
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   nmmRequestMessage = ysMsUtlAllocSvsrMsg(FALSE, msgLen);
#else
   nmmRequestMessage = ysMsUtlAllocSvsrMsg(FALSE);
#endif


   SCpyMsgFix(mBuf,0,msgLen,(Data *) nmmRequestMessage,&msgLen);

   YS_MS_FILL_PHY_LIST_ELEM(pElem, 0, 0, ysGetPhyPtr(nmmRequestMessage), msgLen, event);

   STKLOG(STK_MD_YS,STK_LOG_INFO,"\n Sending NMMMessage=[%d] to PHY withlength=[%lu]\n ",pElem->MessageType,pElem->MessageLen);
   ysSendMsgToPhy(pElem->MessageLen, pElem);
   RETVALUE(SUCCESS);

}
#endif

#ifdef ENABLE_CNM
/* FUnction for storing the ICTA msgs */
PUBLIC S16 ysStoreCnmMsg(Event event, Buffer * mBuf)
{
   YsCellCb   *cellCb = NULLP;
   YsPhyLstCp        *pIctaData;
   PMAC2PHY_QUEUE_EL pElem;
   PGENMSGDESC cnmRequestMessage;
   CmLteTimingInfo cnmTime;
   MsgLen          msgLen;
   /*begin: wyb modify for rem ------ bug10175: build cnm*/
   PGENMSGDESC	  pMsgDesc;
   U8             entityId;
   pMsgDesc = (PGENMSGDESC)mBuf;
   entityId = pMsgDesc->phyEntityId;
   
   /* Get the cellCb */
   cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(entityId);
   #if 0
   if((cellCb = ysMsCfgGetCellCfg(ysCb.cellId)) == NULLP)
   #else
   if(NULLP == cellCb)
   #endif
   /*  end: wyb modify for rem ------ bug10175: build cnm*/
   {
      //printf("\n CellCb not found for sending CNM msgs cellId is %d....\n",ysCb.cellId);
      //RLOG_ARG0(L_ERROR,DBG_CELLID,ysCb.cellId,"CellCb not found for sending CNM msgs");
      STKLOG(STK_MD_YS,STK_LOG_ERR,"\n CellCb not found for sending CNM msgs: entityId is %u\n",entityId);
      RETVALUE(RFAILED);
   }
#ifdef ERRCLASS
   if(NULLP == mBuf)
   {
      RLOG0(L_ERROR," Incorrect Parameter passed mBuf NULLP");
   }
#endif
   /*Get Shared memory to send message to phy*/
   cnmRequestMessage = (PGENMSGDESC) ysMsUtlAllocSvsrMsg(FALSE);

   if (cnmRequestMessage == NULLP)
   {
      //RLOG_ARG0(L_FATAL, DBG_CELLID,ysCb.cellId,"Unable to allocate memory for cnmRequestMessage");
	  RLOG0(L_FATAL,"Unable to allocate memory for cnmRequestMessage");
      MSPD_ERR("Unable to allocate memory for TxVector");
      RETVALUE (RFAILED);
   }

   pElem = ysMsUtlGetPhyListElem();
   if (!pElem)
   {
      RLOG0(L_ERROR," Falied to Get MactoPhy element ");
      //RLOG_ARG0(L_ERROR, DBG_CELLID,ysCb.cellId,"Falied to Get MactoPhy element ");
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
      SvsrFreeMsg(cnmRequestMessage);/*FREE_SVSR*/
#else
      ysFreePhyMsg(cnmRequestMessage);
#endif
      RETVALUE(RFAILED);
   }

   /*This is done as we need to get the message len for SCpyMsgFix*/
   SFndLenMsg(mBuf, &msgLen);
   SCpyMsgFix(mBuf,0,msgLen,(Data *) cnmRequestMessage,&msgLen);

   cnmTime = cellCb->timingInfo;
   YS_INCR_TIMING_INFO(cnmTime, TFU_DLCNTRL_DLDELTA + 1); /* msg can receive at any time
                                                           * it can be received after the PHY
                                                           * API msg list was sent.
                                                           * So postponding to next tti */  
#ifdef TENB_RTLIN_CHANGES
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cnmTime.sfn, cnmTime.subframe,
        ysGetPhyPtr(cnmRequestMessage), msgLen, event);
#else
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
        cnmRequestMessage, msgLen, event);
#endif

   pIctaData = &cellCb->ictaMsgLst[cnmTime.subframe].ictaLst;
   cellCb->ictaMsgLst[cnmTime.subframe].ictaMsg = cnmRequestMessage;
   
   
   ysMsUtlAddToPhyList(pIctaData,pElem);

   RETVALUE(SUCCESS);
}

/* Function for sending the ICTA msgs to PHY */
#endif
#endif /* TENB_RTLIN_CHANGES */

/********************************************************************30**

         End of file:     yw_ms_inf.c@@/main/TeNB_Main_BR/5 - Mon Aug 11 16:42:38 2014

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------

*********************************************************************91*/

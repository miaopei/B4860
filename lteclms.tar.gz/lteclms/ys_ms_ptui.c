/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************
 
     Name:     LTE MAC Convergence Layer
  
     Type:     C source file
  
     Desc:     C source code for Entry point fucntions
  
     File:     ys_ptui.c
  
     Sid:      yw_ms_ptui.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:48 2014
  
     Prg:      rk
  
**********************************************************************/

/** @file ys_ptui.c
@brief This module acts as an interface handler for upper interface and 
manages Pst and Sap related information for upper interface APIs.
*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_lte.h"
#include "ctf.h"           /* CTF defines */
#include "lys.h"           /* layer management defines for LTE-CL */
#include "tfu.h"
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "resultcodes.h"
#endif
#ifdef YS_MSPD
#ifndef TENB_RTLIN_CHANGES
#include "diags.h"    /* Silicon Includes */
#endif /*TENB_RTLIN_CHANGES */
#include "ys_ms.h"          /* defines and macros for CL */
#else
#include "ys_ms.h"
#include <sys/time.h>
#endif
#include "ys_ms_err.h"        /* YS error defines */

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
//#include "spaccdrv.h" /*sumanth*/ /* comment out for ys_qcPhy_itf by syq */
#endif
#endif

/* header/extern include files (.x) */
#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"
#include "ctf.x"           /* CTF types */
#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#ifdef YS_MSPD
#include "ys_ms.x"         /* typedefs for CL */
#else
#include "ys_ms.x"            /* typedefs for CL */
#endif
#if defined(PDCP_RLC_DL_RBUF) || defined(MAC_RLC_UL_RBUF) 
#include "ss_rbuf.x"
#endif
#ifdef VE

#ifdef __cplusplus /* ys004.102: name mangling */
EXTERN "C" {
#endif  /*__cplusplus*/

   EXTERN S16 VeLiCtfBndCfm ARGS(( Pst *pst, SuId suId, U8 status));
   EXTERN S16 VeLiCtfCfgCfm ARGS(( Pst *pst, SuId suId, CtfCfgTransId transId,U8 status));
   EXTERN S16 VeLiCtfEnbStopInd ARGS(( Pst *pst, SuId suId, CtfCfgTransId transId));
#ifdef __cplusplus
}
#endif /* __cplusplus */

EXTERN S16 VeLiCtfUeIdChgCfm ARGS(( Pst *pst, SuId suId, CtfCfgTransId transId,CmUeInfo *ueInfo,U8 status));
#endif
#if defined(PDCP_RLC_DL_RBUF) || defined(MAC_RLC_UL_RBUF) 
EXTERN S16 SPrintSRngStats();
#endif

#if !(defined(LCYSUITFU)  && defined(RG) && defined(LWLCYSUITFU))
#define PTYSUITFU
#endif

#if !(defined(LCYSUICTF)  && defined(YS) && defined(LWLCYSUICTF))
#define PTYSUICTF
#endif

extern U32 noStatsTti;


/* MAX Number of Service Users of YS */
#define YS_MAX_TFU_USR   4

/* MAX Number of Service Users of YS */
#define YS_MAX_CTF_USR   4

#ifdef PTYSUITFU
/** @brief This API is used to receive a Bind confirm from CL to MAC.
*/
EXTERN S16 PtUiTfuBndCfm ARGS((Pst* pst, SuId suId, U8 status));
/** @brief This API is used to receive a Bind confirm from CL to scheduler.
*/
EXTERN S16 PtUiTfuSchBndCfm ARGS((Pst* pst, SuId suId, U8 status));
/** @brief This API is used to indication Random Access Request reception from
 * CL to scheduler.
 */
EXTERN S16 PtUiTfuRaReqInd ARGS((Pst * pst, SuId suId, TfuRaReqIndInfo * raReqInd));
/** @brief This API is used to indicate CQI reporting from CL to scheduler.
*/
EXTERN S16 PtUiTfuUlCqiInd ARGS((Pst * pst, SuId suId, TfuUlCqiIndInfo * ulCqiInd));
/** @brief This API is used to indicate HARQ feedback from CL to scheduler.
*/
EXTERN S16 PtUiTfuHqInd ARGS((Pst * pst, SuId suId, TfuHqIndInfo * hqInd));
/** @brief This API is used to indicate a SR reception from CL to scheduler..
*/
EXTERN S16 PtUiTfuSrInd ARGS((Pst * pst, SuId suId, TfuSrIndInfo * srInd));
/** @brief This API is used to indicate the reception of Raw CQI report from CL to
 * scheduler..
 */
#ifdef TENB_RTLIN_CHANGES
EXTERN S16 PtUiTfuRawCqiInd ARGS((Pst * pst, SuId suId, TfuRawCqiIndInfo * rawCqiInd));
EXTERN S16 PtUiTfuSrsInd ARGS((Pst * pst, SuId suId, TfuSrsIndInfo * ulSrsInd));
#endif

/** @brief This API is used to indicate the reception of CQI report from CL to
 * scheduler..
 */
EXTERN S16 PtUiTfuDlCqiInd ARGS((Pst * pst, SuId suId, TfuDlCqiIndInfo * dlCqiInd));
/** @brief This API is used to indicate Data Reception from CL to MAC.
*/
EXTERN S16 PtUiTfuDatInd ARGS((Pst * pst, SuId suId, TfuDatIndInfo * datInd));
/** @brief This API is used to indicate Decode failure from CL to scheduler..
*/
EXTERN S16 PtUiTfuCrcInd ARGS((Pst * pst, SuId suId, TfuCrcIndInfo * crcInd));
/** @brief This API is used to indicate a Timing Advance from PAL to scheduler..
*/
EXTERN S16 PtUiTfuTimingAdvInd ARGS((Pst * pst, SuId suId, TfuTimingAdvIndInfo * timingAdvInd));
/** @brief This API is the TTI indication from CL to MAC.
*/
EXTERN S16 PtUiTfuTtiInd ARGS((Pst * pst, SuId suId, TfuTtiIndInfo * ttiInd));
/** @brief This API is the TTI indication from CL to scheduler.
*/
EXTERN S16 PtUiTfuSchTtiInd ARGS((Pst * pst, SuId suId, TfuTtiIndInfo * ttiInd));
/** @brief This API is used to indicate PUCCH power delta  from CL to scheduler..
*/
EXTERN S16 PtUiTfuPucchDeltaPwrInd ARGS((Pst * pst, SuId suId, TfuPucchDeltaPwrIndInfo* pucchDeltaPwrInd));


/** @brief This API is the ERR indication from CL to scheduler.
*/
EXTERN S16 PtUiTfuErrInd ARGS((Pst * pst, SuId suId, TfuErrIndInfo * errInd));

#if defined(TENB_T2K3K_SPECIFIC_CHANGES) && defined(LTE_TDD)
/** @brief This API is the Non-RT indication from CL to MAC.
*/
EXTERN S16 PtUiTfuNonRtInd ARGS((Pst * pst, SuId suId));
#endif
#endif /*--#ifdef PTYSUITFU--*/

#ifdef PTYSUICTF
/** @brief This API is used to receive a Bind confirm from CL to MAC.
*/
EXTERN S16 PtUiCtfBndCfm ARGS((Pst* pst, SuId suId, U8 status));
/** @brief This API is used to receive a Configuration confirm from CL to MAC.
*/
EXTERN S16 PtUiCtfCfgCfm ARGS((Pst* pst, SuId suId, 
         CtfCfgTransId  transId,U8 status));
EXTERN S16 PtUiCtfKdfCfm(Pst* pst, SuId suId, CtfCfgTransId transId,
                         CtfKdfCfmInfo *kdfCfmInfo, U8 status);
#endif

EXTERN S16 PtUiCtfEnbStopInd ARGS((Pst* pst, SuId suId, 
         CtfCfgTransId  transId));

#ifdef ENABLE_CNM
EXTERN S16 PtUiCtfCnmCellSyncRsp ARGS((Pst* pst, SuId suId, 
         CtfCfgTransId*  transId, CtfCnmCellSyncRsp *ctfCnmCellSyncRsp));

EXTERN S16 PtUiCtfCnmCellSyncInd ARGS((Pst* pst, SuId suId, 
         CtfCfgTransId*  transId, CtfCnmCellSyncInd *ctfCnmCellSyncInd));

EXTERN S16 PtUiCtfCnmInitSyncRsp ARGS((Pst* pst, SuId suId, 
         CtfCfgTransId*  transId, CtfCnmInitSyncRsp *ctfCnmInitSyncRsp));
#endif
/** @brief This API is used to receive a Bind confirm from CL to MAC.
*/
PRIVATE CONSTANT TfuBndCfm YsUiTfuBndCfmMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuBndCfm,
#else
   PtUiTfuBndCfm,
#endif
#ifdef RG
   RgLiTfuBndCfm,
#else
   PtUiTfuBndCfm,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuBndCfm
#else
      PtUiTfuBndCfm
#endif
};

PRIVATE CONSTANT TfuSchBndCfm YsUiTfuSchBndCfmMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuSchBndCfm,
#else
   PtUiTfuSchBndCfm,
#endif
#ifdef RG
   RgLiTfuSchBndCfm,
#else
   PtUiTfuSchBndCfm,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuSchBndCfm
#else
      PtUiTfuSchBndCfm
#endif
};

/** @brief This API is used to indication Random Access Request reception from
 * CL to MAC.
 */
PRIVATE CONSTANT TfuRaReqInd YsUiTfuRaReqIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuRaReqInd,
#else
   PtUiTfuRaReqInd,
#endif
#ifdef RG
   RgLiTfuRaReqInd,
#else
   PtUiTfuRaReqInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuRaReqInd
#else
      PtUiTfuRaReqInd
#endif
};

/** @brief This API is used to indicate CQI reporting from CL to MAC
*/
PRIVATE CONSTANT TfuUlCqiInd YsUiTfuUlCqiIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuUlCqiInd,
#else
   PtUiTfuUlCqiInd,
#endif
#ifdef RG
   RgLiTfuUlCqiInd,
#else
   PtUiTfuUlCqiInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuUlCqiInd
#else
      PtUiTfuUlCqiInd
#endif
};

/** @brief This API is used to indicate HARQ feedback from CL to MAC
*/
PRIVATE CONSTANT TfuHqInd YsUiTfuHqIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuHqInd,
#else
   PtUiTfuHqInd,
#endif
#ifdef RG
   RgLiTfuHqInd,
#else
   PtUiTfuHqInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuHqInd
#else
      PtUiTfuHqInd
#endif
};

/** @brief This API is used to indicate a SR reception from CL to MAC.
*/
PRIVATE CONSTANT TfuSrInd YsUiTfuSrIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuSrInd,
#else
   PtUiTfuSrInd,
#endif
#ifdef RG
   RgLiTfuSrInd,
#else
   PtUiTfuSrInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuSrInd
#else
      PtUiTfuSrInd
#endif
};

#ifdef TFU_UPGRADE
/** @brief This API is used to indicate the reception of CQI report from CL to
 * MAC.
 */
PRIVATE CONSTANT TfuRawCqiInd YsUiTfuRawCqiIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuRawCqiInd,
#else
   PtUiTfuRawCqiInd,
#endif
#ifdef RG
   RgLiTfuRawCqiInd,
#else
   PtUiTfuRawCqiInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuRawCqiInd
#else
   PtUiTfuRawCqiInd
#endif
};

/** @brief This API is used to indicate the reception SRS report from CL to
 * MAC.
 */
PRIVATE CONSTANT TfuSrsInd YsUiTfuSrsIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuSrsInd,
#else
   PtUiTfuSrsInd,
#endif
#ifdef RG
   RgLiTfuSrsInd,
#else
   PtUiTfuSrsInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuSrsInd
#else
   PtUiTfuSrsInd
#endif
};
#endif
/** @brief This API is used to indicate the reception of CQI report from CL to
 * MAC.
 */
PRIVATE CONSTANT TfuDlCqiInd YsUiTfuDlCqiIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuDlCqiInd,
#else
   PtUiTfuDlCqiInd,
#endif
#ifdef RG
   RgLiTfuDlCqiInd,
#else
   PtUiTfuDlCqiInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuDlCqiInd
#else
      PtUiTfuDlCqiInd
#endif
};

/** @brief This API is used to indicate Data Reception from CL to MAC.
*/
PRIVATE CONSTANT TfuDatInd YsUiTfuDatIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuDatInd,
#else
   PtUiTfuDatInd,
#endif
#ifdef RG
   RgLiTfuDatInd,
#else
   PtUiTfuDatInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuDatInd
#else
      PtUiTfuDatInd
#endif
};

/** @brief This API is used to indicate Decode failure from CL to MAC.
*/
PRIVATE CONSTANT TfuCrcInd YsUiTfuCrcIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuCrcInd,
#else
   PtUiTfuCrcInd,
#endif
#ifdef RG
   RgLiTfuCrcInd,
#else
   PtUiTfuCrcInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuCrcInd
#else
      PtUiTfuCrcInd
#endif
};

/** @brief This API is used to indicate a Timing Advance from CL to MAC.
*/
PRIVATE CONSTANT TfuTimingAdvInd YsUiTfuTimingAdvIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuTimingAdvInd,
#else
   PtUiTfuTimingAdvInd,
#endif
#ifdef RG
   RgLiTfuTimingAdvInd,
#else
   PtUiTfuTimingAdvInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuTimingAdvInd
#else
      PtUiTfuTimingAdvInd
#endif
};

/** @brief This API is the TTI indication from CL to MAC.
*/
PRIVATE CONSTANT TfuTtiInd YsUiTfuTtiIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuTtiInd,
#else
   PtUiTfuTtiInd,
#endif
#ifdef RG
   RgLiTfuTtiInd,
#else
   PtUiTfuTtiInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuTtiInd
#else
      PtUiTfuTtiInd
#endif
};

/** @brief This API is the TTI indication from CL to scheduler.
*/
PRIVATE CONSTANT TfuSchTtiInd YsUiTfuSchTtiIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuSchTtiInd,
#else
   PtUiTfuSchTtiInd,
#endif
#ifdef RG
   RgLiTfuSchTtiInd,
#else
   PtUiTfuSchTtiInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuSchTtiInd
#else
      PtUiTfuSchTtiInd
#endif
};

/** @brief This API is the PUCCH delta power indication from CL to scheduler.
*/
PRIVATE CONSTANT TfuPucchDeltaPwrInd YsUiTfuPucchDeltaPwrIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
  cmPkTfuPucchDeltaPwr,
#else
  PtUiTfuPucchDeltaPwrInd,
#endif
#ifdef RG
   RgLiTfuPucchDeltaPwrInd,
#else
   PtUiTfuPucchDeltaPwrInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuPucchDeltaPwr
#else
    PtUiTfuPucchDeltaPwrInd
#endif
};

/** @brief This API is used to receive a Bind confirm from CL to RRM.
*/
PRIVATE CONSTANT CtfBndCfm YsUiCtfBndCfmMt[YS_MAX_CTF_USR] =
{
#ifdef LCYSUICTF
   cmPkCtfBndCfm,
#else
   PtUiCtfBndCfm,
#endif
#ifdef VE
  VeLiCtfBndCfm,
#else
   PtUiCtfBndCfm,
#endif
#ifdef LWLCYSUICTF
   cmPkCtfBndCfm,
#else
   PtUiCtfBndCfm,
#endif
#ifdef NH
   NhLiCtfBndCfm
#else
   PtUiCtfBndCfm
#endif
};

/** @brief This API is used to receive a Config confirm from CL to RRM.
 */
PRIVATE CONSTANT CtfCfgCfm YsUiCtfCfgCfmMt[YS_MAX_CTF_USR] =
{
#ifdef LCYSUICTF
   cmPkCtfCfgCfm,
#else
   PtUiCtfCfgCfm,
#endif
#ifdef VE
  VeLiCtfCfgCfm,
#else
   PtUiCtfCfgCfm,
#endif
#ifdef LWLCYSUICTF
   cmPkCtfCfgCfm,
#else
   PtUiCtfCfgCfm,
#endif
#ifdef NH
   NhLiCtfCfgCfm
#else
   PtUiCtfCfgCfm
#endif

};

#if defined(TENB_T2K3K_SPECIFIC_CHANGES) && defined(LTE_TDD)
/** @brief This API is the Non-RT indication from CL to MAC.
*/
PRIVATE CONSTANT TfuNonRtInd YsUiTfuNonRtIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuNonRtInd,
#else
   PtUiTfuNonRtInd,
#endif
#ifdef RG
   RgLiTfuNonRtInd,
#else
   PtUiTfuNonRtInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuNonRtInd
#else
   PtUiTfuNonRtInd
#endif
};
#endif


#ifdef TENB_AS_SECURITY
/** @brief This API is used to receive a Config confirm from CL to RRM.
 */
PRIVATE CONSTANT CtfKdfCfm YsUiCtfKdfCfmMt[YS_MAX_CTF_USR] =
{
#ifdef LCYSUICTF
   cmPkCtfKdfCfm,
#else
   PtUiCtfKdfCfm,
#endif
#ifdef VE
  VeLiCtfCfgCfm,
#else
   PtUiCtfKdfCfm,
#endif
#ifdef LWLCYSUICTF
   cmPkCtfKdfCfm,
#else
   PtUiCtfKdfCfm,
#endif
#ifdef NH
   NhLiCtfCfgCfm
#else
  PtUiCtfKdfCfm 
#endif

};
#endif

/** @brief This API is used to send eNB stop indication to eNB-APP
 */
PRIVATE CONSTANT CtfEnbStopInd YsUiCtfEnbStopIndMt[YS_MAX_CTF_USR] =
{
#ifdef LCYSUICTF
   cmPkCtfEnbStopInd,
#else
   PtUiCtfEnbStopInd,
#endif
#ifdef VE
  VeLiCtfEnbStopInd,
#else
   PtUiCtfEnbStopInd,
#endif
#ifdef LWLCYSUICTF
   cmPkCtfEnbStopInd,
#else
   PtUiCtfEnbStopInd,
#endif
#ifdef NH
   /*NhLiCtfEnbStopInd*/
   PtUiCtfEnbStopInd
#else
   PtUiCtfEnbStopInd
#endif
};

#ifdef ENABLE_CNM

/** @brief This API is used to send a Cnm Cell Sync Rsp from CL to App.
*/
PRIVATE CONSTANT  CtfCnmCellSyncRspMsg YsUiCtfCnmCellSyncRspMt[YS_MAX_CTF_USR] =
{
#ifdef LCYSUICTF
  cmPkCtfCnmCellSyncRsp,
#else
  PtUiCtfCnmCellSyncRsp,
#endif
#ifdef VE
  VeLiCtfCnmCellSyncRsp,
#else
  PtUiCtfCnmCellSyncRsp,
#endif
#ifdef LWLCYSUICTF
  cmPkCtfCnmCellSyncRsp,
#else
  PtUiCtfCnmCellSyncRsp,
#endif
#ifdef NH
  NhLiCtfCnmCellSyncRsp,
#else
  PtUiCtfCnmCellSyncRsp 
#endif
};

/** @brief This API is used to send a Cnm Cell Sync Indication from CL to App.
*/
PRIVATE CONSTANT  CtfCnmCellSyncIndMsg YsUiCtfCnmCellSyncIndMt[YS_MAX_CTF_USR] =
{
#ifdef LCYSUICTF
  cmPkCtfCnmCellSyncInd,
#else
  PtUiCtfCnmCellSyncInd,
#endif
#ifdef VE
  VeLiCtfCnmCellSyncInd,
#else
  PtUiCtfCnmCellSyncInd,
#endif
#ifdef LWLCYSUICTF
  cmPkCtfCnmCellSyncInd,
#else
  PtUiCtfCnmCellSyncInd,
#endif
#ifdef NH
  NhLiCtfCnmCellSyncInd,
#else
  PtUiCtfCnmCellSyncInd 
#endif
};
/* CNM End */
/** @brief This API is used to send a Cnm Init Sync Rsp from CL to App.
*/
PRIVATE CONSTANT  CtfCnmInitSyncRspMsg YsUiCtfCnmInitSyncRspMt[YS_MAX_CTF_USR] =
{
#ifdef LCYSUICTF
  cmPkCtfCnmInitSyncRsp,
#else
  PtUiCtfCnmInitSyncRsp,
#endif
#ifdef VE
  VeLiCtfCnmInitSyncRsp,
#else
  PtUiCtfCnmInitSyncRsp,
#endif
#ifdef LWLCYSUICTF
  cmPkCtfCnmInitSyncRsp,
#else
  PtUiCtfCnmInitSyncRsp,
#endif
#ifdef NH
  NhLiCtfCnmInitSyncRsp,
#else
  PtUiCtfCnmInitSyncRsp 
#endif
};

#endif


/* LTE_UNLICENSED */
/** @brief This API is the TTI indication from CL to scheduler.
*/
PRIVATE CONSTANT TfuErrInd YsUiTfuErrIndMt[YS_MAX_TFU_USR] =
{
#ifdef LCYSUITFU
   cmPkTfuErrInd,
#else
   PtUiTfuErrInd,
#endif
#ifdef RG
   RgLiTfuErrInd,
#else
   PtUiTfuErrInd,
#endif
#ifdef LWLCYSUITFU
   cmPkTfuErrInd,
#else
      PtUiTfuErrInd
#endif
};


/**
* @brief This API is used to send ENB-STOP indication to ENB-APP
*
* @details
*
*     Function : PtUiCtfEnbStopInd
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiCtfEnbStopInd
(
Pst* pst,
SuId suId,
CtfCfgTransId  transId
)
{

   TRC3(PtUiCtfEnbStopInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(transId);
   RETVALUE(ROK);
}

#ifdef ENABLE_CNM
/**
* @brief This API is used to send Cnm Init Sync Rsp from CL to App.
*
* @details
*
*     Function :PtUiCtfCnmInitSyncRsp 
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId,
*  @param[in]   CtfCnmInitSyncRsp  *cnmInitSyncRsp
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiCtfCnmInitSyncRsp 
(
Pst* pst,
SuId suId,
CtfCfgTransId  *transId,
CtfCnmInitSyncRsp  *cnmInitSyncRsp
)
{

   TRC3(PtUiCtfCnmInitSyncRsp);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(transId);
   UNUSED(cnmInitSyncRsp);

   RETVALUE(ROK);

}

/**
* @brief This API is used to send Cnm Cell Sync Rsp from CL to App.
*
* @details
*
*     Function :PtUiCtfCnmCellSyncRsp 
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId,
*  @param[in]   CtfCnmCellSyncRsp  *cnmCellSyncRsp
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiCtfCnmCellSyncRsp 
(
Pst* pst,
SuId suId,
CtfCfgTransId  *transId,
CtfCnmCellSyncRsp  *cnmCellSyncRsp
)
{

   TRC3(PtUiCtfCnmCellSyncRsp);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(transId);
   UNUSED(cnmCellSyncRsp);

   RETVALUE(ROK);

}

/**
* @brief This API is used to send Cnm Cell Sync Ind from CL to App.
*
* @details
*
*     Function :PtUiCtfCnmCellSyncInd
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId,
*  @param[in]   CtfCnmCellSyncInd  *cnmCellSyncInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiCtfCnmCellSyncInd 
(
Pst* pst,
SuId suId,
CtfCfgTransId  *transId,
CtfCnmCellSyncInd  *cnmCellSyncInd
)
{

   TRC3(PtUiCtfCnmCellSyncInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(transId);
   UNUSED(cnmCellSyncInd);

   RETVALUE(ROK);

}


#endif
#ifdef YS



/**
* @brief This API is used to receive a Bind confirm from CL to MAC.
*
* @details
*
*     Function : YsUiTfuBndCfm
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   U8  status
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuBndCfm
(
Pst* pst,
SuId suId,
U8 status
)
{

   TRC3(YsUiTfuBndCfm);

   (*YsUiTfuBndCfmMt[pst->selector])(pst, suId, status);

   RETVALUE(ROK);

}

PUBLIC S16 YsUiTfuSchBndCfm
(
Pst* pst,
SuId suId,
U8 status
)
{

   TRC3(YsUiTfuSchBndCfm);

   (*YsUiTfuSchBndCfmMt[pst->selector])(pst, suId, status);

   RETVALUE(ROK);
}


/**
* @brief This API is used to indication Random Access Request reception from
 * CL to MAC.
*
* @details
*
*     Function : YsUiTfuRaReqInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuRaReqIndInfo *  raReqInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuRaReqInd
(
Pst * pst,
SuId suId,
TfuRaReqIndInfo * raReqInd
)
{

   TRC3(YsUiTfuRaReqInd);

   (*YsUiTfuRaReqIndMt[pst->selector])(pst, suId, raReqInd);

   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate CQI reporting from CL to MAC
*
* @details
*
*     Function : YsUiTfuUlCqiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuUlCqiIndInfo *  ulCqiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuUlCqiInd
(
Pst * pst,
SuId suId,
TfuUlCqiIndInfo * ulCqiInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif

   TRC3(YsUiTfuUlCqiInd);

   /*starting Task*/
   SStartTask(&startTime, PID_MAC_UL_CQI_IND);
   (*YsUiTfuUlCqiIndMt[pst->selector])(pst, suId, ulCqiInd);
   /*stopping Task*/
   SStopTask(startTime, PID_MAC_UL_CQI_IND);
   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate HARQ feedback from CL to MAC
*
* @details
*
*     Function : YsUiTfuHarqAckInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuHarqAckIndInfo *  harqAckInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuHqInd
(
Pst * pst,
SuId suId,
TfuHqIndInfo      *hqInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC3(YsUiTfuHqInd);

   /*starting Task*/
   SStartTask(&startTime, PID_MAC_HARQ_IND);
   (*YsUiTfuHqIndMt[pst->selector])(pst, suId, hqInd);
   /*stopping Task*/
   SStopTask(startTime, PID_MAC_HARQ_IND);
   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate a SR reception from CL to MAC.
*
* @details
*
*     Function : YsUiTfuSrInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuSrIndInfo *  srInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuSrInd
(
Pst * pst,
SuId suId,
TfuSrIndInfo * srInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC3(YsUiTfuSrInd);

   /*starting Task*/
   SStartTask(&startTime, PID_MAC_SR_IND);
   (*YsUiTfuSrIndMt[pst->selector])(pst, suId, srInd);
   /*stopping Task*/
   SStopTask(startTime, PID_MAC_SR_IND);

   RETVALUE(ROK);

}

#ifdef TFU_UPGRADE

/**
* @brief This API is used to indicate the reception of CQI report from CL to
 * MAC.
*
* @details
*
*     Function : YsUiTfuRawCqiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuRawCqiIndInfo *  dlCqiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuRawCqiInd
(
Pst * pst,
SuId suId,
TfuRawCqiIndInfo * dlCqiInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC3(YsUiTfuRawCqiInd);

   /*starting Task*/
   SStartTask(&startTime, PID_MAC_DL_CQI_IND);
   (*YsUiTfuRawCqiIndMt[pst->selector])(pst, suId, dlCqiInd);
   /*stopping Task*/
   SStopTask(startTime, PID_MAC_DL_CQI_IND);
   RETVALUE(ROK);

}


/**
* @brief This API is used to indicate the reception of SRS report from CL to
 * MAC.
*
* @details
*
*     Function : YsUiTfuSrsInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuSrsInd
(
Pst * pst,
SuId suId,
TfuSrsIndInfo * ulSrsInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC3(YsUiTfuSrsInd);
   /*starting Task*/
   SStartTask(&startTime, PID_MAC_UL_SRS_IND); 
   (*YsUiTfuSrsIndMt[pst->selector])(pst, suId, ulSrsInd);
   /*stopping Task*/
   SStopTask(startTime, PID_MAC_UL_SRS_IND);
   RETVALUE(ROK);

}
#endif


/**
* @brief This API is used to indicate the reception of CQI report from CL to
 * MAC.
*
* @details
*
*     Function : YsUiTfuDlCqiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuDlCqiIndInfo *  dlCqiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuDlCqiInd
(
Pst * pst,
SuId suId,
TfuDlCqiIndInfo * dlCqiInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC3(YsUiTfuDlCqiInd);

   /*starting Task*/
   SStartTask(&startTime, PID_MAC_DL_CQI_IND);
   (*YsUiTfuDlCqiIndMt[pst->selector])(pst, suId, dlCqiInd);
   /*stopping Task*/
   SStopTask(startTime, PID_MAC_DL_CQI_IND);
   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate Data Reception from CL to MAC.
*
* @details
*
*     Function : YsUiTfuDatInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuDatIndInfo *  datInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuDatInd
(
Pst * pst,
SuId suId,
TfuDatIndInfo * datInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC3(YsUiTfuDatInd);

   /*starting Task*/
   SStartTask(&startTime, PID_MAC_DAT_IND);
   /* No need of assigning selector as this is decided with configuration */

   (*YsUiTfuDatIndMt[pst->selector])(pst, suId, datInd);
   /*stopping Task*/
   SStopTask(startTime, PID_MAC_DAT_IND);
   RETVALUE(ROK);
}



/**
* @brief This API is used to indicate Decode failure from CL to MAC.
*
* @details
*
*     Function : YsUiTfuCrcInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuCrcIndInfo *  crcInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuCrcInd
(
Pst * pst,
SuId suId,
TfuCrcIndInfo * crcInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC3(YsUiTfuCrcInd);
   /*starting Task*/
   SStartTask(&startTime, PID_UL_SCHEDULING);

   (*YsUiTfuCrcIndMt[pst->selector])(pst, suId, crcInd);
   /*stopping Task*/
   SStopTask(startTime, PID_UL_SCHEDULING);
   RETVALUE(ROK);
}



/**
* @brief This API is used to indicate a Timing Advance from CL to MAC.
*
* @details
*
*     Function : YsUiTfuTimingAdvInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuTimingAdvIndInfo *  timingAdvInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuTimingAdvInd
(
Pst * pst,
SuId suId,
TfuTimingAdvIndInfo * timingAdvInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
   TRC3(YsUiTfuTimingAdvInd);
   /*starting Task*/
   SStartTask(&startTime, PID_MAC_TA_IND);

   (*YsUiTfuTimingAdvIndMt[pst->selector])(pst, suId, timingAdvInd);
   
   /*stopping Task*/
   SStopTask(startTime, PID_MAC_TA_IND);
   RETVALUE(ROK);

}



/**
* @brief This API is the TTI indication from CL to MAC.
*
* @details
*
*     Function : YsUiTfuTtiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuTtiIndInfo *  ttiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuTtiInd
(
Pst * pst,
SuId suId,
TfuTtiIndInfo * ttiInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
#ifndef RGL_SPECIFIC_CHANGES
   U32  startTm = GetTIMETICK();
   U32  endTm;
#endif

   TRC3(YsUiTfuTtiInd);

   /*starting Task*/
   SStartTask(&startTime, PID_MAC_TTI_IND);
   /* No need of assigning selector as this is decided with configuration */
   (*YsUiTfuTtiIndMt[pst->selector])(pst, suId, ttiInd);
   /*stopping Task*/
   SStopTask(startTime, PID_MAC_TTI_IND);

#ifndef RGL_SPECIFIC_CHANGES
   endTm = GetTIMETICK();

   MS_CHK_TIME (endTm, startTm, 80);
#endif
   RETVALUE(ROK);
}

/**
* @brief This API is the TTI indication from CL to scheduler.
*
* @details
*
*     Function : YsUiTfuSchTtiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuTtiIndInfo *  ttiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuSchTtiInd
(
Pst * pst,
SuId suId,
TfuTtiIndInfo * ttiInd
)
{
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
#endif
#ifdef MSPD_MLOG_NEW
   U32  startTm = GetTIMETICK();
   U32  endTm;
#endif

   TRC3(YsUiTfuSchTtiInd);

   /*starting Task*/
   SStartTask(&startTime, PID_SCH_TTI_IND);

   /* No need of assigning selector as this is decided with configuration */
   (*YsUiTfuSchTtiIndMt[pst->selector])(pst, suId, ttiInd);
#ifdef MSPD_MLOG_NEW
   /*ABHINAV . Need to move it out of each cell. Need to take up later*/
   if(ttiInd->cells[0].isDummyTti)
   /*stopping Task*/
      SStopTask(startTime, PID_SCH_DUMMY_TTI_IND);
   else
   /*stopping Task*/
      SStopTask(startTime, PID_SCH_TTI_IND);
#endif

   noStatsTti++;
   RETVALUE(ROK);
}

#if defined(TENB_T2K3K_SPECIFIC_CHANGES) && defined(LTE_TDD)
/**
* @brief This API is the Non-RT indication from CL to MAC.
*
* @details
*
*     Function : YsUiTfuNonRtInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuNonRtInd
(
Pst * pst,
SuId suId
)
{
   TRC3(YsUiTfuNonRtInd);

   /* No need of assigning selector as this is decided with configuration */
   (*YsUiTfuNonRtIndMt[pst->selector])(pst, suId);

   RETVALUE(ROK);

}
#endif


/**
* @brief This API is the PUCCH delta power indication from CL to scheduler.
*
* @details
*
*     Function : YsUiTfuPucchDeltaPwrInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuTtiIndInfo *  ttiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuPucchDeltaPwrInd
(
Pst * pst,
SuId suId,
TfuPucchDeltaPwrIndInfo *pucchDeltaPwrInd
)
{
/* ys005.102 : Introduced new variable */
   TRC3(YsUiTfuPucchDeltaPwrInd);

   /* No need of assigning selector as this is decided with configuration */
   (*YsUiTfuPucchDeltaPwrIndMt[pst->selector])(pst, suId, pucchDeltaPwrInd);
/* ys005.102 : Calling MLogTask function */
   RETVALUE(ROK);

}
/**
* @brief This API is used to receive a Bind confirm from CL to RRM.
*
* @details
*
*     Function : YsUiCtfBndCfm
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   U8  status
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiCtfBndCfm
(
Pst* pst,
SuId suId,
U8 status
)
{

   TRC3(YsUiCtfBndCfm);

   (*YsUiCtfBndCfmMt[pst->selector])(pst, suId, status);

   RETVALUE(ROK);

}

/**
* @brief This API is used to receive a Bind confirm from CL to RRM.
*
* @details
*
*     Function : YsUiCtfCfgCfm
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId
*  @param[in]   U8  status
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiCtfCfgCfm
(
Pst* pst,
SuId suId,
CtfCfgTransId transId,
U8 status
)
{

   TRC3(YsUiCtfCfgCfm);

   (*YsUiCtfCfgCfmMt[pst->selector])(pst, suId, transId, status);

   RETVALUE(ROK);

}

#ifdef TENB_AS_SECURITY
/**
* @brief This API is used to receive a Bind confirm from CL to RRM.
*
* @details
*
*     Function : YsUiCtfKdfCfm
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId
*  @param[in]   U8  status
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiCtfKdfCfm
(
Pst* pst,
SuId suId,
CtfCfgTransId transId,
CtfKdfCfmInfo *kdfCfmInf,
U8 status
)
{

   TRC3(YsUiCtfCfgCfm);

   (*YsUiCtfKdfCfmMt[pst->selector])(pst, suId, transId,kdfCfmInf, status);

   RETVALUE(ROK);
}
#endif
#endif /* ifdef YS */
#ifdef PTYSUITFU



/**
* @brief This API is used to receive a Bind confirm from CL to MAC.
*
* @details
*
*     Function : PtUiTfuBndCfm
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   U8  status
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuBndCfm
(
Pst* pst,
SuId suId,
U8 status
)
{

   TRC3(PtUiTfuBndCfm);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);

   RETVALUE(ROK);

}


PUBLIC S16 PtUiTfuSchBndCfm
(
Pst* pst,
SuId suId,
U8 status
)
{

   TRC3(PtUiTfuSchBndCfm);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);

   RETVALUE(ROK);

}


/**
* @brief This API is used to indication Random Access Request reception from
 * CL to MAC.
*
* @details
*
*     Function : PtUiTfuRaReqInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuRaReqIndInfo *  raReqInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuRaReqInd
(
Pst * pst,
SuId suId,
TfuRaReqIndInfo * raReqInd
)
{

   TRC3(PtUiTfuRaReqInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(raReqInd);

   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate CQI reporting from CL to MAC
*
* @details
*
*     Function : PtUiTfuUlCqiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuUlCqiIndInfo *  ulCqiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuUlCqiInd
(
Pst * pst,
SuId suId,
TfuUlCqiIndInfo * ulCqiInd
)
{

   TRC3(PtUiTfuUlCqiInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(ulCqiInd);

   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate HARQ feedback from CL to MAC
*
* @details
*
*     Function : PtUiTfuHqInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuHqIndInfo  *hqInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuHqInd
(
Pst * pst,
SuId suId,
TfuHqIndInfo  *hqInd
)
{

   TRC3(PtUiTfuHqInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(hqInd);

   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate a SR reception from CL to MAC.
*
* @details
*
*     Function : PtUiTfuSrInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuSrIndInfo *  srInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuSrInd
(
Pst * pst,
SuId suId,
TfuSrIndInfo * srInd
)
{

   TRC3(PtUiTfuSrInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(srInd);

   RETVALUE(ROK);

}

#ifdef TENB_RTLIN_CHANGES

/**
* @brief This API is used to indicate the reception of CQI report from CL to
 * MAC.
*
* @details
*
*     Function : PtUiTfuDlCqiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuDlCqiIndInfo *  dlCqiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuRawCqiInd
(
Pst * pst,
SuId suId,
TfuRawCqiIndInfo * rawCqiInd
)
{

   TRC3(PtUiTfuRawCqiInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(rawCqiInd);

   RETVALUE(ROK);

}


/**
* @brief This API is used to indicate the reception of SRS report from CL to
 * MAC.
*
* @details
*
*     Function : PtUiTfuSrsInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuDlCqiIndInfo *  dlCqiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuSrsInd
(
Pst * pst,
SuId suId,
TfuSrsIndInfo * ulSrsInd
)
{

   TRC3(PtUiTfuSrsInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(ulSrsInd);

   RETVALUE(ROK);

}

#endif /*TENB_RTLIN_CHANGES*/



/**
* @brief This API is used to indicate the reception of CQI report from CL to
 * MAC.
*
* @details
*
*     Function : PtUiTfuDlCqiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuDlCqiIndInfo *  dlCqiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuDlCqiInd
(
Pst * pst,
SuId suId,
TfuDlCqiIndInfo * dlCqiInd
)
{

   TRC3(PtUiTfuDlCqiInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(dlCqiInd);

   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate Data Reception from CL to MAC.
*
* @details
*
*     Function : PtUiTfuDatInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuDatIndInfo *  datInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuDatInd
(
Pst * pst,
SuId suId,
TfuDatIndInfo * datInd
)
{

   TRC3(PtUiTfuDatInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(datInd);

   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate Decode failure from CL to MAC.
*
* @details
*
*     Function : PtUiTfuCrcInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuCrcIndInfo *  crcInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuCrcInd
(
Pst * pst,
SuId suId,
TfuCrcIndInfo * crcInd
)
{

   TRC3(PtUiTfuCrcInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(crcInd);

   RETVALUE(ROK);

}



/**
* @brief This API is used to indicate a Timing Advance from CL to MAC.
*
* @details
*
*     Function : PtUiTfuTimingAdvInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuTimingAdvIndInfo *  timingAdvInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuTimingAdvInd
(
Pst * pst,
SuId suId,
TfuTimingAdvIndInfo * timingAdvInd
)
{

   TRC3(PtUiTfuTimingAdvInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(timingAdvInd);

   RETVALUE(ROK);

}



/**
* @brief This API is the TTI indication from CL to MAC.
*
* @details
*
*     Function : PtUiTfuTtiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuTtiIndInfo *  ttiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuTtiInd
(
Pst * pst,
SuId suId,
TfuTtiIndInfo * ttiInd
)
{

   TRC3(PtUiTfuTtiInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(ttiInd);

   RETVALUE(ROK);

}

/**
* @brief This API is the TTI indication from CL to scheduler.
*
* @details
*
*     Function : PtUiTfuSchTtiInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuTtiIndInfo *  ttiInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuSchTtiInd
(
Pst * pst,
SuId suId,
TfuTtiIndInfo * ttiInd
)
{

   TRC3(PtUiTfuSchTtiInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(ttiInd);

   RETVALUE(ROK);

}

/*
* @brief This API is the Pucch DELTA power indication from CL to scheduler.
*
* @details
*
*     Function :PtUiTfuPucchDeltaPwrInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuPucchDeltaPwrIndInfo *pucchDeltaPwrInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuPucchDeltaPwrInd
(
Pst * pst,
SuId suId,
TfuPucchDeltaPwrIndInfo *pucchDeltaPwrInd
)
{

   TRC3(PtUiTfuPucchDeltaPwrInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(pucchDeltaPwrInd);

   RETVALUE(ROK);

}
#endif /*--ifdef PTYSUITFU--*/

#ifdef PTYSUICTF


/**
* @brief This API is used to receive a Bind confirm from CL to MAC.
*
* @details
*
*     Function : PtUiCtfBndCfm
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   U8  status
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiCtfBndCfm
(
Pst* pst,
SuId suId,
U8 status
)
{

   TRC3(PtUiCtfBndCfm);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);

   RETVALUE(ROK);

}

/**
* @brief This API is used to receive a Bind confirm from CL to MAC.
*
* @details
*
*     Function : PtUiCtfCfgCfm
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   U8  status
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiCtfCfgCfm
(
Pst* pst,
SuId suId,
CtfCfgTransId  transId,
U8 status
)
{

   TRC3(PtUiCtfCfgCfm);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(transId);
   UNUSED(status);

   RETVALUE(ROK);

}


/**
* @brief This API is used to receive a Config confirm from CL to RRM.
*
* @details
*
*     Function : PtUiCtfKdfCfm
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId transId
*  @param[in]   CtfKdfCfmInfo *kdfCfmInfo
*  @param[in]   U8  status
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiCtfKdfCfm
(
Pst* pst,
SuId suId,
CtfCfgTransId transId,
CtfKdfCfmInfo *kdfCfmInfo,
U8 status
)
{

   TRC3(PtUiCtfCfgCfm);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(transId);
   UNUSED(kdfCfmInfo);
   UNUSED(status);

   RETVALUE(ROK);

}


#endif /* PTYSUICTF */
/**
* @brief This API is used to send eNB stop indication to APP
*
* @details
*
*     Function : YsUiCtfEnbStopInd
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiCtfEnbStopInd
(
Pst* pst,
SuId suId,
CtfCfgTransId transId
)
{

   TRC3(YsUiCtfEnbStopInd);

   (*YsUiCtfEnbStopIndMt[pst->selector])(pst, suId, transId);

   RETVALUE(ROK);

}

#ifdef ENABLE_CNM

/**
* @brief This API is used to receive a Cnm Init Sync Rsp from CL to RRM.
*
* @details
*
*     Function : YsUiCtfCnmInitSyncRsp
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId
*  @param[in]   CtfCnmInitSyncRsp *ctfCnmInitSyncrsp
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiCtfCnmInitSyncRsp 
(
Pst* pst,
SuId suId,
CtfCfgTransId *transId,
CtfCnmInitSyncRsp *ctfCnmInitSyncrsp
)
{

   TRC3(YsUiCtfCnmInitSyncRsp);

   (*YsUiCtfCnmInitSyncRspMt[pst->selector])(pst, suId, transId, ctfCnmInitSyncrsp);

   RETVALUE(ROK);

}

/**
* @brief This API is used to receive a Cnm Cell Sync Rsp from CL to RRM.
*
* @details
*
*     Function : YsUiCtfCnmCellSyncRsp
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId
*  @param[in]   CtfCnmCellSyncRsp *ctfCnmCellSyncrsp
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiCtfCnmCellSyncRsp 
(
Pst* pst,
SuId suId,
CtfCfgTransId *transId,
CtfCnmCellSyncRsp *ctfCnmCellSyncrsp
)
{

   TRC3(YsUiCtfCnmCellSyncRsp);

   (*YsUiCtfCnmCellSyncRspMt[pst->selector])(pst, suId, transId, ctfCnmCellSyncrsp);

   RETVALUE(ROK);

}

/**
* @brief This API is used to receive a Cnm Cell Sync Ind from CL to RRM.
*
* @details
*
*     Function : YsUiCtfCnmCellSyncInd
*
*  @param[in]   Pst*  pst
*  @param[in]   SuId  suId
*  @param[in]   CtfCfgTransId  transId
*  @param[in]   CtfCnmCellSyncInd *ctfCnmCellSyncind
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiCtfCnmCellSyncInd 
(
Pst* pst,
SuId suId,
CtfCfgTransId *transId,
CtfCnmCellSyncInd *ctfCnmCellSyncind
)
{

   TRC3(YsUiCtfCnmCellSyncInd);

   (*YsUiCtfCnmCellSyncIndMt[pst->selector])(pst, suId, transId, ctfCnmCellSyncind);

   RETVALUE(ROK);

}


#endif


/**
* @brief This API is the Non-RT indication from CL to MAC.
*
* @details
*
*     Function : PtUiTfuNonRtInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuNonRtInd
(
Pst * pst,
SuId suId
)
{

   TRC3(PtUiTfuTtiInd);

   UNUSED(pst);
   UNUSED(suId);

   RETVALUE(ROK);
}

//LTE_UNLICENSED

EXTERN S16 YsUiCtfLaaScanInd
(
Pst* pst,
SuId suId,
CtfLaaScanInd *laaScanInd
);

/**
* @brief This API is used to send Unlicensed band scan results to App.
*
* @details
*
*     Function : YsUiCtfLaaScanInd
*
*  @param[in]   Pst*           pst
*  @param[in]   SuId           suId
*  @param[in]   CtfLaaScanInd *laaScanInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiCtfLaaScanInd
(
Pst* pst,
SuId suId,
CtfLaaScanInd *laaScanInd
)
{

   TRC3(YsUiCtfLaaScanInd);
   /* Currently API is not used */
   RETVALUE(ROK);

}


/**
* @brief This API is the ERR indication from CL to MAC.
*
* @details
*
*     Function : PtUiTfuErrInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuErrIndInfo *  errInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 PtUiTfuErrInd
(
Pst * pst,
SuId suId,
TfuErrIndInfo * errInd
)
{

   TRC3(PtUiTfuErrInd);

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(errInd);

   RETVALUE(ROK);

}


/**
* @brief This API is the ERR indication from CL to scheduler.
*
* @details
*
*     Function : YsUiTfuErrInd
*
*  @param[in]   Pst *  pst
*  @param[in]   SuId  suId
*  @param[in]   TfuErrIndInfo *  errInd
*  @return   S16
*      -# ROK
**/
PUBLIC S16 YsUiTfuErrInd
(
Pst * pst,
SuId suId,
TfuErrIndInfo * errInd
)
{
   TRC3(YsUiTfuErrInd);

   (*YsUiTfuErrIndMt[pst->selector])(pst, suId, errInd);

   RETVALUE(ROK);
}


/********************************************************************30**
  
         End of file:     yw_ms_ptui.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:48 2014
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/2      ---     sgm                   1. eNodeB 1.2 release
/main/2      ys004.102     ms              1. g++ compilation.
*********************************************************************91*/


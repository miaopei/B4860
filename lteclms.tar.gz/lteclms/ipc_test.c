/*
 * Copyright 2011-2013 Freescale Semiconductor, Inc.
 *
 * Author: Ashish Kumar <ashish.kumar@freescale.com>
 * Author: Manish Jaggi <manish.jaggi@freescale.com>
 */
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <getopt.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netpacket/packet.h>
#include <linux/if.h>
#include <time.h>
#include <stdint.h>
#include "danipc_ioctl.h"
     //#include "procPrivsWrapper.h"
#include <linux/capability.h>
#include <pthread.h>
#include "fapiApiInternal.h"
#include "envopt.h"             /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "resultcodes.h"
     
#include "ssi.h"           /* system services */
#include "gen.h"                /* general layer */
#include "tfu.h"
#include "ctf.h"
#include "LtePhyL2Api.h"
#include "ys_ms.h"
#include "apidefs.h"
#include "lys.h"  
     
#include "gen.x"                /* general layer */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"
     
#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#include "ctf.x"
     
#include "ys_ms.x"
     
     //#include "procPrivsWrapper.h"
     
#include <fcntl.h>	
#include <sys/stat.h>
#include <errno.h>
#include <getopt.h>
#include <linux/if.h>
#include <linux/capability.h>
#include <sys/time.h>
#include <sys/types.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <sys/vfs.h>
#include <netdb.h>
#include <signal.h>
     
#include "ys_qcms.h"
     
#include <time.h>

#include "fsl_usmmgr.h"
#include "fsl_bsc913x_ipc.h"
#include "fsl_ipc_errorcodes.h"
#include "ac_ltePhyIpc.h"
#include "ac_shmMgr.h"

#if 0

#include "gen.h"                /* general layer */
#include "tfu.h"
#include "ctf.h"
#include "LtePhyL2Api.h"
#include "ys_ms.h"
#include "gen.x"                /* general layer */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"

#include "lys.x"           /* layer management typedefs for CL */
#include "ctf.x"
#endif

#define UIO_INTERFACE   "/dev/uio0"
#define UIO_INTERFACE2   "/dev/uio1"

#define CMD_LINE_OPT "r:i:"
#define NUM_MAX_CARRIER 1

#define ENTER()	printf(">> %s %d %s\n", __FILE__, __LINE__, __func__)
#define EXIT(A)	printf("<< (%d) %s %d %s\n", A, __FILE__, __LINE__, __func__)
#define mute_print(...)
extern YsCb ysCb;
extern U8 phySubFrame;


fsl_ipc_t ipc[NUM_MAX_CARRIER];
int ch3init;
int ch4init;
void test_init(int rat_id);
int rat_id, loop, mute_flag, loop2;

/* Logging Function */
void dump_msg(char *msg, int len)
{
	int i = 0;
	for (i = 0; i < len; i++)
		printf("%x", msg[i]);

	printf("\n");
}
void usage(char **argv)
{
	printf("Usage: %s -r <rat_id> -i <nr_msg>\n",
		argv[0]);
	printf("whereas,\n <rat_id> : 0 for SingleRAT\n"
		"          : 1 for MultiRAT\n"
		" <nr_msg> : Number of Messages to be exchanged on an"
		" IPC channel \n");
	exit(EXIT_FAILURE);
}
#if 0
int main(int argc, char **argv)
{
	int opt;
	while ((opt = getopt(argc, argv, CMD_LINE_OPT)) != -1) {
		switch (opt) {
		case 'r':
			if (isdigit(optarg[0])) {
				rat_id = atoi(optarg);
				break;
			} else
				usage(argv);
		case 'i':
			loop = atoi(optarg);
			loop2 = loop;
			mute_flag = 1;
			break;
		default:
			usage(argv);
		}

	}
	if (optind == 1)
		usage(argv);

	test_init(rat_id);
	return 0;
}
#endif
///////////////// Create Channels ////////////////////
int isbitset(uint64_t v, int bit)
{
	if ((v >> (63 - bit)) & 0x1)
		return 1;

	return 0;
}

#if 1
void channelParamRsp_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 1;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_PARAM_RESPONSE_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_PARAM_RESPONSE_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);
        printf("ys_qcSendConfigReq(0); \n");
        ys_qcSendConfigReq(1);
        goto end;
	}
end:
	printf("Exiting thread for channelParamRsp\n");
	EXIT(ret);
	pthread_exit(0);
}
void channelErrorInd_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 2;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_ERROR_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_ERROR_INDICATION_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);

	}
end:
	printf("Exiting thread for channelErrorInd_thread\n");
	EXIT(ret);
	pthread_exit(0);
}

void channelCqiInd_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 5;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_CQI_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_CQI_INDICATION_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);

	}
end:
	printf("Exiting thread for channelCqiInd_thread\n");
	EXIT(ret);
	pthread_exit(0);
}

void channelSrInd_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 2;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_SR_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_SR_INDICATION_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);

	}
end:
	printf("Exiting thread for channelSrInd_thread\n");
	EXIT(ret);
	pthread_exit(0);
}

void channelSrsInd_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 2;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_SRS_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_SRS_INDICATION_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);

	}
end:
	printf("Exiting thread for channelSrsInd_thread\n");
	EXIT(ret);
	pthread_exit(0);
}

void channelRachInd_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 2;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_RACH_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_RACH_INDICATION_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);

	}
end:
	printf("Exiting thread for channelRachInd_thread\n");
	EXIT(ret);
	pthread_exit(0);
}

void channelUlschInd_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 2;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_ULSCH_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_ULSCH_INDICATION_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);

	}
end:
	printf("Exiting thread for channelUlschInd_thread\n");
	EXIT(ret);
	pthread_exit(0);
}

void channelCrcInd_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 1;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_CRC_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_CRC_INDICATION_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);

	}
end:
	printf("Exiting thread for channelCrcInd_thread\n");
	EXIT(ret);
	pthread_exit(0);
}

void channelHarqInd_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 5;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_HARQ_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_HARQ_INDICATION_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);

	}
end:
	printf("Exiting thread for channelHarqInd_thread\n");
	EXIT(ret);
	pthread_exit(0);
}

void channelSubframeInd_thread(void *ptr)
{
	uint8_t *recvData_p = NULL;
    unsigned long p;
    uint8_t *buff;
    uint32_t len;
    int retval;
    FAPI_T_MSG_HDR*  msgHead;
	fsl_usmmgr_t* usmmgr_p;
	usmmgr_p = ac_getUsmMgr();
	
	while (1) {
        retval = fsl_ipc_recv_ptr(SC_TO_PA_SUBFRAME_INDICATION_CH, &p, &len, ipc[0]);
        if((retval == 0)&&(len >0))
        {      
           recvData_p = fsl_usmmgr_p2v(p, *usmmgr_p);
           printf("ysCb.ysInit[0].region, %d ysCb.ysInit[0].pool, %d , len %d \n",ysCb.ysInit[0].region, ysCb.ysInit[0].pool, len);
           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                fflush(stdout);
                exit(-1);
            }
    #if 1
            phySubFrame = (U8)(((FAPI_T_SF_IND*)recvData_p)->sf_sfn&0x0F);
            memcpy(buff,recvData_p,len);
    #endif
            ys_qcMsgForwd(buff, len, 0);
        }


	}
end:
	printf("Exiting thread for channelSubframeInd_thread\n");
	EXIT(retval);
	pthread_exit(0);
}

void channelConfigRsp_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 1;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(SC_TO_PA_CONFIG_RESPONSE_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[1]);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(SC_TO_PA_CONFIG_RESPONSE_CH, &p, &len, ipc[1]);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);
        printf("SC_TO_PA_CONFIG_RESPONSE_CH received \n");
		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);
        ys_qcSendStartReq(1);
        goto end;
	}
end:
	printf("Exiting thread for channelConfigRsp\n");
	EXIT(ret);
	pthread_exit(0);
}

void channel3_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int ctr = 0;
	int depth = 16;
	char bs[20] = { 0 };
	ENTER();
	ret = fsl_ipc_configure_channel(3, depth, IPC_PTR_CH, 0, 0, NULL, ipc);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	ch3init = 1;
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(3, &p, &len, ipc);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\n[IPC_PA%d] R:C3:P:[%lx]L:%x\n", rat_id, p, len);

		sprintf(bs, "%x ", ctr++);

		printf("\n[IPC_PA%d] S:C2:M:L:%x\n", rat_id, 9);
	}
end:
	printf("Exiting thread for ch2/3\n");
	EXIT(ret);
	pthread_exit(0);
}
void channel4_thread(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret;
	int depth = 16;
	char retbuf[1024];
	void *vaddr;
	ENTER();
	fsl_usmmgr_t* usmmgr_p;
    usmmgr_p = ac_getUsmMgr();
	ret = fsl_ipc_configure_channel(4, depth, IPC_PTR_CH, 0, 0, NULL, ipc);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	ch4init = 1;
	while (1) {
		do {
			ret = fsl_ipc_recv_ptr(4, &p, &len, ipc);
			usleep(1000);
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			printf("\n ERROR ret %x \n", ret);
			goto end;
		}
		printf("\nR:C4:P:[%lx]L:%x\n", p, len);

		vaddr = fsl_usmmgr_p2v(p, *usmmgr_p);
		if (!vaddr) {
			ret = -ERR_NULL_VALUE;
			printf("\n Error in translating physical address %lx"
				" to virtual address\n", p);
			goto end;
		}

		//ys_qcMsgForwd((Data *)vaddr, len, 0)
	}
end:
	printf("Exiting Thread for ch4/5\n");
	EXIT(ret);
	pthread_exit(0);
}

void channel3_thread_m(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret, ch2send_ctr = 0;
	int tr = 0, ts = 0;
	int ctr = 0, ch3recv_ctr = 0;
	int depth = 16;
	char bs[20] = { 0 };

	ret = fsl_ipc_configure_channel(3, depth, IPC_PTR_CH, 0, 0, NULL, ipc);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	ch3init = 1;
	while (loop-- > 0) {
		do {
			ret = fsl_ipc_recv_ptr(3, &p, &len, ipc);
			usleep(1000);
			tr++;
			if (ret == ERR_SUCCESS)
				tr = 0;
			else if (tr == 500) {
				/* wait for 0.5 sec*/
				printf("Timed out. Message not received"
						" on ch#3\n");
				pthread_exit(0);
			}
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			ENTER();
			printf("\n ERROR ret %x \n", ret);
			printf("Exiting thread for ch3\n");
			goto end;
		}
		ch3recv_ctr++;

		sprintf(bs, "%x ", ctr++);

		//ys_qcMsgForwd((Data *)vaddr, len, 0)
	}

	if (ch3recv_ctr == ch2send_ctr && ch3recv_ctr != 0) {
		printf("(%d) Msg Sent on ch#2\n", ch2send_ctr);
		printf("(%d) Msg Recieved on ch#3\n", ch3recv_ctr);
		printf("Success on ch#2-ch#3 pair\n");
		pthread_exit(0);
	} else
		printf("failure on ch#2-ch#3 pair\n");
end:
	pthread_exit(0);
}

void channel4_thread_m(void *ptr)
{
	unsigned long p;
	uint32_t len;
	int ret, ch4recv_ctr = 0;
	int tr = 0, ts = 0;
	int depth = 16, ch5send_ctr = 0;
	char retbuf[1024];
	void *vaddr;
	fsl_usmmgr_t* usmmgr_p;
    usmmgr_p = ac_getUsmMgr();

	ret = fsl_ipc_configure_channel(4, depth, IPC_PTR_CH, 0, 0, NULL, ipc);
	if (ret) {
		printf("\n ret %x \n", ret);
		EXIT(ret);
		pthread_exit(0);
	}
	ch4init = 1;
	while (loop2-- > 0) {
		do {
			ret = fsl_ipc_recv_ptr(4, &p, &len, ipc);
			usleep(1000);
			tr++;
			if (ret == ERR_SUCCESS)
				tr = 0;
			else if (tr == 500) {
				/* wait for 0.5 sec*/
				printf("Timed out. Message not received"
						" on ch#4\n");
				pthread_exit(0);
			}
		} while (ret == -ERR_CHANNEL_EMPTY);
		if (ret) {
			printf("\n ERROR ret %x \n", ret);
			printf("Exiting Thread for ch4\n");
			goto end;
		}
		ch4recv_ctr++;

		vaddr = fsl_usmmgr_p2v(p, *usmmgr_p);
		if (!vaddr) {
			ret = -ERR_NULL_VALUE;
			printf("\n Error in translating physical address %lx"
				" to virtual address\n", p);
			goto end;
		}
        ys_qcMsgForwd(vaddr, len, 0);
	}

	if (ch4recv_ctr == ch5send_ctr && ch4recv_ctr != 0) {
		printf("(%d) Msg Sent on ch#5\n", ch5send_ctr);
		printf("(%d) Msg Recieved on ch#4\n", ch4recv_ctr);
		printf("Success on ch#4-ch#5 pair\n");
		pthread_exit(0);
	} else
		printf("failure on ch#4-ch#5 pair\n");
end:
	pthread_exit(0);
}
#endif
void *test_p2v(unsigned long phys_addr)
{
   fsl_usmmgr_t* usmmgr_p;
   usmmgr_p = ac_getUsmMgr();
   return fsl_usmmgr_p2v(phys_addr, *usmmgr_p);
}
uint8_t subframe_ind_received = 0;

void receiveNXPPhyMsgNew()
{
    uint8_t *recvData_p = NULL;
    unsigned long p;
    uint8_t *buff;
    uint32_t len;
    int retval = 0;
    
    FAPI_T_MSG_HDR*  msgHead;
    uint8_t carrierIdx = 0;
    fsl_usmmgr_t* usmmgr_p;
    usmmgr_p = ac_getUsmMgr();
    //return;
    for(carrierIdx = 0; carrierIdx < NUM_MAX_CARRIER; carrierIdx++)
    {
 #if 0
        retval = fsl_ipc_recv_ptr(SC_TO_PA_ERROR_INDICATION_CH, &p, &len, ipc[carrierIdx]);
		if((retval == 0)&&(len >0))
        {      
           recvData_p = fsl_usmmgr_p2v(p, usmmgr);
           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                fflush(stdout);
                exit(-1);
            }
            memcpy(buff,recvData_p,len);
            ys_qcMsgForwd(buff, len, carrierIdx);
        }
        #endif
        #if 1

        retval = fsl_ipc_recv_ptr(SC_TO_PA_SUBFRAME_INDICATION_CH, &p, &len, ipc[carrierIdx]);
		  if((retval == 0)&&(len >0))
        {      
           recvData_p = fsl_usmmgr_p2v(p, *usmmgr_p);
           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                fflush(stdout);
                exit(-1);
            }
            #if 1
            phySubFrame = (U8)(((FAPI_T_SF_IND*)recvData_p)->sf_sfn&0x0F);
            phySubFrame = (phySubFrame + 10 -1) % 10;
            memcpy(buff,recvData_p,len);
            #endif
            ys_qcMsgForwd(buff, len, carrierIdx);
        }
        usleep(100);
        #endif
 #if 0
        retval = fsl_ipc_recv_ptr(SC_TO_PA_CRC_INDICATION_CH, recvData_p, &len, ipc[carrierIdx]);
		if((retval == 0)&&(len >0))
        {      
           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                fflush(stdout);
                exit(-1);
            }
            memcpy(buff,recvData_p,len);
            ys_qcMsgForwd(buff, len, carrierIdx);
        }

        retval = fsl_ipc_recv_ptr(SC_TO_PA_ULSCH_INDICATION_CH, recvData_p, &len, ipc[carrierIdx]);
		if((retval == 0)&&(len >0))
        {      
           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                fflush(stdout);
                exit(-1);
            }
            memcpy(buff,recvData_p,len);
            ys_qcMsgForwd(buff, len, carrierIdx);
        }

        retval = fsl_ipc_recv_ptr(SC_TO_PA_RACH_INDICATION_CH, recvData_p, &len, ipc[carrierIdx]);
		if((retval == 0)&&(len >0))
        {      
           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                fflush(stdout);
                exit(-1);
            }
            memcpy(buff,recvData_p,len);
            ys_qcMsgForwd(buff, len, carrierIdx);
        }
   

        retval = fsl_ipc_recv_ptr(SC_TO_PA_SRS_INDICATION_CH, recvData_p, &len, ipc[carrierIdx]);
		if((retval == 0)&&(len >0))
        {      
           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                fflush(stdout);
                exit(-1);
            }
            memcpy(buff,recvData_p,len);
            ys_qcMsgForwd(buff, len, carrierIdx);
        }
   

        retval = fsl_ipc_recv_ptr(SC_TO_PA_SR_INDICATION_CH, recvData_p, &len, ipc[carrierIdx]);
		if((retval == 0)&&(len >0))
        {      
           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                fflush(stdout);
                exit(-1);
            }
            memcpy(buff,recvData_p,len);
            ys_qcMsgForwd(buff, len, carrierIdx);
        }
 

        retval = fsl_ipc_recv_ptr(SC_TO_PA_CQI_INDICATION_CH, recvData_p, &len, ipc[carrierIdx]);
		if((retval == 0)&&(len >0))
        {      
           if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
            {
                STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                fflush(stdout);
                exit(-1);
            }
            memcpy(buff,recvData_p,len);
            ys_qcMsgForwd(buff, len, carrierIdx);
        }
#endif
        if(subframe_ind_received == 0)
        {
            retval = fsl_ipc_recv_ptr(SC_TO_PA_PARAM_RESPONSE_CH, &p, &len, ipc[carrierIdx]);
    		if((retval == 0)&&(len >0))
            {      
    
               recvData_p = fsl_usmmgr_p2v(p, *usmmgr_p);
    
               printf("SC_TO_PA_PARAM_RESPONSE_CH received  len %d\n",len);
               //printf(" %x \n",p);
               printf(" %d  %d %d %d \n",*(recvData_p),*(recvData_p+1),*(recvData_p+2),*(recvData_p+3));
               if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
                {
                    STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                    fflush(stdout);
                    exit(-1);
                }
                memcpy(buff,recvData_p,len);
                ys_qcMsgForwd(buff, len, carrierIdx);
            }
    
    		retval = fsl_ipc_recv_ptr(SC_TO_PA_CONFIG_RESPONSE_CH, &p, &len, ipc[carrierIdx]);
    		if((retval == 0)&&(len >0))
            {      
               recvData_p = fsl_usmmgr_p2v(p, *usmmgr_p);
               if(SGetStaticBuffer(ysCb.ysInit[0].region, ysCb.ysInit[0].pool,&buff, len, 0)!= ROK)
                {
                    STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
                    fflush(stdout);
                    exit(-1);
                }
                memcpy(buff,recvData_p,len);
                STKLOG(STK_MD_YS,STK_LOG_INFO,"SC_TO_PA_CONFIG_RESPONSE_CH carrierId[%d]  \n", carrierIdx);
                ys_qcMsgForwd(buff, len, carrierIdx);
                subframe_ind_received = 1;
            }
        }
    }
    return;
}


int ipc_init_nxp(int rat_id)
{
   fsl_usmmgr_t* usmmgr_p;
	uint64_t bmask;
	int ret = 0;
	int ret1, ret2;
    int depth = 16;
	char *buf = "Hello DSP.";
	pthread_t thread1, thread2;
	mem_range_t sh_ctrl;
	mem_range_t dsp_ccsr;
	mem_range_t pa_ccsr;
    U8 carrierIdx = 0;
    mem_range_t r;

	printf("\n=========$IPC TEST$====%s %s====\n", __DATE__, __TIME__);


    ac_shmIniit();

	usmmgr_p = ac_getUsmMgr();

	/* get values from mmgr */
	ret = get_pa_ccsr_area(&pa_ccsr, *usmmgr_p);
	if (ret) {
		printf("Error in obtaining PA CCSR Area information\n");
		return 1;
	}

	ret = get_dsp_ccsr_area(&dsp_ccsr, *usmmgr_p);
	if (ret) {
		printf("Error in obtaining DSP CCSR Area information\n");
		return 1;
	}

	ret = get_shared_ctrl_area(&sh_ctrl, *usmmgr_p);
	if (ret) {
		printf("Error in obtaining Shared Control Area information\n");
		return 1;
	}
#if 1
		/* use of fsl_ipc_init is deprecated
		* Instead use fsl_ipc_init_rat with rat_id 0,
		* for non-MULTI RAT scenarios*/
	ipc[0] = fsl_ipc_init(test_p2v, sh_ctrl, dsp_ccsr, pa_ccsr, UIO_INTERFACE);
    if (!ipc[0]) {
                printf("Issue with fsl_ipc_init %d\n", ret);
                return;
    }

#endif
#if 0
    ipc[0] = fsl_ipc_init_rat(0,test_p2v, sh_ctrl, dsp_ccsr, pa_ccsr, UIO_INTERFACE);

	ipc[1] = fsl_ipc_init_rat(1,test_p2v, sh_ctrl, dsp_ccsr, pa_ccsr, UIO_INTERFACE);


	if (!ipc[1]) {
		printf("Issue with fsl_ipc_init %d\n", ret);
		return;
	}
    #endif
	do {
		fsl_ipc_chk_recv_status(&bmask, ipc[0]);
		usleep(10000);
		if (!bmask)
			printf("\n main loop #ret %llx \n",
				(long long unsigned int)bmask);
	} while (!(isbitset(bmask, 0)));
#if 0
    do {
		fsl_ipc_chk_recv_status(&bmask, ipc[1]);
		usleep(10000);
		if (!bmask)
			printf("\n main loop #ret %llx \n",
				(long long unsigned int)bmask);
	} while (!(isbitset(bmask, 0)));
    #endif
#if 0
    fsl_ipc_open_prod_ch(PA_TO_SC_PARAM_REQUEST_CH, ipc[0]);
    fsl_ipc_open_prod_ch(PA_TO_SC_CONFIG_REQUEST_CH, ipc[0]);
    fsl_ipc_open_prod_ch(PA_TO_SC_START_REQUEST_CH, ipc[0]);
    fsl_ipc_open_prod_ch(PA_TO_SC_PARAM_REQUEST_CH, ipc[1]);
    fsl_ipc_open_prod_ch(PA_TO_SC_CONFIG_REQUEST_CH, ipc[1]);
    fsl_ipc_open_prod_ch(PA_TO_SC_START_REQUEST_CH, ipc[1]);
#endif
    for(carrierIdx = 0; carrierIdx < NUM_MAX_CARRIER; carrierIdx++)
    {
    #if 1
        fsl_ipc_open_prod_ch(PA_TO_SC_PARAM_REQUEST_CH, ipc[carrierIdx]);
        fsl_ipc_open_prod_ch(PA_TO_SC_CONFIG_REQUEST_CH, ipc[carrierIdx]);
        
        fsl_ipc_open_prod_ch(PA_TO_SC_DLCONF_REQUEST_CH, ipc[carrierIdx]);
        fsl_ipc_open_prod_ch(PA_TO_SC_ULCONF_REQUEST_CH, ipc[carrierIdx]);
        fsl_ipc_open_prod_ch(PA_TO_SC_HIDCI0_REQUEST_CH, ipc[carrierIdx]);
        fsl_ipc_open_prod_ch(PA_TO_SC_TX_REQUEST_CH, ipc[carrierIdx]);
        
        fsl_ipc_open_prod_ch(PA_TO_SC_START_REQUEST_CH, ipc[carrierIdx]);
       #endif
        ret = fsl_ipc_configure_channel(SC_TO_PA_PARAM_RESPONSE_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_PARAM_RESPONSE_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_CONFIG_RESPONSE_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_CONFIG_RESPONSE_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_ERROR_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_ERROR_INDICATION_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_SUBFRAME_INDICATION_CH, 1, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_SUBFRAME_INDICATION_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_HARQ_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_HARQ_INDICATION_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_CRC_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_CRC_INDICATION_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_ULSCH_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_ULSCH_INDICATION_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_RACH_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_RACH_INDICATION_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_SRS_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_SRS_INDICATION_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_SR_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_SR_INDICATION_CH ret error %x \n", ret);
           exit(-1);
	    }
        ret = fsl_ipc_configure_channel(SC_TO_PA_CQI_INDICATION_CH, depth, IPC_PTR_CH, 0, 0, NULL, ipc[carrierIdx]);
        if (ret) 
        {
		   printf("\n config SC_TO_PA_CQI_INDICATION_CH ret error %x \n", ret);
           exit(-1);
	    }
    }

	//fsl_ipc_open_prod_ch(2, ipc);
	//fsl_ipc_open_prod_ch(5, ipc);
   // ys_qcSendParReq(0);


	printf("Trying to start a thread\n");
   #if 0
	ret1 = pthread_create(&thread1, NULL,
			(void *)&channelSubframeInd_thread, NULL);
	if (ret1) {
		printf("pthread_create returns with error: %d", ret1);
		printf("from channel3_thread\n");
		return 1;
	}
    #endif
#if 0

    #if 1
    ret1 = pthread_create(&thread1, NULL,
			(void *)&channelParamRsp_thread, NULL);
	if (ret1) {
		printf("pthread_create returns with error: %d", ret1);
		printf("from channelParamRsp_thread\n");
		return 1;
	}
    #endif
    ret1 = pthread_create(&thread1, NULL,
			(void *)&channelConfigRsp_thread, NULL);
	if (ret1) {
		printf("pthread_create returns with error: %d", ret1);
		printf("from channelConfigRsp_thread\n");
		return 1;
	}
	printf("channelConfigRsp_thread created\n");


    ys_qcSendParReq(1);
#endif
    printf("NXP IPC init ok");
    return 0;
}

void getTimeFromAcMsg(U8* msgPtr, CmLteTimingInfo* msgTime_p)
{
   U16* sf_sfn_p;
   sf_sfn_p = msgPtr + sizeof(FAPI_T_MSG_HDR);
   msgTime_p->sfn = (*sf_sfn_p) >> 4;
   msgTime_p->subframe = (*sf_sfn_p) & 0xF;
}

//N should be arrived at N+1, and handled at N + 2
#define  MAX_UL_LINK_DELAY  2

//msgTime, the time carried in the phy msg, it's stand for the air interface time, 
//currentTime, the time when ys receive the message
//so the "currentTime" should after the "msgTime"

S16 getTimeDiff(CmLteTimingInfo* msgTime_p, CmLteTimingInfo* currentTime_p)
{

   S16 timeDiff = -1;
   
   S16 currentSfn;
   S16 currentSubframe;
   S16 msgSfn;
   S16 msgSubframe;

   currentSfn = currentTime_p->sfn;
   currentSubframe = currentTime_p->subframe;
   msgSfn = msgTime_p->sfn;
   msgSubframe = msgTime_p->subframe;



   if(currentSfn == msgSfn)
   {
      timeDiff = currentSubframe - msgSubframe;
   }
   else if(currentSfn > msgSfn)
   {
      timeDiff = (currentSfn - msgSfn) * 10 + currentSubframe - msgSubframe;
   }
   else
   {
      if((currentSfn == 0) && (msgSfn == 1023))
      {
         timeDiff = 10 + currentSubframe - msgSubframe;
      }
   }
   return timeDiff; 

}
        
        
Bool checkTime(CmLteTimingInfo* msgTime_p, CmLteTimingInfo* curTime_p)
{
   S16 timeDiff;
   timeDiff = getTimeDiff(msgTime_p, curTime_p);

   //firstly, we should make sure the delay is acceptable
   if((timeDiff < 0) || (timeDiff > MAX_UL_LINK_DELAY))
   {
      return FALSE;
   }
  
   return TRUE;
}
void handleACIPCMsg(ipcChannelNum ipcChannel, uint8_t carrierIdx)
{
   uint8_t *recvData_p = NULL;
   unsigned long p;
   uint8_t *buff;
   uint32_t len;
   uint8_t checkTimeResult = TRUE;
   int retval = 0;
   CmLteTimingInfo msgTime;
   YsCellCb* cellCb;
   fsl_usmmgr_t* usmmgr_p;
   usmmgr_p = ac_getUsmMgr();

   do
   {
      retval = fsl_ipc_recv_ptr(ipcChannel, &p, &len, ipc[carrierIdx]);
      if((retval == 0)&&(len >0))
      {
         recvData_p = fsl_usmmgr_p2v(p, *usmmgr_p);
         // TODO: maybe there is no need to alloc this buff
         if(SGetStaticBuffer(ysCb.ysInit[carrierIdx].region, ysCb.ysInit[carrierIdx].pool,&buff, len, 0)!= ROK)
         {
             STKLOG(STK_MD_YS,STK_LOG_INFO,"failed to alloc buffer %s %d!!\n", __FILE__, __LINE__);
             fflush(stdout);
             exit(-1);
         }
         memcpy(buff,recvData_p,len);

         if(ipcChannel == SC_TO_PA_ERROR_INDICATION_CH)
         {
             checkTimeResult = TRUE;
         }
         else
         {
             cellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(carrierIdx);
             getTimeFromAcMsg(buff, &msgTime);    
             checkTimeResult = checkTime(&msgTime, &(cellCb->timingInfo));
         }
         if(checkTimeResult)
         {
            switch(ipcChannel)
            {
               case SC_TO_PA_HARQ_INDICATION_CH:
               {
                  ys_qcHarqIndHndl(buff, carrierIdx);
                  break;
               }
               case SC_TO_PA_RACH_INDICATION_CH:
               {
                  ys_qcRachIndHndl(buff, carrierIdx);
                  break;
               }
               case SC_TO_PA_CRC_INDICATION_CH:
               {
                  ys_qcCrcIndHndl(buff, carrierIdx);
                  break;
               }
               case SC_TO_PA_CQI_INDICATION_CH:
               {
                  ys_qcRxDlCqiHndl(buff, carrierIdx);
                  break;
               }
               case SC_TO_PA_SR_INDICATION_CH:
               {
                  ys_qcRxSrIndHndl(buff, carrierIdx);
                  break;
               }
               case SC_TO_PA_ULSCH_INDICATION_CH:
               {
                  ys_NxpRxUlschIndHndl(buff, carrierIdx);
                  break;
               }
               case SC_TO_PA_ERROR_INDICATION_CH:
               {
                  ys_NxpRxErrorIndHndl(buff, carrierIdx);
                  break;
               }
               #if 0
               case SC_TO_PA_SUBFRAME_INDICATION_CH:
               {
                  getTimeFromAcMsg(buff, &g_ACTime);
                  if(firstTtiGot == false)
                  {
                     firstTtiGot = true;
                     getTimeFromAcMsg(buff, &g_macTime);
                  }
                  break;
               }
               #endif
               default:
               {
                  STKLOG(STK_MD_YS,STK_LOG_ERR,"unsupported IPC channel: %d!!\n",ipcChannel);
               }
            }
            SPutStaticBuffer(ysCb.ysInit[carrierIdx].region, ysCb.ysInit[carrierIdx].pool,(Data *)buff, len, 0);
            
         }
         else
         {
            STKLOG(STK_MD_YS,STK_LOG_WARNING,"msg time check failed: %d. curTime:(%d, %d), msgTime:(%d,%d)",
               ipcChannel,
               cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
               msgTime.sfn, msgTime.subframe);
         }       
      }
   }while((retval == 0)&&(len >0));
}

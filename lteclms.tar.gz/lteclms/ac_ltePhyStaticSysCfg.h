/*******************************************************************************
 *                       ArrayComm Confidential
 *                  Copyright (c) ArrayComm, LLC. 1995-2013
 *
 *      This software is furnished under license and may be used or
 *      copied only in accordance with the terms of such license.
 *******************************************************************************
 * @file   ac_ltePhyStaticSysCfg.h
 * @brief  Include file for LTE PHY static system configuration
 * parameter settings. These static system configuration parameters set the
 * upper limit the executable code will support such as maximum system bandwidth
 * or maximum number of RBs for PUCCH etc...
 *
 * Change Log:
 *      Date              Who            What
 *      2010/04/21        Quoc           Initial draft.
 *      2012/07/12        nzhou          define the static parameters for FSL9131
 *      2013/01/16        nzhou          define the static parameters for MSC8157
 *******************************************************************************
 */
#ifndef LTE_PHY_STATIC_SYS_CFG_H /* once only */
#define LTE_PHY_STATIC_SYS_CFG_H

/* These parameters must be configured appropriately before compilation.
 * They determine the upper limit such as the number RBs the PHY supports
 * and the size of the memory required.
 */

/* Specify the maximum number of serving cells when carreier aggregation */
#define AC_MAX_NUM_CC                     (5)

/* Specify the maximum number of rank in R10 */
#define AC_MAX_NUM_RANK                   (8)

/* Specify the maximum number of RBs PHY support. Valid input are:
 *  ---------------------------------------------------------------------
 *  | Bandwidth(Mhz) |   20  |   15  |    10  |    5   |   3   |  1.4   |
 *  +----------------+-------+-------+--------+--------+-------+--------+
 *  | MAX_NUM_RB     |  100  |   75  |    50  |    25  |   15  |  6     |
 *  ---------------------------------------------------------------------*/
#define AC_MAX_NUM_DSP                    (1)

#define AC_MAX_NUM_RB                     (100)

/* Specify the number of uplink and downlink antennas */
#define AC_MAX_NUM_TX_ANT                 (8) // First version: 4 antenna, next will extend to 8
#define AC_MAX_NUM_RX_ANT                 (8)
#define AC_NUM_TX_ANT_CATM                (2)

#define AC_NUM_SECTORS                    (1)
/* Specify the CP type 0->Normal CP only, 1-> extended CP only, 2->both CP type */
#define AC_SUPPORT_CP_TYPE                (0)

/* Specify RF interface 0->AIC, 1->CPRI, 2->FPGA*/
#define AC_RF_INTERFACE                   (2)
/* Specify number of bit for RF sampling*/
#define AC_SAMPLE_BIT_WIDTH               (16)
/* Specify who provide tti tick for frame sync, 0->L1 is mater, 1->L2 is master*/
#define AC_FRAME_SYNC_MASTER              (0)

/* -------------- Max Settings for Downlink ----------------------- */
/* Place any DL static configuration settings in this section */
/*the frequency domain IQ data Q format for DL channels*/
#define AC_DL_FREQUENCY_DATA_Q_FORMAT     (11)
/* -------------- Max Settings for DL CTRL symbols ----------- */
#define AC_MAX_CFI_VALUE                  (3)
/* -------------- Max Settings for DL CTRL ------------------- */
#define AC_MAX_DL_PDCCH_PER_SUBFRAME             (AC_MAX_PDSCH_PER_SUBFRAME)
#define AC_MAX_UL_PDCCH_FMT3_3A_PER_SUBFRAME     (10) // TBD
#define AC_MAX_UL_PDCCH_FMT0_PER_SUBFRAME        (AC_MAX_PUSCH_PER_SUBFRAME)
#define AC_MAX_UL_PDCCH_PER_SUBFRAME             (AC_MAX_UL_PDCCH_FMT3_3A_PER_SUBFRAME + AC_MAX_PUSCH_PER_SUBFRAME)
#define AC_MAX_PDCCH_PER_SUBFRAME                (AC_MAX_DL_PDCCH_PER_SUBFRAME + AC_MAX_UL_PDCCH_PER_SUBFRAME)
#define AC_MAX_DL_MPDCCH_PER_SUBFRAME            (16)

#define AC_MAX_DL_PCH_PER_SUBFRAME               (4)
/* using uint8 to store the number of HI, maximum value is 255 */
#define AC_MAX_PHICH_PER_SUBFRAME         (255)
/* -------------- Max Settings for PDSCH --------------------- */
/*1 PDSCH for RAR, + 1 PDSCH for SIB + 1 PDSCH for paging*/
#define AC_MAX_PDSCH_PAG_PER_SUBFRAME       (1)
#define AC_MAX_PDSCH_RAR_SIB_PER_SUBFRAME   (2)
#define AC_MAX_PDSCH_DATA_USER_PER_SUBFRAME (16)
#define AC_MAX_CATM_PDSCH_PER_SUBFRAME      (AC_MAX_DL_MPDCCH_PER_SUBFRAME)
#define AC_MAX_256QAM_PDSCH_PER_SUBFRAME    (AC_MAX_PDSCH_DATA_USER_PER_SUBFRAME)
/*19 users = 16 PDSCH data users + 3 COMMON_PDSCH*/
#define AC_MAX_PDSCH_PER_SUBFRAME         (AC_MAX_PDSCH_PAG_PER_SUBFRAME + AC_MAX_PDSCH_RAR_SIB_PER_SUBFRAME + AC_MAX_PDSCH_DATA_USER_PER_SUBFRAME)

/*Specify the max number of TM7 active user */
#define AC_MAX_TM7_ACTIVE_USER            (64) // fixme: need to discuss later

/*every AC_NUM_FRM_TM7_ACTIVE_CHECK subframe to check whether TM7 user is still active user */
#define AC_NUM_FRM_TM7_ACTIVE_CHECK       (8) // fixme: need to discuss later
/*If the TM7 user doesn't appear for AC_MAX_NUM_FRM_TM7_ACTIVE_STAT frames, the TM7 user will become inactive */
#define AC_MAX_NUM_FRM_TM7_ACTIVE_STAT    (50) // fixme: need to discuss later 

/*Specify the max number of DL TB size*/
#define AC_MAX_PDSCH_NUM_TB_PER_USER      (2)
#define AC_MAX_DL_TB_SIZE                 (351232)    //32byte align, 351224---->351232
/* -------------- Max Settings for DL MIMO layers ------------ */
#define AC_MAX_DL_SU_MIMO_LAYER           (2)
#define AC_MAX_DL_MU_MIMO_LAYER           (1)
/*specify DL beam-forming training type 0->None, 1->SRS, 2->PUSCH*/
#define AC_DL_BF_TRAING_TYPE              (0)
/*specify max number of beam-forming sub-bands*/
#define AC_MAX_NUM_DL_BF_SUBBANDS         (14)

/* -------------- Max Settings for PUSCH ----------------------- */
/* Place any PUSCH static configuration settings in this section */
/*Specify receiver type 0->MRC, 1->AIC*/
#define AC_PUSCH_RECEIVER_TYPE             (0)
/*Specify the max number of UL TB size*/
#define AC_MAX_UL_TB_SIZE                 (75376)
/*Specify UL MIMO layers*/
#define AC_MAX_UL_SU_MIMO_LAYER            (1)
#define AC_MAX_UL_MU_MIMO_LAYER            (4)  // Current PUSCH6 algorithm can support up to 4 layer for MU-MIMO.
/*MAX user of PUSCH in one sub-frame*/
#define AC_MAX_PUSCH_PER_SUBFRAME          (24) // Total PUSCH user number across all layers within one subframe.
/*Specify the max number of PUSCH HARQ report UE*/
#define AC_MAX_PUSCH_NUM_HARQ_PER_SUBFRAME (AC_MAX_PUSCH_PER_SUBFRAME) // use maximum user number before there is a clear custom acquirement
/*Specify the max number of PUSCH CQI report UE*/
#define AC_MAX_PUSCH_NUM_CQI_PER_SUBFRAME  (AC_MAX_PUSCH_PER_SUBFRAME) // use maximum user number before there is a clear custom acquirement

/*specify the frequeny hopping mode 0-> not support, 1->support*/
#define AC_PUSCH_FREQ_HOP_SUPPORT         (0)
/* -------------- Max Settings for HARQ ----------------------- */
/*Maximum number of HARQ processes. For FDD the max is 8, the TDD, the maxium is 7, so use the 8 as the max*/
#define AC_MAX_UL_HARQ_PROC               (8)
/*Maximum number of transmission number of UL HARQ, 4 for re-trans, 1 for new data*/
#define AC_MAX_NUM_UL_HARQ_TX             (5)
/*Maximum number of active HARQ users in a duration of AC_NUM_FRM_HARQ_FREE frames.*/
#define AC_MAX_ACT_HARQ_USERS             (1200)
/*If the UE is not actived to transmit UL data within four Radio frame, it's HARQ buffer will be freed automatically*/
#define AC_MAX_NUM_FRM_HARQ_FREE          (4)
/*maximum number of PDUs in UL config message*/
#define AC_MAX_NUM_UL_CFG_PDU             (256)

/* --------------- Max Setttings for PUCCH ---------------------- */
/* Place any PUCCH static configuration settings in this section */
/* Maximum number of RBs for PUCCH in one sub-frame*/
#define AC_MAX_PUCCH_RB_PER_SUBFRAME      (19)
/* Set the maximum number of UE per RB in PUCCH.
 * Valid number are 12, 18 or 36. This number is directly related to
 * pucch_delta_shift what is broadcast on BCH channel.
 */
/* Set the maximum number of format1 orthogonal sequence per RB in PUCCH. */
#define AC_MAX_PUCCH_FRMT1_NUM_OC_PER_RB    (3)
/* Set the maximum number of cyclic shift per RB in PUCCH. */
#define AC_MAX_PUCCH_NUM_CS_PER_RB          (12)
/* Set the maximum number of Format 1 allocations per RB in PUCCH. */
#define AC_MAX_PUCCH_FRMT1_NUM_ALLOC_PER_RB    (AC_MAX_PUCCH_FRMT1_NUM_OC_PER_RB*AC_MAX_PUCCH_NUM_CS_PER_RB)
#define AC_MAX_PUCCH_FRMT1_NUM_UE_PER_RB       AC_MAX_PUCCH_FRMT1_NUM_ALLOC_PER_RB
/* Set the maximum number of Format 2 allocation per RB in PUCCH. */
#define AC_MAX_PUCCH_FRMT2_NUM_ALLOC_PER_RB    (AC_MAX_PUCCH_NUM_CS_PER_RB)
#define AC_MAX_PUCCH_FRMT2_NUM_UE_PER_RB       (AC_MAX_PUCCH_FRMT2_NUM_ALLOC_PER_RB)
/* Set the maximum number of Format 3 uses per RB in PUCCH. */
#define AC_MAX_PUCCH_FRMT3_NUM_UE_PER_RB    (5)
/* Set the maximum number of allocation per UE in PUCCH. */
#define AC_MAX_PUCCH_NUM_ALLOC_PER_UE       (5) //SR + 4ACK/NACK
/* Set the maximum number of allocation per RB in PUCCH. */
#define AC_MAX_PUCCH_NUM_ALLOC_PER_RB    /*lint -e506*/AC_MAX(AC_MAX_PUCCH_FRMT1_NUM_ALLOC_PER_RB, AC_MAX_PUCCH_FRMT2_NUM_ALLOC_PER_RB)/*lint +e506*/
#define AC_MAX_PUCCH_NUM_UE_PER_RB       AC_MAX_PUCCH_NUM_ALLOC_PER_RB
/*Specify the max number of SR UE per subframe*/
#define AC_MAX_PUCCH_NUM_SR_PER_SUBFRMAE    (50)
/*Specify the max number of PUCCH HARQ report UE*/
#define AC_MAX_PUCCH_NUM_HARQ_PER_SUBFRAME  (128)
/*Specify the max number of uplink CQI report UE*/
#define AC_MAX_PUCCH_NUM_CQI_PER_SUBFRAME   (96)

/*MAX user of PUCCH in one sub-frame*/
#if ((AC_MAX_PUCCH_NUM_SR_PER_SUBFRMAE >= AC_MAX_PUCCH_NUM_HARQ_PER_SUBFRAME) && (AC_MAX_PUCCH_NUM_SR_PER_SUBFRMAE >= AC_MAX_PUCCH_NUM_CQI_PER_SUBFRAME))
#define AC_MAX_PUCCH_PER_SUBFRAME         (AC_MAX_PUCCH_NUM_SR_PER_SUBFRMAE)
#elif ((AC_MAX_PUCCH_NUM_HARQ_PER_SUBFRAME >= AC_MAX_PUCCH_NUM_SR_PER_SUBFRMAE) && (AC_MAX_PUCCH_NUM_HARQ_PER_SUBFRAME >= AC_MAX_PUCCH_NUM_CQI_PER_SUBFRAME))
#define AC_MAX_PUCCH_PER_SUBFRAME         (AC_MAX_PUCCH_NUM_HARQ_PER_SUBFRAME)
#elif ((AC_MAX_PUCCH_NUM_CQI_PER_SUBFRAME >= AC_MAX_PUCCH_NUM_SR_PER_SUBFRMAE)&&(AC_MAX_PUCCH_NUM_CQI_PER_SUBFRAME >= AC_MAX_PUCCH_NUM_HARQ_PER_SUBFRAME))
#define AC_MAX_PUCCH_PER_SUBFRAME         (AC_MAX_PUCCH_NUM_CQI_PER_SUBFRAME)
#else
#endif

/* -------------- Max Settings for SRS ----------------------- */
/* Place any SRS static configuration settings in this section */
/*MAX user of SRS in one sub-frame*/
#define AC_MAX_SRS_PER_SUBFRAME           (48)
/*Specify the max number of SRS RB per UE */
#define AC_MAX_SRS_RB_PER_UE              (96)

/* -------------- Max Settings for PRACH ----------------------- */
/* Place any PRACH static configuration settings in this section */
/* Max number of detected UE preamble per subfamre--------------- */
#define AC_MAX_NUM_PRACH_UE_PER_SUBFRAME   (8)
#define AC_MAX_NUM_NB_PRACH_UE             (48)
/* Max root sequence of a oppo*/
#define AC_MAX_NUM_ROOTSEQ_PER_OPP         (64)
/* PRACH support opportunity number */
#define AC_MAX_NUM_RACH_FREQ_OPPORTUNITY   (3)

/* -------------- Max Settings others ----------------------- */
/* Place any other static configuration settings in this section */
#define AC_MAX_PUSCH_CONSTELLATION_SIZE_PER_UE (96) /* 1 RB x 12 SC x 2 slots x 4 bytes*/
#define AC_MAX_ERR_NUM_PER_ERR_TYPE            (32)      /* TBD */
#define AC_MAX_ERR_NUM_PER_ERR_IND             (16)
#define AC_MAX_RNTI_NUM                        (65536)  // RNTI range from 1 to 65535, set the max number to 65536
//reed-muller CQI bits
#define AC_RM_CQI_BITS_SUPPORTED               (11)    //MAX CQI bit supported is 11, consider multi-CC
/*Specify the max number of uplink HARQ report UE*/
#define AC_MAX_NUM_HARQ_PER_SUBFRAME           (AC_MAX_PUCCH_NUM_HARQ_PER_SUBFRAME + AC_MAX_PUSCH_NUM_HARQ_PER_SUBFRAME)
/*Specify the max number of uplink CQI report UE*/
#define AC_MAX_NUM_CQI_PER_SUBFRAME            (AC_MAX_PUCCH_NUM_CQI_PER_SUBFRAME + AC_MAX_PUSCH_NUM_CQI_PER_SUBFRAME)

/*Specify the max number of HARQ bits (The max number of bits for FDD is 10,20 for TDD).Now we only support 11bits.*/
#define AC_MAX_NUM_HARQ_ACK_BITS          (20)

/*Maximum number of active FO state users.*/
#define AC_MAX_ACT_FO_STATE_USERS            (512)

#endif /*LTE_PHY_STATIC_SYS_CFG_H */

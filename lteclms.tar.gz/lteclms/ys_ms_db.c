/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************
 
     Name:     LTE MAC Convergence Layer
  
     Type:     C source file
  
     Desc:     C source code for tables lookup  
     File:     ys_db.c
  
     Sid:      yw_ms_db.c@@/main/TeNB_Main_BR/5 - Wed Jun 11 13:19:52 2014
  
     Prg:      pk
  
**********************************************************************/

/** @file ys_db.c
@brief This module acts as an interface handler for upper interface and 
manages Pst and Sap related information for upper interface APIs.
*/

/* header include files -- defines (.h) */

/* header/extern include files (.x) */
/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_lte.h"
#include "ctf.h"           /* CTF defines */
#include "lys.h"           /* layer management defines for LTE-CL */
#include "tfu.h"

#ifdef YS_MSPD
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "apidefs.h"
#include "LtePhyL2Api.h"
#include "resultcodes.h"
#endif
#include "ys_ms.h"            /* defines and macros for CL */
#else
#include "ys_ms.h"            /* defines and macros for CL */
#endif /* YS_MSPD */
#include "ys_ms_err.h"        /* YS error defines */

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "spaccdrv.h" /*sumanth*/
#endif
#endif

/* header/extern include files (.x) */

#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"
#include "ctf.x"           /* CTF types */
#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"

#ifdef YS_MSPD
#include "ys_ms.x"            /* typedefs for CL */
#else
#include "ys.x"            /* typedefs for CL */
#endif /* YS_MSPD */




PUBLIC Bool               ysPrachPresDb[YS_NUM_PRACH_PRES_ARR];
PUBLIC YsSrCfgInfo        ysSrCfgDb[YS_NUM_SR_CFG];
PUBLIC YsSrsCfgInfo       ysSrsCfgDb[YS_NUM_SRS_CFG];
PUBLIC YsCqiPmiCfgIdxInfo ysCqiPmiCfgDb[YS_NUM_CQI_CFG];

#ifdef YS_MSPD
#ifdef TFU_TDD
PUBLIC YsPrachTddCfgInfo ysPrachTddCfgDb[YS_NUM_PRACH_TDD_CFG] = 
{
   {
      0,
      YS_PREAM_FRMT_0,
      YS_DRA_0_POINT_5,
      YS_rRA_0
   },
   {
      1,
      YS_PREAM_FRMT_0,
      YS_DRA_0_POINT_5,
      YS_rRA_1
   },
   {
      2,
      YS_PREAM_FRMT_0,
      YS_DRA_0_POINT_5,
      YS_rRA_2
   },
   {
      3,
      YS_PREAM_FRMT_0,
      YS_DRA_1,
      YS_rRA_0
   },
   {
      4,
      YS_PREAM_FRMT_0,
      YS_DRA_1,
      YS_rRA_1
   },
   {
      5,
      YS_PREAM_FRMT_0,
      YS_DRA_1,
      YS_rRA_2
   },
   {
      6,
      YS_PREAM_FRMT_0,
      YS_DRA_2,
      YS_rRA_0
   },
   {
      7,
      YS_PREAM_FRMT_0,
      YS_DRA_2,
      YS_rRA_1
   },
   {
      8,
      YS_PREAM_FRMT_0,
      YS_DRA_2,
      YS_rRA_2
   },
   {
      9,
      YS_PREAM_FRMT_0,
      YS_DRA_3,
      YS_rRA_0
   },
   {
      10,
      YS_PREAM_FRMT_0,
      YS_DRA_3,
      YS_rRA_1
   },
   {
      11,
      YS_PREAM_FRMT_0,
      YS_DRA_3,
      YS_rRA_2
   },
   {
      12,
      YS_PREAM_FRMT_0,
      YS_DRA_4,
      YS_rRA_0
   },
   {
      13,
      YS_PREAM_FRMT_0,
      YS_DRA_4,
      YS_rRA_1
   },
   {
      14,
      YS_PREAM_FRMT_0,
      YS_DRA_4,
      YS_rRA_2
   },
   {
      15,
      YS_PREAM_FRMT_0,
      YS_DRA_5,
      YS_rRA_0
   },
   {
      16,
      YS_PREAM_FRMT_0,
      YS_DRA_5,
      YS_rRA_1
   },
   {
      17,
      YS_PREAM_FRMT_0,
      YS_DRA_5,
      YS_rRA_2
   },
   {
      18,
      YS_PREAM_FRMT_0,
      YS_DRA_6,
      YS_rRA_0
   },
   {
      19,
      YS_PREAM_FRMT_0,
      YS_DRA_6,
      YS_rRA_1
   },
   {
      20,
      YS_PREAM_FRMT_1,
      YS_DRA_0_POINT_5,
      YS_rRA_0
   },
   {
      21,
      YS_PREAM_FRMT_1,
      YS_DRA_0_POINT_5,
      YS_rRA_1
   },
   {
      22,
      YS_PREAM_FRMT_1,
      YS_DRA_0_POINT_5,
      YS_rRA_2
   },
   {
      23,
      YS_PREAM_FRMT_1,
      YS_DRA_1,
      YS_rRA_0
   },
   {
      24,
      YS_PREAM_FRMT_1,
      YS_DRA_1,
      YS_rRA_1
   },
   {
      25,
      YS_PREAM_FRMT_1,
      YS_DRA_2,
      YS_rRA_0
   },
   {
      26,
      YS_PREAM_FRMT_1,
      YS_DRA_3,
      YS_rRA_0
   },
   {
      27,
      YS_PREAM_FRMT_1,
      YS_DRA_4,
      YS_rRA_0
   },
   {
      28,
      YS_PREAM_FRMT_1,
      YS_DRA_5,
      YS_rRA_0
   },
   {
      29,
      YS_PREAM_FRMT_1,
      YS_DRA_6,
      YS_rRA_0
   },
   {
      30,
      YS_PREAM_FRMT_2,
      YS_DRA_0_POINT_5,
      YS_rRA_0
   },
   {
      31,
      YS_PREAM_FRMT_2,
      YS_DRA_0_POINT_5,
      YS_rRA_1
   },
   {
      32,
      YS_PREAM_FRMT_2,
      YS_DRA_0_POINT_5,
      YS_rRA_2
   },
   {
      33,
      YS_PREAM_FRMT_2,
      YS_DRA_1,
      YS_rRA_0
   },
   {
      34,
      YS_PREAM_FRMT_2,
      YS_DRA_1,
      YS_rRA_1
   },
   {
      35,
      YS_PREAM_FRMT_2,
      YS_DRA_2,
      YS_rRA_0
   },
   {
      36,
      YS_PREAM_FRMT_2,
      YS_DRA_3,
      YS_rRA_0
   },
   {
      37,
      YS_PREAM_FRMT_2,
      YS_DRA_4,
      YS_rRA_0
   },
   {
      38,
      YS_PREAM_FRMT_2,
      YS_DRA_5,
      YS_rRA_0
   },
   {
      39,
      YS_PREAM_FRMT_2,
      YS_DRA_6,
      YS_rRA_0
   },
   {
      40,
      YS_PREAM_FRMT_3,
      YS_DRA_0_POINT_5,
      YS_rRA_0
   },
   {
      41,
      YS_PREAM_FRMT_3,
      YS_DRA_0_POINT_5,
      YS_rRA_1
   },
   {
      42,
      YS_PREAM_FRMT_3,
      YS_DRA_0_POINT_5,
      YS_rRA_2
   },
   {
      43,
      YS_PREAM_FRMT_3,
      YS_DRA_1,
      YS_rRA_0
   },
   {
      44,
      YS_PREAM_FRMT_3,
      YS_DRA_1,
      YS_rRA_1
   },
   {
      45,
      YS_PREAM_FRMT_3,
      YS_DRA_2,
      YS_rRA_0
   },
   {
      46,
      YS_PREAM_FRMT_3,
      YS_DRA_3,
      YS_rRA_0
   },
   {
      47,
      YS_PREAM_FRMT_3,
      YS_DRA_4,
      YS_rRA_0
   },
   {
      48,
      YS_PREAM_FRMT_4,
      YS_DRA_0_POINT_5,
      YS_rRA_0
   },
   {
      49,
      YS_PREAM_FRMT_4,
      YS_DRA_0_POINT_5,
      YS_rRA_1
   },
   {
      50,
      YS_PREAM_FRMT_4,
      YS_DRA_0_POINT_5,
      YS_rRA_2
   },
   {
      51,
      YS_PREAM_FRMT_4,
      YS_DRA_1,
      YS_rRA_0
   },
   {
      52,
      YS_PREAM_FRMT_4,
      YS_DRA_1,
      YS_rRA_1
   },
   {
      53,
      YS_PREAM_FRMT_4,
      YS_DRA_2,
      YS_rRA_0
   },
   {
      54,
      YS_PREAM_FRMT_4,
      YS_DRA_3,
      YS_rRA_0
   },
   {
      55,
      YS_PREAM_FRMT_4,
      YS_DRA_4,
      YS_rRA_0
   },
   {
      56,
      YS_PREAM_FRMT_4,
      YS_DRA_5,
      YS_rRA_0
   },
   {
      57,
      YS_PREAM_FRMT_4,
      YS_DRA_6,
      YS_rRA_0
   },
   {
      58,
      YS_PREAM_FRMT_NA,
      YS_DRA_NA,
      YS_rRA_NA
   },
   {
      59,
      YS_PREAM_FRMT_NA,
      YS_DRA_NA,
      YS_rRA_NA
   },
   {
      60,
      YS_PREAM_FRMT_NA,
      YS_DRA_NA,
      YS_rRA_NA
   },
   {
      61,
      YS_PREAM_FRMT_NA,
      YS_DRA_NA,
      YS_rRA_NA
   },
   {
      62,
      YS_PREAM_FRMT_NA,
      YS_DRA_NA,
      YS_rRA_NA
   },
   {
      63,
      YS_PREAM_FRMT_NA,
      YS_DRA_NA,
      YS_rRA_NA
   }
};

PUBLIC YsPrachTddMapLst ysPrachTddMapLstDb[YS_NUM_PRACH_TDD_MAP]
                                          [YS_NUM_TDD_SF_CFG]= 
{
   /* PRACH Configuration Index 0 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_4
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_4
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_4
            }
         }  
      }
   },
   /* PRACH Configuration Index 1 */
   {
      {       /* UL/DL Cfg 0 */
         1,
            {
               {
                  YS_FREQ_RES_IDX_0,
                  YS_ODD_SFN,
                  YS_SF_4
               }
            }
      },
      {       /* UL/DL Cfg 1 */
         1,
            {
               {
                  YS_FREQ_RES_IDX_0,
                  YS_ODD_SFN,
                  YS_SF_3
               }
            }
      },
      {       /* UL/DL Cfg 2 */
         1,
            {
               {
                  YS_FREQ_RES_IDX_0,
                  YS_ODD_SFN,
                  YS_SF_2
               }
            }
      },
      {       /* UL/DL Cfg 3 */
         1,
            {
               {
                  YS_FREQ_RES_IDX_0,
                  YS_ODD_SFN,
                  YS_SF_4
               }
            }
      },
      {       /* UL/DL Cfg 4 */
         1,
            {
               {
                  YS_FREQ_RES_IDX_0,
                  YS_ODD_SFN,
                  YS_SF_3
               }
            }
      },
      {       /* UL/DL Cfg 5 */
         1,
            {
               {
                  YS_FREQ_RES_IDX_0,
                  YS_ODD_SFN,
                  YS_SF_2
               }
            }
      },
      {       /* UL/DL Cfg 6 */
         1,
            {
               {
                  YS_FREQ_RES_IDX_0,
                  YS_ODD_SFN,
                  YS_SF_4
               }
            }
      }
   },
   /* PRACH Configuration Index 2 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_9
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_8
            }
         }  
      }
   },
   /* PRACH Configuration Index 3 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            }
         }  
      }
   },
   /* PRACH Configuration Index 4 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_9
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      }
   },
   /* PRACH Configuration Index 5 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      }
   },
   /* PRACH Configuration Index 6 */
   {
      {       /* UL/DL Cfg 0 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_9
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      }
   },
   /* PRACH Configuration Index 7 */
   {
      {       /* UL/DL Cfg 0 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      }
   },
   /* PRACH Configuration Index 8 */
   {
      {       /* UL/DL Cfg 0 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      }
   },
   /* PRACH Configuration Index 9 */
   {
      {       /* UL/DL Cfg 0 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_9
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      }
   },
   /* PRACH Configuration Index 10 */
   {
      {       /* UL/DL Cfg 0 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      }
   },
   /* PRACH Configuration Index 11 */
   {
      {       /* UL/DL Cfg 0 */
         0
      },
      {       /* UL/DL Cfg 1 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      }
   },
   /* PRACH Configuration Index 12 */
   {
      {       /* UL/DL Cfg 0 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_9
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_4
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      }
   },
   /* PRACH Configuration Index 13 */
   {
      {       /* UL/DL Cfg 0 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_9
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      }
   },
   /* PRACH Configuration Index 14 */
   {
      {       /* UL/DL Cfg 0 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      }
   },
   /* PRACH Configuration Index 15 */
   {
      {       /* UL/DL Cfg 0 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_9
            }
         } 
      },
      {       /* UL/DL Cfg 1 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 2 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_4
            }
         } 
      },
      {       /* UL/DL Cfg 4 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 5 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_2
            }
         } 
      },
      {       /* UL/DL Cfg 6 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         } 
      }
   },
   /* PRACH Configuration Index 16 */
   {
      {       /* UL/DL Cfg 0 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_9
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_4
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   },
   /* PRACH Configuration Index 17 */
   {
      {       /* UL/DL Cfg 0 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_9
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   },
   /* PRACH Configuration Index 18 */
   {
      {       /* UL/DL Cfg 0 */
          6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_9
            }
         }
      },
      {       /* UL/DL Cfg 1 */
          6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_8
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
          6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_4
            }
         }
      },
      {       /* UL/DL Cfg 4 */
          6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 5 */
          6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_5,
               YS_ALL_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 6 */
          6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_4
            }
         }
      }
   },
   /* PRACH Configuration Index 19 */
   {
      {       /* UL/DL Cfg 0 */
         0
      },
      {       /* UL/DL Cfg 1 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            }
         } 
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_4
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_8
            }
         } 
      }
   },
   /* PRACH Configuration Index 20 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }
      }
   },
   /* PRACH Configuration Index 21 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_3
            }
         }
      }
   },
   /* PRACH Configuration Index 22 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_8
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }
      }
   },
   /* PRACH Configuration Index 23 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      }
   },
   /* PRACH Configuration Index 24 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }
      }
   },
   /* PRACH Configuration Index 25 */
   {
      {       /* UL/DL Cfg 0 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }  
      }
   },
   /* PRACH Configuration Index 26 */
   {
      {       /* UL/DL Cfg 0 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      }
   },
   /* PRACH Configuration Index 27 */
   {
      {       /* UL/DL Cfg 0 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_8
            }
         } 
      },
      {       /* UL/DL Cfg 1 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            }
         } 
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 4 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            }
         } 
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            }
         } 
      }
   },
   /* PRACH Configuration Index 28 */
   {
      {       /* UL/DL Cfg 0 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 1 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            }
         } 
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 4 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_2
            }
         } 
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      }
   },
   /* PRACH Configuration Index 29 */
   {
      {       /* UL/DL Cfg 0 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_8
            }
         } 
      },
      {       /* UL/DL Cfg 1 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_7
            }
         } 
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_5,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 4 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_5,
               YS_ALL_SFN,
               YS_SF_2
            }
         } 
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_7
            }
         } 
      }
   },
   /* PRACH Configuration Index 30 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }
      }
   },
   /* PRACH Configuration Index 31 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_3
            }
         }
      }
   },
   /* PRACH Configuration Index 32 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_8
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }
      }
   },
   /* PRACH Configuration Index 33 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      }
   },
   /* PRACH Configuration Index 34 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }
      }
   },
   /* PRACH Configuration Index 35 */
   {
      {       /* UL/DL Cfg 0 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_8
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_EVEN_SFN,
               YS_SF_3
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }  
      }
   },
   /* PRACH Configuration Index 36 */
   {
      {       /* UL/DL Cfg 0 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            }
         }
      }
   },
   /* PRACH Configuration Index 37 */
   {
      {       /* UL/DL Cfg 0 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_8
            }
         } 
      },
      {       /* UL/DL Cfg 1 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            }
         } 
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 4 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            }
         } 
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            }
         } 
      }
   },
   /* PRACH Configuration Index 38 */
   {
      {       /* UL/DL Cfg 0 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 1 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            }
         } 
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 4 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_2
            }
         } 
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      }
   },
   /* PRACH Configuration Index 39 */
   {
      {       /* UL/DL Cfg 0 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_8
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_8
            }
         } 
      },
      {       /* UL/DL Cfg 1 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_7
            }
         } 
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_5,
               YS_ALL_SFN,
               YS_SF_3
            }
         } 
      },
      {       /* UL/DL Cfg 4 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_5,
               YS_ALL_SFN,
               YS_SF_2
            }
         } 
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_3
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_7
            }
         } 
      }
   },
   /* PRACH Configuration Index 40 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_2
            }
         }  
      }
   },
   /* PRACH Configuration Index 41 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_2
            }
         }  
      }
   },
   /* PRACH Configuration Index 42 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   },
   /* PRACH Configuration Index 43 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      }
   },
   /* PRACH Configuration Index 44 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   },
   /* PRACH Configuration Index 45 */
   {
      {       /* UL/DL Cfg 0 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      }
   },
   /* PRACH Configuration Index 46 */
   {
      {       /* UL/DL Cfg 0 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      }
   },
   /* PRACH Configuration Index 47 */
   {
      {       /* UL/DL Cfg 0 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_7
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_7
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_2
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      }
   },
   /* PRACH Configuration Index 48 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_1
            }
         }  
      }
   },
   /* PRACH Configuration Index 49 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ODD_SFN,
               YS_SF_1
            }
         }  
      }
   },
   /* PRACH Configuration Index 50 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_6
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_6
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_6
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_EVEN_SFN,
               YS_SF_6
            }
         }  
      }
   },
   /* PRACH Configuration Index 51 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      }
   },
   /* PRACH Configuration Index 52 */
   {
      {       /* UL/DL Cfg 0 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         1,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            }
         }  
      }
   },
   /* PRACH Configuration Index 53 */
   {
      {       /* UL/DL Cfg 0 */
          2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            }
         }
      },
      {       /* UL/DL Cfg 1 */
          2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_2
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
          2,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            }
         }
      }
   },
   /* PRACH Configuration Index 54 */
   {
      {       /* UL/DL Cfg 0 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 1 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 2 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 4 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 5 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 6 */
         3,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      }
   },
   /* PRACH Configuration Index 55 */
   {
      {       /* UL/DL Cfg 0 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 6 */
         4,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            }
         }
      }
   },
   /* PRACH Configuration Index 56 */
   {
      {       /* UL/DL Cfg 0 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 6 */
         5,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      }
   },
   /* PRACH Configuration Index 57 */
   {
      {       /* UL/DL Cfg 0 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_6
            }
         }
      },
      {       /* UL/DL Cfg 1 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_6
            }
         }
      },
      {       /* UL/DL Cfg 2 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_6
            }
         }  
      },
      {       /* UL/DL Cfg 3 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_5,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 4 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_5,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 5 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_3,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_4,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_5,
               YS_ALL_SFN,
               YS_SF_1
            }
         }
      },
      {       /* UL/DL Cfg 6 */
         6,
         {
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_0,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_1,
               YS_ALL_SFN,
               YS_SF_6
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_1
            },
            {
               YS_FREQ_RES_IDX_2,
               YS_ALL_SFN,
               YS_SF_6
            }
         }
      }
   },
   /* PRACH Configuration Index 58 */
   {
      {       /* UL/DL Cfg 0 */
         0
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   },
   /* PRACH Configuration Index 59 */
   {
      {       /* UL/DL Cfg 0 */
         0
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   },
   /* PRACH Configuration Index 60 */
   {
      {       /* UL/DL Cfg 0 */
         0
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   },
   /* PRACH Configuration Index 61 */
   {
      {       /* UL/DL Cfg 0 */
         0
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   },
   /* PRACH Configuration Index 62 */
   {
      {       /* UL/DL Cfg 0 */
         0
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   },
   /* PRACH Configuration Index 63 */
   {
      {       /* UL/DL Cfg 0 */
         0
      },
      {       /* UL/DL Cfg 1 */
         0
      },
      {       /* UL/DL Cfg 2 */
         0
      },
      {       /* UL/DL Cfg 3 */
         0
      },
      {       /* UL/DL Cfg 4 */
         0
      },
      {       /* UL/DL Cfg 5 */
         0
      },
      {       /* UL/DL Cfg 6 */
         0
      }
   }
};
/* PHICH 'm' value Table */     

/* TDD_TODO change number to macros*/
U8 YsTddPhichMValTbl[YS_NUM_TDD_SF_CFG][YS_NUM_SUB_FRAMES] = {                                                                  
   {2, 1, 0, 0, 0, 2, 1, 0, 0, 0},
   {0, 1, 0, 0, 1, 0, 1, 0, 0, 1},                                                                                             {0, 0, 0, 1, 0, 0, 0, 0, 1, 0},                                                                                             {1, 0, 0, 0, 0, 0, 0, 0, 1, 1},
   {0, 0, 0, 0, 0, 0, 0, 0, 1, 1},                                                                                             {0, 0, 0, 0, 0, 0, 0, 0, 1, 0},                                                                                             {1, 1, 0, 0, 0, 1, 1, 0, 0, 1}
};    

U8 YsTddPucchMTable[YS_NUM_TDD_SF_CFG][YS_NUM_SUB_FRAMES] = {  
   {0, 0, 1, 0, 1, 0, 0, 1, 0, 1},
   {0, 0, 2, 1, 0, 0, 0, 2, 1, 0},
   {0, 0, 4, 0, 0, 0, 0, 4, 0, 0},
   {0, 0, 3, 2, 2, 0, 0, 0, 0, 0},
   {0, 0, 4, 4, 0, 0, 0, 0, 0, 0},
   {0, 0, 9, 0, 0, 0, 0, 0, 0, 0},
   {0, 0, 1, 1, 1, 0, 0, 1, 1, 0}
};

/* PUSCH 'K' value Table */
U8 YsTddPuschTxKTbl[YS_NUM_TDD_SF_CFG][YS_NUM_SUB_FRAMES] = {
   {4, 6, 0, 0, 0, 4, 6, 0, 0, 0},
   {0, 6, 0, 0, 4, 0, 6, 0, 0, 4},
   {0, 0, 0, 4, 0, 0, 0, 0, 4, 0},
   {4, 0, 0, 0, 0, 0, 0, 0, 4, 4},
   {0, 0, 0, 0, 0, 0, 0, 0, 4, 4},
   {0, 0, 0, 0, 0, 0, 0, 0, 4, 0},
   {7, 7, 0, 0, 0, 7, 7, 0, 0, 5}
};
#else

PUBLIC YsPrachFddCfgInfo ysPrachFddCfgDb[YS_NUM_PRACH_FDD_CFG] = 
{
   { /* PRACH Cfg Index 0 */
      0,
      YS_PREAM_FRMT_0,
      YS_EVEN_SFN,
      1,
      {
         1
      }
   },
   { /* PRACH Cfg Index 1 */
      1,
      YS_PREAM_FRMT_0,
      YS_EVEN_SFN,
      1,
      {
         4
      }
   },
   { /* PRACH Cfg Index 2 */
      2,
      YS_PREAM_FRMT_0,
      YS_EVEN_SFN,
      1,
      {
         7
      }
   },
   { /* PRACH Cfg Index 3 */
      3,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      1,
      {
         1
      }
   },
   { /* PRACH Cfg Index 4 */
      4,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      1,
      {
         4
      }
   },
   { /* PRACH Cfg Index 5 */
      5,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      1,
      {
         7
      }
   },
   { /* PRACH Cfg Index 6 */
      6,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      2,
      {
         1, 6
      }
   },
   { /* PRACH Cfg Index 7 */
      7,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      2,
      {
         2, 7
      }
   },
   { /* PRACH Cfg Index 8 */
      8,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      2,
      {
         3, 8
      }
   },
   { /* PRACH Cfg Index 9 */
      9,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      3,
      {
         1, 4, 7
      }
   },
   { /* PRACH Cfg Index 10 */
      10,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      3,
      {
         2, 5, 8
      }
   },
   { /* PRACH Cfg Index 11 */
      11,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      3,
      {
         3, 6, 9
      }
   },
   { /* PRACH Cfg Index 12 */
      12,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      5,
      {
         0, 2, 4, 6, 8
      }
   },
   { /* PRACH Cfg Index 13 */
      13,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      5,
      {
         1, 3, 5, 7, 9
      }
   },
   { /* PRACH Cfg Index 14 */
      14,
      YS_PREAM_FRMT_0,
      YS_ALL_SFN,
      10,
      {
         0, 1, 2, 3, 4, 5, 6, 7, 8, 9
      }
   },
   { /* PRACH Cfg Index 15 */
      15,
      YS_PREAM_FRMT_0,
      YS_EVEN_SFN,
      1,
      {
         9
      }
   },
   { /* PRACH Cfg Index 16 */
      16,
      YS_PREAM_FRMT_1,
      YS_EVEN_SFN,
      1,
      {
         1
      }
   },
   { /* PRACH Cfg Index 17 */
      17,
      YS_PREAM_FRMT_1,
      YS_EVEN_SFN,
      1,
      {
         4
      }
   },
   { /* PRACH Cfg Index 18 */
      18,
      YS_PREAM_FRMT_1,
      YS_EVEN_SFN,
      1,
      {
         7
      }
   },
   { /* PRACH Cfg Index 19 */
      19,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      1,
      {
         1
      }
   },
   { /* PRACH Cfg Index 20 */
      20,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      1,
      {
         4
      }
   },
   { /* PRACH Cfg Index 21 */
      21,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      1,
      {
         7
      }
   },
   { /* PRACH Cfg Index 22 */
      22,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      2,
      {
         1, 6
      }
   },
   { /* PRACH Cfg Index 23 */
      23,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      2,
      {
         2, 7
      }
   },
   { /* PRACH Cfg Index 24 */
      24,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      2,
      {
         3, 8
      }
   },
   { /* PRACH Cfg Index 25 */
      25,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      3,
      {
         1, 4, 7
      }
   },
   { /* PRACH Cfg Index 26 */
      26,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      3,
      {
         2, 5, 8
      }
   },
   { /* PRACH Cfg Index 27 */
      27,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      3,
      {
         3, 6, 9
      }
   },
   { /* PRACH Cfg Index 28 */
      28,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      5,
      {
         0, 2, 4, 6, 8
      }
   },
   { /* PRACH Cfg Index 29 */
      29,
      YS_PREAM_FRMT_1,
      YS_ALL_SFN,
      5,
      {
         1, 3, 5, 7, 9
      }
   },
   { /* PRACH Cfg Index 30 */
      30,
      YS_PREAM_FRMT_NA
   },
   { /* PRACH Cfg Index 31 */
      31,
      YS_PREAM_FRMT_1,
      YS_EVEN_SFN,
      1,
      {
         9
      }
   },
   { /* PRACH Cfg Index 32 */
      32,
      YS_PREAM_FRMT_2,
      YS_EVEN_SFN,
      1,
      {
         1
      }
   },
   { /* PRACH Cfg Index 33 */
      33,
      YS_PREAM_FRMT_2,
      YS_EVEN_SFN,
      1,
      {
         4
      }
   },
   { /* PRACH Cfg Index 34 */
      34,
      YS_PREAM_FRMT_2,
      YS_EVEN_SFN,
      1,
      {
         7
      }
   },
   { /* PRACH Cfg Index 35 */
      35,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      1,
      {
         1
      }
   },
   { /* PRACH Cfg Index 36 */
      36,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      1,
      {
         4
      }
   },
   { /* PRACH Cfg Index 37 */
      37,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      1,
      {
         7
      }
   },
   { /* PRACH Cfg Index 38 */
      38,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      2,
      {
         1, 6
      }
   },
   { /* PRACH Cfg Index 39 */
      39,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      2,
      {
         2, 7
      }
   },
   { /* PRACH Cfg Index 40 */
      40,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      2,
      {
         3, 8
      }
   },
   { /* PRACH Cfg Index 41 */
      41,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      3,
      {
         1, 4, 7
      }
   },
   { /* PRACH Cfg Index 42 */
      42,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      3,
      {
         2, 5, 8
      }
   },
   { /* PRACH Cfg Index 43 */
      43,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      3,
      {
         3, 6, 9
      }
   },
   { /* PRACH Cfg Index 44 */
      44,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      5,
      {
         0, 2, 4, 6, 8
      }
   },
   { /* PRACH Cfg Index 45 */
      45,
      YS_PREAM_FRMT_2,
      YS_ALL_SFN,
      5,
      {
         1, 3, 5, 7, 9
      }
   },
   { /* PRACH Cfg Index 46 */
      46,
      YS_PREAM_FRMT_NA
   },
   { /* PRACH Cfg Index 47 */
      47,
      YS_PREAM_FRMT_2,
      YS_EVEN_SFN,
      1,
      {
         9
      }
   },
   { /* PRACH Cfg Index 48 */
      48,
      YS_PREAM_FRMT_3,
      YS_EVEN_SFN,
      1,
      {
         1
      }
   },
   { /* PRACH Cfg Index 49 */
      49,
      YS_PREAM_FRMT_3,
      YS_EVEN_SFN,
      1,
      {
         4
      }
   },
   { /* PRACH Cfg Index 50 */
      50,
      YS_PREAM_FRMT_3,
      YS_EVEN_SFN,
      1,
      {
         7
      }
   },
   { /* PRACH Cfg Index 51 */
      51,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      1,
      {
         1
      }
   },
   { /* PRACH Cfg Index 52 */
      52,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      1,
      {
         4
      }
   },
   { /* PRACH Cfg Index 53 */
      53,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      1,
      {
         7
      }
   },
   { /* PRACH Cfg Index 54 */
      54,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      2,
      {
         1, 6
      }
   },
   { /* PRACH Cfg Index 55 */
      55,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      2,
      {
         2, 7
      }
   },
   { /* PRACH Cfg Index 56 */
      56,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      2,
      {
         3, 8
      }
   },
   { /* PRACH Cfg Index 57 */
      57,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      3,
      {
         1, 4, 7
      }
   },
   { /* PRACH Cfg Index 58 */
      58,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      3,
      {
         2, 5, 8
      }
   },
   { /* PRACH Cfg Index 59 */
      59,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      3,
      {
         3, 6, 9
      }
   },
   { /* PRACH Cfg Index 60 */
      60,
      YS_PREAM_FRMT_NA
   },
   { /* PRACH Cfg Index 61 */
      61,
      YS_PREAM_FRMT_NA
   },
   { /* PRACH Cfg Index 62 */
      62,
      YS_PREAM_FRMT_NA
   },
   { /* PRACH Cfg Index 63 */
      63,
      YS_PREAM_FRMT_3,
      YS_ALL_SFN,
      1,
      {
         9
      }
   }
};
#endif
/* Basis Sequences for (20, A) Code
   References 36-212 Section 5.2.3.3
*/
PUBLIC U8 MSeq[20][13]=
{
  { 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0}, 
  { 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0},
  { 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1},
  { 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1},
  { 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1},
  { 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1},
  { 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1},
  { 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1},
  { 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1},
  { 1, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1},
  { 1, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1},
  { 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1},
  { 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1},
  { 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1},
  { 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1},
  { 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1},
  { 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1},
  { 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1},
  { 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0},
  { 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0}
}; 

/* 16 values 0000 to 1111. And their corresponding
   20 bit values which are pre-computed. 
b(0) = (a(0).M(0, 0) + a(1).M(0, 1) + a(2).M(0, 2) + a(3).M(0, 3))mod 2 */
PUBLIC U8 cqiTo20BitMap[16][2] =
{
   {0, 0},
   {1, 0},
   {2, 0},
   {3, 0},
   {4, 0},
   {5, 0},
   {6, 0},
   {7, 0},
   {8, 0},
   {9, 0},
   {10, 0},
   {11, 0},
   {12, 0},
   {13, 0},
   {14, 0},
   {15, 0}
};
 
/*ys004.102 MSPD Mege for PHY version 1.7*/
PUBLIC Bool               ysPrachPresDb[YS_NUM_PRACH_PRES_ARR];
PUBLIC YsSrCfgInfo        ysSrCfgDb[YS_NUM_SR_CFG];
PUBLIC YsSrsCfgInfo       ysSrsCfgDb[YS_NUM_SRS_CFG];
PUBLIC YsCqiPmiCfgIdxInfo ysCqiPmiCfgDb[YS_NUM_CQI_CFG];

/* Added txPowerControl Array to map PA enum index to the value expected by PHY
 * PHY expect this value as actual power value in db multiply by 256 */
PUBLIC S16 txPowerCntrlMap[8] = {-1536, -1221, -768, -453, 0, 256, 512, 768};  

#ifdef CA_PHY
/* Format 1BCS feedback interpetation for M=3 and M= 4 
   in Harq on PUSCH 
   ysDlHqFdbkOnPusch[M=3/4] [o(0)] [o(1)] [o(2)] [o(3)] */
PUBLIC YsDlFdbkInfo ysDlHqFdbkOnPusch[2][2][2][2][2] =
{
   /* M = 3*/
   {
      /* o(0) = 0 */
      {
         /* o(1) = 0 */
         {
            /* o(2) = 0 */
            {
               /* o(3) = 0 */
               {
                  TFU_HQ_NACK,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               },
               /* o(3) = 1 */
               {
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               }
            },
            /* o(2) = 1 */
            {
               /* o(3) = 0 */
               {
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               },
               /* o(3) = 1 */
               {
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               }
            }
         },
         /* o(1) = 1 */
         {
            /* o(2) = 0 */
            {
               /* o(3) = 0 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               },
               /* o(3) = 1 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               }
            },
            /* o(2) = 1 */
            {
               /* o(3) = 0 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               },
               /* o(3) = 1 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               }
            }
         }
      },
      /* o(0) = 1 */
      {
         /* o(1) = 0 */
         {
            /* o(2) = 0 */
            {
               /* o(3) = 0 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               },
               /* o(3) = 1 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               }
            },
            /* o(2) = 1 */
            {
               /* o(3) = 0 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               },
               /* o(3) = 1 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               }
            }
         },
         /* o(1) = 1 */
         {
            /* o(2) = 0 */
            {
               /* o(3) = 0 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               },
               /* o(3) = 1 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               }
            },
            /* o(2) = 1 */
            {
               /* o(3) = 0 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               },
               /* o(3) = 1 */
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_INVALID,
                  TFU_HQ_INVALID
               }
            }
         }
      }
   },
   /* M = 4*/
   {
      /* o(0) = 0 */
      {
         /* o(0) = 0 , o(1) = 0 */
         {
            /* o(0) = 0 , o(1) = 0 ,o(2) = 0 */
            {
               /* o(0) = 0 , o(1) = 0 ,o(2) = 0 o(3) = 0*/
               {
                  TFU_HQ_NACK,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX
               },
               /* o(0) = 0 , o(1) = 0 ,o(2) = 0 o(3) = 1*/
               {
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX
               }
            },
            /* o(0) = 0 , o(1) = 0 ,o(2) = 1 */
            {
               /* o(0) = 0 , o(1) = 0 ,o(2) = 1 o(3) = 0*/
               {
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX
               },
               /* o(0) = 0 , o(1) = 0 ,o(2) = 1 o(3) = 1*/
               {
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX
               }
            }
         },
         /* o(0) = 0 , o(1) = 1 */
         {
            /* o(0) = 0 , o(1) = 1 ,o(2) = 0*/
            {
               /* o(0) = 0 , o(1) = 1 ,o(2) = 0 ,o(3) = 0*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX
               },
               /* o(0) = 0 , o(1) = 1 ,o(2) = 0 ,o(3) = 1*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX
               }
            },
            /* o(0) = 0 , o(1) = 1 ,o(2) = 1*/
            {
               /* o(0) = 0 , o(1) = 1 ,o(2) = 1 , o(3) = 0*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX
               },
               /* o(0) = 0 , o(1) = 1 ,o(2) = 1 , o(3) = 1*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX
               }
            }
         }
      },
      /* o(0) = 1 */
      {
         /* o(0) = 1 , o(1) = 0 */
         {
            /* o(0) = 1 , o(1) = 0 ,o(2) = 0 */
            {
               /* o(0) = 1 , o(1) = 0 ,o(2) = 0 o(3) = 0*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX
               },
               /* o(0) = 1 , o(1) = 0 ,o(2) = 0 o(3) = 1*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX
               }
            },
            /* o(0) = 1 , o(1) = 0 ,o(2) = 1 */
            {
               /* o(0) = 1 , o(1) = 0 ,o(2) = 1 o(3) = 0*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX
               },
               /* o(0) = 1 , o(1) = 0 ,o(2) = 1 o(3) = 1*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX
               }
            }
         },
         /* o(0) = 1 , o(1) = 1 */
         {
            /* o(0) = 1 , o(1) = 1 ,o(2) = 0*/
            {
               /* o(0) = 1 , o(1) = 1 ,o(2) = 0 ,o(3) = 0*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX
               },
               /* o(0) = 1 , o(1) = 1 ,o(2) = 0 ,o(3) = 1*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX,
                  TFU_HQ_ACK_OR_DTX
               }
            },
            /* o(0) = 1 , o(1) = 1 ,o(2) = 1*/
            {
               /* o(0) = 1 , o(1) = 1 ,o(2) = 1 , o(3) = 0*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK_OR_NACK_OR_DTX
               },
               /* o(0) = 1 , o(1) = 1 ,o(2) = 1 , o(3) = 1*/
               {
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_ACK,
                  TFU_HQ_NACK_OR_DTX
               }
            }
         }
      }
   }
};
/* Format 1BCS feedback interpetation for A=2,3 with M=1*/
/* ysDlFdbkForM1[A][n1pucch][b0][b1] A = 0 For A=2
                                       = 1 For A=3
                                       */
PUBLIC YsDlFdbkInfo ysDlFdbkForM1[2][3][2][2] =
{
   /*For A=2*/
   {
      /*For n1Pucch = 0*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID
            }
         }
      },
      /*For n1Pucch = 1*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      },
      /*For n1Pucch = 2*/
      {
         /*This is INVALID Case, For A=2 there are only 2 n1pucch resources*/
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      }
   },
   /*For A=3*/
   {
      /*For n1Pucch = 0*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX
            }
         }
      },
      /*For n1Pucch = 1*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      },
      /*For n1Pucch = 2*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK
            },
            /*For b1 = 1*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK
            }
         }
      } 
   }
};
/* Format 1BCS feedback interpetation for M=2,3,4 and A=4*/
PUBLIC YsDlFdbkInfo ysDlFdbkForM234[3][4][2][2] =
{
   /*For M=2*/
   {
      /*For n1pucch = 0*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      },
      /*For n1pucch = 1*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      },
      /*For n1pucch = 2*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      },
      /*For n1pucch = 3*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      }
   },
   /*For M=3*/
   {
      /*For n1pucch = 0*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      },
      /*For n1pucch = 1*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      },
      /*For n1pucch = 2*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      },
      /*For n1pucch = 3*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_INVALID,
               TFU_HQ_INVALID
            }
         }
      }
   },
   /*For M=4*/
   {
      /*For n1pucch = 0*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX
            }
         }
      },
      /*For n1pucch = 1*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX
            }
         }
      },
      /*For n1pucch = 2*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX
            }
         }
      },
      /*For n1pucch = 3*/
      {
         /*For b0 = 0*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX
            }
         },
         /*For b0 = 1*/
         {
            /*For b1 = 0*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX,
               TFU_HQ_ACK_OR_NACK_OR_DTX
            },
            /*For b1 = 1*/
            {
               TFU_HQ_ACK,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK_OR_DTX,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_ACK,
               TFU_HQ_NACK_OR_DTX
            }
         }
      }
   }
};   
#endif
#endif
/********************************************************************30**
  
         End of file:     yw_ms_db.c@@/main/TeNB_Main_BR/5 - Wed Jun 11 13:19:52 2014
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---     sgm                   1. eNodeB 1.2 release
/main/1      ys004.102    vr               1. MSPD Merge for PHY ver 1.7 
*********************************************************************91*/


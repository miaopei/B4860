/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/

/********************************************************************20**

     Name:     LTE Uu Stack Manager 
  
     Type:     C source file

     Desc:     Stack Manager Initialization Functions.

     File:     yw_se_tst.c

     Sid:      yw_se_tst.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:51 2014

     Prg:      Sriky 

*********************************************************************21*/

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "cm5.h"           /* common timers */
#include "cm_hash.h"       /* common hash */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash */
#define SCH_INST_ID 1

/* g++ compilation fix,name mangling  */
#ifdef __cplusplus
EXTERN "C" {
#endif  /*__cplusplus*/

EXTERN S16 kwActvInit ARGS ((
Ent    ent,                 /* entity */
Inst   inst,                /* instance */
Region region,              /* region */
Reason reason               /* reason */
));

EXTERN S16 kwActvTsk ARGS ((
Pst *pst,              /* pst structure */
Buffer *mBuf            /* message buffer */
));

EXTERN S16 pjActvInit ARGS ((
Ent    ent,                 /* entity */
Inst   inst,                /* instance */
Region region,              /* region */
Reason reason               /* reason */
));

EXTERN S16 pjActvTsk ARGS ((
Pst *pst,              /* pst structure */
Buffer *mBuf            /* message buffer */
));

EXTERN S16 rgActvInit ARGS((Ent entity, Inst inst, Region 
       region, Reason reason));

EXTERN S16 rgActvTsk ARGS((Pst *pst, Buffer *mBuf));

EXTERN S16 schActvInit ARGS((Ent entity, Inst inst, Region 
       region, Reason reason));

EXTERN S16 schActvTsk ARGS((Pst *pst, Buffer *mBuf));

EXTERN S16 ysActvInit ARGS((Ent entity, Inst inst, Region 
       region, Reason reason));

EXTERN S16 ysActvTsk ARGS((Pst *pst, Buffer *mBuf));

#ifdef __cplusplus
      }
#endif  /*__cplusplus*/

/*
*
*       Fun:   Initialize RLC/PDCP task.
*
*       Desc:  Invoked to create RLC/PDCP TAPA task.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  yw_se_tst.c
*
*/
#ifdef ANSI
PUBLIC S16 smKwInit
(
SSTskId    sysTskId
)
#else
PUBLIC S16 smKwInit(sysTskId)
SSTskId    sysTskId;
#endif
{
   TRC2(smKwInit);

   /* Register RLC-UL TAPA Task */
   if (SRegTTsk((Ent)ENTKW, (Inst)1, (Ttype)TTNORM, (Prior)PRIOR0,
            kwActvInit, (ActvTsk)kwActvTsk) != ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Register RLC TAPA Task */
   if (SRegTTsk((Ent)ENTKW, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
            kwActvInit, (ActvTsk)kwActvTsk) != ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Register PDCP TAPA Task */
   if (SRegTTsk((Ent)ENTPJ, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
            pjActvInit, (ActvTsk)pjActvTsk) != ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Attach RLC-UL TAPA Task */
   if (SAttachTTsk((Ent)ENTKW, (Inst)1, sysTskId)!= ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Attach RLC TAPA Task */
   if (SAttachTTsk((Ent)ENTKW, (Inst)0, sysTskId)!= ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Attach PDCP TAPA Task */
   if (SAttachTTsk((Ent)ENTPJ, (Inst)0, sysTskId)!= ROK)
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   RETVALUE(ROK);
} /* end of smKwInit */

/*
*
*       Fun:   Initialize MAC task.
*
*       Desc:  Invoked to create MAC TAPA task.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  yw_se_tst.c
*
*/
#ifdef ANSI
PUBLIC S16 smRgInit
(
SSTskId    sysTskId
)
#else
PUBLIC S16 smRgInit(sysTskId)
SSTskId    sysTskId;
#endif
{
   TRC2(smRgInit);

   /* Register RRC TAPA Task */
   if (SRegTTsk((Ent)ENTRG, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
            rgActvInit, (ActvTsk)rgActvTsk) != ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Attach RRC TAPA Task */
   if (SAttachTTsk((Ent)ENTRG, (Inst)0, sysTskId)!= ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Register MAC SCHEDULER Task */
   if (SRegTTsk((Ent)ENTRG, (Inst)SCH_INST_ID, (Ttype)TTNORM, (Prior)PRIOR0,
            schActvInit, (ActvTsk)schActvTsk) != ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Attach RRC TAPA Task */
   if (SAttachTTsk((Ent)ENTRG, (Inst)SCH_INST_ID, sysTskId)!= ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   RETVALUE(ROK);
} /* end of smRgInit */

/*
*
*       Fun:   smYsInit
*
*       Desc:  Invoked to create LTE CL TAPA task.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  yw_se_tst.c
*
*/
#ifdef ANSI
PUBLIC S16 smYsInit
(
SSTskId    sysTskId
)
#else
PUBLIC S16 smYsInit(sysTskId)
SSTskId    sysTskId;
#endif
{
   TRC2(smYsInit);

   /* Register CL TAPA Task */
   if (SRegTTsk((Ent)ENTYS, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
            ysActvInit, (ActvTsk)ysActvTsk) != ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   if (SRegTTsk((Ent)ENTTF, (Inst)0, (Ttype)TTNORM, (Prior)PRIOR0,
            NULLP, (ActvTsk)ysActvTsk) != ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Attach RRC TAPA Task */
   if (SAttachTTsk((Ent)ENTTF, (Inst)0, sysTskId)!= ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Attach RRC TAPA Task */
   if (SAttachTTsk((Ent)ENTYS, (Inst)0, sysTskId)!= ROK) 
   {
      RETVALUE(RFAILED);
   } /* end of if statement */

   RETVALUE(ROK);
} /* end of smYsInit */


/*
*
*       Fun:   tst
*
*       Desc:  tst entry point. First entry point.
*
*       Ret:   ROK on success, RFAILED on error
*
*       Notes: None
*
*       File:  yw_se_tst.c
*
*/
#ifdef ANSI
PUBLIC S16 tst
(
Void
)
#else
PUBLIC S16 tst(Void)
#endif
{
   
   /* System tasks that are needed as per the architecture */
   SSTskId rlc_pdcp_mac_cl_taskId;

   TRC2(tst);
   SSetProcId(IARM_PROCESSOR_ID_LOW);
   /* All the System tasks(threads)  are created with same priority*/
   SCreateSTsk(PRIOR0, &rlc_pdcp_mac_cl_taskId); 

   /* Create RLC/PDCP tasks and attach them 
      to a single system thread */
   if(smKwInit(rlc_pdcp_mac_cl_taskId) != ROK)
   {
      /* Fix for CID- 1622-02-01 DefectId- 115851 */
      /* Removed debug print */
      RETVALUE(RFAILED);
   } /* end of if statement */

   /* Create LTE MAC tapa task and attach it
      to a single system thread */
   if(smRgInit(rlc_pdcp_mac_cl_taskId) != ROK )
   {
      /* Fix for CID- 1622-02-01 DefectId- 115851 */
      /* Removed debug print */
      RETVALUE(RFAILED);
   } /* end of if statement */


   /* Create Convergence layer TAPA tasks and attach them 
      to a single system thread */
   if(smYsInit(rlc_pdcp_mac_cl_taskId) != ROK)
   {
      /* Fix for CID- 1622-02-01 DefectId- 115851 */
      /* Removed debug print */
      RETVALUE(RFAILED);
   } /* end of if statement */

   RETVALUE(ROK);
} /* end of tst function */

/*
*
*       Fun:   rdConQ
*
*       Desc:  
*
*       Ret:   ROK on success, RFAILED on error
*
*       Notes: None
*
*       File:  yw_se_tst.c
*
*/
#ifdef ANSI
PUBLIC S16 rdConQ
(
Data data
)
#else
PUBLIC S16 rdConQ(data)
Data data;
#endif
{
   TRC2(rdConQ);
   RETVALUE(ROK);
}



/********************************************************************30**

           End of file:     yw_se_tst.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:51 2014

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1        ---      Sriky         1. initial release TotaleNodeB 1.1
*********************************************************************91*/


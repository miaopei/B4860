/*-----------------------------------------------------------
 * ys_qc_table.c
 *
 * DCIs size calculation according to: Duplexing, Associated UL, Carrier Indicator size[bits],
 * CSI Request size [bits] ,SRS Request size [bits],UL_RBs or DL_RBs
 *
 * OWNER:                
 *
 *-----------------------------------------------------------
*/

#include "envopt.h"             /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "fapiApiInternal.h"
#include "ssi.h"           /* system services */
#include "gen.h"                /* general layer */
#include "tfu.h"
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "lys.h"
#include "resultcodes.h"
#include "ctf.h"
#include "ys_ms.h"
#include "ys_ms_err.h"

#include "gen.x"                /* general layer */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"

#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#include "ctf.x"

#include "ys_ms.x"
#include "ys_qcms.h"



#ifdef QCBC_PLATFORM

const U8 payload_length_dci0[2][6][16] =
{
    {//TDD

        {23,23,25,25,23,23,25,25,27,27,27,27,27,27,27,27},
        {25,25,27,27,25,25,27,27,28,28,29,29,28,28,29,29},
        {27,27,28,28,27,27,28,28,30,30,31,31,30,30,31,31},
        {29,29,30,30,29,29,30,30,33,33,33,33,33,33,33,33},
        {30,30,31,31,30,30,31,31,33,33,34,34,33,33,34,34},
        {31,31,33,33,31,31,33,33,34,34,35,35,34,34,35,35}
    },
    {//FDD
        {21,21,21,21,21,21,21,22,23,23,25,25,23,25,25,25},
        {22,22,23,23,22,23,23,25,25,25,27,27,25,27,27,27},
        {25,25,25,25,25,25,25,27,27,27,28,28,27,28,28,29},
        {27,27,27,27,27,27,27,28,29,29,30,30,29,30,30,31},
        {27,27,28,28,27,28,28,29,30,30,31,31,30,31,31,33},
        {28,28,29,29,28,29,29,30,31,31,33,33,31,33,33,33}
    },
};



const U8 payload_length_dci1[2][6][32] =
{
    {//TDD
        {22,22,22,22,22,22,22,22,25,25,25,25,25,25,25,25,22,22,22,22,22,22,22,22,25,25,25,25,25,25,25,25},
        {27,27,25,25,27,27,25,25,29,29,28,28,29,29,28,28,27,27,25,25,27,27,25,25,29,29,28,28,29,29,28,28},
        {30,30,30,30,30,30,30,30,33,33,33,33,33,33,33,33,30,30,30,30,30,30,30,30,33,33,33,33,33,33,33,33},
        {34,34,34,34,34,34,34,34,37,37,37,37,37,37,37,37,34,34,34,34,34,34,34,34,37,37,37,37,37,37,37,37},
        {36,36,36,36,36,36,36,36,39,39,39,39,39,39,39,39,36,36,36,36,36,36,36,36,39,39,39,39,39,39,39,39},
        {42,42,42,42,42,42,42,42,45,45,45,45,45,45,45,45,42,42,42,42,42,42,42,42,45,45,45,45,45,45,45,45}
    },
    {//FDD
        {19,19,19,19,19,19,19,19,22,22,22,22,22,22,22,22,19,19,19,19,19,19,19,19,22,22,22,22,22,22,22,22},
        {23,23,22,22,23,23,22,22,27,27,25,25,27,27,25,25,23,23,22,22,23,22,22,22,27,27,25,25,27,25,25,25},
        {27,27,27,27,27,27,27,27,30,30,30,30,30,30,30,30,27,27,27,27,27,27,27,28,30,30,30,30,30,30,30,30},
        {31,31,31,31,31,31,31,31,34,34,34,34,34,34,34,34,31,31,31,31,31,31,31,31,34,34,34,34,34,34,34,34},
        {33,33,33,33,33,33,33,33,36,36,36,36,36,36,36,36,33,33,33,33,33,33,33,33,36,36,36,36,36,36,36,36},
        {39,39,39,39,39,39,39,39,42,42,42,42,42,42,42,42,39,39,39,39,39,39,39,39,42,42,42,42,42,42,42,42}
    },
};


const U8 payload_length_dci1a[2][6][32] =
{
    {//TDD
        {23,23,25,25,23,23,25,25,27,27,27,27,27,27,27,27,23,23,25,25,23,23,25,25,27,27,27,27,27,27,27,27},
        {25,25,27,27,25,25,27,27,28,28,29,29,28,28,29,29,25,25,27,27,25,25,27,27,28,28,29,29,28,28,29,29},
        {27,27,28,28,27,27,28,28,30,30,31,31,30,30,31,31,27,27,28,28,27,27,28,28,30,30,31,31,30,30,31,31},
        {29,29,30,30,29,29,30,30,33,33,33,33,33,33,33,33,29,29,30,30,29,29,30,30,33,33,33,33,33,33,33,33},
        {30,30,31,31,30,30,31,31,33,33,34,34,33,33,34,34,30,30,31,31,30,30,31,31,33,33,34,34,33,33,34,34},
        {31,31,33,33,31,31,33,33,34,34,35,35,34,34,35,35,31,31,33,33,31,31,33,33,34,34,35,35,34,34,35,35}
    },
    {//FDD
        {21,21,21,21,21,21,21,21,23,23,25,25,23,23,25,25,21,21,21,21,21,21,21,22,23,23,25,25,23,25,25,25},
        {22,22,23,23,22,22,23,23,25,25,27,27,25,25,27,27,22,22,23,23,22,23,23,25,25,25,27,27,25,27,27,27},
        {25,25,25,25,25,25,25,25,27,27,28,28,27,27,28,28,25,25,25,25,25,25,25,27,27,27,28,28,27,28,28,29},
        {27,27,27,27,27,27,27,27,29,29,30,30,29,29,30,30,27,27,27,27,27,27,27,28,29,29,30,30,29,30,30,31},
        {27,27,28,28,27,27,28,28,30,30,31,31,30,30,31,31,27,27,28,28,27,28,28,29,30,30,31,31,30,31,31,33},
        {28,28,29,29,28,28,29,29,31,31,33,33,31,31,33,33,28,28,29,29,28,29,29,30,31,31,33,33,31,33,33,33}
    },
};

const U8 payload_length_dci1b[2][6][32] =
{
    {//TDD
        {25,25,27,27,25,25,27,27,28,28,28,28,28,28,28,28,25,25,27,27,25,25,27,27,28,28,28,28,28,28,28,28},
        {27,27,28,28,27,27,28,28,30,30,30,30,30,30,30,30,27,27,28,28,27,27,28,28,30,30,30,30,30,30,30,30},
        {29,29,29,29,29,29,29,29,33,33,33,33,33,33,33,33,29,29,29,29,29,29,29,29,33,33,33,33,33,33,33,33},
        {31,31,31,31,31,31,31,31,34,34,34,34,34,34,34,34,31,31,31,31,31,31,31,31,34,34,34,34,34,34,34,34},
        {33,33,33,33,33,33,33,33,35,35,35,35,35,35,35,35,33,33,33,33,33,33,33,33,35,35,35,35,35,35,35,35},
        {33,33,34,34,33,33,34,34,36,36,36,36,36,36,36,36,33,33,34,34,33,33,34,34,36,36,36,36,36,36,36,36}
        },
    {//FDD
        {22,22,22,22,22,22,22,22,25,25,27,27,25,25,27,27,22,22,22,22,22,22,22,23,25,25,27,27,25,27,27,27},
        {25,25,25,25,25,25,25,25,27,27,28,28,27,27,28,28,25,25,25,25,25,25,25,27,27,27,28,28,27,28,28,28},
        {27,27,27,27,27,27,27,27,29,29,29,29,29,29,29,29,27,27,27,27,27,27,27,28,29,29,29,29,29,29,29,30},
        {28,28,28,28,28,28,28,28,31,31,31,31,31,31,31,31,28,28,28,28,28,28,28,29,31,31,31,31,31,31,31,33},
        {29,29,29,29,29,29,29,29,33,33,33,33,33,33,33,33,29,29,29,29,29,29,29,30,33,33,33,33,33,33,33,34},
        {30,30,30,30,30,30,30,30,33,33,34,34,33,33,34,34,30,30,30,30,30,30,30,31,33,33,34,34,33,34,34,34}
    },
};

const U8 payload_length_dci1c[2][6][1] =
{
    {//TDD
        {8},
        {10},
        {12},
        {13},
        {14},
        {15}
    },
    {//FDD
        {8},
        {10},
        {12},
        {13},
        {14},
        {15}
    },
};

const U8 payload_length_dci1d[2][6][32] =
{
    {//TDD
        {25,25,27,27,25,25,27,27,28,28,28,28,28,28,28,28,25,25,27,27,25,25,27,27,28,28,28,28,28,28,28,28},
        {27,27,28,28,27,27,28,28,30,30,30,30,30,30,30,30,27,27,28,28,27,27,28,28,30,30,30,30,30,30,30,30},
        {29,29,29,29,29,29,29,29,33,33,33,33,33,33,33,33,29,29,29,29,29,29,29,29,33,33,33,33,33,33,33,33},
        {31,31,31,31,31,31,31,31,34,34,34,34,34,34,34,34,31,31,31,31,31,31,31,31,34,34,34,34,34,34,34,34},
        {33,33,33,33,33,33,33,33,35,35,35,35,35,35,35,35,33,33,33,33,33,33,33,33,35,35,35,35,35,35,35,35},
        {33,33,34,34,33,33,34,34,36,36,36,36,36,36,36,36,33,33,34,34,33,33,34,34,36,36,36,36,36,36,36,36}
    },
    {//FDD
        {22,22,22,22,22,22,22,22,25,25,27,27,25,25,27,27,22,22,22,22,22,22,22,23,25,25,27,27,25,27,27,27},
        {25,25,25,25,25,25,25,25,27,27,28,28,27,27,28,28,25,25,25,25,25,25,25,27,27,27,28,28,27,28,28,28},
        {27,27,27,27,27,27,27,27,29,29,29,29,29,29,29,29,27,27,27,27,27,27,27,28,29,29,29,29,29,29,29,30},
        {28,28,28,28,28,28,28,28,31,31,31,31,31,31,31,31,28,28,28,28,28,28,28,29,31,31,31,31,31,31,31,33},
        {29,29,29,29,29,29,29,29,33,33,33,33,33,33,33,33,29,29,29,29,29,29,29,30,33,33,33,33,33,33,33,34},
        {30,30,30,30,30,30,30,30,33,33,34,34,33,33,34,34,30,30,30,30,30,30,30,31,33,33,34,34,33,34,34,34}
    },
};

const U8 payload_length_dci2[2][6][2] =
{
    {//TDD
        {34,37},
        {37,41},
        {42,45},
        {46,49},
        {48,51},
        {54,57}
    },
    {//FDD
        {31,34},
        {34,37},
        {39,42},
        {43,46},
        {45,48},
        {51,54}
    },
};

const U8 payload_length_dci2a[2][6][2] =
{
    {//TDD
        {31,34},
        {34,37},
        {39,42},
        {43,46},
        {45,48},
        {51,54}
    },
    {//FDD
        {28,31},
        {31,34},
        {36,39},
        {41,43},
        {42,45},
        {48,51}
    },
};

const U8 payload_length_dci2b[2][6][2] =
{
    {//TDD
        {33,35},
        {35,38},
        {41,43},
        {45,47},
        {46,49},
        {52,55}
    },
    {//FDD
        {28,31},
        {31,34},
        {36,39},
        {41,43},
        {42,45},
        {48,51}
    },
};

const U8 payload_length_dci2c[2][6][2] =
{
    {//TDD
        {34,37},
        {37,41},
        {42,45},
        {46,49},
        {48,51},
        {54,57}
    },
    {//FDD
        {30,33},
        {33,36},
        {38,41},
        {42,45},
        {45,47},
        {50,53}
    },
};

const U8 payload_length_dci2d[2][6][2] =
{
    {//TDD
        {36,39},
        {39,43},
        {44,47},
        {48,51},
        {50,53},
        {56,60}
    },
    {//FDD
        {32,35},
        {35,38},
        {40,43},
        {44,47},
        {47,49},
        {52,55}
    },
};

const U8 payload_length_dci3[2][6][1] =
{
    {//TDD
        {23},
        {25},
        {27},
        {29},
        {30},
        {31}
    },
    {//FDD
        {21},
        {22},
        {25},
        {27},
        {27},
        {28}
    },
};

const U8 payload_length_dci3a[2][6][1] =
{
    {//TDD
        {23},
        {25},
        {27},
        {29},
        {30},
        {31}
    },
    {//FDD
        {21},
        {22},
        {25},
        {27},
        {27},
        {28}
    },
};

const U8 payload_length_dci4[2][6][20] =
{
    {//TDD
        {32,32,32,32,32,33,33,33,34,33,35,35,35,36,35,36,36,36,36,36},
        {33,33,33,33,33,34,35,34,34,34,36,36,36,36,36,37,38,37,37,37},
        {36,36,36,36,36,37,37,37,37,37,39,39,39,39,39,40,40,40,40,40},
        {38,38,38,38,38,39,39,39,39,39,41,41,41,41,41,42,42,42,42,42},
        {39,39,39,39,39,40,40,40,40,40,42,42,42,42,42,43,43,43,43,43},
        {40,40,40,40,40,41,41,41,41,41,43,43,43,43,43,44,44,44,44,44}
    },
    {//FDD
        {30,30,30,30,31,31,31,32,31,31,33,33,33,33,34,34,34,35,34,34},
        {31,32,31,32,31,32,32,32,32,32,34,35,34,35,34,35,35,35,35,35},
        {34,34,34,34,34,35,35,35,35,35,37,37,37,37,37,38,38,38,38,38},
        {36,36,36,36,36,37,37,37,37,37,39,39,39,39,39,40,40,40,40,40},
        {37,37,37,37,37,38,38,38,38,38,40,40,40,40,40,41,41,41,41,41},
        {38,38,38,38,38,40,39,39,39,39,41,41,41,41,41,43,42,42,42,42}
    },
};

 const U8 tm_to_index[9] = {0,0,1,2,0,0,0,3,4};

 /*
 * -------------------------------------------------------------------------------------------
 * Function:		 macsimMod_get_dci_size
 * Description: 	 get dci size according to the input params.
 *
 *
 * Input:		 duplexing
 *               dlBandwidth_index
 *               dci_format
 *				 associated_UL
 *				 carrirer_ind_size_in_bits
 *				 csi_req_size_in_bits
 *				 srs_req_size_in_bits
 *				 less_ul_rbs
 *
 *
 *
 * --------------------------------------------------------------------------------------------
 */

U8 ys_qcGetDciSize
(
U16 duplexing,
DAN_E_CARRIER_BW bandwidth_index,
U32 dci_format,
U8 associated_UL,
U8 carrirer_ind_flag,
U16 csi_req_size,
U8 srs_reqflag,
U8 less_ul_rbs,
U16 tm,
U8 ulDl
)
{
    U8 csi_req_flag = (csi_req_size==2);
    U16 scenario = (associated_UL<<4) + (carrirer_ind_flag<<3) + (csi_req_flag<<2) + (srs_reqflag<<1) + less_ul_rbs;
    U8 dci_size=0xFF ;
    U8 tm_index;

    //Check if we are referring to Uplink DCI or DL DCI's (DL = 1, UL = 0)
    if(ulDl)
    {
        switch (dci_format)
        {
            case FAPI_E_DL_DCI_1:
                dci_size = payload_length_dci1[duplexing][bandwidth_index][scenario];
                break;

            case FAPI_E_DL_DCI_1A:
                dci_size = payload_length_dci1a[duplexing][bandwidth_index][scenario];
                break;

            case FAPI_E_DL_DCI_1B:
                dci_size = payload_length_dci1b[duplexing][bandwidth_index][scenario];
                break;

            case FAPI_E_DL_DCI_1C:
                dci_size = payload_length_dci1c[duplexing][bandwidth_index][0];
                break;

            case FAPI_E_DL_DCI_1D:
                dci_size = payload_length_dci1d[duplexing][bandwidth_index][scenario];
                break;

            case FAPI_E_DL_DCI_2:
                dci_size = payload_length_dci2[duplexing][bandwidth_index][carrirer_ind_flag];
                break;

            case FAPI_E_DL_DCI_2A:
                dci_size = payload_length_dci2a[duplexing][bandwidth_index][carrirer_ind_flag];
                break;

            case FAPI_E_DL_DCI_2B:
                dci_size = payload_length_dci2b[duplexing][bandwidth_index][carrirer_ind_flag];
                break;

            case FAPI_E_DL_DCI_2C:
                dci_size = payload_length_dci2c[duplexing][bandwidth_index][carrirer_ind_flag];
                break;

            case FAPI_E_DL_DCI_2D:
                dci_size = payload_length_dci2d[duplexing][bandwidth_index][carrirer_ind_flag];
                break;

            default:
                break;
        }

    }
    else
    {
        switch (dci_format)
        {
            case FAPI_E_UL_DCI_0:
                scenario = (carrirer_ind_flag<<3) + (csi_req_flag<<2) + (srs_reqflag<<1) + less_ul_rbs; //associated_UL ==1 always in dci format 0, so there are only 16 scenarios.
                dci_size  = payload_length_dci0[duplexing][bandwidth_index][scenario];
                break;

            case FAPI_E_UL_DCI_3:
                dci_size = payload_length_dci3a[duplexing][bandwidth_index][0];
                break;

            case FAPI_E_UL_DCI_3A:
                dci_size = payload_length_dci3a[duplexing][bandwidth_index][0];
                break;

            case FAPI_E_UL_DCI_4:
                tm_index = tm_to_index[tm-1];
                scenario = (carrirer_ind_flag*10) + (csi_req_flag*5) + tm_index;
                dci_size = payload_length_dci4[duplexing][bandwidth_index][scenario];
                break;
            default:
                break;
        }

    }

    return dci_size;
}

S16 ys_qcMsUtlCopyScatterBufPtr
(
Buffer *srcMbuf,            /* source message buffer */
MsgLen cnt,                 /* count */
Data *dstBuf               /* destination buffer */
)
{
    Data *cptr;
    Buffer *tmp;
    MsgLen numBytes;
    PZBCAPI pZbcApi = NULL;
    Void* ptr;

   TRC1(ysMsUtlCopyScatterBufPtr)

#if (ERRCLASS & ERRCLS_INT_PAR)
    /* check source message buffer */
    if (srcMbuf == NULLP)
    {
        SSLOGERROR(ERRCLS_INT_PAR, ESS110, ERRZERO, "ysMsUtlCopyScatterBufPtr : Null Buffer");
        RETVALUE(RFAILED);
    }

    if (cnt <= 0)
    {
        SSLOGERROR(ERRCLS_INT_PAR, ESS112, ERRZERO, "ysMsUtlCopyScatterBufPtr : Invalid Index");
        RETVALUE(RFAILED);
    }

    if (srcMbuf->b_datap->db_type != SS_M_PROTO)
    {
        SSLOGERROR(ERRCLS_INT_PAR, ESS115, ERRZERO, "ysMsUtlCopyScatterBufPtr : Incorrect\ buffer type");
        RETVALUE(RFAILED);
    }
#endif
    /*BEGIN:Added by zyj for BUG 2328 at 2016-6-14*/
    if (srcMbuf == NULLP || cnt <= 0 || srcMbuf->b_cont == NULLP)
    {
        RETVALUE(RFAILED);
    }
    /*END:Added by zyj for BUG 2328 at 2016-6-14*/
    
    /* get the first SS_M_DATA blk */
    tmp = srcMbuf->b_cont;

    /* set cptr to the read ptr of tmp */
    cptr = tmp->b_rptr;

    /*Offset to copy the Ptr, Msglen array*/
    pZbcApi = (PZBCAPI) ((U8 *) dstBuf);

    while (cnt)
    {
        /* determine the number of bytes to be copied */
        numBytes = MIN(cnt, (tmp->b_wptr - cptr));

        /* decrement cnt */
        cnt -= numBytes;
        ptr = cptr;

        pZbcApi->msgPtr = ptr;

        pZbcApi->msgSize = numBytes;

        /*Move to next blk*/
        pZbcApi++;

        /* get the next blk */
        if ((tmp = tmp->b_cont))
            /* set cptr to the read ptr of tmp */
            cptr = tmp->b_rptr;
        else
            break;
    }

    pZbcApi->msgSize = 0;

#ifdef YS_PHY_3_8_2
    pZbcApi->msgPtr = NULL;
#endif

    RETVALUE(ROK);
}
#endif

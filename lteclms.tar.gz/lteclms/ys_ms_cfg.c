/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************

     Name:     LTE MAC Convergenc Layer

     Type:     C source file

     Desc:     C source code for Entry point fucntions

     File:     ys_ms_cfg.c

     Sid:      yw_ms_cfg.c@@/main/TeNB_Main_BR/6 - Tue Jul  8 12:01:28 2014

     Prg:      pk

**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_FILE_ID=295;
static int RLOG_MODULE_ID=1;
/** @file ys_ms_cfg.c
@brief This module acts as an interface handler for upper interface and
manages Pst and Sap related information for upper interface APIs.
*/

/* header include files (.h) */
#include <stdlib.h>

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_lte.h"
#include "ctf.h"           /* CTF defines */
#include "lys.h"           /* layer management defines for LTE-CL */
#include "tfu.h"
#include "ys_ms.h"            /* defines and macros for CL */


/* Silicon Includes */
#ifdef INTEL_ALLOC_WLS_MEM
#include "wls_lib.h"
#endif 
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "apidefs.h"
#include "resultcodes.h"
#ifdef TENB_RTLIN_CHANGES
#include "ctrlmsg.h"
#endif
#endif

#include "ys_ms_err.h"        /* YS error defines */

#include "kwu.h"

/* header/extern include files (.x) */

#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"
#include "ctf.x"           /* CTF types */
#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#include "ys_ms.x"            /* typedefs for CL */
#include "tl_com.h"
EXTERN U8 sndPhyShutDwn;

EXTERN U8 wrSmDfltNumUnLicnsdCells;

#ifndef TENB_T2K3K_SPECIFIC_CHANGES
BOOL   isPhyStopped = TRUE;
#endif
/*ys004.102 :  Merged MSPD code with phy 1.7 */
typedef S16 (*YsMsSm) ARGS((YsCellCb *cellCb, Void *status));
PRIVATE YsMsSm ysMsSmStateMtx[YS_MS_MAX_STATES][YS_MS_MAX_EVNT];
#ifdef ENABLE_CNM
typedef S16 (*YsMsCnmSm) ARGS((PTR msg));
PRIVATE YsMsCnmSm ysMsSmCnmStateMtx[YS_MS_CNM_MAX_STATE][YS_MS_CNM_MAX_EVNT];
PRIVATE S16 ysMsSmStNmmStart(PTR msg);
PRIVATE S16 ysMsSmStNmmStartRsp(PTR mag);
PRIVATE S16 ysMsSmStNmmCellSearchCfm(PTR msg);
PRIVATE S16 ysMsSmStNmmPbchDatInd(PTR msg);
PRIVATE S16 ysMsSmStNmmStopResp(PTR msg);
#endif

/* Function Prototype */
PRIVATE S16 ysMsSmInvSE ARGS((YsCellCb *cellCb, Void *status));
PRIVATE S16 ysMsSmStIdleEvtParam ARGS((YsCellCb *cellCb, Void *status));
PRIVATE S16 ysMsSmStIdleEvtParamRsp ARGS((YsCellCb *cellCb, Void *status));
PRIVATE S16 ysMsSmStIdleEvtCfg ARGS((YsCellCb *cellCb, Void *status));
/* IP_DBG: Added PHY Reconfiguration Request, if PhyState is CFG */
PRIVATE S16 ysMsSmStEvtReCfg ARGS((YsCellCb *cellCb, Void *status));
PRIVATE S16 ysMsSmStIdleEvtCfgRsp ARGS((YsCellCb *cellCb, Void *status));
PRIVATE S16 ysMsSmStCfgEvtStartRsp ARGS((YsCellCb *cellCb, Void *status));
#ifdef YS_PHY_STOP_AUTO
PUBLIC S16 ysMsSmStRunEvtStop ARGS((YsCellCb *cellCb, Void *status));
#else
PRIVATE S16 ysMsSmStRunEvtStop ARGS((YsCellCb *cellCb, Void *status));
#endif
PRIVATE S16 ysMsSmStRunEvtStopRsp ARGS((YsCellCb *cellCb, Void *status));
PRIVATE S16 ysMsSmStRunEvtShutdownReq ARGS((YsCellCb *cellCb, Void *status));
PRIVATE S16 ysMsSmStRunEvtShutdownRsp ARGS((YsCellCb *cellCb, Void *status));

#ifndef TENB_RTLIN_CHANGES
/* Adding Prototype as this function defination is available in ad9361radio.c file in PHY */
EXTERN MXRC Ad9361IRadioScheduleInit ARGS ((UINT32 nProfID, UINT32 NumTxAntennas, UINT32 NumRxAntennas, 
                             UINT32 loopback, UINT32 rxfreq, UINT32 txfreq));
#endif
#ifdef LTE_ADV
PUBLIC S16 ysMsCfgVldtUeSCellReCfg ARGS((CtfDedRecfgInfo *dedRecfg,
                                          YsUeCb            *ueCb));
/* LTE_UNLICENSED */
#if 0//ndef LTE_TDD
PRIVATE S16 ysMsSmStIdleEvtLaaCfg ARGS((YsCellCb *cellCb, Void *status));
PRIVATE S16 ysMsSmStIdleEvtScanReq ARGS((YsCellCb *cellCb, Void *status));
PRIVATE S16 ysMsSmStIdleEvtScanInd ARGS((YsCellCb *cellCb, Void *status));
#endif
#endif


#define ysMsSmStCfgEvtCfg ysMsSmStIdleEvtCfg
#define ysMsSmStCfgEvtCfgRsp ysMsSmStIdleEvtCfgRsp
#define ysMsSmStRunEvtStartRsp ysMsSmStCfgEvtStartRsp

#ifdef TENB_AS_SECURITY
#ifdef TENB_T2K3K_SPECIFIC_CHANGES
PUBLIC Pst pdcpPst;
#if (defined(TENB_AS_SECURITY) && defined(UL_DL_SPLIT))
PUBLIC Pst ulPdcpPst;
#endif
PUBLIC Pst rlcUlPst;
#ifdef SPLIT_RLC_DL_TASK
PUBLIC Pst rlcDlPst;
#endif 
#endif
#endif

U8 cellPhyInstId = YS_PHY_INST_ID;
PUBLIC YsCellCb *ysMsGetCellCbFrmPhyInstId
(
U8 phyInstId
);
/*
*
*       Fun:    ysMsCfgSm
*
*       Desc:   This function invoke state machine
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PUBLIC S16 ysMsCfgSm
(
YsCellCb   *cellCb,
U8         event,
Void       *status
)
{
   S16 ret;

   TRC3(ysMsCfgSm);

   RLOG2(L_ALWAYS, "Inside ysMsCfgSm. Event = %d, PhyState = %d", event, cellCb->phyState);
   STKLOG(STK_MD_YS,STK_LOG_INFO,"Inside ysMsCfgSm. Event = %d, PhyState = %d\n", event, cellCb->phyState);
   fflush(stdout);
   ret = ysMsSmStateMtx[cellCb->phyState][event](cellCb, status);

   RETVALUE(ret);
} /* ysMsCfgSm */


/* In this matrix the rows represent states of the PHY and columns
 * represent events on the phy.
 *
 * State Index numbers:
 * ====================
 *
 * LYS_PHY_STATE_IDLE          ==> 0
 * LYS_PHY_STATE_CFG           ==> 1
 * LYS_PHY_STATE_RUN           ==> 2
 *
 *
 * The columns represent the events that can happen on a Phy.
 * Column Indexes are:
 *
 * YS_MS_INV_EVENT            ==> 0
 * YS_MS_EVENT_CFG            ==> 1
 * YS_MS_EVENT_CFG_RSP        ==> 2
 * YS_MS_EVENT_START_RSP      ==> 3
 * YS_MS_EVENT_STOP           ==> 4
 * YS_MS_EVENT_STOP_RSP       ==> 5
 * YS_MS_EVENT_PARAM          ==> 6 
 * YS_MS_EVENT_PARAM_RSP      ==> 7
 *
 * The function handlers are named as:
 * ysMsSm<State Number><Event Number>
 * eg: ysMsSmS2E1 => Represents handler for the event Configuration
 *                      in the state running
 *
 */

PRIVATE YsMsSm ysMsSmStateMtx[YS_MS_MAX_STATES][YS_MS_MAX_EVNT] =
{
   {
      ysMsSmInvSE, 
      ysMsSmStIdleEvtParam,
      ysMsSmStIdleEvtParamRsp,
      ysMsSmStIdleEvtCfg, 
      ysMsSmStIdleEvtCfgRsp, 
      ysMsSmInvSE,
      ysMsSmInvSE,         
      ysMsSmInvSE,
/* LTE_UNLICENSED */
#ifdef LTE_ADV
#ifndef LTE_TDD
      ysMsSmInvSE, 
      ysMsSmInvSE, 
      ysMsSmInvSE
#endif
#endif
   },
   {
      ysMsSmInvSE, 
      ysMsSmInvSE,
      ysMsSmInvSE,
      ysMsSmStEvtReCfg, 
      ysMsSmStCfgEvtCfgRsp,   
      ysMsSmStCfgEvtStartRsp,
      ysMsSmInvSE,
      ysMsSmInvSE
/* LTE_UNLICENSED   */
#ifdef LTE_ADV 
#ifndef LTE_TDD
         ,ysMsSmInvSE,
      ysMsSmInvSE,
      ysMsSmInvSE
#endif
#endif
   },
   {
      ysMsSmInvSE, 
      ysMsSmInvSE,        
      ysMsSmInvSE,      
      ysMsSmInvSE,
      ysMsSmInvSE,
      ysMsSmStRunEvtStartRsp,
      ysMsSmStRunEvtStop,  
      ysMsSmStRunEvtStopRsp
/* LTE_UNLICENSED    */
#ifdef LTE_ADV 
#ifndef LTE_TDD
         ,ysMsSmInvSE,
      ysMsSmInvSE,
      ysMsSmInvSE
#endif
#endif
   },
   {
      ysMsSmInvSE,
      ysMsSmInvSE,
      ysMsSmInvSE,         
      ysMsSmStRunEvtShutdownReq, //WTF?
      ysMsSmStRunEvtShutdownRsp, //WTF?
      ysMsSmInvSE,
      ysMsSmInvSE,  
      ysMsSmInvSE
/* LTE_UNLICENSED    */
#ifdef LTE_ADV 
#ifndef LTE_TDD
         ,ysMsSmInvSE,
      ysMsSmInvSE,
      ysMsSmInvSE
#endif
#endif
   }
};

#ifdef ENABLE_CNM
/*
*
*       Fun:    ysMsCfgCnmSm
*
*       Desc:   This function invoke CNM state machine
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PUBLIC S16 ysMsCfgCnmSm
(
U8         event,
PTR        msg
)
{
   S16 ret;

   TRC3(ysMsCfgCnmSm);

   RLOG1(L_DEBUG,"Inside ysMsCfgSm. Event = %d ", event);

   STKLOG(STK_MD_YS,STK_LOG_INFO,"CNM:: StateMachine :: State %d Event %d\n",ysCb.cnmState,event);
   ret = ysMsSmCnmStateMtx[ysCb.cnmState][event](msg);

   RETVALUE(ret);
} /* ysMsCfgSm */


/* In this matrix the rows represent states of the PHY and columns
 * represent events on the phy.
 *
 * State Index numbers:
 * ====================
 *
 * LYS_PHY_STATE_IDLE          ==> 0
 * LYS_PHY_STATE_CFG           ==> 1
 * LYS_PHY_STATE_RUN           ==> 2
 *
 *
 * The columns represent the events that can happen on a Phy.
 * Column Indexes are:
 *
 * YS_MS_INV_EVENT            ==> 0
 * YS_MS_EVENT_CFG            ==> 1
 * YS_MS_EVENT_CFG_RSP        ==> 2
 * YS_MS_EVENT_START_RSP      ==> 3
 * YS_MS_EVENT_STOP           ==> 4
 * YS_MS_EVENT_STOP_RSP       ==> 5
 *
 * The function handlers are named as:
 * ysMsSm<State Number><Event Number>
 * eg: ysMsSmS2E1 => Represents handler for the event Configuration
 *                      in the state running
 *
 */

PRIVATE YsMsCnmSm ysMsSmCnmStateMtx[YS_MS_CNM_MAX_STATE][YS_MS_CNM_MAX_EVNT] =
{
   {
       NULLP,
       NULLP,
       NULLP,
       NULLP,
       NULLP,
       NULLP,
       NULLP
   },
   {
       ysMsSmStNmmStart,
       ysMsSmStNmmStartRsp,
       NULLP,
       ysMsSmStNmmCellSearchCfm,
       NULLP,
       ysMsSmStNmmPbchDatInd,
       ysMsSmStNmmStopResp
   }
};
#endif
/*
*
*       Fun:    ysMsSmInvSE
*
*       Desc:   This function handles the invalid event or state.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmInvSE
(
YsCellCb   *cellCb,
Void       *status
)
{

   TRC3(ysMsSmInvSE);

   RLOG_ARG0(L_ERROR, DBG_CELLID,cellCb->cellId,"Invalid state or event");

   RETVALUE(RFAILED);
} /* ysMsSmInvSE */

PRIVATE S16 ysMsSmStIdleEvtParam
(
YsCellCb   *cellCb,
Void       *status
)
{
   //intend to skip param req -- param rsp
   FORCE_CRASH;
   //ys_qcSendParReq();
   return 0;
}

PRIVATE S16 ysMsSmStIdleEvtParamRsp
(
YsCellCb   *cellCb,
Void       *status
)
{
   return 0;
}



/*
*
*       Fun:    ysMsSmStIdleEvtCfg
*
*       Desc:   This function handles the YS_MS_EVENT_CFG event in
*               state LYS_PHY_STATE_IDLE.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

#define MY_1ENABLE_SVSR_API_LOGGER_DEF_MASK         ((1<<12)|(1<<17))

EXTERN S16 ys_qcSendConfigReq(YsCellCb   *cellCb);
PRIVATE S16 ysMsSmStIdleEvtCfg
(
YsCellCb   *cellCb,
Void       *status
)
{
   S16          ret;

   TRC3(ysMsSmStIdleEvtCfg);
   STKLOG(STK_MD_YS,STK_LOG_INFO,"INFO: FAPI_E_PARAM_REQ %d !!\n", cellCb->phyInstId);
   fflush(stdout);

   //ret = ys_qcSendStopReq(cellCb->phyInstId);
   //int i = 3;
   //while(i--)
   //{
      ret = ys_qcSendParReq(cellCb->phyInstId);
   //   sleep(1);
   //}

   //ret = ys_qcSendConfigReq(cellCb);

   if (ret)
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"error: FAPI_E_PARAM_REQ %d failed!!\n", cellCb->phyInstId);
      fflush(stdout);
      RLOG1(L_ERROR, "FAPI_E_PARAM_REQ %d failed!!", cellCb->phyInstId);
      RETVALUE(ret);
   }
   printf("FAPI_E_PARAM_REQ \n");
   MSPD_DBG("FAPI_E_PARAM_REQ %d\n", cellCb->phyInstId);
   RLOG1(L_ALWAYS, "FAPI_E_PARAM_REQ %d", cellCb->phyInstId);
   if (ysGT == 33835)
   {
      ysGT = 0;
   }

   RETVALUE(ret);
} /* ysMsSmStIdleEvtCfg */

/* IP_DBG: Added PHY Reconfiguration Request, if PhyState is CFG */
/*
*
*       Fun:    ysMsSmStEvtReCfg
*
*       Desc:   This function handles the YS_MS_EVENT_CFG event in
*               state LYS_PHY_STATE_CFG.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmStEvtReCfg
(
YsCellCb   *cellCb,
Void       *status
)
{

   S16 		 ret = ROK;

#ifndef QCBC_PLATFORM

#ifndef YS_JMP_PHY_RUN_STE
   PGENMSGDESC  pMsgDesc;
   PINITPARM    msCfgReq;
   U32          l1Size;
#endif
   /* HARQ: PHY_API_CHANGE */
   PMAC2PHY_QUEUE_EL pElem;

   TRC3(ysMsSmStEvtReCfg);
 
#ifndef TENB_RTLIN_CHANGES
   SvsrLoggerSetMask(MY_1ENABLE_SVSR_API_LOGGER_DEF_MASK);
#endif

   l1Size = sizeof(GENMSGDESC) + sizeof(INITPARM);
#ifdef BATCH_PROCESSING_DL
   /* PHY_API_CHANGE : Fill the linked list element */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL) + l1Size);
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      /* HARQ_DBG */
      uart_printf("ysMsUtlGetPhyListElem failed for PHY list element for\
      PHY_RECONFIG_REQ at cellTime(%d,%d)\n",
      cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
      RETVALUE(RFAILED);
   }
   pElem->AlignOffset = l1Size;
   pElem->NumMessageInBlock = 1;
   pMsgDesc = (PGENMSGDESC)(pElem + 1);
#else 
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pMsgDesc = ysMsUtlAllocSvsrMsg(FALSE, (sizeof(GENMSGDESC) + sizeof(INITPARM)));
#else
   pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg(FALSE);
#endif
#endif

   msCfgReq = (PINITPARM)(pMsgDesc + 1);
   cmMemset((U8 *)msCfgReq,(U8 )0,sizeof(INITPARM));

   pMsgDesc->msgType     = PHY_RECONFIG_REQ;
   pMsgDesc->phyEntityId = cellCb->phyInstId;
   pMsgDesc->msgSpecific = sizeof(INITPARM);
   ret = ysMsUtlFillCfgReq(msCfgReq, cellCb);

   cellCb->cellCfg.pilotSigPwr         = cellCb->cellCfg.pilotSigPwr * YS_MS_DB_UNIT;
   cellCb->cellCfg.priSigPwr           = cellCb->cellCfg.priSigPwr * YS_MS_DB_UNIT;
   cellCb->cellCfg.secSigPwr           = cellCb->cellCfg.secSigPwr * YS_MS_DB_UNIT;

#ifndef BATCH_PROCESSING_DL
   /* PHY_API_CHANGE : Fill the linked list element */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      /* HARQ_DBG */
      uart_printf("ysMsUtlGetPhyListElem failed for PHY list element for\
      PHY_RECONFIG_REQ at cellTime(%d,%d)\n",
      cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
      RETVALUE(RFAILED);
   }

#ifdef TENB_RTLIN_CHANGES
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe,
         ysGetPhyPtr(pMsgDesc), l1Size, PHY_RECONFIG_REQ);
#else
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe,
         pMsgDesc, l1Size, PHY_RECONFIG_REQ);
#endif
#else
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe,
         NULLP, l1Size, PHY_RECONFIG_REQ);
#endif

#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
   if(cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg >= MAX_NUM_L1_MESSAGES_PER_TTI)
   {
#ifndef ALIGN_64BIT 
     stop_printf("NumL1Msg %lu  greater than %d \n", cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg, 
                                                    MAX_NUM_L1_MESSAGES_PER_TTI);
#else
     stop_printf("NumL1Msg %u  greater than %d \n", cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg, 
                                                    MAX_NUM_L1_MESSAGES_PER_TTI);
#endif
   }  
#endif
   ysSendMsgToPhy(l1Size, pElem);

   RLOG0(L_DEBUG, "PHY_RECONFIG_REQ");

#endif

   RETVALUE(ret);

} /* ysMsSmStEvtReCfg */

/*
*
*       Fun:    ysMsSmStIdleEvtCfgRsp
*
*       Desc:   This function handles the YS_MS_EVENT_CFG_RSP event in
*               state LYS_PHY_STATE_IDLE.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmStIdleEvtCfgRsp
(
YsCellCb   *cellCb,
Void       *status
)
{
   S16         ret;
   PINITIND    initInd;
   PSTARTREQ   startReq;
   U32         l1Size;
   PGENMSGDESC pMsgDesc;
   /* PHY_API_CHANGE */
   PMAC2PHY_QUEUE_EL pElem;

   TRC3(ysMsSmStIdleEvtCfgRsp);

   initInd = (PINITIND)status;

   if(initInd->status != SUCCESS)
   {
      /* TODO free the INITIND */
      RLOG_ARG1(L_ERROR, DBG_CELLID,cellCb->cellId,
            "Phy Init Failed ErrorVal = %d", initInd->status);
      MSPD_ERR("Phy Init Failed. Error = %d\n", initInd->status);
      YsUiCtfCfgCfm(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,
                     ysCb.ctfSap.transId, CTF_CFG_CFM_NOK);
      RETVALUE(RFAILED);
   }
   else
   {
      /* Who is going to free INITIND ??*/
      /* TODO free the INITIND */
   }

   l1Size = sizeof(GENMSGDESC) + sizeof(STARTREQ);

#ifdef BATCH_PROCESSING_DL
   //printf("ysMsSmStIdleEvtCfgRsp:619: preparing Start Req of length %d\n", l1Size); 
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL) + l1Size);
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      /* HARQ_DBG */
      uart_printf("SvsrAllocMsg failed for PHY list element for PHY_START_REQ at time(%d,%d)\n",
      cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
      RETVALUE(RFAILED);
   }
   pElem->NumMessageInBlock = 1; 
   pElem->AlignOffset = l1Size; 
   pMsgDesc = (PGENMSGDESC)(pElem + 1);
#else
   /* Allocate a message towards Phy using sysCore */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pMsgDesc = ysMsUtlAllocSvsrMsg(FALSE, (sizeof(GENMSGDESC) + sizeof(STARTREQ)));
#else
   pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg(FALSE);
#endif
   if (pMsgDesc == NULLP)
   {
      RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId, 
            "Failed allocating memory for pMsgDesc");
      MSPD_ERR("Unable to allocate memory for TxVector");
      RETVALUE (RFAILED);
   }
#endif

   startReq = (PSTARTREQ)(pMsgDesc );

/* Filling the band ID for automating the ADI ID */
   RLOG1(L_DEBUG," cellCb->cellCfg.antennaCfg.antPortsCnt %d", 
         cellCb->cellCfg.antennaCfg.antPortsCnt);
   
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
   if(isPhyStopped != TRUE)
   {
      if (cellCb->vendorParams.opMode == 4)
      {
         U8 retVal = 1;

         if (cellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_2)
            retVal = Ad9361IRadioScheduleInit(cellCb->cellInfo.bandId,2,2,0,0,0) & 0xFF;
         else if (cellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_1)
            retVal = Ad9361IRadioScheduleInit(cellCb->cellInfo.bandId,1,1,0,0,0) & 0xFF;

         if (retVal)
         {
            RLOG_ARG0(L_ERROR, DBG_CELLID,cellCb->cellId,"ADI Radio schedule Init command Failed");
            RETVALUE(RFAILED);
         }

      }
   }
#endif


#ifndef TENB_RTLIN_CHANGES
   if (cellCb->vendorParams.opMode == 4)
   {
      U8 retVal = 1;

      if (cellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_2)
         retVal = Ad9361IRadioScheduleInit(cellCb->cellInfo.bandId,2,2,0,0,0) & 0xFF;
      else if (cellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_1)
         retVal = Ad9361IRadioScheduleInit(cellCb->cellInfo.bandId,1,1,0,0,0) & 0xFF;

      if (retVal)
      {
         RLOG_ARG0(L_ERROR, DBG_CELLID,cellCb->cellId,"ADI Radio schedule Init command Failed ");
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
         SvsrFreeMsg(pMsgDesc);/*FREE_SVSR_NEW*/
#else
         ysFreePhyMsg(pMsgDesc);
#endif
         RETVALUE(RFAILED);
      }
   }
#endif
   MSPD_DBG("Sendig ysMsUtlFillStartReq \n");
   ret = ysMsUtlFillStartReq(startReq, cellCb);
   if (ret != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"Filling StartReq Failed ");
#ifdef BATCH_PROCESSING_DL
      ysFreePhyMsg(pElem);
#endif
      RETVALUE(RFAILED);
   }


   cellCb->phyState = LYS_PHY_STATE_CFG;

   STKLOG(STK_MD_YS,STK_LOG_INFO,"send PHY_START_REQ cellCb->phyInstId = %u\n",cellCb->phyInstId);
   ysSendMsgToPhy(l1Size, pElem);

   RLOG1(L_ALWAYS, "PHY_START_REQ %d", cellCb->phyInstId);

   RETVALUE(ret);
} /* ysMsSmStIdleEvtCfgRsp */

/*
*
*       Fun:    ysMsSmStCfgEvtStartRsp
*
*       Desc:   This function handles the YS_MS_EVENT_START_RSP event in
*               state LYS_PHY_STATE_CFG.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmStCfgEvtStartRsp
(
YsCellCb   *cellCb,
Void       *status
)
{
   PINITIND   initInd;
   #ifdef TFU_TDD
   U32        idx;
   #endif
   TRC3(ysMsSmStCfgEvtStartRsp);
   STKLOG(STK_MD_YS,STK_LOG_INFO,"------[fun]ysMsSmStCfgEvtStartRsp: received");

   /*
      crude workaround: un-comment this code once fix is there in the PHY 
      to send proper
           MSGT_RESPONSE with PHY_START_CONF for the PHY_START_REQ msg
      */

   initInd = (PINITIND)status;

   if(initInd->status != SUCCESS)
   {
      RLOG_ARG1(L_ERROR,DBG_CELLID,cellCb->cellId,
            "Phy start response failed with ErrorVal = %d", initInd->status);
      MSPD_ERR("Starting Phy Failed. Error = %d\n", initInd->status);
      YsUiCtfCfgCfm(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,
                     ysCb.ctfSap.transId, CTF_CFG_CFM_NOK);
      RETVALUE(RFAILED);
   }

   #ifdef ENABLE_CNM
   if(ysCb.isCnmProcInitiated == TRUE)
   {
      /* Perform ICTA procedure */
      STKLOG(STK_MD_YS,STK_LOG_INFO," CNM::Triggering ICTA Start Req...\n");
      ysMsUtlTrigIctaStartReq(cellCb);
   }
   else
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO," CNM:: Not Triggering ICTA Start Req...\n");
   }
   #endif
   YsUiCtfCfgCfm(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,
                     ysCb.ctfSap.transId, CTF_CFG_CFM_OK);

   cellCb->phyState = LYS_PHY_STATE_RUN;
   #ifdef TFU_TDD
   for(idx = 1; idx < (ysCb.numOfCells); idx++)
   {
      cellCb = ysCb.tfuSapLst[idx]->cellCb;
      cellCb->phyState = LYS_PHY_STATE_RUN;
   }
   #endif
   RLOG0(L_ALWAYS, "PHY_START_CONF");

   RETVALUE(ROK);
} /* ysMsSmStCfgEvtStartRsp */

/*
*
*       Fun:    ysMsSmStRunEvtStop
*
*       Desc:   This function handles the YS_MS_EVENT_STOP event in
*               state LYS_PHY_STATE_RUN.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

#ifdef YS_PHY_STOP_AUTO
PUBLIC S16 ysMsSmStRunEvtStop
(
YsCellCb   *cellCb,
Void       *status
)
#else
PRIVATE S16 ysMsSmStRunEvtStop
(
YsCellCb   *cellCb,
Void       *status
)
#endif
{
   PGENMSGDESC stopReq;
   S16         ret;
   /* PHY_API_CHANGE */
   PMAC2PHY_QUEUE_EL pElem;

   TRC3(ysMsSmStRunEvtStop);

#ifdef BATCH_PROCESSING_DL
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL) + sizeof(GENMSGDESC));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      /* HARQ_DBG */
      RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
      RETVALUE(RFAILED);
   }
   pElem->AlignOffset = sizeof(GENMSGDESC);
   pElem->NumMessageInBlock = 1;
   pElem->Next = NULLP;

   stopReq = (PGENMSGDESC)(pElem + 1);
#else

   /* Allocate a message towards Phy using sysCore */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   stopReq = ysMsUtlAllocSvsrMsg(FALSE, (sizeof(GENMSGDESC)));
#else
   stopReq = (PGENMSGDESC) ysMsUtlAllocSvsrMsg (FALSE);
#endif
   if (stopReq == NULLP)
   {
      RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId,
            "Unable to allocate memory for stopReq");
      MSPD_ERR("Unable to allocate memory for TxVector");
      RETVALUE (RFAILED);
   }
#endif

   ret = ysMsUtlFillStopReq(stopReq, cellCb);
   if (ret != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"Filling stop Request Failed ");
#ifdef BATCH_PROCESSING_DL
      ysFreePhyMsg(pElem);
#endif
      RETVALUE(RFAILED);
   }

#ifndef BATCH_PROCESSING_DL
   /* PHY_API_CHANGE : Fill the linked list element */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      /* HARQ_DBG */
      uart_printf("ysMsUtlAllocSvsrMsg failed for PHY list element for \
            PHY_STOP_REQ at time (%d,%d)\n",
      cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
      SvsrFreeMsg(stopReq);/*FREE_SVSR*/
#else
      ysFreePhyMsg(stopReq);
#endif
      RETVALUE(RFAILED);
   }
#ifdef TENB_RTLIN_CHANGES
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
        ysGetPhyPtr(stopReq), sizeof(GENMSGDESC), PHY_STOP_REQ);
#else
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
        stopReq, sizeof(GENMSGDESC), PHY_STOP_REQ);
#endif
#else 
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, cellCb->timingInfo.subframe,
        NULLP, sizeof(GENMSGDESC), PHY_STOP_REQ);
#endif
   RLOG2(L_ALWAYS,"PST: sending PHY_STOP_REQ to PHY at time(%d,%d) ",cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
   STKLOG(STK_MD_YS,STK_LOG_INFO,"PST: sending PHY_STOP_REQ to PHY at time(%d,%d)\n",cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
   fflush(stdout);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
   if(cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg >= MAX_NUM_L1_MESSAGES_PER_TTI)
   {
#ifndef ALIGN_64BIT
     stop_printf("NumL1Msg %lu  greater than %d \n", cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg, 
                                                    MAX_NUM_L1_MESSAGES_PER_TTI);
#else
     stop_printf("NumL1Msg %u  greater than %d \n", cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg, 
                                                    MAX_NUM_L1_MESSAGES_PER_TTI);
#endif
   }  
#endif
   ysSendMsgToPhy(sizeof(GENMSGDESC), pElem);
   cellCb->stop_Req_sent = 1;
/*   printf("RAGHU: sending stop request stop_Req_sent =%d\n", stop_Req_sent);*/
   RLOG0(L_DEBUG, "PHY_STOP_REQ");
   STKLOG(STK_MD_YS,STK_LOG_INFO,"PHY_STOP_REQ\n");
   RETVALUE(ret);
} /* ysMsSmStRunEvtStop */

/*
*
*       Fun:    ysMsSmStRunEvtStopRsp
*
*       Desc:   This function handles the YS_MS_EVENT_STOP_RSP event in
*               state LYS_PHY_STATE_RUN.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmStRunEvtStopRsp
(
YsCellCb   *cellCb,
Void       *status
)
{
   PINITIND   initInd;

   TRC3(ysMsSmStRunEvtStopRsp);

   initInd = (PINITIND)status;

   if(initInd->status != SUCCESS)
   {
      RLOG_ARG1(L_ERROR, DBG_CELLID,cellCb->cellId,
            "Stop Phy reponse Failed with ErrorVal = %d", initInd->status);
      MSPD_ERR("PST: Stoping Phy Failed. Error = %d\n", initInd->status);
      RETVALUE(RFAILED);
   }
#if BSP_SUPPORT_FOR_CNM
   if(cellCb->cnmState == REM_STATE_CNM )
   {
     cellCb->cnmState = REM_STATE_INIT; 
     ysMsCfgCnmSm(cellCb, YS_MS_CNM_NMM_START, NULLP);
     RETVALUE(ROK); 
   }
#endif
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
   isPhyStopped = TRUE;
#endif
   cellCb->phyState = LYS_PHY_STATE_STOP;
   RLOG0(L_ALWAYS,"ysMsSmStRunEvtStopRsp PHY STATE is  STOPPED");

   ysMsCfgSm(cellCb, YS_MS_EVENT_CFG, NULLP);

   RETVALUE(ROK);
} /* ysMsSmStRunEvtStopRsp */

/*
*
*       Fun:    ysMsSmStNmmStart
*
*       Desc:   This function handles the YS_MS_EVENT_STOP event in
*               state LYS_PHY_STATE_RUN.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/
#ifdef ENABLE_CNM
PUBLIC S16 ysMsSmStNmmStart
(
PTR msg
)
{
   S16  ret = ROK;
   STKLOG(STK_MD_YS,STK_LOG_INFO," CNM:; Triggering NMM start\n");
   ret = ysMsUtlTrigNmmStart(msg);

   RETVALUE(ret);


} /* ysMsSmStNmmStart */

PUBLIC S16 ysMsSmStNmmStartRsp
(
PTR        msg
)
{
   S16  ret = ROK;

   ret = ysMsUtlTrigNmmCellSearchReq(msg);

   RETVALUE(ret);


} /* ysMsSmStNmmStartRsp */

PUBLIC S16 ysMsSmStNmmCellSearchCfm
(
PTR        msg
)
{
   S16  ret = ROK;

   ret = ysMsUtlTrigNmmPbchCfgReq(msg);

   RETVALUE(ret);
} /* ysMsSmStNmmCellSearchCfm*/


PUBLIC S16 ysMsSmStNmmPbchDatInd
(
PTR        msg
)
{
   S16  ret = ROK;

   /* Trigger SYNC_IND response to
    * application. Use the status from pbch dat ind
    * for informing the status */
   /* Trigger NMM Stop Req to PHY */
   /* TODO:: Resp to app can be triggered here
    * or wait for NMM Stop Rsp */

   ret = ysMsUtlTrigNmmStopReq(msg);

   RETVALUE(ret);

} /* ysMsSmStNmmPbchDatInd*/

PUBLIC S16 ysMsSmStNmmStopResp
(
PTR        msg
)
{
   S16  ret = ysCb.cnmNmmStatus;

   /* Trigger SYNC_IND response to
    * application. Use the status from pbch dat ind
    * for informing the status */
   ysMsUtlTrigCnmInitSyncRsp(ret);

   RETVALUE(ret);

} /* ysMsSmStNmmPbchDatInd*/
#endif


/*
*
*       Fun:    ysMsSmStRunEvtShutdownReq
*
*       Desc:   This function handles the YS_MS_EVENT_SHUTDOWN event in
*               state LYS_PHY_STOPPED.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmStRunEvtShutdownReq
(
YsCellCb   *cellCb,
Void       *status
)
{
   /* PGENMSGDESC shutdownReq; */
   S16         ret = ROK;
   /* Raghu To-Do Check with reema about commnted code */
   RLOG0(L_ALWAYS,"ysMsSmStRunEvtShutdownReq: Sent PHY_SHUTDOWN_REQ ");
   ysMsSndPhyShutDwn(cellCb);
   sndPhyShutDwn = 0;


   RETVALUE(ret);
} /* ysMsSmStRunEvtShutdownReq */

/*
*
*       Fun:    ysMsSmStRunEvtShutdownRsp
*
*       Desc:   This function handles the YS_MS_EVENT_SHUTDOWN_RSP event in
*               state LYS_PHY_SHUTDOWN.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmStRunEvtShutdownRsp
(
YsCellCb   *cellCb,
Void       *status
)
{
#ifdef L2_L3_SPLIT
   EXTERN Bool g_usettitmr;
#endif
   PINITIND   initInd;
   S16         ret = ROK;

   TRC3(ysMsSmStRunEvtShutdownRsp);

   initInd = (PINITIND)status;

   if(initInd->status != SUCCESS)
   {
      RLOG_ARG1(L_ERROR, DBG_CELLID,cellCb->cellId,
            "PHY Shutdown Response Failed with ErrorVal = %d", initInd->status);
      MSPD_ERR("PST: PHY Shutdown  Req Failed. Error = %d\n", initInd->status);
      RETVALUE(RFAILED);
   }
   /* Sending configuration confirm to SM ***PST-CellReset*** */
   ysCb.ctfSap.transId.trans[8] = YS_MS_PHY_SHUTDOWN_CFM;
   YsUiCtfCfgCfm(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId, ysCb.ctfSap.transId, CTF_CFG_CFM_OK);
#ifdef L2_L3_SPLIT
   g_usettitmr = FALSE;
#endif
   cellCb->phyState = LYS_PHY_STATE_IDLE;
   /* If the shutdown was initiated for Cell Recfg, 
    * we have to send the INIT again to configure
    * with the updated values(cell recfg) */
   if(cellCb->cellRecfgInitiated == TRUE)
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO," Trig cfg after shtdwn rsp *****\n");
      ret = ysMsCfgSm(cellCb, YS_MS_EVENT_CFG, NULLP);
      cellCb->cellRecfgInitiated = FALSE;
   }
   RLOG0(L_DEBUG,"ysMsSmStRunEvtStopRsp PHY STATE is SHUTDOWN");
   STKLOG(STK_MD_YS,STK_LOG_INFO,"ysMsSmStRunEvtStopRsp PHY STATE is SHUTDOWN\n");

   RETVALUE(ret);
} /* ysMsSmStRunEvtShutdownRsp */

/* LTE_UNLICENSED */
#ifdef LTE_ADV
#if 0//ndef LTE_TDD
PRIVATE S16 ysMsUtlFillLaaCfgReq 
(
YsCellCb           *cellCb,
PPHY_INIT_LAA_REQ  laaInitReq
)
{
   laaInitReq->msgType = INIT_LAA_REQ;
   laaInitReq->msgLength = sizeof(PHY_INIT_LAA_REQ);
   laaInitReq->phyEntityId = cellCb->phyInstId;
   laaInitReq->activityThreshold = cellCb->lteUCfg.activityTh;
   laaInitReq->adaptivePeriodicTxEnable = cellCb->lteUCfg.adaptiveTx;
   laaInitReq->ccaMethod = cellCb->lteUCfg.ccaMethod;
   laaInitReq->coexistenceMethod = cellCb->lteUCfg.coExistMethod;
   laaInitReq->energyThreshold = cellCb->lteUCfg.energyTh;
   laaInitReq->listeningPeriod = cellCb->lteUCfg.listenPrd;
   laaInitReq->lteOnPeriod = cellCb->lteUCfg.lteOnPeriod;
   laaInitReq->scanTimePeriod = cellCb->lteUCfg.scanTimePrd;
   laaInitReq->transmissionPeriod = cellCb->lteUCfg.transPeriod;
   laaInitReq->reserved[0] = 0;
   laaInitReq->reserved[1] = 0;
   laaInitReq->reserved[2] = 0;
   
   STKLOG(STK_MD_YS,STK_LOG_INFO,"Sending: PhyId %d ActThld %d AdaTx %d ccaMth %d coEx %d enThld %d LisPrd %d OnPrd %d scanTime %d TransPrd %d\n", \
                              cellCb->phyInstId, cellCb->lteUCfg.activityTh, cellCb->lteUCfg.adaptiveTx, cellCb->lteUCfg.ccaMethod, \
                              cellCb->lteUCfg.coExistMethod, cellCb->lteUCfg.energyTh, cellCb->lteUCfg.listenPrd, cellCb->lteUCfg.lteOnPeriod, \
                              cellCb->lteUCfg.scanTimePrd, cellCb->lteUCfg.transPeriod);
   MSPD_DBG("Sending: PhyId %d ActThld %d AdaTx %d ccaMth %d coEx %d enThld %d LisPrd %d OnPrd %d scanTime %d TransPrd %d\n", \
                              cellCb->phyInstId, cellCb->lteUCfg.activityTh, cellCb->lteUCfg.adaptiveTx, cellCb->lteUCfg.ccaMethod, \
                              cellCb->lteUCfg.coExistMethod, cellCb->lteUCfg.energyTh, cellCb->lteUCfg.listenPrd, cellCb->lteUCfg.lteOnPeriod, \
                              cellCb->lteUCfg.scanTimePrd, cellCb->lteUCfg.transPeriod);

   RETVALUE(ROK);
}

/*
*
*       Fun:    ysMsSmStIdleEvtLaaCfg
*
*       Desc:   This function handles the YS_MS_EVENT_CFG_LAA event in
*               state LYS_PHY_STATE_IDLE.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmStIdleEvtLaaCfg 
(
YsCellCb   *cellCb,
Void   *status
)
{
#ifndef BATCH_PROCESSING_DL
   PMSGHEADER        pHdr;
   U32               *pMsg;
   PGENMSGDESC       phyMsgDescPtr;
   PGENMSGDESC       pMsgDesc;
#endif
   PPHY_INIT_LAA_REQ         msCfgReq;
   U32               l1Size;
   S16               ret;
   PMAC2PHY_QUEUE_EL pElem;

   TRC3(ysMsSmStIdleEvtLaaCfg);
#if 0
#else
   l1Size = sizeof(PHY_INIT_LAA_REQ);
#endif
#ifndef BATCH_PROCESSING_DL
 
#ifdef TL_ALLOC_ICC_MEM
   pMsgDesc = ysMsUtlGetPhyListElem(l1Size);
#else
   pMsgDesc = ysMsUtlGetPhyListElem();
#endif
   if(pMsgDesc == NULLP)
   {
      uart_printf("Memory allocation failed for PHY_INIT_LAA_REQ\n");
      RETVALUE(RFAILED);
   }
#else
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = ysMsUtlGetPhyListElem(l1Size + sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      uart_printf("Memory allocation failed for PHY_INIT_LAA_REQ\n");
      RETVALUE(RFAILED);
   }
   cmMemset((U8 *)pElem, 0, (l1Size + sizeof(MAC2PHY_QUEUE_EL)));
   pElem->AlignOffset = l1Size; 
   pElem->Next = NULLP;
   pElem->NumMessageInBlock = 1;
#endif

#if 0
#else
   msCfgReq = (PPHY_INIT_LAA_REQ)(pElem + 1);
#endif
   cmMemset((U8 *)msCfgReq,(U8 )0,sizeof(PHY_INIT_LAA_REQ));
   ret = ysMsUtlFillLaaCfgReq(cellCb, msCfgReq);

#ifndef BATCH_PROCESSING_DL
#ifdef TL_ALLOC_ICC_MEM
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      uart_printf("Memory allocation failed for PHY_INIT_LAA_REQ\n");
      ysFreePhyMsg(pMsgDesc);
      RETVALUE(RFAILED);
   }
   phyMsgDescPtr = ysGetPhyPtr(pMsgDesc);
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe,
         phyMsgDescPtr, l1Size, INIT_LAA_REQ);
#else
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe, \
         NULLP, l1Size, INIT_LAA_REQ);
#endif
#ifdef TL_ALLOC_ICC_MEM
   YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
   if(cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg >= MAX_NUM_L1_MESSAGES_PER_TTI)
   {
      stop_printf("NumL1Msg %lu  greater than %d \n", 
            cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg, 
            MAX_NUM_L1_MESSAGES_PER_TTI);
   }  
#endif
   STKLOG(STK_MD_YS,STK_LOG_INFO,"Rishi:Sending INIT_LAA_REQ for id %d\n", cellCb->phyInstId);
   MSPD_DBG("Rishi:Sending INIT_LAA_REQ for id %d\n", cellCb->phyInstId);
   ysSendMsgToPhy(l1Size, pElem);

   RETVALUE(ret);
} /* ysMsSmStIdleEvtLaaCfg */

PRIVATE S16 ysMsUtlFillLaaScanReq
(
YsCellCb            *cellCb,
PPHY_LAA_SCAN_REQ   scanReq
)
{
   U32 idx = 0;
   scanReq->msgType = LAA_SCAN_REQ;
   scanReq->msgLength = sizeof(PHY_LAA_SCAN_REQ);
   scanReq->phyEntityId = cellCb->phyInstId;
   scanReq->nEarfcn = cellCb->lteUCfg.numFreq;
   
   for (idx = 0; idx < cellCb->lteUCfg.numFreq; idx++)
   {
      /* Have to check if sacn is per Unlicensed CELL or goes once for all Unlicensed cell */ 
      scanReq->freqParam[idx].txPowerLimit = cellCb->lteUCfg.txPowerLimit;
      scanReq->freqParam[idx].earfcn = cellCb->lteUCfg.earfcn[idx];
      STKLOG(STK_MD_YS,STK_LOG_INFO,"Filling SCAN REQ: phyEntityId %d nEarfcn %d TxPw %ld erfcn %ld\n", \
		      cellCb->phyInstId,  cellCb->lteUCfg.numFreq, cellCb->lteUCfg.txPowerLimit, cellCb->lteUCfg.earfcn[idx]);
      MSPD_DBG("Filling SCAN REQ: phyEntityId %d nEarfcn %d TxPw %ld erfcn %ld\n", \
		      cellCb->phyInstId,  cellCb->lteUCfg.numFreq, cellCb->lteUCfg.txPowerLimit, cellCb->lteUCfg.earfcn[idx]);
   }

   RETVALUE(ROK);
}

/*
*
*       Fun:    ysMsSmStIdleEvtScanReq 
*
*       Desc:   This function handles the YS_MS_EVENT_LAA_SCAN_REQ event in
*               state LYS_PHY_STATE_IDLE.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmStIdleEvtScanReq
(
YsCellCb   *cellCb,
Void   *status
)
{
#ifndef BATCH_PROCESSING_DL
   PMSGHEADER        pHdr;
   U32               *pMsg;
   PGENMSGDESC       phyMsgDescPtr;
   PGENMSGDESC       pMsgDesc;
#endif
   S16               ret;
   PPHY_INIT_LAA_IND       laaInitInd;
   U32               l1Size;
   PMAC2PHY_QUEUE_EL pElem;
   PPHY_LAA_SCAN_REQ msCfgReq;

   TRC3(ysMsSmStIdleEvtScanReq);

   laaInitInd = (PPHY_INIT_LAA_IND)status;
#if 0
#else
   l1Size = sizeof(PHY_LAA_SCAN_REQ);
#endif

   if(laaInitInd->status != SUCCESS)
   {
      /* TODO free the INITIND */
      YS_DBG_ERR((_ysp, "Laa Phy Init Failed. Error = %d\n", 
                         laaInitInd->status));
      YsUiCtfCfgCfm(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,
                     ysCb.ctfSap.transId, CTF_CFG_CFM_NOK);
      RETVALUE(RFAILED);
   }

#ifndef BATCH_PROCESSING_DL
 
#ifdef TL_ALLOC_ICC_MEM
   pMsgDesc = ysMsUtlGetPhyListElem(l1Size);
#else
   pMsgDesc = ysMsUtlGetPhyListElem();
#endif
   if(pMsgDesc == NULLP)
   {
      uart_printf("Memory allocation failed for PHY_LAA_SCAN_REQ\n");
      RETVALUE(RFAILED);
   }
#else
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = ysMsUtlGetPhyListElem(l1Size + sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      uart_printf("Memory allocation failed for PHY_LAA_SCAN_REQ\n");
      RETVALUE(RFAILED);
   }
   cmMemset((U8 *)pElem, 0, (l1Size + sizeof(MAC2PHY_QUEUE_EL)));
   pElem->AlignOffset = l1Size; 
   pElem->Next = NULLP;
   pElem->NumMessageInBlock = 1;

#endif
#if 0
#else
   msCfgReq = (PPHY_LAA_SCAN_REQ)(pElem + 1);
#endif
   cmMemset((U8 *)msCfgReq,(U8 )0,sizeof(PHY_LAA_SCAN_REQ));

   ret = ysMsUtlFillLaaScanReq(cellCb, msCfgReq);

#ifndef BATCH_PROCESSING_DL
#ifdef TL_ALLOC_ICC_MEM
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
      uart_printf("Memory allocation failed for PHY_LAA_SCAN_REQ\n");
      ysFreePhyMsg(pMsgDesc);
      RETVALUE(RFAILED);
   }
   phyMsgDescPtr = ysGetPhyPtr(pMsgDesc);
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe,
         phyMsgDescPtr, l1Size, LAA_SCAN_REQ);
#else
   YS_MS_FILL_PHY_LIST_ELEM(pElem, cellCb->timingInfo.sfn, \
         cellCb->timingInfo.subframe, \
         NULLP, l1Size, LAA_SCAN_REQ);
#endif
#ifdef TL_ALLOC_ICC_MEM
   YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
   if(cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg >= MAX_NUM_L1_MESSAGES_PER_TTI)
   {
      stop_printf("NumL1Msg %lu  greater than %d \n", 
            cellCb->dlEncL1Msgs[cellCb->timingInfo.subframe].numL1Msg, 
            MAX_NUM_L1_MESSAGES_PER_TTI);
   }  
#endif
   STKLOG(STK_MD_YS,STK_LOG_INFO,"Rishi:Sending LAA_SCAN_REQ for id %d\n", cellCb->phyInstId);
   MSPD_DBG("Rishi:Sending LAA_SCAN_REQ for id %d\n", cellCb->phyInstId);
   ysSendMsgToPhy(l1Size, pElem);

   RETVALUE(ret);
} /* ysMsSmStIdleEvtScanReq */

/*
*
*       Fun:    ysMsSmStIdleEvtScanInd
*
*       Desc:   This function handles the YS_MS_EVENT_LAA_SCAN_IND event in
*               state LYS_PHY_STATE_IDLE.
*
*       Ret:    ROK: if the event can be processed.
*               RFAILED               - FAILURE
*
*       Notes:  None
*
*       File:   ys_ms_cfg.c
*
*/

PRIVATE S16 ysMsSmStIdleEvtScanInd
(
YsCellCb   *cellCb,
Void   *status
)
{
   S16         ret = ROK;
   PPHY_LAA_SCAN_IND laaScanInd;
   PSTARTREQ   startReq;
   U32         l1Size;
   PGENMSGDESC pMsgDesc;
   /* PHY_API_CHANGE */
   PMAC2PHY_QUEUE_EL pElem;
   U8          i;
   CtfLaaScanInd *ctfLaaScanInd;
   static U8 count = 0;

   TRC3(ysMsSmStIdleEvtScanInd);
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   
   laaScanInd = (PPHY_LAA_SCAN_IND)status;

   if(SGetSBuf(ysCb.ysInit[indx].region,ysCb.ysInit[indx].pool,(Data **)&ctfLaaScanInd,
            sizeof(CtfLaaScanInd)) != ROK)                        
   {                                                                                          
      STKLOG(STK_MD_YS,STK_LOG_INFO,"Memory allocation failed \n");                                                  
      RETVALUE(RFAILED);
   }   
   
   ctfLaaScanInd->status = ROK;
   ctfLaaScanInd->nEarfcn = laaScanInd->nEarfcn;

   for (i = 0; i < laaScanInd->nEarfcn; i++)
   {
      ctfLaaScanInd->earfcn[i] = laaScanInd->freqParam[i].earfcn;
   }
    
   /* Send the LAA scan results to App */
   count++;
   
   EXTERN U8 wrSmDfltNumUnLicnsdCells;
   STKLOG(STK_MD_YS,STK_LOG_INFO,"Sending STATE REQ %d\n", wrSmDfltNumUnLicnsdCells);
   MSPD_DBG("Sending STATE REQ %d\n", wrSmDfltNumUnLicnsdCells);
   /*if (count == wrSmDfltNumUnLicnsdCells)*/ /* If all the unlicensed cell is configured */
   {
      YsCellCb *pCellCb = (YsCellCb*)ysMsGetCellCbFrmPhyInstId(0);
      if(pCellCb == NULLP)
      {
         YS_DBG_ERR((_ysp, "ysMsLimProcessMsg(): cellCb is NULL\n"));
         RETVALUE(RFAILED);
      }
      l1Size = sizeof(GENMSGDESC) + sizeof(STARTREQ);

#ifdef BATCH_PROCESSING_DL
      //printf("ysMsSmStIdleEvtCfgRsp:619: preparing Start Req of length %d\n", l1Size); 
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL) + l1Size);
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG */
         uart_printf("SvsrAllocMsg failed for PHY list element for \
               PHY_START_REQ at time(%d,%d)\n",
         pCellCb->timingInfo.sfn, pCellCb->timingInfo.subframe);
         RETVALUE(RFAILED);
      }
      pElem->NumMessageInBlock = 1; 
      pElem->AlignOffset = l1Size; 
      pMsgDesc = (PGENMSGDESC)(pElem + 1);
#else
      /* Allocate a message towards Phy using sysCore */
#ifdef TL_ALLOC_ICC_MEM
      pMsgDesc = ysMsUtlAllocSvsrMsg(FALSE, (sizeof(GENMSGDESC) + sizeof(STARTREQ)));
#else
      pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg(FALSE);
#endif
      if (pMsgDesc == NULLP)
      {
         YS_DBG_ERR((_ysp, "Unable to allocate memory for TxVector"));
         MSPD_ERR("Unable to allocate memory for TxVector");
         RETVALUE (RFAILED);
      }
#endif

      startReq = (PSTARTREQ)(pMsgDesc );

   /* Filling the band ID for automating the ADI ID */
      MSPD_DBG(" cellCb->cellCfg.antennaCfg.antPortsCnt %d\n", \
            pCellCb->cellCfg.antennaCfg.antPortsCnt);
      
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
      if(isPhyStopped != TRUE)
      {
         if (pCellCb->vendorParams.opMode == 4)
         {
            U8 retVal = 1;

            if (pCellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_2)
               retVal = Ad9361IRadioScheduleInit(pCellCb->cellInfo.bandId,2,2,0,0,0) & 0xFF;
            else if (pCellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_1)
               retVal = Ad9361IRadioScheduleInit(pCellCb->cellInfo.bandId,1,1,0,0,0) & 0xFF;

            if (retVal)
            {
               YS_DBG_ERR((_ysp, "ysMsSmStIdleEvtCfgRsp(): ADI comand Failed \n"));
               RETVALUE(RFAILED);
            }

         }
      }
#endif


#ifndef TENB_RTLIN_CHANGES
      if (pCellCb->vendorParams.opMode == 4)
      {
         U8 retVal = 1;

         if (pCellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_2)
            retVal = Ad9361IRadioScheduleInit(pCellCb->cellInfo.bandId,2,2,0,0,0) & 0xFF;
         else if (pCellCb->cellCfg.antennaCfg.antPortsCnt == CTF_AP_CNT_1)
            retVal = Ad9361IRadioScheduleInit(pCellCb->cellInfo.bandId,1,1,0,0,0) & 0xFF;

         if (retVal)
         {
            YS_DBG_ERR((_ysp, "ysMsSmStIdleEvtCfgRsp(): ADI comand Failed \n"));
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
            SvsrFreeMsg(pMsgDesc);/*FREE_SVSR_NEW*/
#else
            ysFreePhyMsg(pMsgDesc);
#endif
            RETVALUE(RFAILED);
         }
      }
#endif
      MSPD_DBG("Sendig ysMsUtlFillStartReq \n");
      ret = ysMsUtlFillStartReq(startReq, pCellCb);
      if (ret != ROK)
      {
         YS_DBG_ERR((_ysp, "ysMsSmStIdleEvtCfgRsp(): StartReq Failed \n"));
#ifdef BATCH_PROCESSING_DL
         ysFreePhyMsg(pElem);
#endif
         RETVALUE(RFAILED);
      }

#ifndef BATCH_PROCESSING_DL
      /* PHY_API_CHANGE : Fill the linked list element */
#ifdef TL_ALLOC_ICC_MEM
      pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG */
         uart_printf("SvsrAllocMsg failed for PHY list element for \
               PHY_START_REQ at time(%d,%d)\n",
         pCellCb->timingInfo.sfn, pCellCb->timingInfo.subframe);
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
         SvsrFreeMsg(pMsgDesc);/*FREE_SVSR*/
#else
         ysFreePhyMsg(pMsgDesc);
#endif
         RETVALUE(RFAILED);
      }
#ifdef TENB_RTLIN_CHANGES
      YS_MS_FILL_PHY_LIST_ELEM(pElem, pCellCb->timingInfo.sfn, pCellCb->timingInfo.subframe,
      	  ysGetPhyPtr(pMsgDesc), l1Size, PHY_START_REQ);
#else
      YS_MS_FILL_PHY_LIST_ELEM(pElem, pCellCb->timingInfo.sfn, pCellCb->timingInfo.subframe,
      	  pMsgDesc, l1Size, PHY_START_REQ);
#endif
#else
      YS_MS_FILL_PHY_LIST_ELEM(pElem, pCellCb->timingInfo.sfn, pCellCb->timingInfo.subframe,
      	  NULLP, l1Size, PHY_START_REQ);
#endif

      pCellCb->phyState = LYS_PHY_STATE_CFG;

#ifdef TL_ALLOC_ICC_MEM
      YS_ADD_PELEM_L1MSG_LIST(pCellCb->timingInfo.subframe, pCellCb, pElem);
      if(pCellCb->dlEncL1Msgs[pCellCb->timingInfo.subframe].numL1Msg >= MAX_NUM_L1_MESSAGES_PER_TTI)
      {
        stop_printf("NumL1Msg %lu  greater than %d \n", pCellCb->dlEncL1Msgs[pCellCb->timingInfo.subframe].numL1Msg, 
                                                       MAX_NUM_L1_MESSAGES_PER_TTI);
      }  
#endif
      MSPD_DBG("Sendig ysMsUtlFillStartReq out finally\n");
      STKLOG(STK_MD_YS,STK_LOG_INFO,"Rishi:Sending PHY_START_REQ for id %d\n", cellCb->phyInstId);
      RLOG1(L_ALWAYS, "PHY_START_REQ %d", cellCb->phyInstId);
      ysSendMsgToPhy(l1Size, pElem);
   }
   
   RETVALUE(ret);
} /* ysMsSmStIdleEvtScanInd */
#endif /* LTE_TDD */
#endif /* CA_PHY */

extern U32 enableLaaLBTSim;
/**
 * @brief API for handle cell configuration request from RRM
 *
 * @details
 *
 *     Function: ysMsCfgAddCellCfg
 *
 *     This API for handle cell configuration request from RRM
 *
 *  @param[in]
 *  @param[in]
 *  @return  S16
 *      -# ROK
 *      -# RFAILED
 **/
PUBLIC S16 ysMsCfgAddCellCfg
(
CtfCellCfgInfo *cellCfg,
YsCellCb  *cellCb
)
{
   S16       ret;
   U16       idx;
   YsTfuSapCb *sap;
   YsTfuSapCb *schTfuSap;
   YsTfuSapCb *macTfuSap;
   U16        offset;
   YsUeCb     ueCb;
   U16        indx = cellCfg->cellId - CM_START_CELL_ID;
   TRC2(ysMsCfgAddCellCfg)

   ret = ROK;

   if(cellCfg->physCellId >= YS_NUM_PHY_CELLS)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCfg->physCellId,
            "Invalid phyCellId: ysMsCfgAddCellCfg failed");
      RETVALUE(RFAILED);
   }

   if (cellCfg->cellId >= (CM_START_CELL_ID + CM_LTE_MAX_CELLS))
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCfg->cellId,
            "Invalid cellId: ysMsCfgAddCellCfg failed");
      RETVALUE(RFAILED);
   }

   schTfuSap = NULLP;
   macTfuSap = NULLP;
   for (idx = 0; idx < ysCb.genCfg.maxTfuSaps; idx++)
   {
      sap = *(ysCb.tfuSapLst + idx);

      if (sap != NULLP)
      {
         if((schTfuSap == NULLP) && (sap->tfuSapCfg.type == LYS_TFU_SCH_SAP))
         {
            if (sap->tfuSapCfg.spId == cellCfg->schSapId)
            {
               schTfuSap = sap;
            }
         }
         if((macTfuSap == NULLP) && (sap->tfuSapCfg.type == LYS_TFU_USR_SAP))
         {
            if (sap->tfuSapCfg.spId == cellCfg->macSapId)
            {
               macTfuSap = sap;
            }
         }
      }

      if ((schTfuSap != NULLP) &&(macTfuSap != NULLP))
         break;
   }

   if ((schTfuSap == NULLP) || (macTfuSap == NULLP))
   {
      
      MSPD_DBG("IP_DBG: Cell %d is not associated with schTfuSap or macTfuSap: ysMsCfgAddCellCfg failed\n",cellCfg->cellId);
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCfg->cellId,
            "Cell is not associated with schTfuSap: ysMsCfgAddCellCfg failed");
      RETVALUE(RFAILED);
   }

   cmMemcpy((U8 *)&cellCb->cellCfg, (U8 *)cellCfg, sizeof(CtfCellCfgInfo));
   cellCb->cellId = cellCfg->cellId;
   cellCb->phyInstId = cellPhyInstId++;
   RASSERT_COREDUMP(cellCb->phyInstId == cellCb->cellId - CM_START_CELL_ID);
   cellCb->prev_sf = 30;
   cellCb->prev_sfn = 1024;
   cellCb->stop_Req_sent = 0;
   cellCb->etmEnable  = FALSE;
#ifdef EMTC_ENABLE
   /* Hardcoded for testing EMTC */ 
	/*cellCb->cellInfo.catMenabled = cellCb->cellCfg.catMenabled;
   cellCb->cellInfo.mPdcchStart = cellCb->cellCfg.mPdcchStart;*/
	cellCb->cellInfo.catMenabled = 1;
   cellCb->cellInfo.mPdcchStart = 3;

   for(idx=0;idx < CTF_MAX_CE_LEVEL; idx++)
   {
     cellCb->ceLevelInfo[idx] = cellCfg->ceLevelInfo[idx];
   }

  // printf("In ysMsCfgAddCellCfg :: EMTC_ENABLE \n");
#endif

/* LTE_UNLICENSED */

#ifdef LTE_ADV
   cellCb->unLicnsdCell   = cellCfg->unLicnsdCfgPres;
  
#if 0 /* Laa_Hard_Coding to enable LAA for SCELL at CL */
   printf (" \n Before hard coding UNLICENSED CONFIG AT CL %d for cell %d --------- \n", cellCb->unLicnsdCell, cellCb->cellId);

   if (cellCb->cellId > CM_START_CELL_ID)
   {
      cellCb->unLicnsdCell = TRUE;
   }
#endif 
   STKLOG(STK_MD_YS,STK_LOG_INFO,"UNLICENSED CONFIG AT CL %d for cell %d --------- \n", cellCb->unLicnsdCell, cellCb->cellId);
   if (cellCb->unLicnsdCell == TRUE)
   {
      cellCb->lteUCfg = cellCfg->lteUCfg;

      wrSmDfltNumUnLicnsdCells = 0;
      enableLaaLBTSim = TRUE;
      /* LBT SIM INIT */
      lbtSimulatorInit();
//#ifdef CA_DBG
      STKLOG(STK_MD_YS,STK_LOG_INFO,"CFG: Cell %d PhyId %d ActThld %d AdaTx %d ccaMth %d coEx %d enThld %d LisPrd %d OnPrd %d scanTime %d TransPrd %d\n", \
            cellCfg->cellId, cellCb->phyInstId, cellCb->lteUCfg.activityTh, cellCb->lteUCfg.adaptiveTx, cellCb->lteUCfg.ccaMethod, \
            cellCb->lteUCfg.coExistMethod, cellCb->lteUCfg.energyTh, cellCb->lteUCfg.listenPrd, cellCb->lteUCfg.lteOnPeriod, \
            cellCb->lteUCfg.scanTimePrd, cellCb->lteUCfg.transPeriod);

      cellCb->unLicnsdCell = FALSE;
      STKLOG(STK_MD_YS,STK_LOG_INFO,"Setting LTE LAA PHY Cofig Forcefully false !!! \n");
//#endif
      MSPD_DBG("CFG: PhyId %d ActThld %d AdaTx %d ccaMth %d coEx %d enThld %d LisPrd %d OnPrd %d scanTime %d TransPrd %d\n", \
            cellCb->phyInstId, cellCb->lteUCfg.activityTh, cellCb->lteUCfg.adaptiveTx, cellCb->lteUCfg.ccaMethod, \
            cellCb->lteUCfg.coExistMethod, cellCb->lteUCfg.energyTh, cellCb->lteUCfg.listenPrd, cellCb->lteUCfg.lteOnPeriod, \
            cellCb->lteUCfg.scanTimePrd, cellCb->lteUCfg.transPeriod);

   }
#endif

   /* crude workaround for now
    * when we receive the first MSGT_RESPONSE from the PHY we treat it like the
    * PHY_STOP_CONF and call ysMsLimProcessMsg (all other MSGT_RESPONSE msgs
    * will not be passed to the LimProcessMsg) to go ahead in the state machine
    * successfully. There is a bug in the PHY, and it sends two MSGT_RESPONSE
    * messages, the first with success and the second with failure on receiving
    * the PHY_START_REQ msg. Fix will be done in the PHY and then this
    * workaround can be removed.
    */
   cellCb->firstCall = TRUE;

#ifdef TFU_TDD
   cellCb->ulDlCfgIdx =  cellCfg->tddSfCfg.sfAssignment;
#endif
   cellCb->phyState = LYS_PHY_STATE_IDLE;
   cellCb->gotRACH = 0;

   /* HARQ: Minor optimization to clean up the code */
   cellCb->cmnChScrInit = 3*cellCb->cellCfg.cellIdGrpId + 
      cellCb->cellCfg.physCellId;

#ifdef RG_SCH_DYNDLDELTA 
   /* Updating rgu dynamic delta related variables */
   cellCb->numDlActUes    = 0;
   cellCb->dlDeltaChgEnb  = YS_DYN_DELTA_CHG_ENB;
   cellCb->dlDeltaDownCnt = 0;
   cellCb->dlDeltaUpCnt   = 0;
   //cellCb->curDlDelta     = TFU_DLDATA_DLDELTA;
   cellCb->curDlDelta     = 1; 
   cellCb->deltaChangeCnt = 0;
   cellCb->cellCfg.numDlUePerTti = cellCfg->numDlUePerTti;
#endif
#ifdef LTEMAC_SPS
   offset = (U16)((PTR)&ueCb.ueSpsHlEnt - (PTR)&ueCb);
   ret = cmHashListInit(&(cellCb->spsRntiHLst),      /* hash list Cp */
            (U16)ysCb.genCfg.nmbUe,             /* HL bins */
            offset,                             /* Offset of HL Entry */
            FALSE,                              /* Allow dup. keys ? */
            CM_HASH_KEYTYPE_DEF,                /* HL key type */
            ysCb.ysInit[indx].region,                 /* Mem region for HL */
            ysCb.ysInit[indx].pool);                  /* Mem pool for HL */
   if(ret != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId, "ueSps hash list init failed ");
      ysUtlDeAlloc((Data *)cellCb, sizeof(YsCellCb), indx);
      RETVALUE(RFAILED);
   }


#endif

   if (ysMsUlmPrcCellCfg(cellCb) != ROK)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,cellCb->cellId,"Failed in processing cell cfg");
#ifdef LTEMAC_SPS
      cmHashListDeinit(&cellCb->spsRntiHLst);
#endif
      ysUtlDeAlloc((Data *)cellCb, sizeof(YsCellCb), indx);
      RETVALUE(RFAILED);
   }

#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   PMAC2PHY_QUEUE_EL pElem;
#ifdef BATCH_PROCESSING_DL
   U32 rxVecSize = sizeof(GENMSGDESC) + sizeof(ULSUBFRDESC) + sizeof(MAC2PHY_QUEUE_EL);
#else
   U32 rxVecSize = sizeof(GENMSGDESC) + sizeof(ULSUBFRDESC);
#endif
   U32 txVecSize = sizeof(GENMSGDESC) + sizeof(DLSUBFRDESC) + sizeof(MAC2PHY_QUEUE_EL);
   U32 hDciVecSize = sizeof(MAC2PHY_QUEUE_EL) + sizeof(HIADCIULMSGDESC);
   U8 loopCnt = 0;

   while(loopCnt < YS_NUM_SUB_FRAMES )
   {
      pElem = NULLP;
      pElem = ysMsUtlGetPhyListElem(txVecSize);
      if(pElem == NULLP)
      {
         RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
         break;
      }
      cellCb->dlEncL1Msgs[loopCnt].txVector = pElem;
      cellCb->dlEncL1Msgs[loopCnt].addTxVecToLst = FALSE;

      pElem = NULLP;

      pElem = ysMsUtlGetPhyListElem(hDciVecSize);
      if(pElem == NULLP)
      {
         RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
         break;
      }
      cellCb->dlEncL1Msgs[loopCnt].pDci0HiVector = pElem;

      pElem = NULLP;
      pElem = ysMsUtlGetPhyListElem(rxVecSize);
      if(pElem == NULLP)
      {
         RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
         break;
      }
      cellCb->ulEncL1Msgs[loopCnt].rxVector = pElem; 
      cellCb->ulEncL1Msgs[loopCnt].addRxVecToLst = FALSE; 
      {
         U16 indx = 0;
         while(indx < MAX_NUM_L1_MESSAGES_PER_TTI)
         {  
            cellCb->dlEncL1Msgs[loopCnt].l1Msg[indx] = NULLP;
            indx++;
         }
      }
      cellCb->dlEncL1Msgs[loopCnt].numL1Msg = 0;

      loopCnt++;
   }
#endif
   cellCb->schTfuSap = schTfuSap;
   cellCb->macTfuSap = macTfuSap;

   /* HARQ: Initializing the time here */
   cellCb->timingInfo.hfn = 1023;
   cellCb->timingInfo.sfn = 1023;
   cellCb->timingInfo.subframe = 9;
#ifdef RG_ULSCHED_AT_CRC
   cellCb->crcSent[9] = 1;
#endif

   macTfuSap->cellCb = cellCb;
   schTfuSap->cellCb = cellCb;

   cellCb->cellId = cellCfg->cellId;
   ysCb.cellCfgLst[cellCb->cellId - CM_START_CELL_ID] = cellCb;

   ysCb.numOfCells++;

   if((cellCb = ysMsCfgGetCellCfg(cellCfg->cellId)) != NULLP)
   {
           uart_printf ("\n in ysMsCfgAddCellCfg still able to get cellId =%d \n", cellCfg->cellId);
   }

   ret = ysMsCfgSm(cellCb, YS_MS_EVENT_CFG, NULLP);
   if(ret != ROK)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,cellCb->cellId,"configuration sm failed ");
#ifdef LTEMAC_SPS
      cmHashListDeinit(&cellCb->spsRntiHLst);
#endif
      ysUtlDeAlloc((Data *)cellCb, sizeof(YsCellCb), indx);
      RETVALUE(RFAILED);
   }

#ifdef TENB_T2K3K_SPECIFIC_CHANGES
#ifdef TENB_AS_SECURITY
   cmMemset((U8*)&pdcpPst,0x00,sizeof(Pst));
#ifdef L2_L3_SPLIT
   pdcpPst.srcProcId = SFndProcId();
   pdcpPst.dstProcId = SFndProcId();
#endif

   pdcpPst.dstEnt = ENTPJ;
   pdcpPst.srcEnt = ENTYS;
   pdcpPst.dstInst= 1; /*Currently posting to DL instance only*/
   pdcpPst.event = 0x49;	/* EVTPJUTTIIND */
#endif
#if (defined(TENB_AS_SECURITY) && defined(UL_DL_SPLIT))
   cmMemset((U8*)&ulPdcpPst,0x00,sizeof(Pst));
   ulPdcpPst.srcProcId = SFndProcId();
   ulPdcpPst.dstProcId = SFndProcId();

   ulPdcpPst.dstEnt = ENTPJ;
   ulPdcpPst.srcEnt = ENTYS;
   ulPdcpPst.dstInst= 0;    /* Posting TICKS to PDCP UL instance*/
   ulPdcpPst.event = 0x49;
#endif
#if defined(L2_L3_SPLIT) || defined(MAC_RLC_UL_RBUF) 
   cmMemset((U8*)&rlcUlPst,0x00,sizeof(Pst));
#ifdef L2_L3_SPLIT
   rlcUlPst.srcProcId = SFndProcId();
   rlcUlPst.dstProcId = SFndProcId();
#else
   rlcUlPst.srcProcId = SFndProcId();
   rlcUlPst.dstProcId = SFndProcId();
#endif
   rlcUlPst.dstEnt = ENTKW;
   rlcUlPst.srcEnt = ENTYS;
#ifdef MAC_RLC_UL_RBUF
#ifdef RGL_SPECIFIC_CHANGES /* added to make compilation pass */
   rlcUlPst.dstInst= 0;
#else
  //Pavana making this change of commenting KW_RLC_UL_MASTER_INSTANCE and initializing to 0
   rlcUlPst.dstInst= 0;
   //rlcUlPst.dstInst= KW_RLC_UL_MASTER_INSTANCE;
#endif
#else   
   rlcUlPst.dstInst= 0;
#endif
   rlcUlPst.event = KWU_EVT_TTI_IND;
#endif
#ifdef SPLIT_RLC_DL_TASK
 cmMemset((U8*)&rlcDlPst,0x00,sizeof(Pst));
#ifdef L2_L3_SPLIT
   rlcDlPst.srcProcId = SFndProcId();
   rlcDlPst.dstProcId = SFndProcId();
#else
   rlcDlPst.srcProcId = SFndProcId();
   rlcDlPst.dstProcId = SFndProcId();
#endif
   rlcDlPst.dstInst= 1;/* DL RLC */
   rlcDlPst.dstEnt = ENTKW;
   rlcDlPst.srcEnt = ENTYS;
   rlcDlPst.event = KWU_EVT_TTI_IND;
#endif 
#endif

   /*Initialize the information maintainted per SF for RRC
    * messages simulation */
#ifdef YS_UL_RRC_CONN_SIMUL
   cmMemset(cellCb->rrcMsgSimlCb.msgInfoSf, 0,
         sizeof(cellCb->rrcMsgSimlCb.msgInfoSf));
#endif

#ifdef YS_ALL_PERF
   cellCb->ttiIndex      = 0;
   cellCb->capPerfData = TRUE;
#endif

   cellCb->cellRecfgInitiated = FALSE;
   RETVALUE(ret);
}  /* ysMsCfgAddCellCfg*/

/*Start Fix for ccpu00123185 */
/**
 * @brief API for handle Tx Power Control request from eNB App
 *
 * @details
 *
 *     Function: ysMsCfgModTxPwrCfg
 *
 *     This API for handle Tx Power configuration request from eNB App
 *
 *  @param[in]
 *  @param[in]
 *  @return  S16
 *      -# ROK
 *      -# RFAILED
 **/
PUBLIC S16 ysMsCfgModTxPwrCfg
(
CtfCellRecfgInfo  *cellRecfg
)
{
   S16       ret;
   YsCellCb  *cellCb;

   TRC2(ysMsCfgModTxPwrCfg)

   ret = ROK;
   cellCb = NULLP;

   if(cellRecfg->cellId >= (CM_START_CELL_ID + CM_LTE_MAX_CELLS))
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellRecfg->cellId,
            "Invalid cellId: ysMsCfgModCellCfg failed");
      RETVALUE(RFAILED);
   }

   if((cellCb = ysMsCfgGetCellCfg(cellRecfg->cellId)) == NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellRecfg->cellId, "Cell Configuration doesn't exist ");
      RETVALUE(RFAILED);
   }

   cellCb->cellCfg.pdschCfg.refSigPwr  = cellRecfg->pdschCfg.refSigPwr;
   cellCb->cellCfg.pilotSigPwr         = cellRecfg->pilotSigPwr * YS_MS_DB_UNIT;
   cellCb->cellCfg.priSigPwr           = cellRecfg->priSigPwr   * YS_MS_DB_UNIT;
   cellCb->cellCfg.secSigPwr           = cellRecfg->secSigPwr   * YS_MS_DB_UNIT;

   RETVALUE(ret);
}  /* ysMsCfgModTxPwrCfg*/
   /*End of Fix for ccpu00123185 */

/**
 * @brief API for handle cell configuration request from RRM
 *
 * @details
 *
 *     Function: ysMsCfgModCellCfg
 *
 *     This API for handle modify cell configuration request from RRM
 *
 *  @param[in]
 *  @param[in]
 *  @return  S16
 *      -# ROK
 *      -# RFAILED
 **/
PUBLIC S16 ysMsCfgModCellCfg
(
CtfCellRecfgInfo  *cellRecfg
)
{
   S16       ret;
   YsCellCb  *cellCb;

   TRC2(ysMsCfgModCellCfg)

   ret = ROK;
   cellCb = NULLP;

   if(cellRecfg->cellId >= (CM_START_CELL_ID + CM_LTE_MAX_CELLS))
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellRecfg->cellId,
            "Invalid cellId: ysMsCfgModCellCfg failed");
      RETVALUE(RFAILED);
   }

   if((cellCb = ysMsCfgGetCellCfg(cellRecfg->cellId)) == NULLP)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,cellRecfg->cellId,"Cell Configuration doesn't exist ");
      RETVALUE(RFAILED);
   }

   cmMemcpy((U8 *)&cellCb->cellCfg.prachCfg, (U8 *)&cellRecfg->prachCfg,
                                          sizeof(CtfPrachCfgInfo));
   cmMemcpy((U8 *)&cellCb->cellCfg.pdschCfg, (U8 *)&cellRecfg->pdschCfg,
                                          sizeof(CtfPdschCfgInfo));
   cmMemcpy((U8 *)&cellCb->cellCfg.puschCfg, (U8 *)&cellRecfg->puschCfg,
                                          sizeof(CtfPuschCfgInfo));
   cmMemcpy((U8 *)&cellCb->cellCfg.phichCfg, (U8 *)&cellRecfg->phichCfg,
                                          sizeof(CtfPhichCfgInfo));
   cmMemcpy((U8 *)&cellCb->cellCfg.pucchCfg, (U8 *)&cellRecfg->pucchCfg,
                                          sizeof(CtfPucchCfgInfo));
   cmMemcpy((U8 *)&cellCb->cellCfg.srsUlCfg, (U8 *)&cellRecfg->srsUlCfg,
                                          sizeof(CtfSrsUlCfgInfo));

   if (ysMsUlmPrcCellRecfg(cellCb) != ROK)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,cellRecfg->cellId,"Failed in processing cell Recfg");
      RETVALUE(RFAILED);
   }
/* PCI Mod change start */
   cellCb->cellCfg.cellIdGrpId = cellRecfg->cellIdGrpId;
   cellCb->cellCfg.physCellIdPres  =  cellRecfg->physCellIdPres;
   cellCb->cellCfg.physCellId      =  cellRecfg->physCellId;

   cellCb->cellCfg.syncSigPowOs          =  cellRecfg->syncSigPowOs ;
   cellCb->cellCfg.syncSigPowOsPres      = cellRecfg->syncSigPowOsPres ;
   cellCb->cellCfg.cfiPowOs              = cellRecfg->cfiPowOs ;
   cellCb->cellCfg.cfiPowOsPres          = cellRecfg->cfiPowOsPres ; 
   cellCb->cellCfg.dciPowOs              = cellRecfg->dciPowOs ;
   cellCb->cellCfg.dciPowOsPres          = cellRecfg->dciPowOsPres ;
   cellCb->cellCfg.extWinMargin          = cellRecfg->extWinMargin ;
   cellCb->cellCfg.extWinMarginPres      = cellRecfg->extWinMarginPres ;
   cellCb->cellCfg.pucchNoiseGamma       = cellRecfg->pucchNoiseGamma ;
   cellCb->cellCfg.pucchNoiseGammaPres   = cellRecfg->pucchNoiseGammaPres ;
   cellCb->cellCfg.prachPkRatio4         = cellRecfg->prachPkRatio4 ;
   cellCb->cellCfg.prachPkRatio0Pres     = cellRecfg->prachPkRatio0Pres ;
   cellCb->cellCfg.prachPkRatio0         = cellRecfg->prachPkRatio0 ;
   cellCb->cellCfg.prachPkRatio0Pres     = cellRecfg->prachPkRatio0Pres ;
   cellCb->cellCfg.srsDopEstFactor       = cellRecfg->srsDopEstFactor ;
   cellCb->cellCfg.srsDopEstFactorPres   = cellRecfg->srsDopEstFactorPres ;
   cellCb->cellCfg.puschProbDtxAck       = cellRecfg->puschProbDtxAck ;
   cellCb->cellCfg.puschProbDtxAckPres   = cellRecfg->puschProbDtxAckPres ;
   cellCb->cellCfg.pucchProbDtxAck       = cellRecfg->pucchProbDtxAck ;
   cellCb->cellCfg.pucchProbDtxAckPres   = cellRecfg->pucchProbDtxAckPres ;


   cellCb->cellCfg.txAntennaPorts        = cellRecfg->txAntennaPorts ;
   cellCb->cellCfg.txAntennaPortsPres   = cellRecfg->txAntennaPortsPres ;
   cellCb->cellCfg.rxAntennaPorts       = cellRecfg->rxAntennaPorts ;
   cellCb->cellCfg.rxAntennaPortsPres   = cellRecfg->rxAntennaPortsPres ;
   cellCb->cellCfg.phySyncMode          = cellRecfg->phySyncMode ;
   cellCb->cellCfg.phySyncModePres   = cellRecfg->phySyncModePres ;
   cellCb->cellCfg.dataRepMode       = cellRecfg->dataRepMode ;
   cellCb->cellCfg.dataRepModePres   = cellRecfg->dataRepModePres ;
   cellCb->cellCfg.rachSrRepMode       = cellRecfg->rachSrRepMode ;
   cellCb->cellCfg.rachSrRepModePres   = cellRecfg->rachSrRepModePres ;
   cellCb->cellCfg.pilotSigPwr = cellRecfg->pilotSigPwr * YS_MS_DB_UNIT;
   cellCb->cellCfg.priSigPwr = cellRecfg->priSigPwr * YS_MS_DB_UNIT;
   cellCb->cellCfg.secSigPwr = cellRecfg->secSigPwr * YS_MS_DB_UNIT;
   /*cellCb->cellCfg.ctfCellStatus = cellRecfg->ctfCellStatus;*/
   /* PCI Mod change end*/
   /* Uptill 3.8.2.8 TDD PHY. PHY_RECFG is not supported
    * We have to stop and shutdown phy , and then 
    * need to send the INIT msg */
   cellCb->cellRecfgInitiated = TRUE;
   /* triggering stop req procedure */
   /* At the end of stop procedure, phyState
    * will change to IDLE. CFG event in IDLE
    * state will trigger INIT req and the start
    * req which will start phy */
   ret = ysMsCfgSm(cellCb, YS_MS_EVENT_STOP, NULLP);

   RETVALUE(ret);
}  /* ysMsCfgModCellCfg*/

/**
 * @brief API for delete cell configuration
 *
 * @details
 *
 *     Function: ysMsCfgDelCellCfg
 *
 *     This API for handle delete cell configuration request from RRM
 *
 *  @param[in]
 *  @param[in]
 *  @return  S16
 *      -# ROK
 *      -# RFAILED
 **/
PUBLIC S16 ysMsCfgDelCellCfg
(
CmLteCellId    cellId
)
{
   S16       ret;
   YsCellCb  *cellCb;
   YsUeCb    *pUeCb;
   YsUeCb    *nUeCb;
#ifdef LTE_ADV
   U8         idx;
#endif

   TRC2(ysMsCfgDelCellCfg)

   ret    = ROK;
   cellCb = NULLP;
   pUeCb   = NULLP;
   nUeCb   = NULLP;
   U16 indx = cellId - CM_START_CELL_ID;
   
   if((cellCb = ysMsCfgGetCellCfg(cellId)) == NULLP)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,cellId,"Cell Configuration doesnt exist ");
      RETVALUE(RFAILED);
   }

   ret = cmHashListGetNext(&ysCb.ueHLst[indx], (PTR)pUeCb, (PTR *)&nUeCb);
   for (;;)
   {
      if (ret != ROK)
      {
         break;
      }
      else
      {  
         pUeCb = nUeCb;
         ret = cmHashListGetNext(&ysCb.ueHLst[indx], (PTR)pUeCb, (PTR *)&nUeCb);
         if (pUeCb->cellCb == cellCb)
         {
            /*If cell is primary , delete the UE*/
            ysMsCfgDeAllocUeCb(cellCb, pUeCb);
         }
#ifdef LTE_ADV         
         else
         {
            /*If cell is secondary, set the cell context to NULLP */
            for (idx = 0; idx < CM_LTE_MAX_CELLS; idx++)
            {
               if (pUeCb->sCellCb[idx] == cellCb)
               {
                  pUeCb->noOfCfgSCells--;
                  pUeCb->sCellCb[idx] = NULLP;
               }
            }
         }
#endif         
      }
   }

#ifdef LTEMAC_SPS
   cmHashListDeinit(&cellCb->spsRntiHLst);
#endif

   if (cellCb->schTfuSap != NULLP)
   {
      cellCb->schTfuSap->cellCb = NULLP;
   }
   if (cellCb->macTfuSap != NULLP)
   {
      cellCb->macTfuSap->cellCb = NULLP;
   }

   if (ysMsUlmPrcDelCellCfg(cellCb) != ROK)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,cellCb->cellId,"Failed in process delete cell cfg ");
      RETVALUE(RFAILED);
   }

   ret = ysMsCfgSm(cellCb, YS_MS_EVENT_STOP, NULLP);

   ysCb.cellCfgLst[cellCb->cellId - CM_START_CELL_ID] = NULLP;
   ysUtlDeAlloc((Data *) (cellCb), sizeof(YsCellCb), indx);

   RETVALUE(ret);
}  /* ysMsCfgDelCellCfg*/

/**
 * @brief API for handle UE configuration request from RRM
 *
 * @details
 *
 *     Function: ysMsCfgAddUeCfg
 *
 *     This API for handle UE configuration request from RRM
 *
 *  @param[in]
 *  @param[in]
 *  @return  S16
 *      -# ROK
 *      -# RFAILED
 **/
PUBLIC S16 ysMsCfgAddUeCfg
(
CtfDedCfgInfo  *dedCfg
)
{
   S16       ret;
   YsCellCb  *cellCb;
   YsUeCb    *ueCb;

   TRC2(ysMsCfgAddUeCfg)

   ret = ROK;
   cellCb = NULLP;

   if(dedCfg->cellId >= (CM_START_CELL_ID + CM_LTE_MAX_CELLS))
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,dedCfg->cellId,
            "Invalid cellId: ysMsCfgAddUeCfg failed");
      RETVALUE(RFAILED);
   }

   if((cellCb = ysMsCfgGetCellCfg(dedCfg->cellId)) == NULLP)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,dedCfg->cellId,"Cell Configuration doesn't exist");
      RETVALUE(RFAILED);
   }
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   if ((ueCb = (YsUeCb *)ysUtlMalloc(sizeof(YsUeCb), indx)) == NULLP)
   {
      RLOG_ARG0(L_ERROR, DBG_CELLID,dedCfg->cellId,"ysUtlMalloc failed for ueCb");
      MSPD_ERR("ysUtlMalloc failed in ysMsCfgAddUeCfg\n");
      RETVALUE(RFAILED);
   }
   
   cmMemcpy((U8 *)&ueCb->ueCfg, (U8 *)dedCfg, sizeof(CtfDedCfgInfo));

   ueCb->ueId = dedCfg->ueId;
   ueCb->cellCb = cellCb;
#ifndef YS_MS_NO_TA
   ueCb->tarptInfo.lnk.node = (PTR)NULL;
   ueCb->tarptInfo.ta = 100; /* initialised with invalid value */
#endif

   if(cmHashListInsert (&(ysCb.ueHLst[indx]), (PTR)ueCb,
         (U8 *)&ueCb->ueId, sizeof(CmLteRnti)) != ROK)
   {
      RLOG_ARG0(L_ERROR,DBG_CRNTI,ueCb->ueId, "HashList Insert returned failed ");
      MSPD_ERR("cmHashListInsert returned failed \n");
      ysUtlDeAlloc((Data *)ueCb, sizeof(YsUeCb), indx);
      RETVALUE(RFAILED);
   }

#ifndef TFU_UPGRADE
   if(ysMsUlmPrcUeCfg(cellCb, ueCb) != ROK)
   {
      RLOG_ARG0(L_ERROR, DBG_CRNTI,ueCb->ueId,"Process UeCfg returned failed ");
      MSPD_ERR("ysMsUlmPrcUeCfg returned failed \n");
      /* Delete from UE list */
      cmHashListDelete (&(ysCb.ueHLst[indx]), (PTR)ueCb);
      ysUtlDeAlloc((Data *)ueCb, sizeof(YsUeCb), indx);
      RETVALUE(RFAILED);
   }
#endif /* TFU_UPGRADE */

#ifdef EMTC_ENABLE
   ueCb->isEmtcUe = dedCfg->isEmtcUe; 
#endif
   RETVALUE(ret);
}  /* ysMsCfgAddUeCfg*/

/**
 * @brief API for handle UE configuration request from RRM
 *
 * @details
 *
 *     Function: ysMsCfgModUeCfg
 *
 *     This API for handle UE configuration request from RRM
 *
 *  @param[in]
 *  @param[in]
 *  @return  S16
 *      -# ROK
 *      -# RFAILED
 **/
PUBLIC S16 ysMsCfgModUeCfg
(
CtfDedRecfgInfo   *dedRecfg
)
{
   S16       ret;
   YsCellCb  *cellCb;
   YsUeCb    *ueCb;
#ifdef LTE_ADV 
   U16 idx=0; 
#endif
   TRC2(ysMsCfgModUeCfg)

   ret = ROK;
   cellCb = NULLP;
   ueCb = NULLP;

   if(dedRecfg->cellId >= (CM_START_CELL_ID + CM_LTE_MAX_CELLS))
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,dedRecfg->cellId,
            "Invalid cellId: ysMsCfgModUeCfg failed");
      RETVALUE(RFAILED);
   }

   if((cellCb = ysMsCfgGetCellCfg(dedRecfg->cellId)) == NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,dedRecfg->cellId, "Cell Configuration doesn't exist ");
      RETVALUE(RFAILED);
   }
   
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   ueCb = ysMsCfgGetUe(cellCb, dedRecfg->ueId);
   /* MSPD ReEst Fix Start*/
   if(ueCb == NULLP)
   {
      RLOG1(L_WARNING,"[%d]UeCB not Found",dedRecfg->ueId);
      RETVALUE(RFAILED);
   }
   if (dedRecfg->ueId != dedRecfg->newUeId)
   {

      if(cmHashListDelete (&(ysCb.ueHLst[indx]), (PTR)ueCb) != ROK)
      {
         RLOG_ARG1(L_ERROR,DBG_CRNTI,dedRecfg->ueId, "deleting UE(%d) from hash List failed", dedRecfg->ueId);
         
         MSPD_ERR("UE Not Found in List\n");
         RETVALUE(RFAILED);
      }
      
      /*PCell_reest: We need not to reset the Scell pointers. Only UeId change
       *is required
       */
      ueCb->ueId= dedRecfg->newUeId;
      if(cmHashListInsert(&(ysCb.ueHLst[indx]), (PTR)ueCb,
               (U8 *)&ueCb->ueId, sizeof(CmLteRnti)) != ROK)
      {
         RLOG_ARG1(L_ERROR, DBG_CRNTI,ueCb->ueId,"Inserting newUE (%d) in has List failed",dedRecfg->newUeId);
         MSPD_ERR("UE Not Found in List\n");
         RETVALUE(RFAILED);
      }
      RETVALUE(ROK);
   }
   /* MSPD ReEst Fix End*/


   if (ueCb != NULLP)
   {
#ifndef TFU_UPGRADE
      ysMsUlmPrcDelUeCfg(cellCb, ueCb);

      cmMemcpy((U8 *)&ueCb->ueCfg.pdschCfg, (U8 *)&dedRecfg->pdschCfg,
                                             sizeof(CtfDedPdschCfgInfo));
      cmMemcpy((U8 *)&ueCb->ueCfg.pucchCfg, (U8 *)&dedRecfg->pucchCfg,
                                             sizeof(CtfDedPucchCfgInfo));
      cmMemcpy((U8 *)&ueCb->ueCfg.puschCfg, (U8 *)&dedRecfg->puschCfg,
                                             sizeof(CtfDedPuschCfgInfo));
      cmMemcpy((U8 *)&ueCb->ueCfg.srsUlCfg, (U8 *)&dedRecfg->srsUlCfg,
                                             sizeof(CtfDedSrsUlCfgInfo));
      cmMemcpy((U8 *)&ueCb->ueCfg.dedSRCfg, (U8 *)&dedRecfg->dedSRCfg,
                                             sizeof(CtfDedSRCfgInfo));

      if(ysMsUlmPrcUeCfg(cellCb, ueCb) != ROK)
      {
         RLOG_ARG0(L_ERROR, DBG_CRNTI,ueCb->ueId,"Processing UeCfg returned failed ");
      }
#endif /* TFU_UPGRADE */
      
#ifdef LTE_ADV
      /* Adding validation for SCell reconfig. If validation failes then don't
       * add/configure any SCell, Do validation only if SCell config is
       * present*/
       if(dedRecfg->sCellInfo.numSCells)
       {
         RLOG_ARG1(L_INFO, DBG_UEID, dedRecfg->ueId, "Addition trigger numScells =%d\n", dedRecfg->sCellInfo.numSCells);
         if(ysMsCfgVldtUeSCellReCfg(dedRecfg, ueCb) != ROK)
         {
            YS_DBG_ERR((_ysp, "SCell reconfiguration has been failed. Don't"
                     "add/configure any SCell. Return falure\n"));
            RETVALUE(RFAILED);
         }
         /* All validations added in func ysMsCfgVldtUeSCellReCfg. If we are here
            means validation is passed hence just add/configure all Scells*/
      
         for (idx=0; idx < dedRecfg->sCellInfo.numSCells; idx++)
         {
            cellCb = ysMsCfgGetCellCfg(dedRecfg->sCellInfo.ueSCellDedCfg[idx].sCellId);
            ueCb->sCellCb[dedRecfg->sCellInfo.ueSCellDedCfg[idx].sCellIdx] = cellCb;
            ueCb->noOfCfgSCells++;
         }
          
         RLOG_ARG1(L_INFO, DBG_UEID, dedRecfg->ueId, "SCell reconfiguration has been successful "
                        "in add/configure any SCell ueCb->noOfCfgSCells =%d \n", ueCb->noOfCfgSCells);
         YS_DBG_INFO((_ysp, "SCell reconfiguration has been successful "
                      "in add/configure any SCell. \n"));
         RETVALUE(ROK);
      }
#endif
      /* ccpu00129384: Re-Configure CTF with UE Category */
      if (dedRecfg->ueCatCfg.pres)
      {
         ueCb->ueCfg.ueCatCfg.ueCategory = dedRecfg->ueCatCfg.ueCategory;
      }
   }
   else
   {
      RLOG_ARG1(L_ERROR,DBG_CELLID,dedRecfg->cellId, "UE (%d) doesnt exist in cell Failed ",dedRecfg->ueId);
      MSPD_ERR("UE (%d) doesnt exist in cell (%d). "
               "Failed \n", dedRecfg->ueId, dedRecfg->cellId);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);
}  /* ysMsCfgModUeCfg*/

#ifdef LTE_ADV
/**
 * @brief API for validating the UE SCell Reconfiguration
 *
 * @details
 *
 *     Function: ysMsCfgVldtUeSCellReCfg
 *
 *     This function validates followings:
 *      1) Number of SCell range 
 *      2) Serving cell indx range
 *      3) Checking if Scell is already added/present for any index
 *      4) Checking if serving cell is present for all the serving cell
 *         index the in hashlist
 *     Notes:
 *       If any of the condition failes then this function returns failure
 *       else success. Incase of failure no Scell will be added
 *
 *  @param[in] CtfDedRecfgInfo   *dedRecfg
 *  @return  S16
 *      -# ROK
 *      -# RFAILED
 **/
PUBLIC S16 ysMsCfgVldtUeSCellReCfg
(
CtfDedRecfgInfo   *dedRecfg,
YsUeCb            *ueCb
)
{
   CtfUeSecCellCfgInfo   *ueSCellDedCfg = NULLP;
   YsCellCb               *cellCb = NULLP;
   U8                     idx;
   S16                    ret = ROK;

   /* Checking num of Scells present in the scell reconfig*/
   if(dedRecfg->sCellInfo.numSCells > CTF_MAX_SCELL_PER_UE ||
         dedRecfg->sCellInfo.numSCells < 1)
   {
      YS_DBG_ERR((_ysp, "Invalid number of SCELL in SCell ReConfiguration\n"));
      RETVALUE(RFAILED);
   }
   
   for (idx=0; idx < dedRecfg->sCellInfo.numSCells; idx++)
   {
      ueSCellDedCfg = &dedRecfg->sCellInfo.ueSCellDedCfg[idx];
      
      /* validate the range of serv cell index */
      if(ueSCellDedCfg->sCellIdx < 1 || ueSCellDedCfg->sCellIdx > \
            CTF_MAX_SCELL_PER_UE)
      {
         YS_DBG_ERR((_ysp, "Invalid serving cell Idx %d",
                  ueSCellDedCfg->sCellIdx));
         ret = RFAILED;
         break;
      }

      /* Checking if Scell is already added for any of the Scell if yes then
       *return failure*/
      if (NULLP != ueCb->sCellCb[ueSCellDedCfg->sCellIdx])
      {
         YS_DBG_ERR((_ysp, "UE (%d) already has this sCellIdx (%d). Return"
                  "failure\n", dedRecfg->ueId, ueSCellDedCfg->sCellIdx));
         ret = RFAILED;
         break;
      }
      
      /* Checking if CellCb is present for SCellId recvd in Scell ReCfg*/
      if (NULLP == (cellCb = ysMsCfgGetCellCfg(ueSCellDedCfg->sCellId)))
      {
         YS_DBG_ERR((_ysp, "SCell doesn't exist for cell (%d). \
                  ysMsCfgModUeCfg Failed \n", ueSCellDedCfg->sCellId));
         ret = RFAILED;
         break;
      }
   } /* End of the for loop*/

   RETVALUE(ret);

}/* ysMsCfgVldtUeSCellReCfg */
#endif /* LTE_ADV*/

/**
 * @brief API for handle UE configuration request from RRM
 *
 * @details
 *
 *     Function: ysMsCfgDelUeCfg
 *
 *     This API for handle UE configuration request from RRM
 *
 *  @param[in]
 *  @param[in]
 *  @return  S16
 *      -# ROK
 *      -# RFAILED
 **/
PUBLIC S16 ysMsCfgDelUeCfg
(
CtfDedReleaseInfo   *dedRel
)
{
   S16       ret;
   YsCellCb  *cellCb;
   YsUeCb    *ueCb;
#ifdef LTE_ADV
   U16 idx = 0;
#endif

   TRC2(ysMsCfgDelUeCfg)

   ret = ROK;
   cellCb = NULLP;

   if(dedRel->cellId >= (CM_START_CELL_ID + CM_LTE_MAX_CELLS))
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,dedRel->cellId,
            "Invalid cellId: ysMsCfgDelUeCfg failed");
      RETVALUE(RFAILED);
   }

   if((cellCb = ysMsCfgGetCellCfg(dedRel->cellId)) == NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,dedRel->cellId, "Cell Configuration doesn't exist");
      RETVALUE(RFAILED);
   }

   ueCb = ysMsCfgGetUe(cellCb, dedRel->ueId);

   if (ueCb != NULLP)
   {
#ifndef YS_MS_NO_TA
      if (ueCb->tarptInfo.lnk.node)
      {
         cmLListDelFrm(&cellCb->taUeLst, &ueCb->tarptInfo.lnk);
      }
#endif
/*sprint4_scelldeletedeact_changes*/
#ifdef LTE_ADV
      if(CTF_SCELL_RELEASE == dedRel->sCellInfo.sCellAction)
      {
         for(idx = 0;idx<dedRel->sCellInfo.numSCells;idx++)
         {
            if(NULLP != ueCb->sCellCb[dedRel->sCellInfo.ueSCellDedCfg[idx].sCellIdx])
            {
               ueCb->sCellCb[idx] = NULLP;
            }
         }
      }
      else
#endif
      {
         /*sprint4_scelldeletedeact_changes*/
         ysMsCfgDeAllocUeCb(cellCb, ueCb);
      }
   }
   else
   {
      RLOG_ARG1(L_ERROR, DBG_CELLID,dedRel->cellId,"UE (%d) doesnt exist in cell Failed ", dedRel->ueId);
      RETVALUE(RFAILED);
   }

   RETVALUE(ret);
}  /* ysMsCfgDelUeCfg*/


/*
*
*       Fun:  ysMsGetCellCbFrmPhyInstId 
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_utl.c
*
*/

PUBLIC YsCellCb *ysMsGetCellCbFrmPhyInstId
(
U8 phyInstId
)
{
   TRC2(ysMsGetCellCbFrmPhyInstId)


   if(phyInstId  >= CM_LTE_MAX_CELLS)
   {
      YS_LOGERR_INTPAR(EYSXXX, (ErrVal)phyInstId,
            "Invalid phyInstanceId:ysMsGetCellCbFrmPhyInstId failed\n");
      RETVALUE(NULLP);
   }

   RETVALUE(ysCb.cellCfgLst[phyInstId]);
} /* end of ysMsCfgGetCellCfg */

/*
*
*       Fun:   ysMsCfgGetCellCfg
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_utl.c
*
*/

PUBLIC YsCellCb *ysMsCfgGetCellCfg
(
CmLteCellId    cellId
)
{
   YsCellCb *cellCb;

   TRC2(ysMsCfgGetCellCfg)

   if((cellId < CM_START_CELL_ID) || (cellId >= (CM_START_CELL_ID + CM_LTE_MAX_CELLS)))
   {
      RLOG_ARG1(L_ERROR,DBG_CELLID,cellId,
            "Invalid cellId:ysMsCfgGetCellCfg failed ysCb.numOfCells[%d]", ysCb.numOfCells);
      RETVALUE(NULLP);
   }

   cellCb = ysCb.cellCfgLst[cellId - CM_START_CELL_ID];

   RETVALUE(cellCb);
} /* end of ysMsCfgGetCellCfg */


PUBLIC YsCellCb *ysMsCfgGetCellCfgByCId
(
S16    carrierId
)
{
   YsCellCb *cellCb;

   TRC2(ysMsCfgGetCellCfg)

   if((carrierId < YS_PHY_INST_ID) || (carrierId >= (YS_PHY_INST_ID + CM_LTE_MAX_CELLS)))
   {
      RLOG_ARG1(L_ERROR,DBG_CELLID,carrierId,
            "Invalid carrierId:ysMsCfgGetCellCfgByCId failed ysCb.numOfCells[%d]", ysCb.numOfCells);
      RETVALUE(NULLP);
   }

   RASSERT_COREDUMP(carrierId == ysCb.cellCfgLst[carrierId]->phyInstId);
   
   cellCb = ysCb.cellCfgLst[carrierId];

   RETVALUE(cellCb);
} /* end of ysMsCfgGetCellCfg */


/*
*
*       Fun:    ysMsCfgGetUe
*
*       Desc:   This function return UE control block
*
*       Ret:   Pointer to ue control block
*
*       Notes: None
*
*       File:   ys_utl.c
*/
PUBLIC YsUeCb *ysMsCfgGetUe
(
YsCellCb        *cellCb,
CmLteRnti       ueId
)
{
   YsUeCb    *ueCb;
   U16       indx = cellCb->cellId-CM_START_CELL_ID;

   TRC2(ysMsCfgGetUe)

   ueCb = NULLP;

   cmHashListFind(&ysCb.ueHLst[indx], (U8 *)&ueId,
               sizeof(CmLteRnti), 0, (PTR *)&ueCb);
#ifdef LTEMAC_SPS
   if (NULLP == ueCb)
   {
      cmHashListFind(&cellCb->spsRntiHLst, (U8 *)&ueId,
            sizeof(CmLteRnti), 0, (PTR *)&ueCb);
   }
#endif
   RETVALUE (ueCb);
} /* end of ysMsCfgGetUe () */

/*
*
*       Fun:   ysMsCfgDeAllocUeCb
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_utl.c
*
*/

PUBLIC S16 ysMsCfgDeAllocUeCb
(
YsCellCb        *cellCb,
YsUeCb          *ueCb
)
{

   TRC2(ysMsCfgDeAllocUeCb)
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   
#ifndef TFU_UPGRADE
   ysMsUlmPrcDelUeCfg(cellCb, ueCb);
#endif /* TFU_UPGRADE */

   /* Delete from UE list */
   cmHashListDelete (&(ysCb.ueHLst[indx]), (PTR)ueCb);
#ifdef LTEMAC_SPS
   cmHashListDelete (&(cellCb->spsRntiHLst), (PTR)ueCb);
#endif
   /* Free the transaction control block memory */
   ysUtlDeAlloc((Data *)ueCb, sizeof(YsUeCb), indx);

   RETVALUE(ROK);
} /* end of ysMsCfgDeAllocUeCb */

/********************************************************************30**

         End of file:     yw_ms_cfg.c@@/main/TeNB_Main_BR/6 - Tue Jul  8 12:01:28 2014

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      pk   1. initial release.
/main/1    ys004.102  vr   1. Merged MSPD code with phy 1.7
*********************************************************************91*/


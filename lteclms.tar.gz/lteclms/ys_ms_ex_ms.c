/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************
 
     Name:     LTE MAC Convergence Layer
  
     Type:     C source file
  
     Desc:     C source code for Entry point fucntions
  
     File:     ys_ex_ms.c
  
     Sid:      yw_ms_ex_ms.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:45 2014
  
     Prg:      pk
  
**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_MODULE_ID=1;
static int RLOG_FILE_ID=241;

/** @file ys_ex_ms.c
@brief This module acts as an interface handler for upper interface and 
manages Pst and Sap related information for upper interface APIs.
*/

/* Trillium Includes */
#include "envopt.h"        /* Environment options */
#include "envdep.h"        /* Environment dependent */
#include "envind.h"        /* Environment independent */
#include "gen.h"           /* General */
#include "ssi.h"           /* System services */
#include "cm5.h"           /* Common timer defines */
#include "cm_tkns.h"       /* Common tokens defines */
#include "cm_mblk.h"       /* Common memory allocation library defines */
#include "cm_llist.h"      /* Common link list defines  */
#include "cm_hash.h"       /* Common hashlist defines */
#include "cm_lte.h"        /* Common LTEE defines */
#include "ctf.h"           /* CTF defines */
#include "lys.h"           /* layer management defines for LTE-CL */
#include "tfu.h"


#ifdef YS_MSPD
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "LtePhyL2Api.h"
#include "resultcodes.h"
#include "apidefs.h"
#endif
#include "ys_ms.h"            /* defines and macros for CL */
#else
#include <sys/time.h>
#include "ys_ms.h"
#endif /* YS_MSPD*/
#include "ys_ms_err.h"        /* CL error header file */

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "spaccdrv.h" /*sumanth*/
#endif
#endif


#include "gen.x"           /* General */
#include "ssi.x"           /* System services */

#include "cm5.x"           /* Common timer library */
#include "cm_tkns.x"       /* Common tokens */
#include "cm_mblk.x"       /* Common memory allocation */
#include "cm_llist.x"      /* Common link list */
#include "cm_hash.x"       /* Common hashlist */
#include "cm_lte.x"        /* Common LTE includes */
#include "ctf.x"
#include "cm_lib.x"
#include "tfu.x"
#include "lys.x"


#ifdef YS_MSPD
/* Silicon Includes */
#include "ys_ms.x"
#else
#include "ys_ms.x"            /* typedefs for CL */
#endif /* YS_MSPD */

#ifdef YS_MSPD
/* PUBLIC RESULTCODE ysReceivePHYMsg ( U32   size, PTR   l1Msg);*/
PUBLIC Void ysReceivePHYMsg ( U32   size, PTR   l1Msg);
#endif

#ifdef MSPD_CORE1_L2_STATS
extern void ysMsProcessStatSelfMsg ARGS((void));
#endif
EXTERN Void ysMtRcvPhyMsg ARGS ((U32 msgCount));
EXTERN S16 ys_qcMsgHndlrNew(PTR qcl1Msg, S32 buffSize, int carrierId);
#ifdef SS_ROUTE_MSG_CORE1
PUBLIC void ysMsRouteIcpuMsg(Buffer *mBuf);
#endif
/*ys004.102 MSPD merge for PHY 1.7*/
/** @brief This is the activation task of the CL layer. 
 * @param pst pointer to the Pst structure
 * @param mBuf pointer to the Buffer. 
 * @return ROK/RFAILED
 */
PUBLIC S16 ysActvTsk
(
Pst     *pst,
Buffer  *mBuf
)
{
   S16       ret   = ROK;

   TRC3(ysActvTsk)

   ret = ROK;
   //RLOG6(L_DEBUG,"ICPU_ROUTE:SrcEnt %d DstEnt %d DstInst %d SrcProcId %d DestProcId %d Event %d ",
   //        pst->srcEnt,pst->dstEnt,pst->dstInst,pst->srcProcId,pst->dstProcId,pst->event);

   switch(pst->srcEnt)
   {
#if defined(YS_MSPD) || defined(YS_PICO)
      /* The originator of this message is the stack manager,
       * unpack and go to the respective primitive processing function */
      case ENTSM:
         switch(pst->event)
         {
#ifdef LCYSMILYS
            case EVTLYSCFGREQ:
               /* Process a config. request */
               cmUnpkLysCfgReq(YsMiLysCfgReq, pst, mBuf);
               break;
            case EVTLYSCNTRLREQ:
               /* Process a control request */
               cmUnpkLysCntrlReq(YsMiLysCntrlReq, pst, mBuf);
               break;
            case EVTLYSSSTAREQ:
               /* Process a status request  */
               cmUnpkLysStaReq(YsMiLysStaReq, pst, mBuf);
               break;
            case EVTLYSSTSREQ:
               /* Process a statistics request */
               cmUnpkLysStsReq(YsMiLysStsReq, pst, mBuf);
               break;
#ifdef TENB_T3K_SPEC_CHNGS 
       case EVTLYSLOGINFOREQ: /*watchdog changes*/ 
               cmUnpkLysLogStrmInfoReq(YsMiLysLogStrmInfoReq, pst, mBuf);
           break;
#endif /* TENB_T3K_SPEC_CHNGS*/ 
#endif /* LCYSMILYS */
            default:
               RLOG1(L_WARNING, "ysActvTsk(): Invalid event (%d)! ",
                           pst->event);
               YS_MS_FREE_BUF(mBuf);
               break;
         }
         break;

      case ENTRG:
         switch (pst->event)
         {
#if  (defined(LCYSUITFU) || defined(LWLCYSUITFU))
            case EVTTFUBNDREQ:
               ret = cmUnpkTfuBndReq (YsUiTfuBndReq, pst, mBuf);
               break;
#ifdef MSPD
            case EVTTFUSCHBNDREQ:
               ret = cmUnpkTfuBndReq (YsUiTfuSchBndReq, pst, mBuf);
               break;
#endif
            case EVTTFUUBNDREQ:
               ret = cmUnpkTfuUbndReq (YsUiTfuUbndReq, pst, mBuf);
               break;
            case EVTTFUCNTRLREQ:
               ret = cmUnpkTfuCntrlReq (YsUiTfuCntrlReq, pst, mBuf);
               break;
            case EVTTFUDATREQ:
               ret = cmUnpkTfuDatReq (YsUiTfuDatReq, pst, mBuf);
               break;
            case EVTTFURECPREQ:
               ret = cmUnpkTfuRecpReq (YsUiTfuRecpReq, pst, mBuf);
               break;
#endif
            default:
               RLOG1(L_WARNING, "ysActvTsk(): Invalid event (%d)! ",
                           pst->event);
               YS_MS_FREE_BUF(mBuf);
               break;

         } /* end of switch (evnt) */
         break;
#endif /* YS_MSPD or YS_PICO */

#if (defined(YS_PICO) || (defined(YS_LTE_PAL) && defined (LTE_PAL_ENB)) || \
      defined(YS_MSPD))
      case ENTVE:
      case ENTNH:
         switch (pst->event)
         {
#ifdef LCYSUICTF
            case EVTCTFBNDREQ:
               ret = cmUnpkCtfBndReq (YsUiCtfBndReq, pst, mBuf);
               break;
            case EVTCTFUBNDREQ:
               ret = cmUnpkCtfUbndReq (YsUiCtfUbndReq, pst, mBuf);
               break;
            case EVTCTFCFGREQ:
               ret = cmUnpkCtfCfgReq (YsUiCtfCfgReq, pst, mBuf);
               break;
#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
            case EVTCTFKDFREQ:
            ret = cmUnpkCtfKdfReq(YsUiCtfKdfReq, pst, mBuf);
            break;
#endif
#endif
#endif
#ifdef ENABLE_CNM
            case EVTCTFCNMINITSYNCREQ:
               {
                  STKLOG(STK_MD_YS,STK_LOG_INFO,"\n CNM:: Rcvd EVTCTFCNMINITSYNCREQ in CL\n");
                  ret = cmUnpkCtfCnmInitSyncReq (YsUiCtfCnmInitSyncReq,pst,mBuf);
               }
               break;
	    case EVTCTFCNMSYNCREQ:
               {
                  ret = cmUnpkCtfCnmCellSyncReq (YsUiCtfCnmCellSyncReq,pst,mBuf); 
               }
	       break;
#endif
            default:
               RLOG1(L_WARNING, "ysActvTsk(): Invalid event (%d)! ",
                           pst->event);
               YS_MS_FREE_BUF(mBuf);
               break;

         } /* end of switch (evnt) */
         break;
#endif

      case ENTTF:
#ifdef MSPD
#ifdef TENB_RTLIN_CHANGES
         {
            U32 size;
            Void *msg;
            SUnpkU32(&size, mBuf);
            cmUnpkPtr(&msg, mBuf);
            YS_MS_FREE_BUF(mBuf);
            YsLiMsgHandler(NULL, msg);
         }
#else
         /* self post: there can be only one event coming from the receiver 
          * thread
          * which is the uplink data
          */
         ret = ysReceivePHYMsg(0, (PTR) mBuf);
#endif
         break;
#else
         switch(pst->event)
         {
#ifdef LTE_PAL_ENB
#else /* LTE_PAL_ENB */
            case EVTTFUCNTRLREQ:
               cmUnpkTfuCntrlReq(YsUiTfuCntrlReq, pst, mBuf);
               break;
            case EVTTFUDATREQ:
               cmUnpkTfuDatReq(YsUiTfuDatReq, pst, mBuf);
               break;
            case EVTTFURECPREQ:
               ret = cmUnpkTfuRecpReq(YsUiTfuRecpReq, pst, mBuf);
               break;
#endif /* LTE_PAL_ENB */
            default:
               RLOG1(L_WARNING, "ysActvTsk(): Invalid event (%d)! ",pst->event);
               YS_MS_FREE_BUF(mBuf);
               break;
         }
         break;
#endif

      case ENTYS:
         switch(pst->event)
         {
            case PHY_INIT_REQ:
            case NMM_START:
            case NMM_STOP:
            case NMM_RSSI_MEAS_REQ:
            case NMM_STOP_RSSI_MEAS_REQ:
            case NMM_CELL_SEARCH_REQ:
            case NMM_STOP_CELL_SEARCH_REQ:
            case NMM_STOP_PBCH_REQ:
            case NMM_SIB1_CONFIG_REQ:
            case NMM_STOP_BCCH_REQ:
            case NMM_BCCH_CONFIG_REQ:
            case NMM_PBCH_CONFIG_REQ:
			/*begin: wyb add for rem ------ bug10175*/
            case NMM_INIT_SYNC_REQ:
            case PHY_INIT_SYNC_STOP:
			/*  end: wyb add for rem ------ bug10175*/
               {
#ifdef RGL_SPECIFIC_CHANGES
                  STKLOG(STK_MD_YS,STK_LOG_INFO," Message handling is not supported !!!!\n");
#else
                  STKLOG(STK_MD_YS,STK_LOG_INFO,"---------ysActvTsk(case ENTYS): send %u to phy\n",pst->event);
                  RLOG1(L_DEBUG,"---------ysActvTsk(case ENTYS): send %u to phy\n",pst->event);
                  ysSendNmMsgToPhy(pst->event, mBuf);
#endif
               }
               break;
            case EVTLYSQCDATA:
               {
                  U32 buffSize;
                  S32 carrierId;
                  PTR msg;
                  SUnpkU32(&carrierId, mBuf);
                  SUnpkS32(&buffSize, mBuf);
                  cmUnpkPtr(&msg, mBuf);
                  YS_MS_FREE_BUF(mBuf); 
                  ys_qcMsgHndlrNew(msg, buffSize, carrierId);
               }
               break;

            default:
               RLOG1(L_WARNING, "ysActvTsk(): Uknown message from RemApp Event=[%d]! ", pst->event);
               break;
         }
         break;
#ifdef ENABLE_CNM
      case ENTWR:
         switch(pst->event)
         {
            case YS_CNM_ICTA_START_REQ: 
            case YS_CNM_ICTA_STOP_REQ: 
            case YS_CNM_ICTA_FOE_REQ: 
               {
                  ysStoreCnmMsg(pst->event, mBuf);
               }
               break;
            //case YS_CNM_INIT_SYNC_REQ:
#ifdef L2_L3_SPLIT
            case NMM_START:
            case NMM_STOP:
            case NMM_RSSI_MEAS_REQ:
            case NMM_STOP_RSSI_MEAS_REQ:
            case NMM_CELL_SEARCH_REQ:
            case NMM_STOP_CELL_SEARCH_REQ:
            case NMM_STOP_PBCH_REQ:
            case NMM_SIB1_CONFIG_REQ:
            case NMM_STOP_BCCH_REQ:
            case NMM_BCCH_CONFIG_REQ:
            case NMM_PBCH_CONFIG_REQ:
			/*begin: wyb add for rem ------ bug10175*/
            case NMM_INIT_SYNC_REQ:
            case PHY_INIT_SYNC_STOP:
			/*  end: wyb add for rem ------ bug10175*/
			   STKLOG(STK_MD_YS,STK_LOG_INFO,"---------ysActvTsk(case ENTWR): send %u to phy\n",pst->event);
			   RLOG1(L_DEBUG,"---------ysActvTsk(case ENTWR): send %u to phy\n",pst->event);
               ysSendNmMsgToPhy(pst->event, mBuf);
               break;
            case EVTL2COREDUMPLOGBUF:
               STKLOG(STK_MD_YS,STK_LOG_INFO,"enodeb_net coredump\nysMsSndPhyShutDown4core ...\n");
               fflush(stdout);
               EXTERN Void ysMsSndPhyShutDown4core(Void);
               ysMsSndPhyShutDown4core();
               SPutMsg(mBuf);
               break;
#endif               
         }
       break;
#endif

      default:
         RLOG1(L_WARNING, "ysActvTsk(): Message from an invalid entity (%d)! ", pst->srcEnt);
         YS_MS_FREE_BUF(mBuf);
         ret = RFAILED;

   } /* end of switch */

   SExitTsk();
   RETVALUE (ret);
} /* end of ysActvTsk */

/********************************************************************30**
  
         End of file:     yw_ms_ex_ms.c@@/main/TeNB_Main_BR/4 - Thu Apr 24 17:06:45 2014
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/2      ---     sgm                   1. eNodeB 1.2 release
/main/1      ys004.102     vr              1. MSPD merge for PHY 1.7
*********************************************************************91*/


/********************************************************************16**

            (c) Copyright 2012 by RadiSys Corporation. All rights reserved.

     This software is confidential and proprietary to RadiSys Corporation.
     No part of this software may be reproduced, stored, transmitted, 
     disclosed or used in any form or by any means other than as expressly
     provided by the written Software License Agreement between Radisys 
     and its licensee.

     Radisys warrants that for a period, as provided by the written
     Software License Agreement between Radisys and its licensee, this
     software will perform substantially to Radisys specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  Radisys also warrants 
     that has the corporate authority to enter into and perform under the 
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     RADISYS MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL RADISYS BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend:

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between Radisys and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact Radisys at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    RadiSys Corporation
                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388
                    Email: support@trillium.com
                    Web: http://www.radisys.com 
 
*********************************************************************17*/


/************************************************************************

     Name:     LTE MAC Convergence Layer

     Type:     C source file

     Desc:     C source code for Entry point fucntions

     File:     ys_ms_utl.c

     Sid:      yw_ms_utl.c@@/main/TeNB_Main_BR/6 - Wed Jun 11 13:19:54 2014

     Prg:      rp

**********************************************************************/
#if defined(RLOG_ENABLE_TEXT_LOGGING) || defined(CREAT_LOG_DB)
static const char* RLOG_MODULE_NAME="CL";
#endif
static int RLOG_MODULE_ID=1;
static int RLOG_FILE_ID=236;

#include <stdlib.h>
#include <math.h>

/* header include files -- defines (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* common timers defines */
#include "cm_hash.h"       /* common hash list defines */
#include "cm_llist.h"      /* common linked list defines */
#include "cm_mblk.h"       /* memory management */
#include "cm_tkns.h"       /* common tokens */
#include "cm_lte.h"
#include "ctf.h"           /* CTF defines */
#include "lys.h"           /* layer management defines for LTE-CL */
#include "tfu.h"
#include "ys_ms.h"         /* defines and macros for CL */
#include "ys_ms_err.h"        /* YS error defines */

#ifdef TENB_AS_SECURITY
#ifndef TENB_T2K3K_SPECIFIC_CHANGES
#include "spaccdrv.h" /*sumanth*/
#endif
#endif

/* header/extern include files (.x) */

#include "gen.x"           /* general layer typedefs */
#include "ssi.x"           /* system services typedefs */
#include "cm5.x"           /* common timers */
#include "cm_hash.x"       /* common hash list */
#include "cm_lib.x"        /* common library */
#include "cm_llist.x"      /* common linked list */
#include "cm_mblk.x"       /* memory management */
#include "cm_tkns.x"       /* common tokens */
#include "cm_lte.x"
#include "ctf.x"           /* CTF types */
#include "lys.x"           /* layer management typedefs for CL */
#include "tfu.x"
#include "danipc_ioctl.h"

/* Silicon Includes */
#ifdef INTEL_ALLOC_WLS_MEM
#include "wls_lib.h"
#endif
#ifdef XEON_SPECIFIC_CHANGES
#include "lte_phy_l2_api.h"
#else
#include "apidefs.h"
#include "LtePhyL2Api.h"
#include "ctrlmsg.h"
#endif
#ifdef TENB_RTLIN_CHANGES
#ifdef SS_USE_ICC_MEMORY
#include "icc_lib.h"
#endif /* SS_USE_ICC_MEMORY */
#else
#include "appinit.h"
#endif /*TENB_RTLIN_CHANGES*/

#include "ys_ms.x"            /* typedefs for CL */
#include "tl_com.h"

#if (defined (MAC_FREE_RING_BUF) || defined (RLC_FREE_RING_BUF))
#include "ss_rbuf.h"
#include "ss_rbuf.x"
#ifndef XEON_SPECIFIC_CHANGES
#include "mt_plat_t33.x"
#endif
#endif


#ifdef RSYS_WIRESHARK 
PUBLIC Bool ysCheckSrbOrCcch(Buffer *mBuf);
#endif

#ifdef TFU_TDD
extern  U8 ysTddUlDlSubfrmTbl[7][10];
#endif
EXTERN U32 rgNumSrGrant; /* SR_RACH_STATS */
EXTERN U32 rgNumMsg4PdcchWithCrnti;
EXTERN U32 tpcPusch[2];
EXTERN U32 tpcPucch[2];
#ifdef CA_PHY
EXTERN U32 wrSmDfltNumCells; 
#endif


#ifdef YS_SCATTER_GATHER
#ifdef L2_OPTMZ
PRIVATE S16 ysMsUtlCopyScatterBufPtrMux ARGS((
TfuDatReqTbInfo *tbInfo,
MsgLen cnt,                 /* count */
Data *dstBuf,               /* destination buffer */
U16 index
));
#endif
PRIVATE S16 ysMsUtlCopyScatterBufPtr ARGS((
Buffer *srcMbuf,            /* source message buffer */
MsgLen cnt,                 /* count */
Data *dstBuf               /* destination buffer */
));
#endif
#ifdef ENABLE_CNM
YsCnmEarfcnTable ysEarfcnTable[YS_CNM_MAX_EARFCN_TABLE_SIZE] =
{
   {1900,36000,36000,36199,33},
   {2010,36200,36200,36349,34},
   {1850,36350,36350,36949,35},
   {1930,36950,36950,37549,36},
   {1910,37550,37550,37749,37},
   {2570,37750,37750,38249,38},
   {1880,38250,38250,38249,39},
   {2300,38650,38650,39649,40},
};

#endif
PRIVATE U8 ysDciAmbigSize[61] = {0,0,0,0,0,0,0,0,0,0,0,
                         0,1,0,1,0,1,0,0,0,1,
                         0,0,0,1,0,1,0,0,0,0,
                         0,1,0,0,0,0,0,0,0,1,
                         0,0,0,1,0,0,0,0,0,0,
                         0,0,0,0,0,1,0,0,0,0};
/*ys004.102 :  Merged MSPD code with phy 1.7 */

U32 numCo;
PUBLIC U32 dciFormat1ASize = 0;

/* header/extern include files (.x) */
/* header include files (.h) */

/* Static variables */
PRIVATE enum ModulationOptions ModulationType[32] =
{
QPSK, QPSK, QPSK, QPSK, QPSK, QPSK, QPSK, QPSK,
QPSK, QPSK, QAM16, QAM16, QAM16, QAM16, QAM16, QAM16,
QAM16, QAM64, QAM64, QAM64, QAM64, QAM64, QAM64, QAM64,
QAM64, QAM64, QAM64, QAM64, QAM64, QPSK, QAM16, QAM64
};

/* Bit masks used for set/get bit range macros */
U8 YsMsBitMaskArr1[8] =
{
   0xff, 0x7f, 0x3f, 0x1f, 0x0f, 0x07, 0x03, 0x01
};
U8 YsMsBitMaskArr2[8] =
{
   0x80, 0xb0, 0xe0, 0xf0, 0xf8, 0xfb, 0xfe, 0xff
};

U8 pmiNumOfLayerMap2AntPortDCI2[2][8] = {{2,1,1,1,1,1,1,0},{2,2,2,0,0,0,0,0}};

U8 pmiNumOfLayerMap4AntPortDCI2[2][64] = {
               {4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,\
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},\
                                        {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,\
                    4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0}
                   };

U8 pmiNumOfLayerMap4AntPortDCI2A[2][4] = {{4,2,0,0},{2,3,4,0}};
U8 precodingInfoToCbMap[2][8] = {{0,0,1,2,3,2,3,3},{1,2,2}};

PUBLIC Void ysMsSetBitRange
(
 U8      *byteArr,
 U8      bitIndex,
 U8      len,
 U32     val
)
{
   U8    octIndx;
   U8    bitStartOffset;

   octIndx = bitIndex / 8;
   bitStartOffset = bitIndex % 8;

   if ((bitStartOffset + len) > 8)
   {
      U8 tmpVal;
      /* the field straddles the byte boundary */

      tmpVal = val >> (len - (8 - bitStartOffset));
      byteArr[octIndx] |= tmpVal;

      tmpVal = val << (8 -(len -(8 - bitStartOffset)));
      byteArr[octIndx + 1] |= tmpVal;

   }
   else
   {
      U8 tmpVal = val << (8 - bitStartOffset - len);
      byteArr[octIndx] |= tmpVal;
   }
}

/*
*
*       Fun:   ysMsUtlFillCfgReq
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_utl.c
*
*/

PUBLIC S16 ysMsUtlFillCfgReq
(
INITPARM      *msCfgReq,
YsCellCb      *cellCb
)
{
   CtfCellCfgInfo *cellCfg;

   TRC2(ysMsUtlFillCfgReq);

   cellCfg = &cellCb->cellCfg;

   /*TODO:Setting this for the time being as per Vitaliy input.Might be 
     reverted at later stage */
   msCfgReq->channelBandwidth = YS_MS_GET_CH_BW(cellCfg->bwCfg);
#ifdef TFU_TDD
  msCfgReq->ulDlConfig = cellCfg->tddSfCfg.sfAssignment; 
  msCfgReq->specialSubframeConfig = cellCfg->tddSfCfg.spclSfPatterns;
#endif

   msCfgReq->frtypeDuplexmode = YS_MS_GET_DUP_MODE(cellCfg->txCfg);

   msCfgReq->radioAccessMode = YS_MS_ACCESS_MODE_OFDMA;

   msCfgReq->physicalResourceBandwidth = YS_MS_GET_RSRC_BW(cellCfg->txCfg);

   msCfgReq->numberResourceBlocksperSlot = YS_MS_GET_DL_BW(cellCfg->bwCfg);

   msCfgReq->phyLayerCellIdGroup = cellCfg->cellIdGrpId;
   msCfgReq->phyLayerId = cellCfg->physCellId;

   msCfgReq->fastfwdorPreclockingNumber = YS_MS_FAST_FW_PRE_LOCK_NUM;

   msCfgReq->fftSize = YS_MS_GET_FFT_SIZE(cellCfg->bwCfg);

   msCfgReq->numberUsedSubcarriers = YS_MS_GET_DL_BW(cellCfg->bwCfg) * \
                                     YS_MS_GET_RSRC_BW(cellCfg->txCfg);

   msCfgReq->nMaxDlRb = YS_MS_GET_DL_BW(cellCfg->bwCfg);
   msCfgReq->nMaxUlRb = YS_MS_GET_UL_BW(cellCfg->bwCfg);
#if (defined (E_TM) && defined (TENB_T2K3K_SPECIFIC_CHANGES))
   if(TRUE == cellCb->etmEnable) /*ETM MODE is on */
   {
      msCfgReq->txAntennaPortCount = 1; /* as per MSPD suggestion for ETM feature for T2K*/
      msCfgReq->referenceSignalPower = 0; /*as per MSPD suggestion for ETM testing on T2k*/
   }
   else
#endif
   {
      msCfgReq->referenceSignalPower = cellCfg->pdschCfg.refSigPwr;
      msCfgReq->txAntennaPortCount = YS_MS_GET_NUM_TX_ANT(cellCfg->antennaCfg);
   }
   msCfgReq->primarySyncSignalPower= cellCfg->priSigPwr;
   msCfgReq->secondarySyncSignalPower = cellCfg->secSigPwr;
   RLOG3(L_DEBUG,"msCfgReq->referenceSignalPower = %d,"
         "msCfgReq->primarySyncSignalPower=%d,"
         "msCfgReq->secondarySyncSignalPower=%d",
         msCfgReq->referenceSignalPower, 
         msCfgReq->primarySyncSignalPower,
         msCfgReq->secondarySyncSignalPower);
   msCfgReq->numDataRePerPRB = YS_MS_GET_RE_PER_PRB(cellCfg->antennaCfg);
   msCfgReq->cyclicPrefixType = YS_MS_GET_CP_TYPE(cellCfg->txCfg);

#ifdef PHY_3828
   /*By Default setting RX antenna to 2 */
   msCfgReq->rxAntennaPortCount = 1;
#else
   /*By Default setting RX antenna to 1 */
   msCfgReq->rxAntennaPortCount = 1;
#endif

#ifdef CA_PHY
#ifdef TFU_TDD
   msCfgReq->rxAntennaPortCount = 1;
#else
   msCfgReq->rxAntennaPortCount = 2;
#endif
//   if(ysCb.numOfCells > 1)
   if(wrSmDfltNumCells > 1)
   {
      msCfgReq->carrierAggregationLevel = 1;
   }
#endif /* LTE_ADV */

//vz always do 2 RX ant
msCfgReq->rxAntennaPortCount = 2;

#ifndef TENB_T2K3K_SPECIFIC_CHANGES
   msCfgReq->phyCfg =
      (PHYINIT_NEW_MAC_TO_PHY_INTERFACE | PHYINIT_PHY_MAINTAINS_PBCH | 
       PHYINIT_ROBUST_CONTROL | PHYINIT_DONT_FREE_NEXT_MISSED_VECTOR);

#ifdef LOWLATENCY
msCfgReq->phyCfg = msCfgReq->phyCfg | PHYINIT_LOW_LATENCY_PATH;
#endif
#ifdef DLHQ_RTT_OPT
msCfgReq->phyCfg = msCfgReq->phyCfg | PHYINIT_TWO_MUXCONTROL_LISTS;
#endif

#else
#ifdef E_TM
if (TRUE == cellCb->etmEnable) /*ETM lib doesn't support PHYINIT_USE_SCATTERED_TXSDU_POINTERS, hence disabling it*/
{
   msCfgReq->phyCfg =
      (PHYINIT_NEW_MAC_TO_PHY_INTERFACE | PHYINIT_PHY_MAINTAINS_PBCH | 
       PHYINIT_ROBUST_CONTROL);
}
else
#endif
{
#ifdef YS_SCATTER_GATHER
   msCfgReq->phyCfg =
      (PHYINIT_NEW_MAC_TO_PHY_INTERFACE | PHYINIT_PHY_MAINTAINS_PBCH | 
       PHYINIT_ROBUST_CONTROL | PHYINIT_USE_SCATTERED_TXSDU_POINTERS);
#else
    msCfgReq->phyCfg =
      (PHYINIT_NEW_MAC_TO_PHY_INTERFACE | PHYINIT_PHY_MAINTAINS_PBCH |
       PHYINIT_ROBUST_CONTROL);
#endif
}
#ifdef LOWLATENCY
msCfgReq->phyCfg = msCfgReq->phyCfg | PHYINIT_LOW_LATENCY_PATH;
#endif

#endif
#ifdef YS_MS_ULZBC
msCfgReq->phyCfg = msCfgReq->phyCfg | PHYINIT_USE_SCATTERED_RXSDU_POINTERS;
STKLOG(STK_MD_YS,STK_LOG_INFO,"PHYINIT_USE_RXSDU_POINTER enabled\n");
#endif

#ifdef EMTC_ENABLE
    if(cellCb->cellInfo.catMenabled)
    {
       /* Disable this flag because PHY will take MIB from L2 */
      /* ADARSHA */
      if(msCfgReq->phyCfg & PHYINIT_PHY_MAINTAINS_PBCH)
      {
         msCfgReq->phyCfg = msCfgReq->phyCfg & ~(1<< PHYINIT_PHY_MAINTAINS_PBCH);
      }
      msCfgReq->phyCfg = msCfgReq->phyCfg | PHYINIT_GLOBAL_CATM_ENABLE;
      msCfgReq->addFeatures[3] = 1; // PBCH repetaions are enabled 
      STKLOG(STK_MD_YS,STK_LOG_INFO,"In ysMsUtlFillCfgReq :: EMTC Enable %s %d \n", __FILE__, __LINE__);
    }
#endif


#ifndef TFU_TDD
   msCfgReq->reserved = 0;
#endif

   msCfgReq->pb = cellCfg->pdschCfg.p_b;

#ifndef YS_MS_NO_TA
   msCfgReq->rxSduLineMonitorInfoenable = 1;
#endif

   msCfgReq->customExtensionReportEn = 0;
   /*TODO:setting this to INDV for the time being as per Vitaliy input, 
     might b changed at a later stage.*/
#ifndef PHY_3_8_3     
  // New Phy has removed this Param
#ifndef CA_PHY
   msCfgReq->rachReportMode = YS_RACH_REPORT_MODE_INDV;
#endif   
#endif
   msCfgReq->txSduConfEnable = YS_TX_SDU_CFM_DIS;
   /*Setting these parameters so that CL need not wait for PHY
     to send TX_START_CFM before CL can start transmission of
     TX SUDs.*/
   msCfgReq->txStartConfDisable = 1;
   msCfgReq->rxStartConfDisable = 1;

   msCfgReq->sduConfig = YS_SDU_CFG_NO_SHARED_MEM;

   msCfgReq->radioFrameNumber = YS_PHY_INIT_SFN;
   msCfgReq->subframeNumber = YS_PHY_INIT_SF;
   msCfgReq->slotNumber = YS_PHY_INIT_SLOT;

   if(cellCfg->srsUlCfg.pres == TRUE)
   {

      /* changed according to MS values */
      msCfgReq->srsBandwidthConfig = cellCfg->srsUlCfg.srsSetup.srsBw;
      msCfgReq->srsSubframeConfig = cellCfg->srsUlCfg.srsSetup.sfCfg;
      msCfgReq->srsSimultaneousANandSRS = cellCfg->srsUlCfg.srsSetup.srsANSimultTx;
      RLOG_ARG3(L_DEBUG,DBG_CELLID,cellCb->cellId,"msCfgReq->srsBandwidthConfig=%d, " 
            "msCfgReq->srsSubframeConfig=%d, msCfgReq->srsSimultaneousANandSRS=%d",
            msCfgReq->srsBandwidthConfig,
            msCfgReq->srsSubframeConfig,
            msCfgReq->srsSimultaneousANandSRS);
   }
   else
   {
      msCfgReq->srsSubframeConfig = 15;	/* add by lcwu, bugYALU! */
   }
   /*TODO:Setting this to 15 irrespective of srsUlCfg.pres flag, this can be 
     removed later */
#ifdef XEON_SPECIFIC_CHANGES
      msCfgReq->srsSubframeConfig = 15;
#endif

   if(cellCfg->prachCfg.pres == TRUE)
   {
      msCfgReq->prachConfigurationIndex = cellCfg->prachCfg.prachCfgIndex;
      msCfgReq->prachFrequencyOffset = cellCfg->prachCfg.prachFreqOffset;
      msCfgReq->prachHighSpeedFlag = cellCfg->prachCfg.highSpeedFlag;
      msCfgReq->prachCyclicShiftConfig = cellCfg->prachCfg.zeroCorrelationZoneCfg;
      msCfgReq->prachRootSequenceIndex = cellCfg->prachCfg.rootSequenceIndex;
      RLOG2(L_DEBUG,"msCfgReq->prachConfigurationIndex = %d"
            "msCfgReq->prachFrequencyOffset=%d",
            msCfgReq->prachConfigurationIndex, msCfgReq->prachFrequencyOffset);
      RLOG3(L_DEBUG,"msCfgReq->prachHighSpeedFlag=%d,"
            "msCfgReq->prachCyclicShiftConfig=%d,"
            "msCfgReq->prachRootSequenceIndex=%d", 
            msCfgReq->prachHighSpeedFlag,
            msCfgReq->prachCyclicShiftConfig, 
            msCfgReq->prachRootSequenceIndex);
      msCfgReq->phichResource = cellCfg->phichCfg.resource;
      msCfgReq->phichDuration = cellCfg->phichCfg.duration;
   }

   RETVALUE(ROK);
}

/*
*
*       Fun:   ysMsUtlFillTxVector
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/
PUBLIC S16 ysMsUtlFillTxVector
(
TfuCntrlReqInfo *tfuCntrlReq,
YsCellCb        *cellCb,
PDLSUBFRDESC    pTxVect
)
{
   CmLList      *cmLstEnt;
   TfuPdcchInfo *pdcchInfo;
   U8           chIdx;
   U8           idx;
#ifdef EMTC_ENABLE
   U8           idx1;
#endif
#ifndef XEON_SPECIFIC_CHANGES
   U8           numDlCh;
#endif
   DCICHANNELDESC *dciCh;
   DLCMNTXPWRCTL  *dlCmnPwrCtl;
#ifdef LTEMAC_SPS
   YsUeCb    *ueCb = NULLP;
#endif
#ifdef BATCH_PROCESSING_DL
   YsPhyTxSdu      phyTxSdu;
   U8              *pStrtAddr = NULLP;
   PMAC2PHY_QUEUE_EL pElem = NULLP;
#endif
   U16 indx = cellCb->cellId-CM_START_CELL_ID;

   TRC2(ysMsUtlFillTxVector)

   pTxVect->subframeNumber   = tfuCntrlReq->dlTiming.subframe;
   pTxVect->frameNumber      = tfuCntrlReq->dlTiming.sfn;

   pTxVect->subframeType     = DLTX;
   pTxVect->antennaPortcount = YS_MS_GET_NUM_TX_ANT(cellCb->cellCfg.antennaCfg);

   /* Fill DlSubframeCommonControlStructure */
#ifdef TFU_TDD
   if(ysTddUlDlSubfrmTbl[cellCb->ulDlCfgIdx][pTxVect->subframeNumber] == YS_TDD_UL_SUBFRAME)
   {
      pTxVect->numCtrlSymbols = 0;
   }
   else
#endif
   {
      pTxVect->numCtrlSymbols        = tfuCntrlReq->cfi;
   }
   pTxVect->phichResource         = cellCb->cellCfg.phichCfg.resource;
   pTxVect->phichDuration         = cellCb->cellCfg.phichCfg.duration;

   /* HARQ: DCI0_PHICH: No DCI0 and PHICH channels in txVector */

#ifdef EMTC_ENABLE
   pTxVect->lprime_mpdcch_start = cellCb->cellInfo.mPdcchStart;
#endif
#ifdef TFU_TDD
#ifndef PHY_3_8_3
   //New Phy has removed this Value
   pTxVect->numberOfPhichChannels = 0;
#endif   
#endif   
#ifdef EMTC_ENABLE
   pTxVect->numCtrlChannels       = tfuCntrlReq->dlPdcchLst.count 
   									+ tfuCntrlReq->dlMpdcchLst.count;
#else
   pTxVect->numCtrlChannels       = tfuCntrlReq->dlPdcchLst.count; 
#endif

#ifndef XEON_SPECIFIC_CHANGES
   numDlCh = pTxVect->numberofChannelDescriptors;
#endif
   chIdx = pTxVect->numberofChannelDescriptors;

   /* Leave space for four PDSCH and start filling DCIs thereafer,
    * later probably fill DCIs after filling PDSCHs so the
    * change becomes more generic and reliable */
#ifdef XEON_SPECIFIC_CHANGES
   //dciCh = (DCICHANNELDESC *)&pTxVect->dlCh[numDlCh+12];
   dciCh = (DCICHANNELDESC *)&pTxVect->dciCh[0];
#else
   dciCh = (DCICHANNELDESC *)&pTxVect->dlCh[numDlCh+7];
#endif

#ifdef BIT_64
   pTxVect->offsetDCIChannels     = (U64)dciCh - (U64)pTxVect;
#else
   pTxVect->offsetDCIChannels     = (U32)dciCh - (U32)pTxVect;
#endif

#ifdef BATCH_PROCESSING_DL
#ifdef EMTC_ENABLE
   if((tfuCntrlReq->dlPdcchLst.count > 0) ||
		(tfuCntrlReq->dlMpdcchLst.count > 0))
#else
   if(tfuCntrlReq->dlPdcchLst.count > 0)
#endif
   {
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
#ifdef EMTC_ENABLE
      U32 l1Size = sizeof(MAC2PHY_QUEUE_EL) + ((tfuCntrlReq->dlPdcchLst.count + 
      							tfuCntrlReq->dlMpdcchLst.count) * 32);
#else
      U32 l1Size = sizeof(MAC2PHY_QUEUE_EL) + (tfuCntrlReq->dlPdcchLst.count * 32);
#endif
      pElem = ysMsUtlGetPhyListElem(l1Size);
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG */
         RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
         RETVALUE(RFAILED);
      }
#ifndef EMTC_ENABLE
      /* For PDCCH as per the document the size of Align Offset is 32 */
      pElem->AlignOffset = 32;
#else
      if(tfuCntrlReq->dlMpdcchLst.count > 0)
      {
         pElem->AlignOffset = sizeof(DCICHANNELDESC);
      }
#endif
      pElem->NumMessageInBlock = 0;
      pStrtAddr = (U8 *)(pElem + 1);
   }
#endif
   /* Fill the DCI Chan Desc structure with dlPdcchLst, DCI FORMAT 1A */
   for (idx = 0, cmLstEnt = tfuCntrlReq->dlPdcchLst.first;
        (chIdx < MAXCHSUBFRAME) && cmLstEnt
#ifdef BATCH_PROCESSING_DL
            && pStrtAddr && pElem
#endif
;
        cmLstEnt = cmLstEnt->next, idx++, chIdx++)
   {
      pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
#ifdef LTEMAC_SPS
      if (pdcchInfo->isSpsRnti == TRUE)
      {
         /* rnti field of pdcchInfo is SPS Rnti */
         cmHashListFind(&cellCb->spsRntiHLst, (U8 *)&pdcchInfo->rnti,
               sizeof(CmLteRnti), 0, (PTR *)&ueCb);

         if ((ueCb != NULLP) && (ueCb->ueId != pdcchInfo->crnti))
         {
            cmHashListDelete (&(cellCb->spsRntiHLst), (PTR)ueCb);
            ueCb = NULLP;
         }

         if (NULLP == ueCb)
         {
            cmHashListFind(&ysCb.ueHLst[indx], (U8 *)&pdcchInfo->crnti,
                  sizeof(CmLteRnti), 0, (PTR *)&ueCb);
            ueCb->spsRnti = pdcchInfo->rnti;
            /* Duplicate check is done in insert */
            if(cmHashListInsert (&(cellCb->spsRntiHLst), (PTR)ueCb,
                     (U8 *)&ueCb->spsRnti, sizeof(CmLteRnti)) != ROK)
            {
               RLOG_ARG0(L_ERROR,DBG_CRNTI,pdcchInfo->rnti,"cmHashListInsert returned failed ");
               MSPD_ERR("cmHashListInsert returned failed \n");
            }
         }
      }
#endif

#ifdef BATCH_PROCESSING_DL
      phyTxSdu.txSduReq = (PGENMSGDESC)pStrtAddr;
      if (ysMsUtlFillDCIChanDesc(pdcchInfo, cellCb, &phyTxSdu, 
               &dciCh[idx], chIdx, tfuCntrlReq->dlTiming) == RFAILED)
#else
      if (ysMsUtlFillDCIChanDesc(pdcchInfo, cellCb,
         &dciCh[idx], chIdx, tfuCntrlReq->dlTiming) == RFAILED)
#endif
         {
            /* HARQ_TODO: Need to see what can be done here */
#ifdef BATCH_PROCESSING_DL
            ysFreePhyMsg(pElem);
#endif
            RETVALUE(RFAILED);
         }
#ifdef BATCH_PROCESSING_DL
      pElem->NumMessageInBlock++;
      pStrtAddr = pStrtAddr + pElem->AlignOffset;
#endif
   }
#ifndef EMTC_ENABLE
/* ADARSHA */
#ifdef BATCH_PROCESSING_DL
      if(idx > 0)
      {
         pElem->MessageLen = (pStrtAddr - (U8 *)(pElem)) - sizeof(MAC2PHY_QUEUE_EL);
         YS_MS_FILL_PHY_LIST_ELEM(pElem, tfuCntrlReq->dlTiming.sfn, tfuCntrlReq->dlTiming.subframe,
               NULLP, pElem->MessageLen, PHY_BATCH_MSG_REQ);
         YsPhyLstCp        *pDlCntrl = &cellCb->dlEncL1Msgs[tfuCntrlReq->dlTiming.subframe].dlCntrl;
         ysMsUtlAddToPhyList(pDlCntrl,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
         YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
         idx = 0;
      }
#endif
#endif

#ifdef EMTC_ENABLE
	/* Fill the DCI Chan Desc structure with dlMpdcchLst, DCI FORMAT 61A */
   for (idx1 = 0, cmLstEnt = tfuCntrlReq->dlMpdcchLst.first;
        (chIdx < MAXCHSUBFRAME) && cmLstEnt
#ifdef BATCH_PROCESSING_DL
            && pStrtAddr && pElem
#endif
;
        cmLstEnt = cmLstEnt->next, idx1++, chIdx++)
	{
      pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
		
#ifdef BATCH_PROCESSING_DL
      phyTxSdu.txSduReq = (PGENMSGDESC)pStrtAddr;
      if (ysMsUtlFillDCIChanDesc(pdcchInfo, cellCb, &phyTxSdu, 
               &dciCh[idx1], chIdx, tfuCntrlReq->dlTiming) == RFAILED)
#else
      if (ysMsUtlFillDCIChanDesc(pdcchInfo, cellCb,
         &dciCh[idx1], chIdx, tfuCntrlReq->dlTiming) == RFAILED)
#endif
         {
            /* HARQ_TODO: Need to see what can be done here */
#ifdef BATCH_PROCESSING_DL
            ysFreePhyMsg(pElem);
#endif
            RETVALUE(RFAILED);
         }
#ifdef BATCH_PROCESSING_DL
      pElem->NumMessageInBlock++;
      pStrtAddr = pStrtAddr + pElem->AlignOffset;
#endif
   }
#endif	  
#ifdef BATCH_PROCESSING_DL
#ifdef EMTC_ENABLE
      if((idx > 0) || (idx1 > 0))
#else
      if(idx > 0)
#endif
      {
         pElem->MessageLen = (pStrtAddr - (U8 *)(pElem)) - sizeof(MAC2PHY_QUEUE_EL);
         YS_MS_FILL_PHY_LIST_ELEM(pElem, tfuCntrlReq->dlTiming.sfn, tfuCntrlReq->dlTiming.subframe,
               NULLP, pElem->MessageLen, PHY_BATCH_MSG_REQ);
         YsPhyLstCp        *pDlCntrl = &cellCb->dlEncL1Msgs[tfuCntrlReq->dlTiming.subframe].dlCntrl;
         ysMsUtlAddToPhyList(pDlCntrl,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
         YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
      }
#endif

   /* As is the case for DCIs (starting right after dlChs), power
    * control info may also start right after DCIs */
   //if(pTxVect->offsetPowerCtrl != 0) I find it uninitialised! lichangwu, 2017-11-06
   {
      dlCmnPwrCtl = (DLCMNTXPWRCTL* )&dciCh[idx];
#ifdef BIT_64
      pTxVect->offsetPowerCtrl       = (U64)dlCmnPwrCtl - (U64)pTxVect;
#else
      pTxVect->offsetPowerCtrl       = (U32)dlCmnPwrCtl - (U32)pTxVect;
#endif
      /* dlCmnPwrCtl->prsRa          = cellCb->cellCfg.pdschCfg.refSigPwr; */
      dlCmnPwrCtl->pilotPower     = cellCb->cellCfg.pilotSigPwr;
      dlCmnPwrCtl->psyncPower     = cellCb->cellCfg.priSigPwr;
      dlCmnPwrCtl->ssyncPower     = cellCb->cellCfg.secSigPwr;
      dlCmnPwrCtl->prsRa          = 0;

      /*settting it to 0 for temp testing (IQ sample)
TODO:Find out if this parameter value can be derived
from MAC.*/
      dlCmnPwrCtl->ciPower        = 0;
      //dlCmnPwrCtl->paprControl    = 0;
      //dlCmnPwrCtl->paprThreshold  = 0;

   }

   pTxVect->numberofChannelDescriptors = chIdx;
   cellCb->dlEncL1Msgs[tfuCntrlReq->dlTiming.subframe].numChannels= chIdx;
   pTxVect->offsetCustomFeatures       = 0; /* This entry is absent */

   RETVALUE(ROK);
} /* end of ysMsUtlFillTxVector */


/* HARQ: DCI0_PHICH */
/*
*
*       Fun:   ysMsUtlFillAndAddDci0HiInfo
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

#ifdef BATCH_PROCESSING_DL
PUBLIC S16 ysMsUtlFillAndAddDci0HiInfo
(
TfuCntrlReqInfo  *tfuCntrlReq,
YsCellCb         *cellCb
)
#else
PUBLIC S16 ysMsUtlFillAndAddDci0HiInfo
(
TfuCntrlReqInfo  *tfuCntrlReq,
YsCellCb         *cellCb,
PHIADCIULMSGDESC pDci0HiVector
)
#endif
{
   CmLList      *cmLstEnt;
   TfuPhichInfo *phichInfo;
   YsPhyTxSdu   phyTxSdu;
   U32          channelIdx;
   TfuPdcchInfo *pdcchInfo;
   /* CmLListCp    *dlMsgLst;*/
   PMAC2PHY_QUEUE_EL pElem;
#ifdef BATCH_PROCESSING_DL
   U8            *pStrtAddr = NULLP;
   PHIADCIULMSGDESC pDci0HiVector;
   //U8               dci3flg = 0;
#endif
   YsPhyLstCp        *pUlCntrl;
   PDLSUBFRDESC txVector;
   DCICHANNELDESC *dciCh = NULLP;
   U8                sfNum;
   U8               chIdx = 0;
#ifdef LTEMAC_SPS
   YsUeCb    *ueCb = NULLP;
#endif
   U16 indx = cellCb->cellId-CM_START_CELL_ID;

   TRC2(ysMsUtlFillAndAddDci0HiInfo)

#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = cellCb->dlEncL1Msgs[tfuCntrlReq->ulTiming.subframe].pDci0HiVector;
   if(NULLP == pElem)
   {
      stop_printf("pElem is NULL\n");
   }
   pDci0HiVector = (PHIADCIULMSGDESC)(pElem + 1);
#else
#ifdef BATCH_PROCESSING_DL
   pElem = ysMsUtlGetPhyListElem();
   if (!pElem)
   {
     /* HARQ_DBG */
      RLOG2(L_FATAL,"Memory Allocation failed for PHY list element for HiDci0 Vector "
               "at time (%d,%d)",
     cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
	  RETVALUE(RFAILED);
   }
   pElem->AlignOffset = sizeof(HIADCIULMSGDESC);
   pElem->NumMessageInBlock = 1; 
   pDci0HiVector = (PHIADCIULMSGDESC)(pElem + 1);
#endif
#endif

   pDci0HiVector->msgLength = sizeof(HIADCIULMSGDESC);
   pDci0HiVector->msgType     = PHY_TXHIADCIUL_REQ;
   pDci0HiVector->phyEntityId = cellCb->phyInstId;
   pDci0HiVector->subFrameNumber = tfuCntrlReq->ulTiming.subframe;
   pDci0HiVector->frameNumber = tfuCntrlReq->ulTiming.sfn;
   sfNum = pDci0HiVector->subFrameNumber;

   pDci0HiVector->numHiSdus             = tfuCntrlReq->phichLst.count;
#ifdef EMTC_ENABLE
   pDci0HiVector->numDciUlSdus          = tfuCntrlReq->ulPdcchLst.count + tfuCntrlReq->ulMpdcchLst.count;
#else
   pDci0HiVector->numDciUlSdus          = tfuCntrlReq->ulPdcchLst.count;
#endif
   //SID_END
   pDci0HiVector->reserved              = 0;
   RLOG_NULL(L_UNUSED,"Num of DCI0:values (%d) (%d) ",
   pDci0HiVector->numHiSdus, pDci0HiVector->numDciUlSdus);


   pUlCntrl = &cellCb->dlEncL1Msgs[sfNum].ulCntrl;
   channelIdx = cellCb->dlEncL1Msgs[sfNum].numChannels;

#ifndef BATCH_PROCESSING_DL
   /* Add HiDci0 vector to the linked list of PHY messages */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
   pElem = ysMsUtlGetPhyListElem();
#endif
   if (!pElem)
   {
     /* HARQ_DBG */
      RLOG2(L_FATAL,"ysMsUtlAllocSvsrMsg failed for PHY list element for HiDci0 Vector"
            "at time (%d,%d)",
            cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
      RETVALUE(RFAILED);
   }
   YS_MS_FILL_PHY_LIST_ELEM(pElem, pDci0HiVector->frameNumber, pDci0HiVector->subFrameNumber,
          ysGetPhyPtr(pDci0HiVector), sizeof(HIADCIULMSGDESC), PHY_TXHIADCIUL_REQ);
#else
   YS_MS_FILL_PHY_LIST_ELEM(pElem, pDci0HiVector->frameNumber, 
         pDci0HiVector->subFrameNumber,
         NULLP, sizeof(HIADCIULMSGDESC), PHY_TXHIADCIUL_REQ);
#endif

   ysMsUtlAddToPhyList(pUlCntrl,pElem);
#ifdef BATCH_PROCESSING_DL
#ifdef EMTC_ENABLE
   if((tfuCntrlReq->phichLst.count > 0) || 
      (tfuCntrlReq->ulPdcchLst.count > 0) ||
      (tfuCntrlReq->ulMpdcchLst.count >0))
#else
   if((tfuCntrlReq->phichLst.count > 0) || 
      (tfuCntrlReq->ulPdcchLst.count > 0)) 
#endif
   {
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
#ifdef EMTC_ENABLE
      U32 l1Size = sizeof(MAC2PHY_QUEUE_EL) + (tfuCntrlReq->phichLst.count 
      						+ tfuCntrlReq->ulPdcchLst.count + tfuCntrlReq->ulMpdcchLst.count) * 32;
#else
      U32 l1Size = sizeof(MAC2PHY_QUEUE_EL) + (tfuCntrlReq->phichLst.count	+ tfuCntrlReq->ulPdcchLst.count) * 32;
#endif
      pElem = ysMsUtlGetPhyListElem(l1Size);
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG :TODO: need to free the allocated messages */
         RLOG_ARG2(L_FATAL,DBG_CELLID,cellCb->cellId,"Memory Allocation failed "
               "for PHY list element for HI SDU at time(%d,%d)",
               cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
         RETVALUE(RFAILED);
      }
      pElem->AlignOffset = 32;
#ifdef EMTC_ENABLE
      if(tfuCntrlReq->ulMpdcchLst.count > 0)
      {
         pElem->AlignOffset = sizeof(DCIULCATMSDUMSG);/* size of catm dci sdu is more than 32 (it is 36)  */
      }
#endif

      pElem->NumMessageInBlock = 0;
      pStrtAddr = (U8 *)(pElem + 1);
   }
#endif


   /* Fill the structure with PHICH list, PHICHs */
   for (cmLstEnt = tfuCntrlReq->phichLst.first;cmLstEnt
#ifdef BATCH_PROCESSING_DL
         && pStrtAddr
#endif
;
             cmLstEnt = cmLstEnt->next, channelIdx++)
   {
      phichInfo = (TfuPhichInfo*)(cmLstEnt->node);
#ifdef BATCH_PROCESSING_DL
      phyTxSdu.txSduReq = (PGENMSGDESC )pStrtAddr; 
      pElem->NumMessageInBlock++;
      pStrtAddr = pStrtAddr + pElem->AlignOffset;
#endif

#ifndef TFU_TDD
      if (ysMsUtlFillDci0HiSdu(&phyTxSdu, phichInfo, NULLP, PHICH,
               channelIdx, cellCb) != ROK)
#else
      if (ysMsUtlFillDci0HiSdu(&phyTxSdu, phichInfo, NULLP, PHICH,
               channelIdx, cellCb, tfuCntrlReq->ulTiming.subframe) != ROK)
#endif
      {
         /* YS_MS_FREE(phyTxSdu, sizeof(YsPhyTxSdu)); */
         RETVALUE(RFAILED);
      }

      /* Add Hi SDUs to the linked list of PHY messages */

#ifndef BATCH_PROCESSING_DL
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG :TODO: need to free the allocated messages */
         RLOG_ARG2(L_FATAL,DBG_CELLID,cellCb->cellId,"Memory Allocation failed for"
               "PHY list element for HI SDU at time(%d,%d)",
               cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);
         RETVALUE(RFAILED);
      }
      YS_MS_FILL_PHY_LIST_ELEM(pElem, pDci0HiVector->frameNumber, pDci0HiVector->subFrameNumber,
	      ysGetPhyPtr(phyTxSdu.txSduReq), sizeof(HIINFOMSGDESC), PHY_TXHISDU_REQ);
      ysMsUtlAddToPhyList(pUlCntrl,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
#endif
      phyTxSdu.txSduReq = NULLP;
      phyTxSdu.sduLen = 0;

   }

#if 1
   PGENMSGDESC pMsgDesc;
   U8 dlsfNum = 0;
   DLCMNTXPWRCTL  *dlCmnPwrCtl = NULLP;
   /* Get the Tx Vector for updating the channel descriptors. */
   dlsfNum = (sfNum + (TFU_DELTA - TFU_ULCNTRL_DELTA)) % YS_NUM_SUB_FRAMES;
   pMsgDesc = (PGENMSGDESC ) cellCb->dlEncL1Msgs[dlsfNum].txVector;
   txVector = (PDLSUBFRDESC)(pMsgDesc + 1);
   dciCh = (DCICHANNELDESC *)&txVector->dlCh[7];
   chIdx = txVector->numberofChannelDescriptors;
#endif

   /* Fill the structure with ulPdcchLst, DCI Format 0 */
   for (cmLstEnt = tfuCntrlReq->ulPdcchLst.first; cmLstEnt;
         cmLstEnt = cmLstEnt->next, channelIdx++)
   {
      pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);
      if((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3) || 
            ((pdcchInfo->dci.dciFormat == TFU_DCI_FORMAT_3A)))
      {
#ifdef BATCH_PROCESSING_DL
         if (chIdx < MAXCHSUBFRAME)
         {
            phyTxSdu.txSduReq = (PGENMSGDESC)pStrtAddr;
            if (ysMsUtlFillDCIChanDesc(pdcchInfo, cellCb, &phyTxSdu, 
                     &dciCh[chIdx], chIdx, tfuCntrlReq->ulTiming) == RFAILED)
            {
               RETVALUE(RFAILED);
            }
            chIdx++;
#if 1
            txVector->numCtrlChannels += 1;
            //dci3flg = 1;
#endif
            pElem->NumMessageInBlock++;
            pStrtAddr = pStrtAddr + pElem->AlignOffset;
         }
         (pDci0HiVector->numDciUlSdus)--;
         channelIdx--;
#else
         (pDci0HiVector->numDciUlSdus)--;
         channelIdx--;
         continue;
#endif
      }
      else 
      {
/*      RLOG2(L_FATAL, "ysMsUtlFillAndAddDci0HiInfo filling PHICH at :(%d,%d) ",
               cellCb->timingInfo.sfn, cellCb->timingInfo.subframe);*/
#ifdef BATCH_PROCESSING_DL
         phyTxSdu.txSduReq = (PGENMSGDESC )pStrtAddr;
         pElem->NumMessageInBlock++;
         pStrtAddr = pStrtAddr + pElem->AlignOffset;
#endif
#ifndef TFU_TDD
         if (ysMsUtlFillDci0HiSdu(&phyTxSdu, NULLP, pdcchInfo, PDCCH,
                  channelIdx, cellCb) != ROK)
#else
            if (ysMsUtlFillDci0HiSdu(&phyTxSdu, NULLP, pdcchInfo, PDCCH,
                     channelIdx, cellCb,  tfuCntrlReq->ulTiming.subframe ) != ROK)
#endif
            {
               /* YS_MS_FREE(phyTxSdu, sizeof(YsPhyTxSdu)); */
               RETVALUE(RFAILED);
            }
      }


#ifdef LTEMAC_SPS
      if (pdcchInfo->isSpsRnti == TRUE)
      {
         /* rnti field of pdcchInfo is SPS Rnti */
         cmHashListFind(&cellCb->spsRntiHLst, (U8 *)&pdcchInfo->rnti,
               sizeof(CmLteRnti), 0, (PTR *)&ueCb);

         if ((ueCb != NULLP) && (ueCb->ueId != pdcchInfo->crnti))
         {
            cmHashListDelete (&(cellCb->spsRntiHLst), (PTR)ueCb);
            ueCb = NULLP;
         }

         if (NULLP == ueCb)
         {
            cmHashListFind(&ysCb.ueHLst[indx], (U8 *)&pdcchInfo->crnti,
                  sizeof(CmLteRnti), 0, (PTR *)&ueCb);
            ueCb->spsRnti = pdcchInfo->rnti;
            /* Duplicate check is done in insert */
            if(cmHashListInsert (&(cellCb->spsRntiHLst), (PTR)ueCb,
                     (U8 *)&ueCb->spsRnti, sizeof(CmLteRnti)) != ROK)
            {
               RLOG_ARG0(L_ERROR,DBG_CRNTI,pdcchInfo->rnti,"cmHashListInsert returned failed ");
               MSPD_ERR("cmHashListInsert returned failed \n");
            }
         }
      }
#endif
#ifndef BATCH_PROCESSING_DL
      /* Add DCI0 SDUs to the linked list of PHY messages */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG :TODO: need to free the allocated messages */
         RLOG_ARG2(L_ERROR,DBG_CELLID,cellCb->cellId,"Memory Allocation failed for PHY list element %d"
               "for DCI0 SDU %d", cellCb->timingInfo.sfn, 
               cellCb->timingInfo.subframe);
         RETVALUE(RFAILED);
      }
      YS_MS_FILL_PHY_LIST_ELEM(pElem, pDci0HiVector->frameNumber, pDci0HiVector->subFrameNumber,
              ysGetPhyPtr(phyTxSdu.txSduReq), sizeof(DCIULSDUMSG), PHY_TXDCIULSDU_REQ);
      ysMsUtlAddToPhyList(pUlCntrl,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
#endif

      phyTxSdu.txSduReq = NULLP;
      phyTxSdu.sduLen = 0;
   }
#ifdef EMTC_ENABLE
	/* Fill the structure with ulMpdcchLst, DCI Format 60-A */
   for (cmLstEnt = tfuCntrlReq->ulMpdcchLst.first; cmLstEnt;
         cmLstEnt = cmLstEnt->next, channelIdx++)
	{
      pdcchInfo = (TfuPdcchInfo*)(cmLstEnt->node);    

#ifndef TFU_TDD
#ifdef BATCH_PROCESSING_DL
      phyTxSdu.txSduReq = (PGENMSGDESC )pStrtAddr;
      pElem->NumMessageInBlock++;
      pStrtAddr = pStrtAddr + pElem->AlignOffset;
#endif
      if (ysMsUtlFillDci0HiSdu(&phyTxSdu, NULLP, pdcchInfo, MPDCCH,
               channelIdx, cellCb) != ROK)
#else
      if (ysMsUtlFillDci0HiSdu(&phyTxSdu, NULLP, pdcchInfo, MPDCCH,
               channelIdx, cellCb,  tfuCntrlReq->ulTiming.subframe ) != ROK)
#endif
      {
         /* YS_MS_FREE(phyTxSdu, sizeof(YsPhyTxSdu)); */
         RETVALUE(RFAILED);
      }
      
#ifndef BATCH_PROCESSING_DL
      /* Add DCI0 SDUs to the linked list of PHY messages */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
      pElem = ysMsUtlGetPhyListElem();
#endif
      if (!pElem)
      {
         /* HARQ_DBG :TODO: need to free the allocated messages */
         RLOG_ARG2(L_ERROR,DBG_CELLID,cellCb->cellId,"Memory Allocation failed for PHY list element %d"
               "for DCI0 SDU %d", cellCb->timingInfo.sfn, 
               cellCb->timingInfo.subframe);
         RETVALUE(RFAILED);
      }
      YS_MS_FILL_PHY_LIST_ELEM(pElem, pDci0HiVector->frameNumber, pDci0HiVector->subFrameNumber,
              ysGetPhyPtr(phyTxSdu.txSduReq), sizeof(DCIULCATMSDUMSG), PHY_TXDCICATMSDU);
      ysMsUtlAddToPhyList(pUlCntrl,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
#endif

      phyTxSdu.txSduReq = NULLP;
      phyTxSdu.sduLen = 0;
   }
#endif
#if 1
   if(chIdx > txVector->numberofChannelDescriptors)
   {
      dlCmnPwrCtl = (DLCMNTXPWRCTL* )&dciCh[chIdx];
#ifndef ALIGN_64BIT
      txVector->offsetPowerCtrl   = (U32)dlCmnPwrCtl - (U32)txVector;
#else
      txVector->offsetPowerCtrl   = (U64)dlCmnPwrCtl - (U64)txVector;
#endif
      // selva use chIdx instead of channelIdx
      txVector->numberofChannelDescriptors = chIdx;
      dlCmnPwrCtl->pilotPower     = cellCb->cellCfg.pilotSigPwr;
      dlCmnPwrCtl->psyncPower     = cellCb->cellCfg.priSigPwr;
      dlCmnPwrCtl->ssyncPower     = cellCb->cellCfg.secSigPwr;
      dlCmnPwrCtl->prsRa          = 0;
      dlCmnPwrCtl->ciPower        = 0;
   }
#endif
#ifdef BATCH_PROCESSING_DL
		//TODO_SID need to check wat sizeof shpuld be present here
      YS_MS_FILL_PHY_LIST_ELEM(pElem, pDci0HiVector->frameNumber, pDci0HiVector->subFrameNumber,
      		                   NULLP, sizeof(DCIULSDUMSG), PHY_BATCH_MSG_REQ);

      pElem->MessageLen = (pStrtAddr - (U8 *)(pElem) - sizeof(MAC2PHY_QUEUE_EL));

      ysMsUtlAddToPhyList(pUlCntrl,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
#endif

   cellCb->dlEncL1Msgs[sfNum].numChannels = channelIdx;
   RETVALUE(ROK);
} /* end of ysMsUtlFillAndAddDci0HiInfo */

/*
*
*       Fun:   ysMsUtlFillMappingInfo
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC Void ysMsUtlFillMappingInfo
(
YsCellCb        *cellCb,
U32             riv,
U8              *startRb,
U8              *numRb
)
{
   TRC2(ysMsUtlFillMappingInfo)
   U8 numRb1, startRb1;
   U8 bW = 0;
#ifdef EMTC_ENABLE   
   bW = 6; /* 36.213 7.1.6.3 .NDlRb = 6*/
#else   
   bW = cellCb->cellInfo.dlBw;
#endif   

   /*-- Logic for obtaining startRes, numRes can be found in R1-072119 --*/
   numRb1 = (riv / bW) + 1;
   startRb1 = riv % bW;

   if ((numRb1 + startRb1) > bW)
   {
      *numRb = bW + 2 - numRb1;
      *startRb = bW -1 - startRb1;
   }
   else
   {
      *numRb = numRb1;
      *startRb = startRb1;
   }

   RETVOID;
}

/*
 *
 *       Fun:   ysMsUtlCalcStartRes
 *
 *       Desc: calculates the start RB accroding to the system bandwidth 
 *              for given narrowBand
 *
 *
 *       Ret:
 *
 *       Notes: None
 *
 *       File:  ys_ms_utl.c
 *
 */

PUBLIC U8 ysMsUtlCalcStartRes
(
 YsCellCb        *cellCb,
 U8               nbIdx
 )
{
   TRC2(ysMsUtlCalcStartRes)
   U8  numNB; 
   U8  startRb;
   U8  cellMod ;
   U8  startRes;
   /*Calculate total number of narrowBand for system Bandwidth*/
   numNB   = cellCb->cellInfo.dlBw/6;
   /*calculate startRB for a given system Bandwidth */
   startRb = (cellCb->cellInfo.dlBw/2) - ((6 * numNB)/2);
   /* calculate value of i0 as per 36.211 section 6.2.7 */
   cellMod = (cellCb->cellInfo.dlBw % 2);
   

   /* this check is for calculating start RB according to the bandwidth as per 36.211 section 6.2.7
    for 20 MHZ, start 2 RB and end  2 RB's are unused 
    for 10 MHZ , start 1 RB and end 1 RB is unused
    for 15 MHZ,  start 1 RB , middle 1 RB and end 1 RB is unused */
   if(0 == cellMod)
   {
      startRes = 6 * nbIdx + startRb;
   }
   else
   {
      /* if narrowBand index is less than total number of narrwband divided by 2 */
      if(nbIdx < (numNB/2))
      {
         startRes = 6 * nbIdx + startRb;
      }
      /*if narrowBand index is grether than total number of narrowBand divided by 2 then skip one Rb*/
      else
      {
         startRes = 6 * nbIdx + startRb + 1;
      }
   }
   RETVALUE(startRes);
}

/*
*
*       Fun:   ysMsUtlFillMappingInfoForRaType0
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PRIVATE Void ysMsUtlFillMappingInfoForRaType0
(
YsCellCb        *cellCb,
U8              *resAllocMap,
MAPPINGINFO     *phymap
)
{
#define IS_BIT_SET(_a, _i)  ((_a) & (1<<(_i)))
   U32  i, j;
   U32  n;
   U8   rbgSize = cellCb->cellInfo.rbgSize;
   U8   dlBw    = cellCb->cellInfo.dlBw;

   n = 0;
   for (i = 0; i < TFU_MAX_ALLOC_BYTES; ++i)
   {
      U8  base = i * 8;
      if (!resAllocMap[i])
         continue;
      for (j = 0; j < 8; ++j)
      {
         if (IS_BIT_SET(resAllocMap[i], 7-j))
         {
            phymap->reselmInfo[n].startRes = (base + j) * rbgSize;
            phymap->reselmInfo[n].numRes   = rbgSize;
            ++n;
         }
      }
   }
   if (phymap->reselmInfo[n-1].startRes + phymap->reselmInfo[n-1].numRes > dlBw)
      phymap->reselmInfo[n-1].numRes =  dlBw - phymap->reselmInfo[n-1].startRes;
   RASSERT_COREDUMP(n <= MAXMAPCNT);
   phymap->numberofEntries = n;
   if (phymap->numberofEntries == 0)
      RLOG0(L_ERROR,"<TX SDU size 0>Invalid Tx vector being sent");
   for (i = j = 0; i < n; ++i)
   {
      j += phymap->reselmInfo[i].numRes;
   }
   RASSERT_COREDUMP(j != 0);
}

/*
*
*       Fun:   ysMsUtlFillDlChanDesc
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC S16 ysMsUtlFillDlChanDesc
(
TfuDatReqPduInfo *tfuDatReqPdu,
TfuPhichInfo    *phichInfo,
YsCellCb        *cellCb,
PDLCHANDESC     dlCh,
U8              channelType,
U16             channelId,
CmLteTimingInfo timingInfo
)
{
   TRC2(ysMsUtlFillDlChanDesc)
   /*-- Only one sub-channel info is filled as numCodeWords is always one --*/
   PDLSUBCHINFO subChInfo = &dlCh->subChInfo[0];
   YsUeCb     *ueCb;
   PDLSUBCHINFO subChInfoCw2 = &dlCh->subChInfo[1];
   U8 cw1index = 0;
   U8 cw2index = 0;

  /* dlMsgLst = &(cellCb->dlEncL1Msgs[(cellCb->timingInfo.subframe + TFU_DELTA)
         % YS_NUM_SUB_FRAMES].txSduLst); */
   /* Changed these values on inputs from MSPD */
   dlCh->persistEnable = TRUE;
   dlCh->repeatCycle = 1;
   /* API change for 3.8.2.8 */
   dlCh->channelType = channelType;
   dlCh->numCodeWords = 1;
   dlCh->nLayers = cellCb->cellInfo.numAntPorts;
   dlCh->transmissionMode = cellCb->cellInfo.cmnTransMode;
   /* Adding channel Id */
   dlCh->channelId = channelId;
   /* initialize the num entries for mapping */
   dlCh->mapInfo.numberofEntries = 0;
   dlCh->dlPrecoderInfo.cddType = NOCDD;
   dlCh->dlPrecoderInfo.codeBookIdx = 0;
   cmMemset(dlCh->dlPrecoderInfo.codebookSubsetRestriction, 0, 8);

#ifdef EMTC_ENABLE
	dlCh->catMenabled = cellCb->cellInfo.catMenabled;
#endif

#ifdef YS_PHY_3_8_2
   dlCh->distributedFlag = 0; //VZ: for 3.8.2
#endif
   switch(channelType)
   {
      case PDSCH:
         ueCb = ysMsCfgGetUe(cellCb, tfuDatReqPdu->rnti);
         if (ueCb)
         {
            dlCh->ueCategory =  ueCb->ueCfg.ueCatCfg.ueCategory;
#ifdef CA_PHY
            dlCh->ueTransmissionMode = tfuDatReqPdu->transMode;
#endif /* LTE_ADV */ 
            /*ccpu00144611 - Fix for SISO compilation -start */
#ifdef PHY_3828
            dlCh->ueTransmissionMode = tfuDatReqPdu->transMode ;
#endif
#ifdef EMTC_ENABLE
            dlCh->catMenabled = ueCb->isEmtcUe;
#endif

            /*ccpu00144611 - Fix for SISO compilation -end */
         }
         else
         {
            dlCh->ueCategory = 5;
            tfuDatReqPdu->pa = 4;/* 0 db*/
         }
         /* Filling txpowerControl value based on the pa value 
          * received from MAC */
         dlCh->txpowerControl = txPowerCntrlMap[tfuDatReqPdu->pa];
         dlCh->crcInfo.crcLength = TWTYFOUR; /*-- 36.212 - 5.3.2.1 --*/
         dlCh->crcInfo.crcScrambling = 1;
         dlCh->scrInfo.scrinitValueinput = tfuDatReqPdu->rnti;
         subChInfo->codingDescriptor = TURBOCDR;
         subChInfo->blockCodeConcatenation = 1;

         /*-- based on the DCI format we fill sub channel info --*/
         switch(tfuDatReqPdu->dciInfo.format)
         {
            case TFU_DCI_FORMAT_1A:
               {
                  TfuDciFormat1aAllocInfo *format1a = 
                     &tfuDatReqPdu->dciInfo.u.format1aAllocInfo;
                  dlCh->hCid = format1a->harqProcId.val;
                  /* MS_FIX: syed If it is a BCCH/PCCH/RAR transmission
                   * then set modulation Type to QPSK regardless of iMcs */
                  if ((tfuDatReqPdu->rnti == YS_SI_RNTI) || 
                        (tfuDatReqPdu->rnti == YS_P_RNTI) || 
                        (tfuDatReqPdu->rnti <= YS_MAX_RARNTI))
                  {
                     subChInfo->modulationType = QPSK;
                  }
                  else
                  {
                     subChInfo->modulationType = ModulationType[format1a->mcs];
                  }
                  subChInfo->mcsType = format1a->mcs;
                  dlCh->hCid = format1a->harqProcId.val;
                  subChInfo->nDi = format1a->ndi;
                  subChInfo->rV = format1a->rv;
                  subChInfo->flushReq = 0;
                  dlCh->mapInfo.numberofEntries = 1;
                  ysMsUtlFillMappingInfo(cellCb, format1a->alloc.u.riv,
                        &dlCh->mapInfo.reselmInfo[0].startRes,
                        &dlCh->mapInfo.reselmInfo[0].numRes);
                  RASSERT_COREDUMP(dlCh->mapInfo.reselmInfo[0].numRes != 0);
                  break;
               }
            case TFU_DCI_FORMAT_1:
               {
                  TfuDciFormat1AllocInfo *format1 = 
                     &tfuDatReqPdu->dciInfo.u.format1AllocInfo;
                  dlCh->hCid = format1->harqProcId;
                  subChInfo->modulationType = ModulationType[format1->mcs];
                  subChInfo->mcsType = format1->mcs;
                  subChInfo->nDi = format1->ndi;
                  subChInfo->rV = format1->rv;
                  subChInfo->flushReq = 0;
                  dlCh->mapInfo.numberofEntries = 0;
                  if (format1->isAllocType0)
                     ysMsUtlFillMappingInfoForRaType0(cellCb, 
                           format1->resAllocMap,
                           &dlCh->mapInfo);
                  break;
               }
#ifdef NOT_SUPPORTED_BY_MAC
            case TFU_DCI_FORMAT_1B:
               {
                  TfuDciFormat1bAllocInfo *format1b = 
                     &tfuDatReqPdu->dciInfo.u.format1bAllocInfo;
                  dlCh->hCid = format1b->harqProcId;
                  subChInfo->mcsType = format1b->mcs;
                  subChInfo->modulationType = ModulationType[format1b->mcs];
                  /*TODO:Changing this for the moment as per Vitaliy inputs, 
                    revert it if this chnage is not permanent.*/
                  subChInfo->nDi = format1b->ndi;
                  subChInfo->rV = format1b->rv;
                  subChInfo->flushReq = 0;
                  break;
               }
            case TFU_DCI_FORMAT_1C:
               {
                  subChInfo->modulationType = BPSK;
                  break;
               }
            case TFU_DCI_FORMAT_1D:
               {
                  TfuDciFormat1dAllocInfo *format1d = 
                     &tfuDatReqPdu->dciInfo.u.format1dAllocInfo;
                  subChInfo->mcsType = format1d->mcs;
                  subChInfo->modulationType = ModulationType[format1d->mcs];
                  subChInfo->rV = format1d->rv;

                  dlCh->hCid = format1d->harqProcId;
                  break;
               }
#endif
            case TFU_DCI_FORMAT_2:
               {
                  TfuDciFormat2AllocInfo *format2AllocInfo = 
                     &tfuDatReqPdu->dciInfo.u.format2AllocInfo;
                  if (format2AllocInfo->transSwap)
                  {
                     cw1index = 1;
                  }
                  else
                  {
                     cw2index = 1;
                  }

                  if(1 != tfuDatReqPdu->nmbOfTBs)  /*When there are Two TBs*/
                  {
                     dlCh->dlPrecoderInfo.cddType = NOCDD;
                     subChInfo->mcsType = format2AllocInfo->tbInfo[cw1index].mcs;
                     subChInfo->modulationType = 
                        ModulationType[subChInfo->mcsType];
                     subChInfo->rV = format2AllocInfo->tbInfo[cw1index].rv;
		     
                     dlCh->hCid = format2AllocInfo->harqProcId;
                     subChInfo->nDi = format2AllocInfo->tbInfo[cw1index].ndi;
                     subChInfo->flushReq = 0;/* need to revisit this */

                     dlCh->numCodeWords = 1;
                     /* If 2nd TB is available then we need to have 2 CWs */
                     if( !((format2AllocInfo->tbInfo[1].mcs == 0 ) && 
                              (format2AllocInfo->tbInfo[1].rv == 1)))
                     {
                        dlCh->numCodeWords++;

                        subChInfoCw2->codingDescriptor = TURBOCDR;
                        subChInfoCw2->blockCodeConcatenation = 1;
                        subChInfoCw2->mcsType = 
                           format2AllocInfo->tbInfo[cw2index].mcs;
                        subChInfoCw2->modulationType = 
                           ModulationType[subChInfoCw2->mcsType];
                        subChInfoCw2->rV = format2AllocInfo->tbInfo[cw2index].rv;

			dlCh->hCid = format2AllocInfo->harqProcId;
                        subChInfoCw2->nDi = 
                           format2AllocInfo->tbInfo[cw2index].ndi;
                        subChInfoCw2->flushReq = 0;/* need to revisit this */
                        dlCh->transmissionMode = CLSLPSPMUX;
                     }
                  }
                  else if((format2AllocInfo->tbInfo[1].mcs == 0 ) && 
                        (format2AllocInfo->tbInfo[1].rv == 1))
                  {
                     subChInfo->mcsType = format2AllocInfo->tbInfo[0].mcs;
                     subChInfo->modulationType = 
                        ModulationType[subChInfo->mcsType];
                     subChInfo->rV = format2AllocInfo->tbInfo[0].rv;
		     
                     dlCh->hCid = format2AllocInfo->harqProcId;
                     subChInfo->nDi = format2AllocInfo->tbInfo[0].ndi;
                     subChInfo->flushReq = 0;/* need to revisit this */

                     dlCh->numCodeWords = 1;
                     dlCh->dlPrecoderInfo.cddType = NOCDD;
                     dlCh->transmissionMode = TXDIVERSITY;
                  }
                  else
                  {
                     MSPD_DBG("Retransmitting 1st TB alone with TM2 mode \
                           Filling TX vector\n");
                     subChInfo->mcsType = format2AllocInfo->tbInfo[1].mcs;
                     subChInfo->modulationType = 
                        ModulationType[subChInfo->mcsType];
                     subChInfo->rV = format2AllocInfo->tbInfo[1].rv;
		     dlCh->hCid = format2AllocInfo->harqProcId;
                     subChInfo->nDi = format2AllocInfo->tbInfo[1].ndi;
                     subChInfo->flushReq = 0;/* need to revisit this */

                     dlCh->numCodeWords = 1;
                     dlCh->dlPrecoderInfo.cddType = NOCDD;
                     dlCh->transmissionMode = TXDIVERSITY;
                  }

                  if (cellCb->cellInfo.numAntPorts == 4 )
                  {
                     dlCh->nLayers = 
                        pmiNumOfLayerMap4AntPortDCI2[dlCh->numCodeWords - 1 ]
                        [format2AllocInfo->precoding];
                  }
                  else if (cellCb->cellInfo.numAntPorts == 2 )
                  {
                     dlCh->nLayers = 
                        pmiNumOfLayerMap2AntPortDCI2[dlCh->numCodeWords - 1 ]
                        [format2AllocInfo->precoding];
                  }
                  /* TODO MIMO set dlCh->dlPrecoderInfo.codeBookIdx */
                  dlCh->dlPrecoderInfo.codebookSubsetRestriction[0]=63; /* 0011 1111 */
                  dlCh->dlPrecoderInfo.codeBookIdx = 
                     precodingInfoToCbMap[dlCh->numCodeWords - 1][format2AllocInfo->precoding];
                  if (format2AllocInfo->isAllocType0)
                     ysMsUtlFillMappingInfoForRaType0(cellCb, 
                           format2AllocInfo->resAllocMap,
                           &dlCh->mapInfo);
                  else
                     RLOG0(L_ERROR,"CL: Unhandled resource allocation type");
                  break;
               }
            case TFU_DCI_FORMAT_2A:
               {
                  TfuDciFormat2AAllocInfo *format2AAllocInfo = 
                     &tfuDatReqPdu->dciInfo.u.format2AAllocInfo;
                  if (format2AAllocInfo->transSwap)
                  {
                     cw1index = 1;
                  }
                  else
                  {
                     cw2index = 1;
                  }

                  if(1 != tfuDatReqPdu->nmbOfTBs)
                  {
                     dlCh->dlPrecoderInfo.cddType = LARGECDD;
                     subChInfo->mcsType = format2AAllocInfo->tbInfo[cw1index].mcs;
                     subChInfo->modulationType = 
                        ModulationType[subChInfo->mcsType];
                     subChInfo->rV = format2AAllocInfo->tbInfo[cw1index].rv;
		     dlCh->hCid = format2AAllocInfo->harqProcId;
                     subChInfo->nDi = format2AAllocInfo->tbInfo[cw1index].ndi;
                     subChInfo->flushReq = 0;/* need to revisit this */

                     dlCh->numCodeWords = 1;
                     /* mimo_comment : merge these blocks */
                     if( !((format2AAllocInfo->tbInfo[1].mcs == 0 ) && 
                              (format2AAllocInfo->tbInfo[1].rv == 1)))
                     {
                        dlCh->numCodeWords++;

                        subChInfoCw2->codingDescriptor = TURBOCDR;
                        subChInfoCw2->blockCodeConcatenation = 1;
                        subChInfoCw2->mcsType = 
                           format2AAllocInfo->tbInfo[cw2index].mcs;
                        subChInfoCw2->modulationType = 
                           ModulationType[subChInfoCw2->mcsType];
                        subChInfoCw2->rV = format2AAllocInfo->tbInfo[cw2index].rv;
			dlCh->hCid = format2AAllocInfo->harqProcId;
                        subChInfoCw2->nDi = 
                           format2AAllocInfo->tbInfo[cw2index].ndi;
                        subChInfoCw2->flushReq = 0;/* need to revisit this */
                        /* Keep track of 2 codewords for HARQ, won't be 
                           needed post TFU UPGRADE */
#ifndef TFU_UPGRADE
                        ueCb->cwCount[timingInfo.subframe] = 2;
#endif
                        dlCh->transmissionMode = OPNLPSPMUX;
                     }
                  }
                  else if((format2AAllocInfo->tbInfo[1].mcs == 0 ) && 
                        (format2AAllocInfo->tbInfo[1].rv == 1))
                  {
                     dlCh->dlPrecoderInfo.cddType = LARGECDD;
                     subChInfo->mcsType = format2AAllocInfo->tbInfo[0].mcs;
                     subChInfo->modulationType = 
                        ModulationType[subChInfo->mcsType];
                     subChInfo->rV = format2AAllocInfo->tbInfo[0].rv;
                     subChInfo->nDi = format2AAllocInfo->tbInfo[0].ndi;
		     dlCh->hCid = format2AAllocInfo->harqProcId;
                     subChInfo->flushReq = 0;/* need to revisit this */

                     dlCh->numCodeWords = 1;
                     dlCh->transmissionMode = TXDIVERSITY;
                  }
                  else
                  {
                     RLOG0(L_DEBUG," Retransmitting 1st TB alone with TM2 mode Filling TX vector");
                     dlCh->dlPrecoderInfo.cddType = LARGECDD;
                     subChInfo->mcsType = format2AAllocInfo->tbInfo[1].mcs;
                     subChInfo->modulationType = 
                        ModulationType[subChInfo->mcsType];
                     subChInfo->rV = format2AAllocInfo->tbInfo[1].rv;

		     dlCh->hCid = format2AAllocInfo->harqProcId;
                     subChInfo->nDi = format2AAllocInfo->tbInfo[1].ndi;
                     subChInfo->flushReq = 0;/* need to revisit this */

                     dlCh->numCodeWords = 1;
                     dlCh->transmissionMode = TXDIVERSITY;
                  }

                  if (cellCb->cellInfo.numAntPorts == 4 )
                  {
                     dlCh->nLayers = 
                        pmiNumOfLayerMap4AntPortDCI2A[dlCh->numCodeWords - 1 ]
                        [format2AAllocInfo->precoding];

			if(dlCh->numCodeWords == 2)
			{
	                     if(dlCh->nLayers == 0)		
			      MSPD_ERR("MIMO_DBG::  case0 INVALID number of layers =%d\n",dlCh->nLayers);
			}
			else if(dlCh->nLayers == 2)  /* special ReTX case handling where Tx had 2CW but bcaz of nack ReTx is 1cw */
			{
			   dlCh->transmissionMode = OPNLPSPMUX;
			}
		//	else
		//	   printf("MIMO_DBG::  case1 INVALID number of layers =%d\n",dlCh->nLayers);
                  }
                  else
                  {
                     dlCh->nLayers = dlCh->numCodeWords;
                  }
                  /* TODO MIMO set dlCh->dlPrecoderInfo.codeBookIdx */
                  if (format2AAllocInfo->isAllocType0)
                     ysMsUtlFillMappingInfoForRaType0(cellCb, 
                           format2AAllocInfo->resAllocMap,
                           &dlCh->mapInfo);
                  else
                     RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"CL: Unhandled resource allocation type");
               }
               break;
#ifdef EMTC_ENABLE
            case TFU_DCI_FORMAT_6_1A:
               {
                  U8 riv = 0;
                  U8 nbIdx = 0;
                  //SID_INT
                  if (tfuDatReqPdu->rnti != YS_SI_RNTI)
                  {
                     dlCh->ueCategory = 0;
                  }
                  TfuDciFormat61AllocInfo *format61a = 
                     &tfuDatReqPdu->dciInfo.u.format61AllocInfo;
                  dlCh->hCid = format61a->harqProcId;

                  if ((tfuDatReqPdu->rnti == YS_SI_RNTI) || 
                        (tfuDatReqPdu->rnti == YS_P_RNTI) || 
                        (tfuDatReqPdu->rnti <= YS_MAX_RARNTI))
                  {
                     subChInfo->modulationType = QPSK;
                  }
                  else
                  {
                     subChInfo->modulationType = ModulationType[format61a->mcs];
                  }
                  subChInfo->mcsType = format61a->mcs;
                  subChInfo->nDi = format61a->ndi;
                  subChInfo->rV = format61a->rv;
                  subChInfo->flushReq = 0;
                  dlCh->mapInfo.numberofEntries = 1;
                  riv = format61a->riv & 0x0000001F;
                  nbIdx = format61a->riv >> 5;						
                  RLOG1(L_DEBUG, "RV in 61A is %d\n", subChInfo->rV);	

                  ysMsUtlFillMappingInfo(cellCb, riv,
                        &dlCh->mapInfo.reselmInfo[0].startRes,
                        &dlCh->mapInfo.reselmInfo[0].numRes);
                  RASSERT_COREDUMP(dlCh->mapInfo.reselmInfo[0].numRes != 0);
                  /* Above startRes will give the startRb within the narrowband
                     Below function will append the startRb within the entire bw */	
                  dlCh->mapInfo.reselmInfo[0].startRes += ysMsUtlCalcStartRes(cellCb,nbIdx);
                  /*printf("In ysMsUtlFillDlChanDesc :: startRes %d, dlBw %d, nbIdx %ld, numRes %d, riv %d, rnti %d, mcsType %d and orig_riv %ld\n",
                    dlCh->mapInfo.reselmInfo[0].startRes, cellCb->cellInfo.dlBw, nbIdx, dlCh->mapInfo.reselmInfo[0].numRes, 
                    riv, tfuDatReqPdu->rnti, subChInfo->mcsType, format61a->riv); 
                    printf("In ysMsUtlFillDlChanDesc :: nDi %d and rV %d \n",
                    subChInfo->nDi, subChInfo->rV); 
                    printf("In ysMsUtlFillDlChanDesc :: (%d,%d) and nbIdx %ld \n",
                    timingInfo.sfn, timingInfo.subframe, nbIdx); 
                    RLOG3(L_DEBUG, "In ysMsUtlFillDlChanDesc :: (%d,%d) and nbIdx %ld \n",  timingInfo.sfn, timingInfo.subframe, nbIdx);*/	
                  //dlCh->catMScramblerInitValue = format61a->scramblerInitValue;// + cellCb->cmnChScrInit;
                  dlCh->catMScramblerInitValue = format61a->scramblerInitValue;
                  break;
               }
            case TFU_DCI_FORMAT_6_2:
               {
                  U32 nbIdx = 0;
                  TfuDciFormat62AllocInfo *format62 =
                     &tfuDatReqPdu->dciInfo.u.format62AllocInfo;


                  if (tfuDatReqPdu->rnti == YS_P_RNTI)
                  {
                     subChInfo->modulationType = QPSK;
                  }
                  subChInfo->mcsType = format62->mcs;
                  subChInfo->nDi = 0;
                  subChInfo->rV = 0;
                  subChInfo->flushReq = 0;
                  dlCh->mapInfo.numberofEntries = 1;
                  nbIdx = format62->riv;
                  /* paging wil use entire narrowband. So startrb wil be the startrb of the narrowband*/
                  dlCh->mapInfo.reselmInfo[0].startRes = ysMsUtlCalcStartRes(cellCb,nbIdx);
                  dlCh->mapInfo.reselmInfo[0].numRes = 6;
                  dlCh->catMScramblerInitValue = format62->scramblerInitValue;
                  break;
               }

#endif
            default:
               {
                  RLOG1(L_ALWAYS,"Unhandled DCI format %d", tfuDatReqPdu->dciInfo.format);
                  RASSERT_COREDUMP(0);
               }
         }
         break;
      case PBCH:
         dlCh->txpowerControl = 0;
         subChInfo->codingDescriptor = TBVITCC;
         subChInfo->blockCodeConcatenation = YS_BLK_CODE_CAT_DIS;
         subChInfo->mcsType = 4;

         subChInfo->modulationType = QPSK;  /*  36.211 - 6.6.2 */
         dlCh->crcInfo.crcLength = SIXTEEN; /*-- 36.212 - 5.3.1 --*/
         dlCh->crcInfo.crcScrambling = 1;
         /* Mindspeed requires this value to be 0 as of now */
         /*TODO:Can compute this value one time and store it in a 
           parmeteter in Cell CB so that it doesn't
          * gets computed everytime*/
         dlCh->scrInfo.scrinitValueinput = cellCb->cmnChScrInit;
#ifdef EMTC_ENABLE
         dlCh->catMScramblerInitValue = cellCb->cmnChScrInit;
#endif

         break;
   }
#ifndef FOUR_TX_ANTENNA /* Need to verify for Singlecell and CA cases then remove this */
        /* Nawas:: the below settng is as per the suggestion given
        by Intel (sumesh). 
        Revisit this in case of Tm4*/
   dlCh->nLayers = dlCh->numCodeWords;

   if(dlCh->numCodeWords == 1)
   {
      if(cellCb->cellInfo.numAntPorts > 1)
      {
         dlCh->transmissionMode = TXDIVERSITY;
      }else
      {
         dlCh->transmissionMode = SINGLEANT;
      }
   }
#endif

   dlCh->scrInfo.scramblerType = DLSCR;
   RETVALUE(ROK);
}

extern U32 isLAAChanActive;
extern U32 enableLaaLBTSim ;
extern U32 lbtSndErrInd;
/*
*
*       Fun:   ysMsUtlFillDCIChanDesc
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

#ifdef BATCH_PROCESSING_DL
PUBLIC S16 ysMsUtlFillDCIChanDesc
(
TfuPdcchInfo    *pdcchInfo,
YsCellCb        *cellCb,
YsPhyTxSdu      *phyTxSdu,
PDCICHANNELDESC  dciCh,
U16              channelId,
CmLteTimingInfo  timingInfo
)
#else
PUBLIC S16 ysMsUtlFillDCIChanDesc
(
TfuPdcchInfo    *pdcchInfo,
YsCellCb        *cellCb,
PDCICHANNELDESC  dciCh,
U16              channelId,
CmLteTimingInfo  timingInfo
)
#endif
{
   TRC2(ysMsUtlFillDCIChanDesc)
   U16 tmpRnti = 0;
#ifndef BATCH_PROCESSING_DL
   /* HARQ */
   YsPhyTxSdu phyTxSdu;
#endif

   /* LBT SIMULATION */
#ifdef LTE_ADV
#if 1
   if ((CM_START_CELL_ID < cellCb->cellId) && (enableLaaLBTSim) && (isLAAChanActive == FALSE))
   {
      tmpRnti = 666;
      if (pdcchInfo->rnti >= 60 && pdcchInfo->rnti <500)
      {
         rgStats.inactivePdcchCount++;
         tmpRnti = pdcchInfo->rnti;
         pdcchInfo->rnti = 666;
      }
   }
#endif
#endif
   /*presently we do not have any parmaeter on CTF/TFU interface to derive
    * txpowerControl value, hence hardcoding it. We would eventually need to get
    * this parameter value from RRM/MAC. */
   dciCh->txpowerControl = 0; /* dci.u.format0Info.tpcCmd? */
   dciCh->reserved = 0;
   dciCh->reserved1 = 0;
   dciCh->numCodeWords = 1;
   dciCh->nLayers = cellCb->cellInfo.numAntPorts;
   dciCh->transmissionMode = cellCb->cellInfo.cmnTransMode;
   /*-- number of entries in the resource mapping info --*/
   dciCh->numberofEntries = 1;

   dciCh->channelType = PDCCH;
   dciCh->channelId = channelId;

   dciCh->crcLength = SIXTEEN;

   dciCh->startRes = pdcchInfo->nCce;
   switch(pdcchInfo->aggrLvl)
   {
      case CM_LTE_AGGR_LVL1:
         dciCh->numRes = 1;
         break;
      case CM_LTE_AGGR_LVL2:
         dciCh->numRes = 2;
         break;
      case CM_LTE_AGGR_LVL4:
         dciCh->numRes = 4;
         break;
      case CM_LTE_AGGR_LVL8:
         dciCh->numRes = 8;
         break;
#ifdef EMTC_ENABLE
      case CM_LTE_AGGR_LVL12:
         dciCh->numRes = 12;
         break;
      case CM_LTE_AGGR_LVL16:
         dciCh->numRes = 16;
         break;
      case CM_LTE_AGGR_LVL24:
         dciCh->numRes = 24;
         break;
#endif
      default:
         RLOG0(L_WARNING,"Invalid aggrLvl");
         break;
   }

   switch(pdcchInfo->dci.dciFormat)
   {
      case TFU_DCI_FORMAT_0:
         dciCh->crcScrambling = 1; /* 0 = Disabled or 1 = RNTI */
         dciCh->scrmblerInitValue = pdcchInfo->rnti;
         dciCh->reserved1 = 0; /*pdcchInfo->dci.u.format0Info.mcs; -- 
                                 temp change to see if CQI 14 CRC error goes away*/
         break;
      case TFU_DCI_FORMAT_1:
      case TFU_DCI_FORMAT_1A:
         dciCh->crcScrambling = 1; /* 0 = Disabled or 1 = RNTI */
         dciCh->scrmblerInitValue = pdcchInfo->rnti;

         dciCh->reserved1 = 0; /* pdcchInfo->dci.u.format1aInfo.t.pdschInfo.
                                  allocInfo.mcs; -- temp changes to see if 
                                  crc error on CQI 14 goes away */
         break;
      case TFU_DCI_FORMAT_2:
         {

            dciCh->crcScrambling = 1; /* 0 = Disabled or 1 = RNTI */
            dciCh->scrmblerInitValue = pdcchInfo->rnti;
            /* Doing work around for issuing the proper PUCCH format in the 
               reception request for multi TB case */
            /* TODO MIMO: codeword stuff should be handled as part of PDSCH, 
               not here */
            /* ueCb->ueSubFrInfo[timingInfo.subframe].cwCount = 
               dciCh->numCodeWords; */
            break;
         }

      case TFU_DCI_FORMAT_2A:
         {

            dciCh->crcScrambling = 1; /* 0 = Disabled or 1 = RNTI */
            dciCh->scrmblerInitValue = pdcchInfo->rnti;

            break;
         }
     case TFU_DCI_FORMAT_3:
        {
         dciCh->crcScrambling = 1;
         dciCh->scrmblerInitValue = pdcchInfo->rnti;
         break;
         }
      case TFU_DCI_FORMAT_3A:
        {
         dciCh->crcScrambling = 1;
         dciCh->scrmblerInitValue = pdcchInfo->rnti;
         break;
         }
      //case TFU_DCI_FORMAT_1:
      case TFU_DCI_FORMAT_1B:
      case TFU_DCI_FORMAT_1C:
      case TFU_DCI_FORMAT_1D:
        {
         RLOG0(L_ERROR,"Unhandled DCI format");
         break;
         }
#ifdef LTEMAC_SPS
      case TFU_DCI_FORMAT_INVALID:
         {
         break;
         }
#endif
#ifdef EMTC_ENABLE
      case TFU_DCI_FORMAT_6_0A:
			{
            RLOG1(L_DEBUG, "Filing TxVector for DCI_FORMAT_6_0A, channel ID is %d\n", dciCh->channelId);
				dciCh->channelType = MPDCCH;
				dciCh->catMinUse = TRUE;
				dciCh->numberofEntries = 1; 
				dciCh->distributedAlloc = pdcchInfo->distributedAlloc; 
				dciCh->localizedAntPortIndex = pdcchInfo->localizedAntPortIndex;
				dciCh->dmrs_txpowerControl = pdcchInfo->dmrs_txpowerControl;
				
				//Need to add cases for higher aggregation level
            switch(pdcchInfo->aggrLvl)
            {
               case CM_LTE_AGGR_LVL1:
                  dciCh->MpdcchInfo[0].numCCE = 1;
                  break;
               case CM_LTE_AGGR_LVL2:
                  dciCh->MpdcchInfo[0].numCCE = 2;
                  break;
               case CM_LTE_AGGR_LVL4:
                  dciCh->MpdcchInfo[0].numCCE = 4;
                  break;
               case CM_LTE_AGGR_LVL8:
                  dciCh->MpdcchInfo[0].numCCE = 8;
                  break;
#ifdef EMTC_ENABLE
               case CM_LTE_AGGR_LVL12:
                  dciCh->MpdcchInfo[0].numCCE = 12;
                  break;
               case CM_LTE_AGGR_LVL16:
                  dciCh->MpdcchInfo[0].numCCE = 16;
                  break;
               case CM_LTE_AGGR_LVL24:
                  dciCh->MpdcchInfo[0].numCCE = 24;
                  break;
#endif
               default:
                  break;
            }
				dciCh->MpdcchInfo[0].nRBxm = pdcchInfo->nRBxm;
				dciCh->MpdcchInfo[0].startCCE = pdcchInfo->nCce;
				dciCh->MpdcchInfo[0].startRB = pdcchInfo->startRB;
				dciCh->MpdcchInfo[0].scramblerInit = pdcchInfo->scramblerInit;
				dciCh->MpdcchInfo[0].demodRSforMpdcchInitValue = pdcchInfo->demodRSInitValue;
            /* ADARSHA */
            break;
      	}
		case TFU_DCI_FORMAT_6_1A:
			{
            RLOG1(L_DEBUG, "Filing TxVector for DCI_FORMAT_6_1A, channel ID is %d\n", dciCh->channelId);
				dciCh->channelType = MPDCCH;
            dciCh->crcScrambling = 1;
				dciCh->catMinUse = TRUE;
				dciCh->numberofEntries = 1;
				dciCh->distributedAlloc = pdcchInfo->distributedAlloc; 
				dciCh->scrmblerInitValue = pdcchInfo->rnti;
				dciCh->localizedAntPortIndex = pdcchInfo->localizedAntPortIndex;
				dciCh->dmrs_txpowerControl = pdcchInfo->dmrs_txpowerControl;
				//Need to add cases for higher aggregation level
            switch(pdcchInfo->aggrLvl)
            {
               case CM_LTE_AGGR_LVL1:
                  dciCh->MpdcchInfo[0].numCCE = 1;
                  break;
               case CM_LTE_AGGR_LVL2:
                  dciCh->MpdcchInfo[0].numCCE = 2;
                  break;
               case CM_LTE_AGGR_LVL4:
                  dciCh->MpdcchInfo[0].numCCE = 4;
                  break;
               case CM_LTE_AGGR_LVL8:
                  dciCh->MpdcchInfo[0].numCCE = 8;
                  break;
#ifdef EMTC_ENABLE
               case CM_LTE_AGGR_LVL12:
                  dciCh->MpdcchInfo[0].numCCE = 12;
                  break;
               case CM_LTE_AGGR_LVL16:
                  dciCh->MpdcchInfo[0].numCCE = 16;
                  break;
               case CM_LTE_AGGR_LVL24:
                  dciCh->MpdcchInfo[0].numCCE = 24;
                  break;
#endif
               default:
                  break;
            }
				dciCh->MpdcchInfo[0].nRBxm = pdcchInfo->nRBxm;
				dciCh->MpdcchInfo[0].startCCE = pdcchInfo->nCce;
				dciCh->MpdcchInfo[0].startRB = pdcchInfo->startRB;
				dciCh->MpdcchInfo[0].scramblerInit = pdcchInfo->scramblerInit;
				dciCh->MpdcchInfo[0].demodRSforMpdcchInitValue = pdcchInfo->demodRSInitValue;
            /* ADARSHA */
            break;
			}
      case TFU_DCI_FORMAT_6_2:
         {
            RLOG1(L_DEBUG, "Filing TxVector for DCI_FORMAT_6_2, channel ID is %d\n", dciCh->channelId);
            dciCh->channelType = MPDCCH;
            dciCh->crcScrambling = 1;
            dciCh->catMinUse = TRUE;
            dciCh->numberofEntries = 1;
            dciCh->distributedAlloc = pdcchInfo->distributedAlloc; 
            dciCh->localizedAntPortIndex = pdcchInfo->localizedAntPortIndex;
            dciCh->dmrs_txpowerControl = pdcchInfo->dmrs_txpowerControl;
            dciCh->scrmblerInitValue = pdcchInfo->rnti;
            switch(pdcchInfo->aggrLvl)
            {
               case CM_LTE_AGGR_LVL1:
                  dciCh->MpdcchInfo[0].numCCE = 1;
                  break;
               case CM_LTE_AGGR_LVL2:
                  dciCh->MpdcchInfo[0].numCCE = 2;
                  break;
               case CM_LTE_AGGR_LVL4:
                  dciCh->MpdcchInfo[0].numCCE = 4;
                  break;
               case CM_LTE_AGGR_LVL8:
                  dciCh->MpdcchInfo[0].numCCE = 8;
                  break;
#ifdef EMTC_ENABLE
               case CM_LTE_AGGR_LVL12:
                  dciCh->MpdcchInfo[0].numCCE = 12;
                  break;
               case CM_LTE_AGGR_LVL16:
                  dciCh->MpdcchInfo[0].numCCE = 16;
                  break;
               case CM_LTE_AGGR_LVL24:
                  dciCh->MpdcchInfo[0].numCCE = 24;
                  break;
#endif
               default:
                  break;
            }
            dciCh->MpdcchInfo[0].nRBxm = pdcchInfo->nRBxm;
            dciCh->MpdcchInfo[0].startCCE = pdcchInfo->nCce;
            dciCh->MpdcchInfo[0].startRB = pdcchInfo->startRB;
            /* for below need to pass the TYPE1_CMN_SERAH SPACE in sch for correct value */
            dciCh->MpdcchInfo[0].scramblerInit = pdcchInfo->scramblerInit;
            dciCh->MpdcchInfo[0].demodRSforMpdcchInitValue = pdcchInfo->demodRSInitValue;

            break;
         }
#endif

       default:
       {
         RLOG1(L_ERROR,"Unhandled DCI format %d", pdcchInfo->dci.dciFormat);
         break;
       }
   }
   /*-- Fill the TxSdu --*/
#ifdef BATCH_PROCESSING_DL
   if (ysMsUtlFillTxSduForPDCCH(phyTxSdu, pdcchInfo, 
                                dciCh->channelId, cellCb) != ROK)
#else
   if (ysMsUtlFillTxSduForPDCCH(&phyTxSdu, pdcchInfo, 
                                dciCh->channelId, cellCb) != ROK)
#endif
   {
      MSPD_ERR("ysMsUtlFillTxSduForPDCCH failed!\n");
      RETVALUE(ROK);
   }
#ifndef BATCH_PROCESSING_DL
   /* Add this to the linked list of PHY messages */
   {
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      PMAC2PHY_QUEUE_EL pElem = ysMsUtlGetPhyListElem(sizeof(MAC2PHY_QUEUE_EL));
#else
      PMAC2PHY_QUEUE_EL pElem = ysMsUtlGetPhyListElem();
#endif
      YsPhyLstCp        *pDlCntrl = &cellCb->dlEncL1Msgs[timingInfo.subframe].dlCntrl;
      PTXSDUREQ         pTxSduReq       = (PTXSDUREQ)phyTxSdu.txSduReq;
      if (!pElem)
      {
         /* HARQ_DBG */
         RLOG0(L_FATAL, "ysMsUtlGetPhyListElem(): Memory allocation failed");
         RETVALUE(RFAILED);
      }
      YS_MS_FILL_PHY_LIST_ELEM(pElem, timingInfo.sfn, timingInfo.subframe,
            ysGetPhyPtr(pTxSduReq), phyTxSdu.sduLen, PHY_TXSDU_REQ);
      ysMsUtlAddToPhyList(pDlCntrl,pElem);
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
      YS_ADD_PELEM_L1MSG_LIST(cellCb->timingInfo.subframe, cellCb, pElem);
#endif
   }
#endif
#if 1
   /* LBT SIMULATION */
   if ((CM_START_CELL_ID < cellCb->cellId) && (enableLaaLBTSim) && (isLAAChanActive == FALSE))
   {
      if (tmpRnti >= 60 && tmpRnti <500)
      {
         pdcchInfo->rnti = tmpRnti;
      }
   }
#endif

   RETVALUE(ROK);
}

/*
*
*       Fun:   ysMsUtlPrntErrInfo
*
*       Desc:  Prints the Error Information
*
*       Ret:   void
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC Void ysMsUtlPrntErrInfo
(
U8         errCode
)
{

   TRC2(ysMsUtlPrntErrInfo);

   switch(errCode)
   {
      case 1:
         RLOG1(L_ERROR,"Error Code : %d Primitive is not Supported", 
                  errCode);
         break;
      case 2:
         RLOG1(L_ERROR,"Error Code : %d FEC Code Type is not Supported",
                  errCode);
         break;
      case 3:
         RLOG1(L_ERROR,"Error Code : %d Overrun", errCode);
         break;
      case 4:
         RLOG1(L_ERROR,"Error Code : %d Underrun", errCode);
         break;
      case 5:
         RLOG1(L_ERROR,"Error Code : %d Transport Media Error", errCode);
         break;
      case 6:
         RLOG1(L_ERROR,"Error Code : %d TX data size does not match TXVECTOR",
                               errCode);
         break;
      case 7:
         RLOG1(L_ERROR,"Error Code : %d Invalid TXVECTOR format", 
                  errCode);
         break;
      case 8:
         RLOG1(L_ERROR,"Error Code : %d Invalid RXVECTOR format", 
                  errCode);
         break;
      case 9:
         RLOG1(L_ERROR,"Error Code : %d RX CRC Error", errCode);
         break;
      case 10:
         RLOG1(L_ERROR,"Error Code : %d Transmit timeout with missing" 
                  "TXSDU", errCode);
         break;
      case 11:
         RLOG1(L_ERROR,"Error Code : %d Receiver did not match RXSDU"
                  "in RXVECTOR", errCode);
         break;
      case 12:
         RLOG1(L_ERROR,"Error Code : %d Timeout on TXSTART.req", 
                  errCode);
         break;
      case 13:
         RLOG1(L_ERROR,"Error Code : %d Timeout on RXSTART.req", 
                  errCode);
         break;
      case 14:
         RLOG1(L_ERROR,"Error Code : %d No Custom Extensions Handler" 
                  "Registered", errCode);
         break;
      default:
         RLOG1(L_WARNING,"Error Code : %d Unknown Error Code", errCode);
         break;
   }

   RETVOID;

} /* end of ysMsUtlPrntErrInfo */


/***********************************************************
 *
 *     Func : ysMsCalcRiv
 *
 *     Desc : This function calculates RIV.
 *
 *     Ret  : None.
 *
 *     Notes: None.
 *
 *     File :
 *
 **********************************************************/
PRIVATE U16 ysMsCalcRiv
(
U8           bw,
U8           rbStart,
U8           numRb
)
{
   U8           numRbMinus1 = numRb - 1;
   U16          riv;

   TRC2(ysMsCalcRiv);

   if (numRbMinus1 <= bw/2)
   {
      riv = bw * numRbMinus1 + rbStart;
   }
   else
   {
      riv = bw * (bw - numRbMinus1) + (bw - rbStart - 1);
   }
   RETVALUE(riv);
} /* rgMUXCalcRiv */

/* EXTERN Bool capDbg; */
/*
*
*       Fun:   ysMsUtlFillTxSduForPBCH
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_utl.c
*
*/
PUBLIC S16 ysMsUtlFillTxSduForPBCH
(
YsPhyTxSdu     *phyTxSdu,
TfuDatReqInfo *bchDatReq,
U16           channelId,
YsCellCb      *cellCb
)
{
   PTXSDUREQ  txSduReq;
   MsgLen     bufLen;
#ifndef YS_SCATTER_GATHER
   MsgLen     cLen;
#endif
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
   VOLATILE U32     startTime1 = 0;
#endif

   TRC2(ysMsUtlFillTxSduForPBCH)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (bchDatReq == NULLP)
   {
      RLOG0(L_ERROR,"ysMsUtlFillTxSduForPBCH(): invalid ptr");
      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */
   U16 indx = cellCb->cellId - CM_START_CELL_ID;

   /*starting Task*/
   SStartTask(&startTime, PID_CL_FILL_TXSDU);
#ifndef BATCH_PROCESSING_DL
#ifdef TENB_RTLIN_CHANGES
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   txSduReq = (PTXSDUREQ)ysAllocPhyMsg(sizeof(TXSDUREQ));
#else
   txSduReq = (PTXSDUREQ)ysAllocPhyMsg();
#endif
#else
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   txSduReq = (PTXSDUREQ)ysMsUtlAllocSvsrMsg(TRUE, sizeof(TXSDUREQ));
#else
   txSduReq = (PTXSDUREQ)ysMsUtlAllocSvsrMsg(TRUE);
#endif
#endif
#else
   txSduReq = (PTXSDUREQ)phyTxSdu->txSduReq;
#endif
   if (txSduReq == NULLP)
   {
      RLOG_ARG0(L_ERROR,DBG_CELLID,cellCb->cellId,"Failed to allocate memory for TXSDU");
      RETVALUE (RFAILED);
   }


   /*starting Task*/
   SStartTask(&startTime1, PID_CL_PBCH_DAT_REQ);
   SFndLenMsg(bchDatReq->bchDat.val, &bufLen);

   /*Length of MIB should be 24 bits, i.e. 3 bytes. Since word size is 
    * 4 bytes
    * however bufLen is set to 4, But we can set bufLen as 3 here 
    * to copy just 3 octets into pTxSdu.*/
#ifndef EMTC_ENABLE
   bufLen -= 1;
#endif

   /*For PBCH channel these parameters are not relevant, hence setting them to 0.*/
   txSduReq->nackAck = 0;
   txSduReq->uciFormat = 0;

   txSduReq->msgLen = bufLen;
   txSduReq->maxBitsperCw = (bufLen * 8);
   phyTxSdu->sduLen = sizeof(TXSDUREQ) + bufLen;


#ifdef YS_SCATTER_GATHER
   txSduReq->pTxSdu = 0;
   if (ysMsUtlCopyScatterBufPtr(bchDatReq->bchDat.val, bufLen, (Data*) (txSduReq + 1)) != ROK)
   {
      YS_MS_FREE(txSduReq, phyTxSdu->sduLen, indx);//sduLen error!
      RETVALUE(RFAILED);
   }   
#else
   /*-- Copy the mBuf into the flat buffer --*/
   /*Offset fix*/
   if(SCpyMsgFix(bchDatReq->bchDat.val, (MsgLen)0, bufLen,
               (Data*) (txSduReq + 1), &cLen) != ROK)
   {
      YS_MS_FREE(txSduReq, phyTxSdu->sduLen, indx);
      RETVALUE(RFAILED);
   }
#endif

   /*stopping Task*/
   SStopTask(startTime1, PID_CL_PBCH_DAT_REQ);

   txSduReq->chanId = channelId;
   txSduReq->msgType = PHY_TXSDU_REQ;
   txSduReq->phyEntityId = cellCb->phyInstId;
   txSduReq->channelType = PBCH;
   txSduReq->cwId = 0; /* Overridden by caller if needed (for mimo) */

   phyTxSdu->txSduReq = (PGENMSGDESC)txSduReq;

   /*stopping Task*/
   SStopTask(startTime, PID_CL_FILL_TXSDU);
   RETVALUE(ROK);
}

#ifdef YS_SCATTER_GATHER
#ifndef YS_PHY_3_8_2
static struct tl_cache_list_block tl_ioctl_l[MAX_SCATTERED_API_SDU];
#endif

/*
*
*       Fun:   ysMsUtlCopyScatterBufPtr 
*
*       Desc:  This function copies data from a message
*              into a fixed buffer.
*
*       Ret:   ROK - Success
*                RFAILED - Failure
*
*       Notes: None
*
*       File:  ys_ms_utl.c 
*
*/

#define TEST_MAC_RUP32B(x) (((x)+31)&(~31))

PRIVATE S16 ysMsUtlCopyScatterBufPtr
(
Buffer *srcMbuf,            /* source message buffer */
MsgLen cnt,                 /* count */
Data *dstBuf               /* destination buffer */
)
{
   Data *cptr;
   Buffer *tmp;
   MsgLen numBytes;
   PZBCAPI pZbcApi = NULL;
   Void* ptr;

#if 0 /* comment out for ys_qcPhy_itf by syq */
#ifndef YS_PHY_3_8_2
   struct tl_cache_list_block *ptl_ioctl_l = tl_ioctl_l;
#endif
#endif

   TRC1(ysMsUtlCopyScatterBufPtr)
   TRC_DUMP_MBUF(srcMbuf);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check source message buffer */
   if (srcMbuf == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS110, ERRZERO, "ysMsUtlCopyScatterBufPtr : Null Buffer");
      RETVALUE(RFAILED);
   }

   if (cnt <= 0)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS112, ERRZERO, "ysMsUtlCopyScatterBufPtr : Invalid Index");
      RETVALUE(RFAILED);
   }
 

   if (srcMbuf->b_datap->db_type != SS_M_PROTO)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS115, ERRZERO, "ysMsUtlCopyScatterBufPtr : Incorrect\
                                                   buffer type");
      RETVALUE(RFAILED);
   }
#endif

   /* get the first SS_M_DATA blk */
   tmp = srcMbuf->b_cont;


   /* set cptr to the read ptr of tmp */
   cptr = tmp->b_rptr;

   /*Offset to copy the Ptr, Msglen array*/
   pZbcApi = (PZBCAPI) ((U8 *) dstBuf);

   
   while (cnt > 0)
   {
      /* determine the number of bytes to be copied */
      numBytes = MIN(cnt, (tmp->b_wptr - cptr));

      /* decrement cnt */
      cnt -= numBytes;

#ifdef YS_BUF_COPY
      /*Allocate memory for copying data in the current blk*/
      ptr = ysAllocPhyMsg();

      SMemCpy((Void *) ptr, (Void *) cptr, (size_t) numBytes);
#else
      ptr = cptr;
#endif

#ifndef YS_PHY_3_8_2
      MARK_TL_DCACHE_CLEAN(ptl_ioctl_l, ptr, TEST_MAC_RUP32B(numBytes));

      /*Copy Pointer and msg size info for this blk*/
      pZbcApi->msgPtr = ptr;
#else
      pZbcApi->msgPtr = ptr;

#endif
#ifndef INTEL_ALLOC_WLS_MEM
      pZbcApi->msgPtr = TL_VA2PA(ysCb.ysIccHdl, pZbcApi->msgPtr);
#else
      pZbcApi->msgPtr = ysWlsVaToPa(pZbcApi->msgPtr);
#endif

      pZbcApi->msgSize = numBytes;
      /*Move to next blk*/
      pZbcApi++;
#ifndef YS_PHY_3_8_2
      ptl_ioctl_l++;
#endif

      /* get the next blk */
      if ((tmp = tmp->b_cont))
         /* set cptr to the read ptr of tmp */
         cptr = tmp->b_rptr;
      else
         break;
   }
#ifndef YS_PHY_3_8_2
   if ((U32)ptl_ioctl_l !=  (U32)tl_ioctl_l)
   {
       ptl_ioctl_l--;
       ptl_ioctl_l->next = NULL;
       TL_CachePerform(ysCb.ysIccHdl, tl_ioctl_l);
   }
#endif

   pZbcApi->msgSize = 0;

#ifdef YS_PHY_3_8_2
   pZbcApi->msgPtr = NULL;
#if !defined (TL_ALLOC_ICC_MEM) && !defined (INTEL_ALLOC_WLS_MEM)
   TL_CacheClean(ysCb.ysIccHdl, (PZBC_LIST_ITEM) dstBuf);
#endif
#endif

   RETVALUE(ROK);
}

#ifdef L2_OPTMZ
PRIVATE S16 ysMsUtlCopyScatterBufPtrMux
(
TfuDatReqTbInfo *tbInfo,
MsgLen cnt1,                 /* count */
Data *dstBuf,               /* destination buffer */
U16 index
)
{
   Data *cptr;
   Buffer *tmp;
   MsgLen numBytes,cnt;
   PZBCAPI pZbcApi = NULL;
   Void* ptr;
   U8  lchIdx, pIdx;
   TRC1(ysMsUtlCopyScatterBufPtrMux)
/* SANTOSH: 
 * 1. Fill MAC HDR.
 * 2. Fill MAC CES.
 * 3. MUX THE RLC PDUS.
 * 4. FILL PADDING IF PRESENT with PRE ALLOCATED PADDING DATA */

   /*Offset to copy the Ptr, Msglen array*/
   pZbcApi = (PZBCAPI) ((U8 *) dstBuf);

   SFndLenMsg(tbInfo->macHdr, &cnt);
   tmp  = tbInfo->macHdr->b_cont;
   cptr = tmp->b_rptr;
  while (cnt)
   {
      /* determine the number of bytes to be copied */
      numBytes = MIN(cnt, (tmp->b_wptr - cptr));

      /* decrement cnt */
      cnt -= numBytes;

      ptr = cptr;

      pZbcApi->msgPtr = ptr;

      pZbcApi->msgPtr = TL_VA2PA(ysCb.ysIccHdl, pZbcApi->msgPtr);
      pZbcApi->msgSize = numBytes;

      /*Move to next blk*/
      pZbcApi++;

      /* get the next blk */
      if ((tmp = tmp->b_cont))
         /* set cptr to the read ptr of tmp */
         cptr = tmp->b_rptr;
      else
         break;
   }

   SFndLenMsg(tbInfo->macCes, &cnt);
   tmp  = tbInfo->macCes->b_cont;
   cptr = tmp->b_rptr;
  while (cnt)
   {
      /* determine the number of bytes to be copied */
      numBytes = MIN(cnt, (tmp->b_wptr - cptr));

      /* decrement cnt */
      cnt -= numBytes;

      ptr = cptr;

      pZbcApi->msgPtr = ptr;

      pZbcApi->msgPtr = TL_VA2PA(ysCb.ysIccHdl, pZbcApi->msgPtr);
      pZbcApi->msgSize = numBytes;

      /*Move to next blk*/
      pZbcApi++;

      /* get the next blk */
      if ((tmp = tmp->b_cont))
         /* set cptr to the read ptr of tmp */
         cptr = tmp->b_rptr;
      else
         break;
   }

  for(lchIdx = 0; lchIdx < tbInfo->numLch;lchIdx++)
  {
     for(pIdx = 0; pIdx < tbInfo->lchInfo[lchIdx].numPdu; pIdx++)
     {
        SFndLenMsg(tbInfo->lchInfo[lchIdx].mBuf[pIdx], &cnt);
        tmp  = tbInfo->lchInfo[lchIdx].mBuf[pIdx]->b_cont;
        if(NULL == tmp)
        {
           pZbcApi->msgPtr = (Void*)ysCb.macPadPtr[index];
           pZbcApi->msgPtr = TL_VA2PA(ysCb.ysIccHdl, pZbcApi->msgPtr);
           pZbcApi->msgSize = cnt;
           /*Move to next blk*/
           pZbcApi++;
           STKLOG(STK_MD_YS,STK_LOG_ERR,"tmp is NULL \n");
           continue;
        }

        /* set cptr to the read ptr of tmp */
        cptr = tmp->b_rptr;

        while (cnt)
        {
           /* determine the number of bytes to be copied */
           numBytes = MIN(cnt, (tmp->b_wptr - cptr));

           /* decrement cnt */
           cnt -= numBytes;

           ptr = cptr;

           pZbcApi->msgPtr = ptr;

           pZbcApi->msgPtr = TL_VA2PA(ysCb.ysIccHdl, pZbcApi->msgPtr);
           pZbcApi->msgSize = numBytes;

           /*Move to next blk*/
           pZbcApi++;

           /* get the next blk */
           if ((tmp = tmp->b_cont))
              /* set cptr to the read ptr of tmp */
              cptr = tmp->b_rptr;
           else
              break;
        }
     }
  }
 /* Fill the MAC Padding Element */
#if 1
  if(tbInfo->padSize)
  {
           pZbcApi->msgPtr = (Void*)ysCb.macPadPtr[index];
           pZbcApi->msgPtr = TL_VA2PA(ysCb.ysIccHdl, pZbcApi->msgPtr);
           pZbcApi->msgSize = tbInfo->padSize;
           /*Move to next blk*/
           pZbcApi++;
  }
#endif

   pZbcApi->msgSize = 0;

#ifdef YS_PHY_3_8_2
   pZbcApi->msgPtr = NULL;
#endif

   RETVALUE(ROK);
}

#endif
#endif

/*
*
*       Fun:   ysMsUtlFillTxSduForPDSCH
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_utl.c
*
*/
PUBLIC S16 ysMsUtlFillTxSduForPDSCH
(
YsPhyTxSdu     *phyTxSdu,
TfuDatReqPduInfo *datReq,
U16           channelId,
YsCellCb      *cellCb,
U8            tbIndex
)
{
   PTXSDUREQ  txSduReq;
   MsgLen     bufLen;
#ifndef YS_SCATTER_GATHER
   MsgLen     cLen;
#endif
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
   VOLATILE U32     startTime1 = 0;
#endif
   TRC2(ysMsUtlFillTxSduForPDSCH)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (datReq == NULLP)
   {
      RLOG0(L_ERROR,"ysMsUtlFillTxSduForPDSCH(): invalid ptr");
      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

      /*starting Task*/
      SStartTask(&startTime, PID_CL_FILL_TXSDU);

  U16 indx = cellCb->cellId - CM_START_CELL_ID;
  
#ifdef BATCH_PROCESSING_DL
  txSduReq = (PTXSDUREQ)phyTxSdu->txSduReq;
#else
#ifdef TENB_RTLIN_CHANGES
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   txSduReq = (PTXSDUREQ)ysAllocPhyMsg(sizeof(TXSDUREQ));
#else
      txSduReq = (PTXSDUREQ)ysAllocPhyMsg();
#endif
#else
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   txSduReq = (PTXSDUREQ)ysMsUtlAllocSvsrMsg(TRUE, (sizeof(TXSDUREQ)));
#else
      txSduReq = (PTXSDUREQ)ysMsUtlAllocSvsrMsg(TRUE);
#endif
#endif
#endif
      if (txSduReq == NULLP)
      {
         RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId,"Failed to allocate memory for TXSDU");
         RETVALUE (RFAILED);
      }

      /*starting Task*/
      SStartTask(&startTime1, PID_CL_PDSCH_DAT_REQ);
#ifdef  L2_OPTMZ
      bufLen = datReq->tbInfo[tbIndex].tbSize;
#else       
   if (!datReq->mBuf[tbIndex])
   {
      RETVALUE(RFAILED);
   }

   SFndLenMsg(datReq->mBuf[tbIndex], &bufLen);
#endif 
   /* for calculating data rates */
   {
      rgStats.dlrate_tfu[indx] += bufLen;
   }

   /*For PDSCH channel these parameters are not relevant, 
     hence setting them to 0.*/
   txSduReq->nackAck = 0;
   txSduReq->uciFormat = 0;

   txSduReq->msgLen = bufLen;
   /* Protection for not sending TxSdu len zero */
   if (0 == txSduReq->msgLen)
   {
#ifndef L2_OPTMZ
      stop_printf("Trying to send txSduReq->msgLen as zero for Data\
            Txsdu @celltime (%u, %u)tbIndex%d rnti%d buf:0x%lx \n",cellCb->timingInfo.sfn,
            cellCb->timingInfo.subframe,tbIndex,datReq->rnti,(PTR)datReq->mBuf[tbIndex]);
#else
      stop_printf("Trying to send txSduReq->msgLen as zero for Data\
            Txsdu @celltime (%u, %u)tbIndex%d rnti%d  \n",cellCb->timingInfo.sfn,
            cellCb->timingInfo.subframe,tbIndex,datReq->rnti);
#endif
   }
   txSduReq->maxBitsperCw = (bufLen * 8);
   /*For PDSCH, this parameter isin't relevant. */
   txSduReq->phichGrpNumber = 0;
   phyTxSdu->sduLen = sizeof(TXSDUREQ) + bufLen;

#ifdef YS_SCATTER_GATHER
   txSduReq->pTxSdu = 0;
#ifndef L2_OPTMZ
   if (ysMsUtlCopyScatterBufPtr(datReq->mBuf[tbIndex], bufLen, (Data*) (txSduReq + 1)) != ROK)
   {
      YS_MS_FREE(txSduReq, phyTxSdu->sduLen, indx);//sduLen error!
      RETVALUE(RFAILED);
   }   
#else 
   if( datReq->rnti >= 0x003D && datReq->rnti < 0xFFF3)
   { 
      if (ysMsUtlCopyScatterBufPtrMux(&datReq->tbInfo[tbIndex], bufLen, (Data*) (txSduReq + 1), indx) != ROK)
      {
         YS_MS_FREE(txSduReq, phyTxSdu->sduLen, indx);
         RETVALUE(RFAILED);
      } 
   }
   else 
   {  
      if (ysMsUtlCopyScatterBufPtr(datReq->tbInfo[tbIndex].lchInfo[0].mBuf[0], bufLen, (Data*) (txSduReq + 1)) != ROK)
      {
         YS_MS_FREE(txSduReq, phyTxSdu->sduLen, indx);
         RETVALUE(RFAILED);
      } 
   }

#endif      
#else
   /* Copy the mBuf into the flat buffer */
   /*offset fix */
   if (SCpyMsgFix(datReq->mBuf[tbIndex], (MsgLen)0, bufLen,
            (Data*) (txSduReq + 1), &cLen) != ROK)
   {
      YS_MS_FREE(txSduReq, phyTxSdu->sduLen, indx);
      RETVALUE(RFAILED);
   }
#endif
   
   /*stopping Task*/
   SStopTask(startTime1, PID_CL_PDSCH_DAT_REQ);

   txSduReq->chanId = channelId;
   txSduReq->msgType = PHY_TXSDU_REQ;
   txSduReq->phyEntityId = cellCb->phyInstId;
   txSduReq->channelType = PDSCH;
   txSduReq->cwId = 0; /* Overridden by caller if needed (for mimo) */

#ifndef BATCH_PROCESSING_DL
   phyTxSdu->txSduReq = (PGENMSGDESC)txSduReq;
#endif

   /*stopping Task*/
   SStopTask(startTime, PID_CL_FILL_TXSDU);

   RETVALUE(ROK);
} /* end of ysMsUtlFillTxSduForPDSCH */

/*
*
*       Fun:   ysMsUtlFillTxSduForPDCCH
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_utl.c
*
*/
PUBLIC S16 ysMsUtlFillTxSduForPDCCH
(
YsPhyTxSdu     *phyTxSdu,
TfuPdcchInfo  *pdcchInfo,
U16           channelId,
YsCellCb      *cellCb
)
{
   PTXSDUREQ  txSduReq;
   U8         dci[8] = {0};
   U16        dciSize = 0;
   U8         *pDci = dci;
#ifdef XXX_TASK_MEAS
   VOLATILE U32     startTime = 0;
   VOLATILE U32     startTime1 = 0;
#endif
   TRC2(ysMsUtlFillTxSduForPDCCH)

   /*starting Task*/
   SStartTask(&startTime, PID_CL_FILL_TXSDU);
#ifdef BATCH_PROCESSING_DL
   txSduReq = (PTXSDUREQ)phyTxSdu->txSduReq; 
#else
#ifdef TENB_RTLIN_CHANGES
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   txSduReq = (PTXSDUREQ)ysAllocPhyMsg(sizeof(TXSDUREQ));
#else
   txSduReq = (PTXSDUREQ)ysAllocPhyMsg();
#endif
#else
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   txSduReq = (PTXSDUREQ)ysMsUtlAllocSvsrMsg(TRUE, (sizeof(TXSDUREQ)));
#else
   txSduReq = (PTXSDUREQ)ysMsUtlAllocSvsrMsg(TRUE);
#endif
#endif
#endif
   if (txSduReq == NULLP)
   {
      RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId,"Failed to allocate memory for TXSDU");
      RETVALUE (RFAILED);
   }

   txSduReq->channelType = PDCCH;
   /*starting Task*/
   SStartTask(&startTime1, PID_CL_PDCCH_DAT_REQ);
   switch(pdcchInfo->dci.dciFormat)
   {
      case TFU_DCI_FORMAT_0:
      {
         U16 bW, bits, idx = 0;
         U16 bitIdx = 0;
         U16          riv;
         TfuDciFormat0Info *format0 = &pdcchInfo->dci.u.format0Info;

         bW = YS_MS_GET_UL_BW(cellCb->cellCfg.bwCfg);

         /*-- Calculate resource block assignment bits need to be set
           Which is ln(N(N+1)/2) 36.212 5.3.3.1 --*/
         bits = (bW * (bW + 1) / 2);
         while ((bits & 0x8000) == 0)
         {
            bits <<= 1;
            idx++;
         }
         bits = 16 - idx;

         YS_MS_SETBITRANGE(pDci, bitIdx, 1, 0); bitIdx++; /*-- Format 0 --*/
         YS_MS_SETBITRANGE(pDci, bitIdx, 1, format0->hoppingEnbld);
         bitIdx++;
         riv = ysMsCalcRiv(bW, format0->rbStart, format0->numRb);
         if (format0->hoppingEnbld)
         {
            /*-- Resource block assignment bits need to be set
              Which is ln(N(N+1)/2) --*/
            /*-- How to calculate this --*/
            YS_MS_SETBITRANGE(pDci, bitIdx, format0->hoppingBits, 0);  
            bitIdx += format0->hoppingBits;
            /*-- How to calculate this --*/
            YS_MS_SETBITRANGE(pDci, bitIdx, 
                  (bits - format0->hoppingBits), 0); 
            bitIdx += (bits - format0->hoppingBits);
         }
         else
         {
            /*-- How to calculate this --*/
            YS_MS_SETBITRANGE(pDci, bitIdx, bits, riv); 
            bitIdx += (bits);
         }

         YS_MS_SETBITRANGE(pDci, bitIdx, 5, format0->mcs);
         bitIdx += 5;
         YS_MS_SETBITRANGE(pDci, bitIdx, 1, format0->ndi);
         bitIdx++;
         YS_MS_SETBITRANGE(pDci, bitIdx, 2, format0->tpcCmd);
         bitIdx += 2;
         YS_MS_SETBITRANGE(pDci, bitIdx, 3, format0->nDmrs);
         bitIdx += 3;
#ifdef TFU_TDD
         if(!cellCb->ulDlCfgIdx)
         {/*UL Index is valid only for config mode 0
           *Both UlIndex and DAI should not co exist together
           */
            YS_MS_SETBITRANGE(pDci, bitIdx, 2, format0->ulIdx);
            bitIdx += 2;
         }
         else
         {
            YS_MS_SETBITRANGE(pDci, bitIdx, 2, format0->dai-1);
            bitIdx += 2;
         }
#endif
         YS_MS_SETBITRANGE(pDci, bitIdx, format0->numCqiBit, format0->cqiReq);
         bitIdx += format0->numCqiBit;

         /* fix for dci size () missing */
         dciSize = (bitIdx + 7) / 8;
         /*fix for decoding on WJ.*/
         /*Adding two bits for format 0 to make it equat to size for
          * format 1A, i.e. 27 bits */
         txSduReq->maxBitsperCw = bitIdx+2;
         if(bitIdx < dciFormat1ASize)
         {
            txSduReq->maxBitsperCw = dciFormat1ASize;
         }
         else
         {
            txSduReq->maxBitsperCw = bitIdx;
         }
         break;
      }
      case TFU_DCI_FORMAT_1A:
      {
         U16 bW, bits, idx = 0;
         U16 bitIdx = 0;
         Tfudciformat1aPdsch *format1a;

         bW = cellCb->cellInfo.dlBw;

         /*-- Calculate resource block assignment bits need to be set
           Which is ln(N(N+1)/2) --*/
         bits = (bW * (bW + 1) / 2);
         while ((bits & 0x8000) == 0)
         {
            bits <<= 1;
            idx++;
         }
         bits = 16 - idx;

         YS_MS_SETBITRANGE(pDci, bitIdx, 1, 1); bitIdx++; /*-- Format 1A --*/
         if (pdcchInfo->dci.u.format1aInfo.isPdcchOrder)
         {
            YS_MS_SETBITRANGE(pDci, bitIdx, 1, 0); bitIdx++;
            /*-- Resource block assignment bits need to be set
              Which is ln(N(N+1)/2) --*/
#if 0/* Naw:: Setting only the required bits.0xFFFF was overwriting above fields*/
            YS_MS_SETBITRANGE(pDci, bitIdx, bits, 0xffff);
#else
            YS_MS_SETBITRANGE(pDci, bitIdx, bits, (1 << bits)-1 );
#endif
            bitIdx += bits;

            YS_MS_SETBITRANGE(pDci, bitIdx, 6, 
                  pdcchInfo->dci.u.format1aInfo.t.
                  pdcchOrder.preambleIdx);
            bitIdx += 6;

            YS_MS_SETBITRANGE(pDci, bitIdx, 4, 
                  pdcchInfo->dci.u.format1aInfo.t.
                  pdcchOrder.prachMaskIdx);
            bitIdx += 4;
            /* Naw::Fix for DCI 1A for PDCCHOrder encoding */
            /* dciFormat1ASize will not be 0 here
             * There must be some DCI1A which would have gone
             * previously before this pdcch order DCI*/
            txSduReq->maxBitsperCw = dciFormat1ASize;
            dciSize = (txSduReq->maxBitsperCw + 7) / 8;
         }
         else
         {
            format1a = &pdcchInfo->dci.u.format1aInfo.t.pdschInfo;
            if (format1a->allocInfo.isLocal)
            {
               YS_MS_SETBITRANGE(pDci, bitIdx, 1, 0); bitIdx++;
            }
            else
            {
               YS_MS_SETBITRANGE(pDci, bitIdx, 1, 1); bitIdx++;
            }
            /*-- Resource block assignment bits need to be set
              Which is ln(N(N+1)/2) --*/
            YS_MS_SETBITRANGE(pDci, bitIdx, bits, 
                  format1a->allocInfo.alloc.u.riv);
            bitIdx += bits;

            YS_MS_SETBITRANGE(pDci, bitIdx, 5, format1a->allocInfo.mcs);
            bitIdx += 5;
#ifndef TFU_TDD
            YS_MS_SETBITRANGE(pDci, bitIdx, 3, 
                  format1a->allocInfo.harqProcId.val);
            bitIdx += 3;
#else
            YS_MS_SETBITRANGE(pDci, bitIdx, 4, 
                  format1a->allocInfo.harqProcId.val);
            bitIdx += 4;
#endif
            YS_MS_SETBITRANGE(pDci, bitIdx, 1, format1a->allocInfo.ndi);
            bitIdx++;
            YS_MS_SETBITRANGE(pDci, bitIdx, 2, format1a->allocInfo.rv);
            bitIdx += 2;
            YS_MS_SETBITRANGE(pDci, bitIdx, 2, format1a->tpcCmd);
            bitIdx += 2;
#ifdef TFU_TDD
            if(format1a->dai.pres)
            {
               YS_MS_SETBITRANGE(pDci, bitIdx, 2, format1a->dai.val - 1);
               bitIdx += 2;
            }else
            {/* DAI is reserved for Common channels */
               YS_MS_SETBITRANGE(pDci, bitIdx, 2, 0);
               bitIdx += 2;
            }
#endif
            dciSize = (bitIdx + 7) / 8;

            /*fix for decoding on WJ.*/
            //txSduReq->maxBitsperCw = bitIdx+1;
#if 0
#else
            txSduReq->maxBitsperCw = pdcchInfo->dciNumOfBits;
#endif
            dciFormat1ASize = txSduReq->maxBitsperCw;

         }
         break;
      }
      case TFU_DCI_FORMAT_1:
      {
         U16 bW;
         U16 bitIdx = 0;
         U16 resMapLen = 0;
         U8 rbgPerBwSize = 0,bitCount = 0;
         U8 bytesPerMapLen = 0;
            U8 tempSize = 0;
         U8 resMapCount = 0;
         U8 rbgSize = cellCb->cellInfo.rbgSize;
         TfuDciFormat1Info *format1Info = &(pdcchInfo->dci.u.format1Info);
         TfuDciFormat1AllocInfo *format1AllocInfo = &(format1Info->allocInfo);

         bW = cellCb->cellInfo.dlBw;
         rbgSize = cellCb->cellInfo.rbgSize;

         /* Resource allocation header is present iff the BW is > 10 PRBS */
         if(bW > 10 )
         {
            /* type 0 - 0 type 1 -1 */
            YS_MS_SETBITRANGE(pDci, bitIdx, 1, 
                  !(format1AllocInfo->isAllocType0) );
            bitIdx++;
         }

         if( format1AllocInfo->isAllocType0 )
         {/* Type 0 : size is bw/P */
            /* mimo_comment: ceiling*/
            resMapLen = YS_MS_CEIL(bW, rbgSize);
         }else
         {/* Type 1 : size is ln(p) + 1 + ((bw/p) - ln(p) - 1) */
            bitCount = 1;
            while ( bitCount <= rbgSize)
            {
               bitCount <<= 1;
               tempSize++;
            }
            /* mimo_comment: ceiling*/
            rbgPerBwSize = ( bW % rbgSize )? ( bW / rbgSize):
               (( bW / rbgSize) + 1 );
            resMapLen = tempSize + 1 + ( rbgPerBwSize - tempSize - 1 );
         }
         /* Resource allocation map field */
         bytesPerMapLen = (resMapLen >> 3) + ((resMapLen % 8)?1:0);
         /* mimo_comment: process the last byte outside the loop*/
         for ( resMapCount = 0; resMapCount < bytesPerMapLen - 1; 
               resMapCount++)
         {
            YS_MS_SETBITRANGE(pDci, bitIdx, 8 ,
                  format1AllocInfo->resAllocMap[resMapCount]);
            bitIdx += 8;
         }

         /* filling from the last byte info */
         if (!( resMapLen % 8 ))
         {
            YS_MS_SETBITRANGE(pDci, bitIdx, 8 ,
                  format1AllocInfo->resAllocMap[resMapCount]);
            bitIdx += 8;
         }else
         {
            YS_MS_SETBITRANGE(pDci, bitIdx, (resMapLen % 8 ) ,
                  format1AllocInfo->resAllocMap[resMapCount]);
            bitIdx += (resMapLen % 8 );
         }
       
          
         YS_MS_SETBITRANGE(pDci, bitIdx, 5, format1AllocInfo->mcs);
         bitIdx += 5;

#ifndef TFU_TDD
         YS_MS_SETBITRANGE(pDci, bitIdx, 3, 
               format1AllocInfo->harqProcId);
         bitIdx += 3;
#else
         YS_MS_SETBITRANGE(pDci, bitIdx, 4, 
               format1AllocInfo->harqProcId);
         bitIdx += 4;
#endif

         YS_MS_SETBITRANGE(pDci, bitIdx, 1, format1AllocInfo->ndi);
         bitIdx++;

         YS_MS_SETBITRANGE(pDci, bitIdx, 2, format1AllocInfo->rv);
         bitIdx += 2;

         YS_MS_SETBITRANGE(pDci, bitIdx, 2, format1Info->tpcCmd);
         bitIdx += 2;

#ifdef TFU_TDD
         YS_MS_SETBITRANGE(pDci, bitIdx, 2, format1Info->dai - 1);
         bitIdx += 2;
#endif
         /* DCI 1 Size should not be same as DCI 0/1A. 
          * DCI 1 Size shild not be the sizes mentioned 
          * in Table 5.3.3.1.2-1 , 36.213 */
         if(bitIdx == dciFormat1ASize)
         {
            STKLOG(STK_MD_YS,STK_LOG_INFO,"DCI 1 size is matching with 1A \n");
            bitIdx++;
         }
#if 0
#else
         txSduReq->maxBitsperCw = pdcchInfo->dciNumOfBits;
#endif
         dciSize = (txSduReq->maxBitsperCw + 7) / 8;

         break;
      }
      case TFU_DCI_FORMAT_1B:
         RLOG0(L_DEBUG,"DCI format 1B unhandled");
         RETVALUE(RFAILED);
      case TFU_DCI_FORMAT_1C:
         RLOG0(L_DEBUG,"DCI format 1C unhandled");
         RETVALUE(RFAILED);
      case TFU_DCI_FORMAT_1D:
         RLOG0(L_DEBUG,"DCI format 1D unhandled");
         RETVALUE(RFAILED);
      case TFU_DCI_FORMAT_2:
         {
            U16 bW = 0;
            U16 bitIdx = 0;
            U16 resMapLen = 0;
            U8 rbgSize = 0;
            U8 bitCount = 0;
            U8 tempSize = 0;
    //        U8 rbgPerBwSize = 0;
            U8 resMapBytes = 0;
            //U8 remBits;

            TfuDciFormat2Info *format2 = &pdcchInfo->dci.u.format2Info;
            TfuDciFormat2AllocInfo *format2AllocInfo = 
               &pdcchInfo->dci.u.format2Info.allocInfo;

            bW = cellCb->cellInfo.dlBw;
            rbgSize = cellCb->cellInfo.rbgSize;

            /* Resource allocation header is present iff the BW is > 10 PRBS */
            if(bW > 10 )
            {
               /* type 0 - 0 type 1 -1 */
               YS_MS_SETBITRANGE(pDci, bitIdx, 1,
                     !(format2AllocInfo->isAllocType0) );
               bitIdx++;
            }

            if( format2AllocInfo->isAllocType0 )
            {/* Type 0 : size is bw/P */
               /* TODO MIMO: precompute */
               resMapLen = YS_MS_CEIL(bW, rbgSize);
            }else
            {/* Type 1 : size is ln(p) + 1 + ((bw/p) - ln(p) - 1) */
               bitCount = 1;
               while ( bitCount <= rbgSize)
               {
                  bitCount <<= 1;
                  tempSize++;
               }
               resMapLen = YS_MS_CEIL(bW, rbgSize);
            }

            /* Resource allocation map field */
            if (bitIdx)
            {
               /* Shift by one and copy res map bits */
               U8 dciidx = 0;
               U8 i;
               U8 resmap = format2AllocInfo->resAllocMap[0];
               resMapBytes = (resMapLen-1) / 8;
               //remBits = (resMapLen-1) % 8 + 1;
               for (i = 0; i < resMapBytes; i++)
               {
                  resmap = format2AllocInfo->resAllocMap[i];
                  pDci[dciidx] |= (resmap >> 1);
                  pDci[dciidx+1] |= (resmap << 7);
                  ++dciidx;
               }
               resmap = format2AllocInfo->resAllocMap[i];
               pDci[dciidx++] |= (resmap >> 1);
            }
            else
            {
               U32 i;
               for (i = 0; i < TFU_MAX_ALLOC_BYTES; ++i)
                  pDci[i] = format2AllocInfo->resAllocMap[i];
            }
            bitIdx += resMapLen;

            YS_MS_SETBITRANGE(pDci, bitIdx, 2 ,format2->tpcCmd);
            bitIdx += 2;
            /* TODO::Fill DAI for TDD */
#ifdef TFU_TDD
            YS_MS_SETBITRANGE(pDci, bitIdx, 2 ,format2->dai - 1);
            bitIdx += 2;

            YS_MS_SETBITRANGE(pDci, bitIdx, 4 ,
                  format2AllocInfo->harqProcId);
            bitIdx += 4;
#else
            YS_MS_SETBITRANGE(pDci, bitIdx, 3 ,
                  format2AllocInfo->harqProcId);
            bitIdx += 3;
#endif
            YS_MS_SETBITRANGE(pDci, bitIdx, 1 ,format2AllocInfo->transSwap);
            bitIdx += 1;

            YS_MS_SETBITRANGE(pDci, bitIdx, 5 ,
                  format2AllocInfo->tbInfo[0].mcs);
            bitIdx += 5;

            YS_MS_SETBITRANGE(pDci, bitIdx, 1 ,
                  (format2AllocInfo->tbInfo[0].ndi & 0x01));
            bitIdx += 1;

            YS_MS_SETBITRANGE(pDci, bitIdx, 2 ,
                  format2AllocInfo->tbInfo[0].rv);
            bitIdx += 2;

            YS_MS_SETBITRANGE(pDci, bitIdx, 5 ,
                  format2AllocInfo->tbInfo[1].mcs);
            bitIdx += 5;

            YS_MS_SETBITRANGE(pDci, bitIdx, 1 ,
                  (format2AllocInfo->tbInfo[1].ndi & 0x01));
            bitIdx += 1;

            YS_MS_SETBITRANGE(pDci, bitIdx, 2 ,
                  format2AllocInfo->tbInfo[1].rv);
            bitIdx += 2;

            /* if antennaPortCount = 2, precoding size is 3, 
               if antennaPortCount = 4 precoding size is 6*/
            if( YS_MS_GET_NUM_TX_ANT(cellCb->cellCfg.antennaCfg) == 2 ) 
            {
               /* Get the antennaCount value */
               YS_MS_SETBITRANGE(pDci, bitIdx, 3 ,format2AllocInfo->precoding);
               bitIdx += 3;
            }else if( YS_MS_GET_NUM_TX_ANT(cellCb->cellCfg.antennaCfg) == 4 )
            {
               YS_MS_SETBITRANGE(pDci, bitIdx, 6 ,format2AllocInfo->precoding);
               bitIdx += 6;
            }
            txSduReq->maxBitsperCw = bitIdx + ysDciAmbigSize[bitIdx];
            dciSize = (txSduReq->maxBitsperCw / 8) + ((txSduReq->maxBitsperCw % 8)?1:0);
            break;
         }
      case TFU_DCI_FORMAT_2A:
         {
            U16 bW = 0;
            U16 bitIdx = 0;
            U16 resMapLen = 0;
            U8 rbgSize = 0;
            U8 bitCount = 0;
            U8 tempSize = 0;
            U8 rbgPerBwSize = 0;
            U8 resMapBytes = 0;
            //U8 remBits;

            TfuDciFormat2AInfo *format2a = &pdcchInfo->dci.u.format2AInfo;
            TfuDciFormat2AAllocInfo *format2AAllocInfo = 
               &pdcchInfo->dci.u.format2AInfo.allocInfo;

            bW = cellCb->cellInfo.dlBw;
            rbgSize = cellCb->cellInfo.rbgSize;

            /* Resource allocation header is present iff the BW is > 10 PRBS */
            if(bW > 10 )
            {
               /* type 0 - 0 type 1 -1 */
               YS_MS_SETBITRANGE(pDci, bitIdx, 1,
                     !(format2AAllocInfo->isAllocType0) );
               bitIdx++;
            }

            if( format2AAllocInfo->isAllocType0 )
            {/* Type 0 : size is bw/P */
               /* TODO MIMO: precompute */
               resMapLen = YS_MS_CEIL(bW, rbgSize);
            }else
            {/* Type 1 : size is ln(p) + 1 + ((bw/p) - ln(p) - 1) */
               bitCount = 1;
               while ( bitCount <= rbgSize)
               {
                  bitCount <<= 1;
                  tempSize++;
               }
               rbgPerBwSize = ( bW % rbgSize )? ( bW / rbgSize):
                  (( bW / rbgSize) + 1 );
               resMapLen = tempSize + 1 + ( rbgPerBwSize - tempSize - 1 );
            }

            /* Resource allocation map field */
            if (bitIdx)
            {
               /* Shift by one and copy res map bits */
               U8 dciidx = 0;
               U8 i;
               U8 resmap = format2AAllocInfo->resAllocMap[0];
               resMapBytes = (resMapLen-1) / 8;
               //remBits = (resMapLen-1) % 8 + 1;
               for (i = 0; i < resMapBytes; i++)
               {
                  resmap = format2AAllocInfo->resAllocMap[i];
                  pDci[dciidx] |= (resmap >> 1);
                  pDci[dciidx+1] |= (resmap << 7);
                  ++dciidx;
               }
               resmap = format2AAllocInfo->resAllocMap[i];
               pDci[dciidx++] |= (resmap >> 1);
            }
            else
            {
               U32 i;
               for (i = 0; i < TFU_MAX_ALLOC_BYTES; ++i)
                  pDci[i] = format2AAllocInfo->resAllocMap[i];
            }
            bitIdx += resMapLen;

            YS_MS_SETBITRANGE(pDci, bitIdx, 2 ,format2a->tpcCmd);
            bitIdx += 2;
            /* TODO::Fill DAI for TDD */
#ifdef TFU_TDD
            YS_MS_SETBITRANGE(pDci, bitIdx, 2 ,format2a->dai - 1);
            bitIdx += 2;

            YS_MS_SETBITRANGE(pDci, bitIdx, 4 ,
                  format2AAllocInfo->harqProcId);
            bitIdx += 4;
#else
            YS_MS_SETBITRANGE(pDci, bitIdx, 3 ,
                  format2AAllocInfo->harqProcId);
            bitIdx += 3;
#endif
            YS_MS_SETBITRANGE(pDci, bitIdx, 1 ,format2AAllocInfo->transSwap);
            bitIdx += 1;

            YS_MS_SETBITRANGE(pDci, bitIdx, 5 ,
                  format2AAllocInfo->tbInfo[0].mcs);
            bitIdx += 5;

            YS_MS_SETBITRANGE(pDci, bitIdx, 1 ,
                  (format2AAllocInfo->tbInfo[0].ndi & 0x01));
            bitIdx += 1;

            YS_MS_SETBITRANGE(pDci, bitIdx, 2 ,
                  format2AAllocInfo->tbInfo[0].rv);
            bitIdx += 2;

            YS_MS_SETBITRANGE(pDci, bitIdx, 5 ,
                  format2AAllocInfo->tbInfo[1].mcs);
            bitIdx += 5;

            YS_MS_SETBITRANGE(pDci, bitIdx, 1 ,
                  (format2AAllocInfo->tbInfo[1].ndi & 0x01));
            bitIdx += 1;

            YS_MS_SETBITRANGE(pDci, bitIdx, 2 ,
                  format2AAllocInfo->tbInfo[1].rv);
            bitIdx += 2;

            /* if antennaPortCount = 2, precoding size is 3, 
               if antennaPortCount = 4 precoding size is 6*/
            if( YS_MS_GET_NUM_TX_ANT(cellCb->cellCfg.antennaCfg) == 4) 
            {
               /* Get the antennaCount value */
               YS_MS_SETBITRANGE(pDci, bitIdx, 2 ,format2AAllocInfo->precoding);
               bitIdx += 2;
            }
            //txSduReq->maxBitsperCw = bitIdx+1;
#if 0
#else
            txSduReq->maxBitsperCw = pdcchInfo->dciNumOfBits;
#endif
            //dciSize = (bitIdx + 7) / 8;
            dciSize = (txSduReq->maxBitsperCw / 8) + ((txSduReq->maxBitsperCw % 8)?1:0);
            break;
         }
      case TFU_DCI_FORMAT_3:
         {
            U16 bitIdx = 0;
            U8  idx =1;
            TfuDciFormat3Info *format3 = &pdcchInfo->dci.u.format3Info;   
            /* GRP_PWR: TODO. Make computation for number of indices function of dci format 0 size */ 
            for (; idx < TFU_MAX_2BIT_TPC - 2; ++idx)
            {
               YS_MS_SETBITRANGE(pDci, bitIdx, 2, format3->tpcCmd[idx]);
               bitIdx += 2;
            }   
            dciSize = (bitIdx + 7) / 8;
            txSduReq->maxBitsperCw = bitIdx+1;
            /* Updating stats */
            {
               if(pdcchInfo->dci.u.format3Info.isPucch)
                  tpcPucch[0]++;
               else
                  tpcPusch[0]++;
            }
            break;
         }
      case TFU_DCI_FORMAT_3A:
         {
            U16 bitIdx = 0;
            U8  idx =1;
            TfuDciFormat3AInfo *format3a = &pdcchInfo->dci.u.format3AInfo;   
            /* GRP_PWR: TODO. Make computation for number of indices function of dci format 0 size */ 
            for (; idx < TFU_MAX_1BIT_TPC - 5; ++idx)
            {
               YS_MS_SETBITRANGE(pDci, bitIdx, 1, format3a->tpcCmd[idx]);
               bitIdx += 1;
            }      
            dciSize = (bitIdx + 7) / 8;
            txSduReq->maxBitsperCw = bitIdx + 1;
            /* Updating stats */
            {
               if(pdcchInfo->dci.u.format3AInfo.isPucch)
                  tpcPucch[1]++;
               else
                  tpcPusch[1]++;
            }
            break;
         }
#ifdef EMTC_ENABLE
		case TFU_DCI_FORMAT_6_1A:
			{
            RLOG0(L_DEBUG,"Filling TxSdu for DCI Format 6_1A\n");
				U16 bW, bits, idx = 0;
				U16 bitIdx = 0;
				Tfudciformat61aPdsch *format61a;

				bW = cellCb->cellInfo.dlBw/ 6;

				bits = bW;
				//Calculate number of bits required to represent NBs
				while ((bits & 0x8000) == 0)
				{
				   bits <<= 1;
				   idx++;
				}
				//Adding 5 as in 5.3.3.1.12 - 36.212
				bits = (15 - idx) + 5;

				YS_MS_SETBITRANGE(pDci, bitIdx, 1, 1); bitIdx++; /*-- Format 6-1A --*/
				if (pdcchInfo->dci.u.format61aInfo.isPdcchOrder)
				{

					YS_MS_SETBITRANGE(pDci, bitIdx, bits, (1 << bits)-1 );
				   bitIdx += bits;

				   YS_MS_SETBITRANGE(pDci, bitIdx, 6, 
				         pdcchInfo->dci.u.format61aInfo.t.
				         pdcchOrder.preambleIdx);
				   bitIdx += 6;

				   YS_MS_SETBITRANGE(pDci, bitIdx, 4, 
				         pdcchInfo->dci.u.format61aInfo.t.
				         pdcchOrder.prachMaskIdx);
				   bitIdx += 4;

					YS_MS_SETBITRANGE(pDci, bitIdx, 2, 
				         pdcchInfo->dci.u.format61aInfo.t.
				         pdcchOrder.ceLevel);
				   bitIdx += 2;
				   /* Naw::Fix for DCI 1A for PDCCHOrder encoding */
				   /* dciFormat1ASize will not be 0 here
				    * There must be some DCI1A which would have gone
				    * previously before this pdcch order DCI*/
				    //TODO_SID
				   txSduReq->maxBitsperCw = pdcchInfo->dciNumOfBits;
				   dciSize = (txSduReq->maxBitsperCw + 7) / 8;
				}
				else
				{
				   format61a = &pdcchInfo->dci.u.format61aInfo.t.pdschInfo;

					YS_MS_SETBITRANGE(pDci, bitIdx, 1, format61a->hoppingEnbld); bitIdx++;

				   /*-- Resource block assignment bits need to be set
				     Which is ln(N(N+1)/2) --*/
				   YS_MS_SETBITRANGE(pDci, bitIdx, bits, 
				         format61a->allocInfo.riv);
				   bitIdx += bits;

				   YS_MS_SETBITRANGE(pDci, bitIdx, 4, format61a->allocInfo.mcs);
				   bitIdx += 4;

					YS_MS_SETBITRANGE(pDci, bitIdx, 2, format61a->rep);
				   bitIdx += 2;
#ifndef TFU_TDD
				   YS_MS_SETBITRANGE(pDci, bitIdx, 3, 
				         format61a->allocInfo.harqProcId);
				   bitIdx += 3;
#else
				   YS_MS_SETBITRANGE(pDci, bitIdx, 4, 
				         format61a->allocInfo.harqProcId);
				   bitIdx += 4;
#endif
				   YS_MS_SETBITRANGE(pDci, bitIdx, 1, format61a->allocInfo.ndi);
				   bitIdx++;
					
				   YS_MS_SETBITRANGE(pDci, bitIdx, 2, format61a->allocInfo.rv);
				   bitIdx += 2;
					
				   YS_MS_SETBITRANGE(pDci, bitIdx, 2, format61a->tpcCmd);
				   bitIdx += 2;
					
#ifdef TFU_TDD
				//TODO_SID - reserved if repetation > 1
				   if(format61a->dai.pres)
				   {
				      YS_MS_SETBITRANGE(pDci, bitIdx, 2, format61a->dai.val - 1);
				      bitIdx += 2;
				   }else
				   {/* DAI is reserved for Common channels */
				      YS_MS_SETBITRANGE(pDci, bitIdx, 2, 0);
				      bitIdx += 2;
				   }
#endif
#if 0/* 36.212 This field is present only if PDSCH transmission is 
        configured with TM9 for DCI formats scheduling PDSCH which 
        are mapped onto the UE specific search space given by the C-RNTI as defined*/
					YS_MS_SETBITRANGE(pDci, bitIdx, 2, format61a->antPortAndScrId);
				   bitIdx += 2;
#endif

					YS_MS_SETBITRANGE(pDci, bitIdx, 1, format61a->isSrs);
				   bitIdx += 1;
					
					//TODO_SID - TPMI and PMI present for TM6 only.Need to check.

					YS_MS_SETBITRANGE(pDci, bitIdx, 2, format61a->harqAckOffst);
				   bitIdx += 2;

					YS_MS_SETBITRANGE(pDci, bitIdx, 2, format61a->dciRep);
				   bitIdx += 2;
					
				   //dciSize = (bitIdx + 7) / 8;

				   /*fix for decoding on WJ.*/
				   //txSduReq->maxBitsperCw = bitIdx+1;
				   //TODO_SID -check
#if 1 /* workaround..need to fix the dci size issue in mac*/
				   txSduReq->maxBitsperCw = bitIdx;
#else
				   txSduReq->maxBitsperCw = pdcchInfo->dciNumOfBits;
#endif
				   dciSize = (txSduReq->maxBitsperCw + 7) / 8;
               /*Put print for dciSize. If it is not coming as  29 */
               txSduReq->channelType = MPDCCH;

				}
				break;
			}
		case TFU_DCI_FORMAT_6_0A:
		case TFU_DCI_FORMAT_6_0B:
		case TFU_DCI_FORMAT_6_1B:
			{
            txSduReq->channelType = MPDCCH;
				STKLOG(STK_MD_YS,STK_LOG_INFO,"Invalid DCI Format %d\n", pdcchInfo->dci.dciFormat);
				break;
			}
      case TFU_DCI_FORMAT_6_2:
         {
            U16 bW, bits, idx = 0;
            U16 bitIdx = 0;
            Tfudciformat62Pdsch *format62;
            format62 = &pdcchInfo->dci.u.format62Info.t.pdschInfo;
            
            bW = cellCb->cellInfo.dlBw/ 6;

            bits = bW;
            //Calculate number of bits required to represent NBs
            while ((bits & 0x8000) == 0)
            {
               bits <<= 1;
               idx++;
            }
            bits = (15 - idx);
            /* if check defines whether paging is going on MPDCCH or Direct Information Indication is going */
            if (pdcchInfo->dci.u.format62Info.isPaging)
            {
               YS_MS_SETBITRANGE(pDci, bitIdx, 1,pdcchInfo->dci.u.format62Info.isPaging); 
               bitIdx++;
               YS_MS_SETBITRANGE(pDci, bitIdx, bits,format62->format62AllocInfo.riv); 
               bitIdx += bits;
               YS_MS_SETBITRANGE(pDci, bitIdx,3 ,format62->format62AllocInfo.mcs); 
               bitIdx += 3;
               YS_MS_SETBITRANGE(pDci, bitIdx,3 ,format62->repNum); 
               bitIdx += 3;
               YS_MS_SETBITRANGE(pDci, bitIdx,2 ,format62->dciSubRepNum); 
               bitIdx += 2;

               txSduReq->maxBitsperCw = pdcchInfo->dciNumOfBits;
               dciSize = (txSduReq->maxBitsperCw + 7) / 8;
               txSduReq->channelType = MPDCCH;

            }
            else
            {
               YS_MS_SETBITRANGE(pDci, bitIdx, 1,pdcchInfo->dci.u.format62Info.isPaging); 
               bitIdx++;
               YS_MS_SETBITRANGE(pDci, bitIdx,8 ,pdcchInfo->dci.u.format62Info.t.directIndication.directInd); 
               bitIdx += 8;
               YS_MS_SETBITRANGE(pDci, bitIdx, bits ,0); 
               bitIdx += bits;

               txSduReq->maxBitsperCw = pdcchInfo->dciNumOfBits;
               dciSize = (txSduReq->maxBitsperCw + 7) / 8;
               txSduReq->channelType = MPDCCH;
            }
            break;
         }
#endif
      default:
         RLOG_ARG0(L_WARNING,DBG_CELLID,cellCb->cellId,"Unknown DCI format");
         RETVALUE(RFAILED);
   }

   phyTxSdu->sduLen = sizeof(TXSDUREQ)+dciSize;

   /*Added as per discussion with Sumesh*/
   txSduReq->pTxSdu = 0;
   /*fix for copying the TX SDU */
   cmMemcpy((U8 *)((U8 *)txSduReq + sizeof(TXSDUREQ)), pDci, dciSize);
   txSduReq->msgLen = dciSize;
   /* Protection for not sending TxSdu len zero */
   if (0 == txSduReq->msgLen)
   {
      stop_printf("Trying to send txSduReq->msgLen as zero for DCI \
            Txsdu @celltime (%u, %u)\n",cellCb->timingInfo.sfn,
            cellCb->timingInfo.subframe);
   }

   /*For PDCCH, this parameter isin't relevant. */
   txSduReq->phichGrpNumber = 0;

   /*For PDCCH channel these parameters are not relevant, 
     hence setting them to 0.*/
   txSduReq->nackAck = 0;
   txSduReq->uciFormat = 0;
   
   /*stopping Task*/
   SStopTask(startTime1, PID_CL_PDCCH_DAT_REQ);
   txSduReq->chanId = channelId;
   txSduReq->msgType = PHY_TXSDU_REQ;
   txSduReq->phyEntityId = cellCb->phyInstId;
   /*ADARSHA */
   txSduReq->cwId = 0; /* Overridden by caller if needed (for mimo) */

#ifndef BATCH_PROCESSING_DL
   phyTxSdu->txSduReq = (PGENMSGDESC)txSduReq;
#endif
   /*stopping Task*/
   SStopTask(startTime, PID_CL_FILL_TXSDU);
   RETVALUE(ROK);
} /* end of ysMsUtlFillTxSduForPDCCH */


/* HARQ_UL: Function to form HI and DCI0 SDUs */
/*
*
*       Fun:   ysMsUtlFillDci0HiSdu
*
*       Desc:
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_utl.c
*
*/
#ifndef TFU_TDD
PUBLIC S16 ysMsUtlFillDci0HiSdu
(
YsPhyTxSdu     *phyTxSdu,
TfuPhichInfo  *phichInfo,
TfuPdcchInfo  *pdcchInfo,
U8            channelType,
U16           channelId,
YsCellCb      *cellCb
)
#else
PUBLIC S16 ysMsUtlFillDci0HiSdu
(
YsPhyTxSdu     *phyTxSdu,
TfuPhichInfo  *phichInfo,
TfuPdcchInfo  *pdcchInfo,
U8            channelType,
U16           channelId,
YsCellCb      *cellCb,
U8            subframe
)
#endif
{

   PGENMSGDESC pMsgDesc;
   PHIINFOMSGDESC  hiSdu;
   PDCIULSDUMSG    dci0Sdu;
#ifdef EMTC_ENABLE
	PDCIULCATMSDUMSG   dci60Sdu;
#endif
   TRC2(ysMsUtlFillDci0HiSdu)


   switch(channelType)
   {
      case PHICH:
      {
#ifdef BATCH_PROCESSING_DL
         pMsgDesc = phyTxSdu->txSduReq;
#else
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
         pMsgDesc = (PGENMSGDESC )ysMsUtlAllocSvsrMsg(TRUE, (sizeof(HIINFOMSGDESC)));
#else
         pMsgDesc = (PGENMSGDESC )ysMsUtlAllocSvsrMsg(TRUE);
#endif
   if (pMsgDesc == NULLP)
   {
      RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId,"Failed to allocate memory for DCI0HISDU");
      MSPD_ERR("Failed to allocate memory for DCI0HISDU");
      RETVALUE (RFAILED);
   }
#endif
         hiSdu= (PHIINFOMSGDESC)(pMsgDesc);
         if (phichInfo)
         {

            U8     nGPhich;
            U8     sixNg = cellCb->cellInfo.phichSixNg;
            U8     seqIdx;
            U8     twoNSfPhich;
                U8     bw = cellCb->cellInfo.dlBw;

            /* HARQ_UL: Removed the incorrect assigment of phichSeqIndex*/

            if(CTF_PHICH_DUR_NORMAL == cellCb->cellCfg.phichCfg.duration)
            {
               nGPhich = ((sixNg * ((bw + 7)/ 8) + 5)/6);
               twoNSfPhich = 8;
            }
            else
            {
               nGPhich = 2 * ((sixNg * ((bw + 7)/ 8) + 5)/6);
                twoNSfPhich = 4;
            }
               seqIdx = ((phichInfo->rbStart/nGPhich) + phichInfo->nDmrs) % 
                  (twoNSfPhich);

            hiSdu->channelId = channelId;
            hiSdu->msgType = PHY_TXHISDU_REQ;
            hiSdu->msgLength = sizeof(HIINFOMSGDESC);
            hiSdu->nackAck = phichInfo->isAck;
#ifndef TFU_TDD
               hiSdu->phichGroupNumber = 
                  (phichInfo->rbStart + phichInfo->nDmrs) % nGPhich;
#else
            hiSdu->phichGroupNumber = 
                  (phichInfo->rbStart + phichInfo->nDmrs) % nGPhich + 
                   (phichInfo->iPhich * YsTddPhichMValTbl[cellCb->ulDlCfgIdx][subframe] * nGPhich);
#endif
            hiSdu->phichSequenceIndex = seqIdx;
            hiSdu->transmissionMode = cellCb->cellInfo.cmnTransMode;
            hiSdu->txPowerControl = 0 /* HARQ_TODO */;
#ifdef CA_PHY
#if 0//ndef TFU_TDD
            hiSdu->twoHarqInfoValid = 0 ;/*TODO */
            hiSdu->phichSequenceIndex2 = 0 ; /*TODO */
            hiSdu->phichGroupNumber2 = 0; /*TODO */
#endif
#endif
            hiSdu->phyEntityId = cellCb->phyInstId;
         }
         break;
      }

      case PDCCH:
         switch(pdcchInfo->dci.dciFormat)
         {
            case TFU_DCI_FORMAT_0:
               {
                  U16 bW, bits, idx = 0;
                  U16 bitIdx = 0;
                  U16          riv;
                  U8         dci[8];
                  U16        dciSize;
                  U8         *pDci = dci;
                  TfuDciFormat0Info *format0 = &pdcchInfo->dci.u.format0Info;
#ifdef BATCH_PROCESSING_DL
                  pMsgDesc = phyTxSdu->txSduReq;
#else
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
                  pMsgDesc = (PGENMSGDESC )ysMsUtlAllocSvsrMsg(TRUE, (sizeof(DCIULSDUMSG)));
#else
                  pMsgDesc = (PGENMSGDESC )ysMsUtlAllocSvsrMsg(TRUE);
#endif
                  if (pMsgDesc == NULLP)
                  {
                     RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId,"Failed to allocate memory for DCI0HISDU");
                     MSPD_ERR("Failed to allocate memory for DCI0HISDU");
                     RETVALUE (RFAILED);
                  }
#endif
                  dci0Sdu= (PDCIULSDUMSG)(pMsgDesc);

                  /* SR_RACH_STATS */
                  if (format0->isSrGrant == TRUE)
                  {
                     rgNumSrGrant++;
                  }
                  if (format0->isMsg4PdcchWithCrnti == TRUE)
                  {
                     rgNumMsg4PdcchWithCrnti++;
                  }

                  bW = YS_MS_GET_UL_BW(cellCb->cellCfg.bwCfg);

                  /*-- Calculate resource block assignment bits need to be set
                    Which is ln(N(N+1)/2) 36.212 5.3.3.1 --*/
                  bits = (bW * (bW + 1) / 2);
                  while ((bits & 0x8000) == 0)
                  {
                     bits <<= 1;
                     idx++;
                  }
                  bits = 16 - idx;

                  cmMemset(pDci, 0, 8);
                  YS_MS_SETBITRANGE(pDci, bitIdx, 1, 0); bitIdx++; /*-- Format 0 --*/
                  YS_MS_SETBITRANGE(pDci, bitIdx, 1, format0->hoppingEnbld);
                  bitIdx++;
                  riv = ysMsCalcRiv(bW, format0->rbStart, format0->numRb);
#ifdef LTEMAC_SPS
                  if (format0->rbStart ==  0xFF)
                  {
                     riv = ~(~0 << bits);
                     //printf ("SPS_CL_REL ISSUE riv %x \n",riv);
                  }
#endif
                  if (format0->hoppingEnbld)
                  {
                     /*-- Resource block assignment bits need to be set
                       Which is ln(N(N+1)/2) --*/
                     YS_MS_SETBITRANGE(pDci, bitIdx, format0->hoppingBits, 0);  
                     bitIdx += format0->hoppingBits;
                     YS_MS_SETBITRANGE(pDci, bitIdx, 
                     (bits - format0->hoppingBits), 0); 
                     bitIdx += (bits - format0->hoppingBits);
                  }
                  else
                  {
                     YS_MS_SETBITRANGE(pDci, bitIdx, bits, riv); 
                     bitIdx += (bits);
                  }


                  YS_MS_SETBITRANGE(pDci, bitIdx, 5, format0->mcs);
                  bitIdx += 5;
                  YS_MS_SETBITRANGE(pDci, bitIdx, 1, format0->ndi);
                  bitIdx++;
                  YS_MS_SETBITRANGE(pDci, bitIdx, 2, format0->tpcCmd);
                  bitIdx += 2;
                  YS_MS_SETBITRANGE(pDci, bitIdx, 3, format0->nDmrs);
                  bitIdx += 3;
#ifdef TFU_TDD

               if(!cellCb->ulDlCfgIdx)
               {/*UL Index is valid only for config mode 0
                 *Both UlIndex and DAI should not co exist together
                 */
                  STKLOG(STK_MD_YS,STK_LOG_ERR,"Filling UL Idx!!!!%d\n",cellCb->ulDlCfgIdx);
                  YS_MS_SETBITRANGE(pDci, bitIdx, 2, format0->ulIdx);
                  bitIdx += 2;
               }else
               {
                  YS_MS_SETBITRANGE(pDci, bitIdx, 2, format0->dai - 1);
                  bitIdx += 2;
               }

#endif
                  YS_MS_SETBITRANGE(pDci, bitIdx, format0->numCqiBit, format0->cqiReq);
                  bitIdx += format0->numCqiBit;
#if 0
                  dciSize = (bitIdx / 8) + ((bitIdx % 8)?1:0);
#endif
                  /*fix for decoding on WJ.*/
                  /* Adding two bits for format 0 to make it equat to size for
                   * format 1, i.e. 27 bits */
                  dci0Sdu->channelId = channelId;
                  dci0Sdu->msgType = PHY_TXDCIULSDU_REQ;
                  dci0Sdu->msgLength = sizeof(DCIULSDUMSG);
                  dci0Sdu->numBitsDciUL = pdcchInfo->dciNumOfBits;
                  dciSize = (pdcchInfo->dciNumOfBits + 7) / 8;
                  RASSERT_COREDUMP(bitIdx <= pdcchInfo->dciNumOfBits);
                  dci0Sdu->phyEntityId = cellCb->phyInstId;

                  switch(pdcchInfo->aggrLvl)
                  {
                     case CM_LTE_AGGR_LVL1:
                        dci0Sdu->numCCE = 1;
                        break;
                     case CM_LTE_AGGR_LVL2:
                        dci0Sdu->numCCE = 2;
                        break;
                     case CM_LTE_AGGR_LVL4:
                        dci0Sdu->numCCE = 4;
                        break;
                     case CM_LTE_AGGR_LVL8:
                        dci0Sdu->numCCE = 8;
                        break;
                     default:
                        break;
                  }

                  dci0Sdu->rnti = pdcchInfo->rnti;
                  dci0Sdu->startCCE = pdcchInfo->nCce;
                  dci0Sdu->numPayloadBytes = dciSize; /* HARQ_TODO: Chk if needed*/
                  dci0Sdu->transmissionMode = cellCb->cellInfo.cmnTransMode;
                  dci0Sdu->txPowerControl = 0 /* HARQ_TODO */;
                  /* HARQ_TODO: Correct after APIs are frozen */
               /*Added as per discussion with Sumesh*/
                    dci0Sdu->pTxSdu = 0;
                  cmMemcpy((U8 *)((U8 *)dci0Sdu + sizeof(DCIULSDUMSG)), pDci,
                        dciSize);
                  break;
               }

            default:
               RLOG_ARG0(L_WARNING,DBG_CELLID,cellCb->cellId,"Unknown DCI format");
               RETVALUE(RFAILED);
         }
         break;
#ifdef EMTC_ENABLE	
		case MPDCCH:
			switch(pdcchInfo->dci.dciFormat)
         {
         	
            case TFU_DCI_FORMAT_6_0A:
               {
                  U16 bW, bits, idx = 0;
                  U16 bitIdx = 0;
                  U8         dci[8];
                  U16        dciSize;
                  U8         *pDci = dci;
                  TfuDciFormat60aInfo *format60 = &pdcchInfo->dci.u.format60aInfo;
#ifdef BATCH_PROCESSING_DL
                  pMsgDesc = phyTxSdu->txSduReq;
#else
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
                  pMsgDesc = (PGENMSGDESC )ysMsUtlAllocSvsrMsg(TRUE, (sizeof(DCIULCATMSDUMSG)));
#else
                  pMsgDesc = (PGENMSGDESC )ysMsUtlAllocSvsrMsg(TRUE);
#endif
                  if (pMsgDesc == NULLP)
                  {
                     RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId,"Failed to allocate memory for DCI0HISDU");
                     MSPD_ERR("Failed to allocate memory for DCI0HISDU");
                     RETVALUE (RFAILED);
                  }
#endif
                  dci60Sdu= (PDCIULCATMSDUMSG)(pMsgDesc);
#if 0
                  /* SR_RACH_STATS */
                  if (format60->isSrGrant == TRUE)
                  {
                     rgNumSrGrant++;
                  }
                  if (format0->isMsg4PdcchWithCrnti == TRUE)
                  {
                     rgNumMsg4PdcchWithCrnti++;
                  }
#endif
                  bW = YS_MS_GET_UL_BW(cellCb->cellCfg.bwCfg)/6;

                  bits = bW;
                  while ((bits & 0x8000) == 0)
                  {
                     bits <<= 1;
                     idx++;
                  }
                  //bits represent number of bits required to represent NB index
                  bits = (15 - idx) + 5;

                  cmMemset(pDci, 0, 8);
                  YS_MS_SETBITRANGE(pDci, bitIdx, 1, 0); bitIdx++; /*-- Format 60-A --*/
                  YS_MS_SETBITRANGE(pDci, bitIdx, 1, format60->hoppingEnbld);
                  bitIdx++;

                  YS_MS_SETBITRANGE(pDci, bitIdx, bits, format60->riv); 
                  bitIdx += (bits);

                  YS_MS_SETBITRANGE(pDci, bitIdx, 4, format60->mcs);
                  bitIdx += 4;

                  YS_MS_SETBITRANGE(pDci, bitIdx, 2, format60->rep);
                  bitIdx += 2;

                  YS_MS_SETBITRANGE(pDci, bitIdx, 3, format60->hqProcId);
                  bitIdx += 3;

                  YS_MS_SETBITRANGE(pDci, bitIdx, 1, format60->ndi);
                  bitIdx++;

                  YS_MS_SETBITRANGE(pDci, bitIdx, 2, format60->rv);
                  bitIdx+= 2;

                  YS_MS_SETBITRANGE(pDci, bitIdx, 2, format60->tpcCmd);
                  bitIdx += 2;

#ifdef TFU_TDD
                  if(!cellCb->ulDlCfgIdx)
                  {/*UL Index is valid only for config mode 0
                    *Both UlIndex and DAI should not co exist together
                    */
                     STKLOG(STK_MD_YS,STK_LOG_ERR,"Filling UL Idx!!!!%d\n",cellCb->ulDlCfgIdx);
                     YS_MS_SETBITRANGE(pDci, bitIdx, 2, format60->ulIdx);
                     bitIdx += 2;
                  }
                  else
                  {
                     YS_MS_SETBITRANGE(pDci, bitIdx, 2, format60->dai - 1);
                     bitIdx += 2;
                  }

#endif
                  YS_MS_SETBITRANGE(pDci, bitIdx, 1, format60->cqiReq);
                  bitIdx++;

                  YS_MS_SETBITRANGE(pDci, bitIdx, 1, format60->isSrs);
                  bitIdx++;

                  YS_MS_SETBITRANGE(pDci, bitIdx, 2, format60->dciRep);
                  bitIdx += 2;

                  dciSize = (bitIdx / 8) + ((bitIdx % 8)?1:0);
                  /*fix for decoding on WJ.*/
                  /* Adding two bits for format 0 to make it equat to size for
                   * format 1, i.e. 27 bits */
                  dci60Sdu->channelId = channelId;
                  dci60Sdu->msgType = PHY_TXDCICATMSDU;//PHY_TXDCIULSDU_REQ;
                  dci60Sdu->msgLength = sizeof(DCIULCATMSDUMSG);
                  dci60Sdu->numBitsDciUL = pdcchInfo->dciNumOfBits;

#if 1
                  /* Size has to be same as 61A . in case of 10mhz it is 29*/
                  if(dci60Sdu->numBitsDciUL != 29)
                     STKLOG(STK_MD_YS,STK_LOG_ERR,"ERROR:: Invalid size for DCI 6_0A(not 29). Size is %d",
                           dci60Sdu->numBitsDciUL);


#endif

                  dci60Sdu->phyEntityId = cellCb->phyInstId;

                  //Need to add cases for higher aggregation level
                  switch(pdcchInfo->aggrLvl)
                  {
                     case CM_LTE_AGGR_LVL1:
                        dci60Sdu->numCCE = 1;
                        break;
                     case CM_LTE_AGGR_LVL2:
                        dci60Sdu->numCCE = 2;
                        break;
                     case CM_LTE_AGGR_LVL4:
                        dci60Sdu->numCCE = 4;
                        break;
                     case CM_LTE_AGGR_LVL8:
                        dci60Sdu->numCCE = 8;
                        break;
#ifdef EMTC_ENABLE
                     case CM_LTE_AGGR_LVL12:
                        dci60Sdu->numCCE = 12;
                        break;
                     case CM_LTE_AGGR_LVL16:
                        dci60Sdu->numCCE = 16;
                        break;
                     case CM_LTE_AGGR_LVL24:
                        dci60Sdu->numCCE = 24;
                        break;
#endif
                     default:
                        break;
                  }

                  dci60Sdu->rnti = pdcchInfo->rnti;
                  dci60Sdu->startCCE = pdcchInfo->nCce;
                  dci60Sdu->numPayloadBytes = 0; /* HARQ_TODO: Chk if needed*/
                  dci60Sdu->transmissionMode = cellCb->cellInfo.cmnTransMode;
                  dci60Sdu->txPowerControl = 0 /* HARQ_TODO */;
                  //TODO_SID
                  dci60Sdu->setNum = 0; 
                  dci60Sdu->localizedPortIndex = pdcchInfo->localizedAntPortIndex;
                  dci60Sdu->distributedAlloc = pdcchInfo->distributedAlloc;
                  dci60Sdu->startRB = pdcchInfo->startRB;
                  dci60Sdu->nRbXm = pdcchInfo->nRBxm;
                  dci60Sdu->dmrs_txpowerControl = pdcchInfo->dmrs_txpowerControl;
                  dci60Sdu->reserved1 = 0;
                  dci60Sdu->scramblerInit = pdcchInfo->scramblerInit;
                  dci60Sdu->demodRSforMpdcchInitValue = pdcchInfo->demodRSInitValue;

                  /* HARQ_TODO: Correct after APIs are frozen */
                  /*Added as per discussion with Sumesh*/
                  dci60Sdu->pTxSdu = 0;
                  cmMemcpy((U8 *)((U8 *)dci60Sdu + sizeof(DCIULCATMSDUMSG)), pDci,
                        dciSize);
                  break;
               }
            default:
               STKLOG(STK_MD_YS,STK_LOG_ERR,"ERROR - Unknown DCI format\n");
               RETVALUE(RFAILED);
         }
         break;
#endif
      default:
         YS_DBG_ERR((_ysp, "Unknown channel"));
         RETVALUE(RFAILED);
         break;
   }


#ifndef BATCH_PROCESSING_DL
   phyTxSdu->txSduReq = pMsgDesc;
#endif

   RETVALUE(ROK);
} /* end of ysMsUtlFillDci0HiSdu */


/*
*
*       Fun:   ysMsUtlEmptyLst
*
*       Desc:  This function is used to empty and free a given linked list
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC S16 ysMsUtlEmptyLst
(
CmLListCp *lst
)
{

   CmLList *cmLstEnt;
   YsPhyTxSdu *phyTxSdu;


   TRC2(ysMsUtlEmptyLst)

   cmLstEnt = lst->first;

   while (cmLstEnt)
   {

      phyTxSdu = (YsPhyTxSdu*)cmLstEnt->node;
      cmLstEnt = cmLstEnt->next;
      cmLListDelFrm(lst, &phyTxSdu->lnk);
      /* TODO: need to free the TXSDU also */
      YS_MS_FREE(phyTxSdu, sizeof(YsPhyTxSdu), 0);
   }


   RETVALUE (ROK);

}

/*
*
*       Fun:   ysMsUtlFillStartReq
*
*       Desc:  This primitive is used to fill start request
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC S16 ysMsUtlFillStartReq
(
PSTARTREQ      startReq,
YsCellCb       *cellCb
)
{
   TRC2(ysMsUtlFillStartReq)
   if (startReq == NULLP || cellCb == NULLP)
   {
      RLOG0(L_ERROR,"ysMsUtlFillStartReq(): Invalid ptr");
      RETVALUE (RFAILED);
   }
   /* Configuring PHY from configuration file */
   startReq->msgType     = PHY_START_REQ;
   startReq->phyEntityId = cellCb->phyInstId;
   {
     startReq->mode        = cellCb->vendorParams.opMode;
     startReq->count       = cellCb->vendorParams.counter;
     startReq->period      = cellCb->vendorParams.period;
   }

   RETVALUE (ROK);
} /* ysMsUtlFillStartReq */

/*
*
*       Fun:   ysMsUtlFillStopReq
*
*       Desc:  This primitive is used to fill stop request
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC S16 ysMsUtlFillStopReq
(
PGENMSGDESC    stopReq,
YsCellCb       *cellCb
)
{
   TRC2(ysMsUtlFillStopReq)
   if (stopReq == NULLP || cellCb == NULLP)
   {
      RLOG0(L_ERROR,"ysMsUtlFillStopReq(): Invalid ptr");
      RETVALUE (RFAILED);
   }

   stopReq->msgSpecific    = 0; /* Need to find what to fill */
   stopReq->msgType        = PHY_STOP_REQ;
   stopReq->phyEntityId    = cellCb->phyInstId;

   RETVALUE (ROK);
} /* ysMsUtlFillStopReq */

/*
*
*       Fun:   ysMsUtlFillShutdownReq
*
*       Desc:  This primitive is used to fill shutdown request
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC S16 ysMsUtlFillShutdownReq
(
PGENMSGDESC    shutdownReq,
YsCellCb       *cellCb
)
{
   TRC2(ysMsUtlFillShutdownReq)
   if (shutdownReq == NULLP || cellCb == NULLP)
   {
      RLOG0(L_ERROR,"ysMsUtlFillShutdownReq(): Invalid ptr");
      RETVALUE (RFAILED);
   }

   shutdownReq->msgSpecific    = 0; /* Need to find what to fill */
   shutdownReq->msgType        = PHY_SHUTDOWN_REQ;
   shutdownReq->phyEntityId    = cellCb->phyInstId;

   RETVALUE (ROK);
} /* ysMsUtlFillShutdownReq */

#ifndef TENB_RTLIN_CHANGES
/* HARQ */
/*
*
*       Fun:   ysMsUtlAllocSvsrMsg
*
*       Desc:  This primitive is used to allocate svsrMsg
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC PGENMSGDESC ysMsUtlAllocSvsrMsg
(
Bool isSdu
)
{
   TRC2(ysMsUtlAllocSvsrMsg)
  PGENMSGDESC msg;
  VOLATILE U32     startTime = 0;
  
  /*starting Task*/
  SStartTask(&startTime, PID_SVSRALLOC_MSG);
  if (!isSdu)
  {
     msg = (PGENMSGDESC)SvsrAllocMsgEx(YS_MS_MAX_SDU_SZ);
     if (msg == NULLP)
     {
        RLOG1(L_FATAL,"Svsr FAILED Invalid memory %x...Exiting...", msg);
        stop_printf("Svsr FAILED Invalid memory %x...Exiting...\n", msg);
       exit(-1);
      }
     /*stopping Task*/
     SStopTask(startTime, PID_SVSRALLOC_MSG);
      RETVALUE(msg);
  }
  if (msg = (PGENMSGDESC)SvsrAllocMsg())
  {
#if 0  /* VINAYAKA */
      if ( (U32)msg < NULLP)
      {
       RLOG1(L_ERROR,"Svsr FAILED Invalid memory %x......Exiting......\n", msg);
       stop_printf("Svsr FAILED Invalid memory %x......Exiting......\n", msg);
       exit(-1);
      }
#endif
     /*stopping Task*/
     SStopTask(startTime, PID_SVSRALLOC_MSG);
      RETVALUE(msg);
  }

   RLOG_ARG0(L_ERROR,"Svsr FAILED......Exiting......");
   stop_printf("Svsr FAILED......Exiting......\n");
   exit(-1);
}
#endif


PUBLIC S16 ysUtlAllocQCIPCSBuf
(
Data    **pData,            /* Pointer of the data to be returned */
Size    size,                /* size */
U16     indx                 /* cell index*/
)
{
   S16 ret;

   //size += sizeof(struct danipc_cdev_msghdr);   
   ret = SGetSBuf(ysCb.ysInit[indx].region, ysCb.ysInit[indx].pool, pData, size );
   //*pData += sizeof(struct danipc_cdev_msghdr);
   //printf("ysUtlAllocQCIPCSBuf size %d ,ret %d \n",size,ret);
   RETVALUE(ret);
}

PUBLIC S16 ysUtlFreeQCIPCSBuf
(
Data    *pData,            /* Pointer of the data to be returned */
Size    size,                /* size */
U16 	indx				 /* cell index*/

)
{
   S16 ret;

   //size += sizeof(struct danipc_cdev_msghdr);
   //pData -= sizeof(struct danipc_cdev_msghdr);
   
   ret = SPutSBuf(ysCb.ysInit[indx].region, ysCb.ysInit[indx].pool, pData, size);	
   RETVALUE(ret);
}




/*
*
*       Fun:   ysMsUtlGetPhyListElem
*
*       Desc:  This primitive is used to allocate and get a PHY list element
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
PUBLIC PMAC2PHY_QUEUE_EL ysMsUtlGetPhyListElem
(
   U32 size
)
#else
PUBLIC PMAC2PHY_QUEUE_EL ysMsUtlGetPhyListElem
(
)
#endif
{
   TRC2(ysMsUtlGetPhyListElem)
   PGENMSGDESC      pMsgDesc;
   PMAC2PHY_QUEUE_EL pElem = NULLP;

   /* Allocate a message towards Phy using sysCore */
#if defined (INTEL_ALLOC_WLS_MEM) || defined (TL_ALLOC_ICC_MEM)
   pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg (FALSE, size);
#else
   pMsgDesc = (PGENMSGDESC) ysMsUtlAllocSvsrMsg (FALSE);
#endif
   if (pMsgDesc == NULLP)
   {
      RLOG0(L_FATAL, "Unable to allocate memory for PhyListElem");
      RETVALUE (NULLP);
   }
   pElem = (PMAC2PHY_QUEUE_EL)(pMsgDesc);

   RETVALUE(pElem);

}

/* HARQ */
/*
*
*       Fun:   ysMsUtlAddToPhyList
*
 *       Desc:  This primitive is used to add an element to the beginning 
 *              of the linked list
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC S16 ysMsUtlAddToPhyList
(
YsPhyLstCp        *lstCp,
PMAC2PHY_QUEUE_EL lstElem
)
{
   TRC2(ysMsUtlAddToPhyList)
  PMAC2PHY_QUEUE_EL lstStart = lstCp->head;
  lstCp->count++;
  if (!lstStart)
  {
     lstCp->head = lstCp->tail = lstElem;
    RETVALUE(ROK);
  }

   lstElem->Next = lstStart;
   /* lstStart->Next = lstElem; */
   lstCp->head = lstElem;

   RETVALUE(ROK);

}

/*
*
*       Fun:   ysMsUtlApndAllCellList
*
 *       Desc:  This primitive is used to concatenate all
 *       the cells list to single list
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC PMAC2PHY_QUEUE_EL ysMsUtlApndAllCellList
(
U8 sfNum
)
{
   TRC2(ysMsUtlApndAllCellList)
   YsPhyLstCp          *pUlDlList;
   YsCellCb            *cellCb    = ysCb.tfuSapLst[0]->cellCb;
   U8                   idx;

   if(cellCb == NULLP)
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"No cells added yet....\n");
      RETVALUE(NULLP);
   }

   pUlDlList = &cellCb->dlEncL1Msgs[sfNum].ulDlLst;

   if (FALSE == cellCb->dlEncL1Msgs[sfNum].isdatReqPres)
   {
      ysMsDlmSndVectSDU(cellCb);
   }

   for(idx = 1; idx < (ysCb.numOfCells); idx++)
   {
      cellCb = ysCb.tfuSapLst[idx]->cellCb;

      if (FALSE == cellCb->dlEncL1Msgs[sfNum].isdatReqPres)
      {
         ysMsDlmSndVectSDU(cellCb);
      }
      else
      {
         STKLOG(STK_MD_YS,STK_LOG_INFO,"Did not Frame the vectrs for idx.. %d\n",idx);
      }

      ysMsUtlCatPhyList(pUlDlList, &cellCb->dlEncL1Msgs[sfNum].ulDlLst);
   }

   RETVALUE(pUlDlList->head);
}

/*
*
*       Fun:   ysMsUtlInitAllCellList
*
 *       Desc:  This primitive is used to intialize all
 *       the cells UL DL list
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC Void ysMsUtlInitAllCellList
(
U8 sfNum
)
{
   TRC2(ysMsUtlInitAllCellList)
   YsCellCb            *cellCb;
   U8                   idx;

   for(idx = 0; idx < (ysCb.numOfCells); idx++)
   {
      cellCb = ysCb.tfuSapLst[idx]->cellCb;
      ysMsUtlInitPhyList(&cellCb->dlEncL1Msgs[sfNum].ulDlLst);
   }
   RETVOID;
}




/*
*
*       Fun:   ysMsUtlCatPhyList
*
 *       Desc:  This primitive is used to concatenate two lists. 
 *              It concatenates in order L1L2
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC S16 ysMsUtlCatPhyList
(
YsPhyLstCp        *lstCp1,
YsPhyLstCp        *lstCp2
)
{
   TRC2(ysMsUtlCatPhyList)
   PMAC2PHY_QUEUE_EL lstTail1 = lstCp1->tail;
   PMAC2PHY_QUEUE_EL lstHead2 = lstCp2->head;

   if (lstTail1)
   {
      lstTail1->Next = lstHead2;
      lstCp1->tail = lstCp2->tail;
      lstCp1->count += lstCp2->count;
   }
   else
   {
      *lstCp1 = *lstCp2;
   }
   RETVALUE(ROK);

}


/* HARQ */
/*
*
*       Fun:   ysMsUtlInitPhyList
*
*       Desc:  This primitive is used to initialize the lists
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC S16 ysMsUtlInitPhyList
(
YsPhyLstCp        *lstCp
)
{
TRC2(ysMsUtlInitPhyList)
 lstCp->count = 0;
 lstCp->head = NULLP;
 lstCp->tail = NULLP;
 RETVALUE(ROK);

}

/*
*
*       Fun:   ysMsUtlFreePhyList
*
*       Desc:  This primitive is used to free the list
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*
*/

PUBLIC S16 ysMsUtlFreePhyList
(
YsPhyLstCp        *lstCp
)
{
   TRC2(ysMsUtlFreePhyList)
 PMAC2PHY_QUEUE_EL tmp = lstCp->head;
 PMAC2PHY_QUEUE_EL next = NULLP;

 while (tmp)
 {
   next = tmp->Next;
#ifndef TENB_RTLIN_CHANGES
   SvsrFreeMsg(tmp->MessagePtr);
   SvsrFreeMsg(tmp);
#else
#ifndef BATCH_PROCESSING_DL
   ysFreePhyMsg(tmp->MessagePtr);
#endif
   {
   ysFreePhyMsg(tmp);
   }
#endif
   tmp = next;
 }

 lstCp->count = 0;
 lstCp->head = NULLP;
 lstCp->tail = NULLP;
 RETVALUE(ROK);

}

/*
 * *
 * *       Fun:   ysSendCrcToMac
 * *
 * *       Desc:
 * *
 * *       Ret:
 * *
 * *       Notes: None
 * *
 * *       File:  ys_ms_utl.c
 * *
 * */
PUBLIC Void ysSendCrcToMac
(
 YsCellCb          *cellCb,
 TfuCrcIndInfo     *crcIndInfo
 )
{
#if 1
#else
#ifndef RG_SCH_DYNDLDELTA
   U8 dlCntrlsubframe = 0;
#endif
#endif
   YsUiTfuCrcInd(&cellCb->schTfuSap->sapPst, cellCb->schTfuSap->suId,
         crcIndInfo);
   /* Check whether we are expecting DatReq for (currenttime + TFU_DELTA)th 
    * subframe
    * or not. If not
    * 1. Append the UlCntrlReq elements to PHY message List.
    * 2. Then send the TX&RX vector down
    * else
    * Do nothing*/
#if 1
   U8 sfNum = (cellCb->timingInfo.subframe + TFU_DELTA) % YS_NUM_SUB_FRAMES;
   cellCb->dlEncL1Msgs[sfNum].isCrcToMacSnd = TRUE;
#else
#ifndef RG_SCH_DYNDLDELTA
   dlCntrlsubframe =
      (cellCb->timingInfo.subframe + TFU_DELTA) % YS_NUM_SUB_FRAMES;
   if (FALSE == cellCb->dlEncL1Msgs[dlCntrlsubframe].isdatReqPres)
   {
        ysMsDlmSndVectSDU(cellCb);
        CM_MEAS_TIME(cellCb->timingInfo.subframe, CM_DBG_MAC_TTI_IND, CM_DBG_SND_SDU);
   }
#else
   U8 sfNum = (cellCb->timingInfo.subframe + TFU_DELTA) % YS_NUM_SUB_FRAMES;
   cellCb->dlEncL1Msgs[sfNum].isCrcToMacSnd = TRUE;
   Bool   infoRcvd = FALSE;
   infoRcvd = ysChkSfInfoStatus(cellCb);
   
   if (TRUE == infoRcvd )
   {
      /* sending the Tx&RX vector down */
      ysMsDlmSndVectSDU(cellCb);
   }
#endif
#endif
   return;
}

#ifndef TENB_RTLIN_CHANGES 
PUBLIC Void rsysStopHndlr()
{
   U32  memavail;
   extern SysStayInfo syscoreinfo [4];
   static U32 writeOnlyOnce = 0;
   U8 coreId = 2;

   if (writeOnlyOnce)
   {
      RETVOID;
   }
   writeOnlyOnce = 1;
   RLOG0(L_ALWAYS,"PHY stopped, showing memory info");
#ifdef SS_LOCKLESS_MEMORY            
   SGlobMemInfoShow();
#ifndef SS_GLOBAL_MEMORY            
   SRegInfoShow(0, &memavail);
#endif /* SS_GLOBAL_MEMORY */
#endif /* SS_LOCKLESS_MEMORY */
   for (;coreId <= 3; ++coreId)
   {
      RLOG2(L_ALWAYS,"syscoreinfo[%u].mBuf 0x%x", coreId, syscoreinfo[coreId].mBuf);
      RLOG2(L_ALWAYS,"syscoreinfo[%u].event %u", coreId,syscoreinfo[coreId].event);
      RLOG3(L_ALWAYS,"syscoreinfo[%u].dstEnt %u 0x%x",coreId,syscoreinfo[coreId].dstEnt, syscoreinfo[coreId].dstEnt);
      RLOG2(L_ALWAYS,"syscoreinfo[%u].dstInst %u",coreId,syscoreinfo[coreId].dstInst);
      RLOG3(L_ALWAYS,"syscoreinfo[%u].srcEnt %u 0x%x",coreId,syscoreinfo[coreId].srcEnt, syscoreinfo[coreId].srcEnt);
      RLOG2(L_ALWAYS,"syscoreinfo[%u].timestamp 0x%x",coreId, syscoreinfo[coreId].timestamp);
      RLOG2(L_ALWAYS,"syscoreinfo[%u].caller[0] 0x%x",coreId, syscoreinfo[coreId].caller[0]);
     RLOG2(L_ALWAYS,"syscoreinfo[%u].caller[1] 0x%x",coreId, syscoreinfo[coreId].caller[1]);
     RLOG2(L_ALWAYS,"syscoreinfo[%u].caller[2] 0x%x",coreId, syscoreinfo[coreId].caller[2]);
     RLOG2(L_ALWAYS,"syscoreinfo[%u].caller[3] 0x%x",coreId, syscoreinfo[coreId].caller[3]);
      RLOG2(L_ALWAYS,"syscoreinfo[%u].res[0] %u",coreId, syscoreinfo[coreId].res[0]); /* 1 is for Icore msg */
      RLOG2(L_ALWAYS,"syscoreinfo[%u].res[1] %u",coreId,syscoreinfo[coreId].res[1]); /* 1 is for start of the task */
   }
}
#endif /* TENB_RTLIN_CHANGES */

#ifndef YS_MS_NO_TA
/*
 *       Fun:   ysMsUtlIncrTime
 *
 *       Desc:
 *
 *       Ret:
 *
 *       Notes: None
 *
 *       File:
 */
PUBLIC Void ysMsUtlIncrTime
(
 CmLteTimingInfo   *t,
 U32                delta
 )
{
   U32   sfnincr = delta / 10;
   U32   sfincr  = delta % 10;
   U32   sf      = (U32)t->subframe;

   if ((sf = sf + sfincr) > 10)
   {
      sf -= 10;
      ++sfnincr;
   }
   t->subframe = sf;
   t->sfn = (t->sfn + sfnincr) % 1024;
   return;
}


/*
 *       Fun:   ysMsUtlAddToTaLst
 *
 *       Desc:
 *
 *       Ret:
 *
 *       Notes: None
 *
 *       File:
 */
PUBLIC Void ysMsUtlAddToTaLst
(
 YsCellCb          *cellCb,
 YsUeCb            *ueCb
)
{
   CmLListCp  *lst = &cellCb->taUeLst;

   /* Add to head */
   lst->crnt = lst->first;
   ueCb->tarptInfo.lnk.node = (PTR)ueCb;
   cmLListInsCrnt(lst, &ueCb->tarptInfo.lnk);
   return;
}


/*
 *       Fun:   ysMsUtlTmrProc
 *
 *       Desc:
 *
 *       Ret:
 *
 *       Notes: None
 *
 *       File:
 */
PUBLIC Void ysMsUtlTmrProc
(
 YsCellCb          *cellCb
 )
{
   CmLListCp  *lst = &cellCb->taUeLst;
   CmLList    *n   = lst->first;
   while (n)
   {
      YsUeCb    *ue = (YsUeCb*)(n->node);
      n = n->next;
      if (YS_TIMING_INFO_SAME(ue->tarptInfo.throttleExp, cellCb->timingInfo))
      {
         cmLListDelFrm(lst, &ue->tarptInfo.lnk);
         ue->tarptInfo.lnk.node = (PTR)NULL;
      }
   }
   return;
}
#endif

#ifdef TENB_RTLIN_CHANGES
/* This function name is same as that provided by MSPD,
 * currently not available in lib so temporarily defined
 * here */
/*
*
*       Fun:   MsgGetDataOffset
*
*       Desc:  Get data offset
*
*       Ret:
*
*       Notes: None
*
*       File:  ys_ms_utl.c
*/
PTR MsgGetDataOffset
(
PTR msg
)
{
   PMSGHEADER pHdr = (PMSGHEADER) msg;
   return ((PTR)&pHdr->param[0]);
}
#endif /* TENB_RTLIN_CHANGES */

PUBLIC Void ysMsMapRntiToChan(YsCellCb * cellCb, CmLteRnti rnti, U8 subframe, 
U16 channelId)
{
   TRC2(ysMsMapRntiToChan)
   cellCb->chan2Rnti[subframe][channelId].rnti = rnti;

   RETVOID;
}

PUBLIC Void ysMsGetRntiFrmChanId(YsCellCb * cellCb, CmLteRnti *rnti, 
      U8 subframe, U16 channelId)
{  
   TRC2(ysMsGetRntiFrmChanId)
   *rnti = cellCb->chan2Rnti[subframe][channelId].rnti;

   RETVOID;
}


PUBLIC S16 ysMsSndMissedCrcInd(YsCellCb * cellCb)
{
   TRC2(ysMsSndMissedCrcInd)
   CmLteTimingInfo rxSduSf = {0};
   CmLteTimingInfo timingInfo = {0};
   S16 ret = 0;
   U16 indx = cellCb->cellId - CM_START_CELL_ID;
   
   timingInfo = cellCb->timingInfo;
     
   rxSduSf.subframe = timingInfo.subframe ? (timingInfo.subframe - 1): 9;

   if (!cellCb->crcSent[rxSduSf.subframe])
   {
      TfuCrcIndInfo     *crcIndInfo = NULLP;
      /* Send the CRC Indication to MAC for the corresponding subframe */
      ret = ysUtlAllocEventMem((Ptr *)&crcIndInfo,
      sizeof(TfuCrcIndInfo), indx, __FUNCTION__,__LINE__);
      if(ret == RFAILED)
      {
         RLOG_ARG0(L_FATAL,DBG_CELLID,cellCb->cellId,
                   "ysMsSndMissedCrcInd(): Memory allocation failed for CrcInd");
         RETVALUE(RFAILED);
      } /* end of if statement */

      cmLListInit(&(crcIndInfo->crcLst));
      crcIndInfo->cellId = cellCb->cellId;
      YS_MS_DECR_TIME(timingInfo, rxSduSf, 1);
      crcIndInfo->timingInfo.sfn = rxSduSf.sfn;
      crcIndInfo->timingInfo.subframe = rxSduSf.subframe;

      RLOG4(L_ERROR,"Sending missed CRC for the previous TTI (%d,%d) at (%d, %d)",
            crcIndInfo->timingInfo.sfn,
            crcIndInfo->timingInfo.subframe,
            cellCb->timingInfo.sfn, 
            cellCb->timingInfo.subframe);
       
      ysSendCrcToMac(cellCb, crcIndInfo);
      cellCb->crcSent[rxSduSf.subframe] = TRUE;
      cellCb->isCrcExptd[rxSduSf.subframe] = FALSE;     
   }
   RETVALUE(ROK);
}

EXTERN U32 dlrate_pju;
EXTERN U32 ulrate_rgu, ulrate_kwu, ulrate_pju;
Void PrintCLStats(RG_STATS *pRgStatsCopy)
{
#define to_mbps(_rate) (_rate /(3.0*125*1000))
   STKLOG(STK_MD_YS,STK_LOG_INFO,"Data Rate DL: tfu=%.2f rgu=%.2f kwu=%.2f pju=%.2f UL: tfu=%.2f rgu=%.2f kwu=%.2f pju=%.2f\n",
         to_mbps((pRgStatsCopy->dlrate_tfu[0]+pRgStatsCopy->dlrate_tfu[1])), to_mbps(pRgStatsCopy->rgDlrate_rgu),to_mbps(pRgStatsCopy->dlrate_kwu),to_mbps(dlrate_pju),
         to_mbps(pRgStatsCopy->rgUlrate_tfu), to_mbps(ulrate_rgu), to_mbps(ulrate_kwu), to_mbps(ulrate_pju));
   dlrate_pju = 0;
   ulrate_rgu = ulrate_kwu = ulrate_pju = 0;
}


#ifdef ENABLE_CNM
/* For filling NMM start message */
PUBLIC S16 ysMsUtlTrigNmmStart
(
PTR         msg
)
{

   TRC2(ysMsUtlTrigNmmStart)
   Buffer *nmmBuf = NULLP;
   ysMsNmmHdr nmmHdr;
   ysMsNmmStart nmmStart;


   if( ROK != SGetMsg(ysCb.ysInit[0].region, ysCb.ysInit[0].region, (Buffer **) &nmmBuf))
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"Mem alloc Failed for Nmm Start Msg\n");
      RETVALUE(RFAILED);
   }

   nmmHdr.msgLength = sizeof(ysMsNmmHdr) + sizeof(ysMsNmmStart);
   nmmHdr.msgType = NMM_START;
   nmmHdr.phyEntityId = 0;

   SAddPstMsgMult((Data *)&nmmHdr,sizeof(ysMsNmmHdr),nmmBuf);    /* MsgLen */

   nmmStart.usSupportedRAT = 0;
#ifdef LTE_TDD
   nmmStart.usDuplex       = 1;
#else
   nmmStart.usDuplex       = 0;
#endif
   if(ysCb.cnmSyncReqMsg.measBandWidth == 50)
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"NFFT configuring for 10 MHZ -> 1024\n\n");
      nmmStart.Nfft           = 1024;
   }else if(ysCb.cnmSyncReqMsg.measBandWidth == 100)
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"NFFT configuring for 20 MHZ -> 2048\n\n");
      nmmStart.Nfft           = 2048;
   }else
   {
      STKLOG(STK_MD_YS,STK_LOG_INFO,"NFFT configuring for BW(%drbs)-> 1024\n\n",
            ysCb.cnmSyncReqMsg.measBandWidth);
      nmmStart.Nfft           = 1024;
   }

   nmmStart.Nfft           = 2048 ;/* need to correct this */
   nmmStart.NrxAnte        = 1;
   nmmStart.reverse1       = 0;
   nmmStart.mode           = 4;
   nmmStart.reverse2       = 0;
   nmmStart.reverse3       = 0;
   nmmStart.count          = 0;
   nmmStart.period         = 0;

   SAddPstMsgMult((Data *)&nmmStart,sizeof(ysMsNmmStart),nmmBuf);    /* MsgLen */

   ysSendNmMsgToPhy(NMM_START, nmmBuf);

   RETVALUE(ROK);
}

/* For filling NMM stop message */
PUBLIC S16 ysMsUtlTrigNmmStopReq
(
PTR         msg
)
{
   TRC2(ysMsUtlTrigNmmStopReq)

   Buffer *nmmBuf = NULLP;
   ysMsNmmHdr   nmmHdr;

   if( ROK != SGetMsg(ysCb.ysInit[0].region, ysCb.ysInit[0].region, (Buffer **) &nmmBuf))
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"Mem alloc Failed for Nmm Start Msg\n");
      RETVALUE(RFAILED);
   }

   nmmHdr.msgLength = sizeof(ysMsNmmHdr);
   nmmHdr.msgType = NMM_STOP;
   nmmHdr.phyEntityId = 0;

   SAddPstMsgMult((Data *)&nmmHdr,sizeof(ysMsNmmHdr),nmmBuf);    /* MsgLen */

   ysSendNmMsgToPhy(NMM_STOP, nmmBuf);

   RETVALUE(ROK);
}


/* For Filling NMM Cell Search Req Msg */
PUBLIC S16 ysMsUtlTrigNmmCellSearchReq
(
PTR         msg
)
{

   TRC2(ysMsUtlTrigNmmCellSearchReq)

   U16  earfcn = ysCb.cnmSyncReqMsg.earfcn;
   U16  pci    = ysCb.cnmSyncReqMsg.pciList[0].nbrPCellId;
   U16  cellSearchReqSize = 0;

   Buffer *nmmBuf = NULLP;
   ysMsNmmHdr   nmmHdr;
   ysMsNmmCellSearchReq nmmCellSearchReq;

   if( ROK != SGetMsg(ysCb.ysInit[0].region, ysCb.ysInit[0].region, (Buffer **) &nmmBuf))
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"Mem alloc Failed for Nmm Start Msg\n");
      RETVALUE(RFAILED);
   }

   STKLOG(STK_MD_YS,STK_LOG_INFO,"CNM:: Cell Searc Req Earfcn %d pci %d\n",earfcn,pci);

   nmmCellSearchReq.earfcn = earfcn ;
   nmmCellSearchReq.exhstiveSearch = 0;
   nmmCellSearchReq.pciCount =  1;
   nmmCellSearchReq.pciList[0] = pci;
   nmmCellSearchReq.measBw = 6;
   nmmCellSearchReq.measPeriod = 10;
   nmmCellSearchReq.vendorFieldCount = 0;

   //cellSearchReqSize = sizeof(ysMsNmmCellSearchReq) - ((YS_MS_MAX_PCI_COUNT - 1) * sizeof(U16)) - (YS_MS_MAX_VENDOR_FIELD_SIZE * sizeof(U16));
   cellSearchReqSize = sizeof(ysMsNmmCellSearchReq);
   //nmmHdr.msgLength = sizeof(ysMsNmmHdr) + sizeof(ysMsNmmCellSearchReq);
   nmmHdr.msgLength = sizeof(ysMsNmmHdr) + cellSearchReqSize;
   nmmHdr.msgType = NMM_CELL_SEARCH_REQ;
   nmmHdr.phyEntityId = 0;

   SAddPstMsgMult((Data *)&nmmHdr,sizeof(ysMsNmmHdr),nmmBuf);    /* MsgLen */

   SAddPstMsgMult((Data *)&nmmCellSearchReq,cellSearchReqSize,nmmBuf);    /* MsgLen */
 
   ysSendNmMsgToPhy(NMM_CELL_SEARCH_REQ, nmmBuf);

   RETVALUE(ROK);
}

/* For Filling NMM PBCH Config Req Msg*/
PUBLIC S16 ysMsUtlTrigNmmPbchCfgReq
(
PTR         msg
)
{
   TRC2(ysMsUtlTrigNmmPbchCfgReq)
   U16  earfcn = ysCb.cnmSyncReqMsg.earfcn;
   U16  pci    = ysCb.cnmSyncReqMsg.pciList[0].nbrPCellId;

   Buffer *nmmBuf = NULLP;
   ysMsNmmHdr   nmmHdr;
   ysMsNmmPbchCfgReq nmmPbchCfgReq;

   if( ROK != SGetMsg(ysCb.ysInit[0].region, ysCb.ysInit[0].region, (Buffer **) &nmmBuf))
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"Mem alloc Failed for Nmm Start Msg\n");
      RETVALUE(RFAILED);
   }


   nmmHdr.msgLength = sizeof(ysMsNmmHdr) + sizeof(ysMsNmmPbchCfgReq);
   nmmHdr.msgType = NMM_PBCH_CONFIG_REQ;
   nmmHdr.phyEntityId = 0;


   SAddPstMsgMult((Data *)&nmmHdr,sizeof(ysMsNmmHdr),nmmBuf);    /* MsgLen */

   nmmPbchCfgReq.pci = pci;
   nmmPbchCfgReq.earfcn = earfcn;
   nmmPbchCfgReq.vendorFieldCount = 1;
   
   nmmPbchCfgReq.vendorField[0] = 1;
 
   SAddPstMsgMult((Data *)&nmmPbchCfgReq,sizeof(ysMsNmmPbchCfgReq),nmmBuf);    /* MsgLen */

   STKLOG(STK_MD_YS,STK_LOG_INFO,"ICTA::PBCH:: PCI %d earfcn %d\n",
         pci,
         earfcn);
   ysSendNmMsgToPhy(NMM_PBCH_CONFIG_REQ, nmmBuf);

   RETVALUE(ROK);
}
/* Deriving freq band index for the given earfcn */
PRIVATE S16 ysCnmDeriveFreqBand(U16 earfcn,U8 *freqBand)
{
   TRC2(ysCnmDeriveFreqBand)
   U8 bandIdx;
   for( bandIdx = 0; bandIdx < YS_CNM_MAX_EARFCN_TABLE_SIZE;bandIdx++)
   {
      if(earfcn >= ysEarfcnTable[bandIdx].earfcnStart && 
         earfcn <= ysEarfcnTable[bandIdx].earfcnEnd)
      {
         *freqBand = bandIdx;
         break;
      }
   }

   if(bandIdx == YS_CNM_MAX_EARFCN_TABLE_SIZE)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}

/* Deriving freq from earfcn */
PRIVATE S16 ysCnmDeriveFreqFromEarfcn(U16 earfcn,U16 *freq)
{
   TRC2(ysCnmDeriveFreqFromEarfcn)
   YsCnmEarfcnTable *earfcnTableEntry;
   U8 freqBand = 0;
   /* Freq = FDL_LOW + 0.1(Earfcn - earfcnOffset) . this is as per 36.104 */
   if(ROK != ysCnmDeriveFreqBand(earfcn,&freqBand))
   {
#ifdef CNM_DEBUG
      STKLOG(STK_MD_YS,STK_LOG_INFO," Freq derivation failed for earfcn %d\n",earfcn);
#endif
      RETVALUE(RFAILED);
   }

   earfcnTableEntry = &ysEarfcnTable[freqBand];

   /* fDlLow is in MHz */
   *freq = (earfcnTableEntry->fDlLow ) + ( 0.1 * ( earfcn -
            earfcnTableEntry->nOffsetDl));

#ifdef CNM_DEBUG
   STKLOG(STK_MD_YS,STK_LOG_INFO,"Earfcn %d Freq %d\n",earfcn,*freq);
#endif

   RETVALUE(ROK);

}



/* For Filling ICTA_START_REQ */
PUBLIC S16 ysMsUtlTrigIctaStartReq
(
YsCellCb   *cellCb
)
{
   TRC2(ysMsUtlTrigIctaStartReq)
   YsCnmIctaStartMsg cnmIctaStartMsg;
   Buffer            *mBuf           = NULLP;
   U32               refClkFreq = 0;/* 40Mhz for avnet
                                 * 25MHz for DM
                                 */
   U32               fracPart        = 0;
   U16               intPart         = 0;
   U16               freqSniff       = 0;
   U8                adiFactor       = 4; /* this is from ADI doc,
                                            * it will be 4 or TDD for all bands */
   U8                *vendorLst;
   U8                boardType       = 0;
   U16               servEarfcn      = 0;
   U8                nghCellNrb      = ysCb.cnmSyncReqMsg.pciList[0].nbrCellNRb;
   U16               nghEarfcn       = ysCb.cnmSyncReqMsg.earfcn;
   U16               nghPci          = ysCb.cnmSyncReqMsg.pciList[0].nbrPCellId;
   U16               indx            = cellCb->cellId - CM_START_CELL_ID;
   
   if( ROK != SGetMsg(ysCb.ysInit[indx].region, ysCb.ysInit[indx].region, (Buffer **) &mBuf))
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"Mem alloc Failed for Icta Start Msg\n");
      RETVALUE(RFAILED);
   }
 
   boardType    = cellCb->vendorParams.boardType;
   servEarfcn   = cellCb->vendorParams.servEarfcn;
   if(boardType == 1) /* Need to add this vendor specific field */
   {/* AVNET setup */
       STKLOG(STK_MD_YS,STK_LOG_INFO,"AVNET SETUP USED...\n");
       refClkFreq = 40; /* 40MHz */
   }
   else if(boardType == 2)
   {/* DM board setup */
       STKLOG(STK_MD_YS,STK_LOG_INFO,"DM SETUP USED...\n");
       refClkFreq = 50; /* 25MHz */
   }
      /* Frame Start Msg */
   STKLOG(STK_MD_YS,STK_LOG_INFO,"ICTA_START:: nghEarfcn %d nghPci %d servEarfcn %d nghnRb %d\n",
         nghEarfcn,nghPci,servEarfcn,
         nghCellNrb);

   cnmIctaStartMsg.msgLen              = sizeof(YsCnmIctaStartMsg);
   cnmIctaStartMsg.msgType             = YS_CNM_ICTA_START_REQ;
   cnmIctaStartMsg.phyEntityId         = 0;
   cnmIctaStartMsg.nghEarfcn           = nghEarfcn;
   cnmIctaStartMsg.servEarfcn          = servEarfcn;
   cnmIctaStartMsg.nghPci              = nghPci;
   cnmIctaStartMsg.nghCellCp           = 0; /* as per mspd */
   cnmIctaStartMsg.nghSpecSfCfg        = 0;/* as per mspd */
   cnmIctaStartMsg.nghTxAntCount       = 2; /* Need to change hardcoding once this variables are populated from OAM*/
   cnmIctaStartMsg.nghTrackNRb         = nghCellNrb;
   cnmIctaStartMsg.trackPeriod         = 250; /* As per MSPD input *//* Data on every track_period will be stopped */
   /* valid values are {10,20,40,100,250,500,1000} */
   cnmIctaStartMsg.vendorSpcfcLstCount = 0;
   cnmIctaStartMsg.radioChipType       = 0;/* 0:ADI936x */

   cnmIctaStartMsg.vendorSpcfcLstCount = 1;
   /* Populate the 936x params 
    * Few params are board (DM , AVNET) specific
    */
   /* Steps
    * 1. Equation is
    * Integer part = Floor(Freq/Ref_freq)
    * Fractional Part = Round(8,388,593 * ((Freq/Ref_freq) IntegerPart))
    * Ref_freq for AVNET setup is 40MHz, DM board is 25MHz
    * Above equation and values are from intel
    * 2. Derive the freq from earfcn for neigh
    * 3. Calculate the Integer part
    * 4. Calculate the Fractoional Part
    * */
   if( ROK != ysCnmDeriveFreqFromEarfcn(nghEarfcn,&freqSniff))
   {
      RETVALUE(RFAILED);
   }

   STKLOG(STK_MD_YS,STK_LOG_INFO,"ICTA::servFreqSniff %d nghEarfcn %d\n",freqSniff,nghEarfcn);

   vendorLst    = (U8 *)(cnmIctaStartMsg.vendorSpcfcLst.ictaRadioAddElement);

   //intPart      = (U16)(freqSniff/10);/* 10--> 40e6/4 */
   intPart      = (U16)((freqSniff * adiFactor)/refClkFreq);
   *vendorLst++ = (U8)(intPart); /* LSB byte .Little Endian*/
   *vendorLst++ = (U8)(intPart >> 8);  /* MSB byte */


   fracPart     =  round((float)((((freqSniff * adiFactor)/
                  (((float)(refClkFreq))/10))-(intPart*10))*8388593)/10); /* 1 --> 40e6/4/10)*/

   *vendorLst++ = (U8)(fracPart);/* 0-7 bits */
   *vendorLst++ = (U8)(fracPart >> 8);/* 8-15 bits */
   *vendorLst++ = (U8)(fracPart >> 16);/* 16-22 bits */


   *vendorLst++ = 0x50; // config word 5 data, 242[2:0]+239[3:0]              
   *vendorLst++ = 0x4E; // config word 6 data, 242[4:3]+Icp init <5:0>             
   *vendorLst++ = 0x0E; // config word 7 data, 23B[5:0] Icp <5:0>               
   *vendorLst++ = 0xBB; // config word 8 data, 240[3:0]+R3 init <3:0>               
   *vendorLst++ = 0xFF; // config word 9 data, 23F[3:0]+C3 init <3:0>               
   *vendorLst++ = 0x3C; // config word A data, 23E[3:0]+23E[7:4]              
   *vendorLst++ = 0xEE; // config word B data, 23F[7:4]+R1 init <3:0>               
   *vendorLst++ = 0x71; // config word C data, 250[6:4]+005[3:0]              
   *vendorLst++ = 0xE9; // config word D data, 238[6:3]+251[3:0]              
   *vendorLst++ = 0x45; // config word E data, 237[7:0]             
   *vendorLst++ = 0x48; // config word F data, 236[6:0]+238[0]  

   if(boardType == 2)
   {/* DM board */
      *vendorLst++=0x03; // Rx: 1A
   }
   else
   {/* non DM boards */
      *vendorLst++=0x4C; // Rx: 1C
   }
   vendorLst+=3;      // reserved

   /* Serving cells params */

   if( ROK != ysCnmDeriveFreqFromEarfcn(servEarfcn,&freqSniff))
   {
      RETVALUE(RFAILED);
   }
   STKLOG(STK_MD_YS,STK_LOG_INFO,"ICTA::servFreqSniff %d servEarfcn %d\n",freqSniff,servEarfcn);

   vendorLst    = (U8 *)(cnmIctaStartMsg.vendorSpcfcLst.enbRadioAddElement);

   intPart      = (U16)((freqSniff * adiFactor)/refClkFreq);
   *vendorLst++ = (U8)(intPart); /* LSB byte .Little Endian*/
   *vendorLst++ = (U8)(intPart >> 8);  /* MSB byte */

   fracPart     =  round((float)((((freqSniff * adiFactor)/
                  (((float)(refClkFreq))/10))-(intPart*10))*8388593)/10); /* 1 --> 40e6/4/10)*/


   *vendorLst++ = (U8)(fracPart);/* 0-7 bits */
   *vendorLst++ = (U8)(fracPart >> 8);/* 8-15 bits */
   *vendorLst++ = (U8)(fracPart >> 16);/* 16-22 bits */

   *vendorLst++ = 0x50; // config word 5 data, 242[2:0]+239[3:0]              
   *vendorLst++ = 0x4E; // config word 6 data, 242[4:3]+Icp init <5:0>             
   *vendorLst++ = 0x0E; // config word 7 data, 23B[5:0] Icp <5:0>               
   *vendorLst++ = 0xBB; // config word 8 data, 240[3:0]+R3 init <3:0>               
   *vendorLst++ = 0xFF; // config word 9 data, 23F[3:0]+C3 init <3:0>               
   *vendorLst++ = 0x3C; // config word A data, 23E[3:0]+23E[7:4]              
   *vendorLst++ = 0xEE; // config word B data, 23F[7:4]+R1 init <3:0>               
   *vendorLst++ = 0x71; // config word C data, 250[6:4]+005[3:0]              
   *vendorLst++ = 0xE9; // config word D data, 238[6:3]+251[3:0]              
   *vendorLst++ = 0x45; // config word E data, 237[7:0]             
   *vendorLst++ = 0x48; // config word F data, 236[6:0]+238[0]  

   if(boardType == 2)
   {/* DM board */
      *vendorLst++=0x03; // Rx: 1A
   }
   else
   {/* non DM boards */
      *vendorLst++=0x4C; // Rx: 1C
   }

   vendorLst+=3;      // reserved

   if(ROK != SAddPstMsgMult((Data *)&cnmIctaStartMsg,
            sizeof(YsCnmIctaStartMsg),mBuf))
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"SAddPst failed\n");
      RETVALUE(RFAILED);
   }

   ysCb.ictaStartMsgTrigd = TRUE;
   ysStoreCnmMsg(YS_CNM_ICTA_START_REQ, mBuf);
   RETVALUE(ROK);
}

/* Filling ICTA_STOP Msg */
PUBLIC S16 ysMsUtlTrigIctaStopReq()
{
   TRC2(ysMsUtlTrigIctaStopReq)
   YsCnmIctaStopMsg cnmIctaStopMsg;
   Buffer            *mBuf = NULLP;

   if( ROK != SGetMsg(ysCb.ysInit[0].region, ysCb.ysInit[0].region, (Buffer **) &mBuf))
   {
#ifdef CNM_DEBUG
      RLOG0(L_FATAL, "ysMsUtlTrigIctaStopReq(): Memory allocation failed");
#endif
      RETVALUE(RFAILED);
   }

   cnmIctaStopMsg.msgLen              = sizeof(YsCnmIctaStopMsg);
   cnmIctaStopMsg.msgType             = YS_CNM_ICTA_STOP_REQ;
   cnmIctaStopMsg.phyEntityId         = 0;
   cnmIctaStopMsg.vendorSpcfcLstCount = 0;

   if(ROK != SAddPstMsgMult((Data *)&cnmIctaStopMsg,
            sizeof(YsCnmIctaStopMsg),mBuf))
   {
#ifdef CNM_DEBUG
      STKLOG(STK_MD_YS,STK_LOG_ERR,"SAddPst failed in StopReq..\n");
#endif
      RETVALUE(RFAILED);
   }

   ysStoreCnmMsg(YS_CNM_ICTA_STOP_REQ, mBuf);
   RETVALUE(ROK);
}

PUBLIC S16 ysMsUtlTrigCnmInitSyncRsp
(
S16 status
)
{
   TRC2(ysMsUtlTrigCnmInitSyncRsp)
   /*Allocate Memory for Init Rsp message update the status and send*/                        
   CtfCnmInitSyncRsp *ctfCnmInitSyncRsp = NULL;                                               

   if(SGetSBuf(ysCb.ysInit[0].region,ysCb.ysInit[0].pool,(Data **)&ctfCnmInitSyncRsp,\
            sizeof(CtfCnmInitSyncRsp)) != ROK)                        
   {                                                                                          
      RLOG0(L_FATAL, "SGetSBuf(): Memory allocation failed");
      RETVALUE(RFAILED);
   }                                                                                          
   /*update the Sync Rsp from the ysCb space holder */                                        
   ctfCnmInitSyncRsp->status = status;
   ctfCnmInitSyncRsp->earfcn = ysCb.cnmSyncReqMsg.earfcn;

   /* Done with initial NMM procedure rquired for CNM procuedure */
   ysCb.cnmState = YS_MS_CNM_INIT_DONE;
   if(status != ROK)
   {/* As the initial sync proc failed,
       no need to trigger ICTA procedure */
      ysCb.cnmState = YS_MS_INIT_STATE;
       /* further INit sync req needs to be handled
        * as the initial sync is failed */
      ysCb.isCnmProcInitiated = FALSE;
   }

   STKLOG(STK_MD_YS,STK_LOG_INFO,"Sending Init Sync Rsp to app status %d\n",status);
   RETVALUE(YsUiCtfCnmInitSyncRsp(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,                      
            &ysCb.cnmTransId, ctfCnmInitSyncRsp));                                                     

}

PUBLIC S16 ysMsUtlTrigSyncLossInd()
{
   TRC2(ysMsUtlTrigSyncLossInd)
   CtfCnmCellSyncInd *ctfCnmCellSyncInd = NULL;
   if(SGetSBuf(ysCb.ysInit[0].region,ysCb.ysInit[0].pool,(Data **)&ctfCnmCellSyncInd,\
            sizeof(CtfCnmCellSyncInd)) != ROK)
   {                                                                                          
      STKLOG(STK_MD_YS,STK_LOG_ERR,"Memory allocation failed \n");                                                  
      RETVALUE(RFAILED);
   }                                                                                          
   /*update the Sync Rsp from the ysCb space holder */                                        
   ctfCnmCellSyncInd->status = RFAILED;

   RETVALUE(YsUiCtfCnmCellSyncInd(&ysCb.ctfSap.sapPst, ysCb.ctfSap.suId,
         &ysCb.cnmTransId, ctfCnmCellSyncInd));
   RETVALUE(ROK); 

}
#endif

PUBLIC Bool ysMsIsSubframeReadyToSend(U8 sfNum)
{
   TRC2(ysMsIsSubframeReadyToSend)
   YsCellCb           *cellCb         = NULLP;
   U8                  cellReadyCount = 0; 
   U8                  idx=0;
   

   for(idx = 0; idx < (ysCb.numOfCells); idx++)
   {
      cellCb = ysCb.tfuSapLst[idx]->cellCb;

      if(cellCb == NULLP)
      {
         STKLOG(STK_MD_YS,STK_LOG_INFO,"No cells added yet....\n");
         RETVALUE(FALSE);
      }
#if 0
#else
      //if(TRUE == ysChkSfInfoStatus(cellCb, sfNum))
      if(TRUE == ysChkSfInfoStatus(cellCb))
      {
         cellReadyCount++;
      }
#endif
   }

   if(cellReadyCount == ysCb.numOfCells)
   {
      RETVALUE(TRUE);
   }

   RETVALUE(FALSE);
}

#ifdef LTE_ADV
/* LBT SIM */
void sendErrInd(void);
#endif
PUBLIC Void ysMsSendSubframeToPhy(U8 sfNum)
{
   TRC2(ysMsSendSubframeToPhy)
   PMAC2PHY_QUEUE_EL  pMsgDesc;

   if((pMsgDesc = ysMsUtlApndAllCellList(sfNum)) == NULLP)
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"No vectors prsent in the list...");
      RLOG0(L_ERROR,"No vectors prsent in the list...");
      RETVOID;
   }
   /* Append all cells list to one list.
    * appenindign all lists to first cell list */

   if(ysSendMsgToPhy(sizeof(MAC2PHY_QUEUE_EL),pMsgDesc) != ROK)
   {
      /* HARQ_TODO: Free the uldlList before retruning from here */
      STKLOG(STK_MD_YS,STK_LOG_ERR,"Failed to send the TxVector");
      RLOG0(L_ERROR,"Failed to send the TxVector");
      RETVOID;
   }
   /* Reinitialize the list */
   /* reinitialize the ulDlLst of all the cells */
   //ysMsUtlInitPhyList(&ysCb.combUlDlLst[sfNum]);
   ysMsUtlInitAllCellList(sfNum);

#ifdef LTE_ADV
   /* LTE_UNLICENSED LBT simulation */
   sendErrInd();
#endif

   RETVOID;
}

/* Free Mgr thread handler */
#if (defined (MAC_FREE_RING_BUF) || defined (RLC_FREE_RING_BUF))
sem_t freeMgrSem;           

void ysMsFreeRingBuf(SsRngBufId ringId)
{
   TRC2(ysMsFreeRingBuf)
   S16          ret;
   RgKwFreeInfo *freeBufInfo;

   while(NULLP != (freeBufInfo = (RgKwFreeInfo *)SRngGetRIndx(ringId)))
   {
      S32		deltaGT = ysGT - freeBufInfo->freeGT;
      if (deltaGT < 0)
         deltaGT += YS_TOTL_SUB_FRAMES_IN_SFN;
      if (deltaGT <= 5)
      {
         break;
      }

      if(freeBufInfo->bufToFree != NULLP)
      {
         if(freeBufInfo->freeType  == 0)
         {
            SPutMsg((Buffer *)(freeBufInfo->bufToFree));
         }
         else if(freeBufInfo->freeType  == 1)
         {
            ret = SPutStaticBuffer(0,0, (Data *)freeBufInfo->bufToFree,
                  256, SS_SHARABLE_MEMORY);/* Size is dont care param */
            if(ret != ROK)
            {
               STKLOG(STK_MD_YS,STK_LOG_ERR,"Static Buffer free failed in batch free!!!\n");
            }
         }

#if 0
         *(Void **)&freeBufInfo->freeType  = freeBufInfo->bufToFree; /* 2017-8-3 added lichangwu, for mBuf corruption debug */
#endif
         freeBufInfo->bufToFree = NULLP;
         //freeBufInfo->freeType  = 0;
         SRngIncrRIndx(ringId);
      }
   }

   RETVOID;
}

Void *freeMgrHdlr(Void *param)
{
   /* Create semaphore */
   /* initialize the started semaphore */
   if (sem_init(&freeMgrSem, 0, 1) != 0)
   {
      STKLOG(STK_MD_YS,STK_LOG_ERR,"sem_init failed....\n");
      RETVALUE(NULLP);
   }

   while(1)
   {

      sem_wait(&freeMgrSem);
#if 0
#else
#ifdef MAC_FREE_RING_BUF
      ysMsFreeRingBuf(SS_RNG_BUF_MAC_FREE_RING);
#endif
#ifdef RLC_FREE_RING_BUF
      ysMsFreeRingBuf(SS_RNG_BUF_RLC_FREE_RING);
#endif
#endif
   }

   RETVALUE(NULLP);
}
#endif
#ifdef RSYS_WIRESHARK
/* This function has been moved from ys_ms_ul.c, which was specifically meant
 * for only uplink. Now its made generic for both uplink and downlink */
/**
 *  *    @brief   This function posts the logs to wireshark application 
 *   *          for the ccch/srb1/srb2 
 *    *    @param[in]  srcBuf    MAC PDU.
 *     *    @param[in]  rnti      UE C-RNTI.
 *      *    @param[in]  subFrame  sub frmae information.
 *       *    @param[in]  direction  UL/DL information.
 *        */
PUBLIC Void ysMsUtlSendMsgToWireShark(Buffer *srcBuf,U16 rnti,U16 subFrame,U8 direction,U8 cellIdx)
{
   TRC2(ysMsUtlSendMsgToWireShark)
   /* printf("HEXDUMP IN CL\n");
   SPrntMsg(srcBuf, 0, 0);*/
   if(ysCb.genCfg.enblSIAndPagngLog || ysCheckSrbOrCcch(srcBuf))
   {
      Buffer *dstBuf;
#if 1
      /* copy the MAC PDU Info into mBuf */
      if(ROK != SAddMsgRef(srcBuf, ysCb.ysInit[cellIdx].region, ysCb.ysInit[cellIdx].pool, &dstBuf))
#else
      if(ROK != SCpyMsgMsg(srcBuf, ysCb.ysInit.region, ysCb.ysInit.pool, &dstBuf))
#endif
      {
         /* error print */
         YS_DBG_ERR((_ysp, "ysSendMsgToWireShark:: SAddMsgRef failed \n"));
         RETVOID;
      }
      CM_SAVE_MBUF_FILELINE(dstBuf);
#ifdef TFU_TDD
      postToApp(dstBuf,
            2,  /* TDD */
            direction,  /*UL or DL direction*/
            3, /* C-RNTI Type */
            rnti,
            rnti,
            subFrame,
            0 /* Predefined FALSE */,
            0 /* retx FALSE */,
            1 /* crcStatus TRUE*/
            );
#else
      postToApp(dstBuf,
            1,  /* FDD */
            direction,  /* UL or DL dirction*/
            3, /* C-RNTI Type*/
            rnti,
            rnti,
            subFrame,
            0 /* Predefined FALSE */,
            0 /* retx FALSE */,
            1 /* crcStatus TRUE*/
            );
#endif
   }
   RETVOID;
}

/* Imp: Do not delete this */
void postToApp(Buffer *mBuf, U8 radioType, U8 direction, U8 rntiType,
      U16     rnti, U16 ueid,     U16       subframe,
      U8      isPredefinedData, U8 retx, U8 crcStatus)
{

   SPkU8(direction,mBuf);
   SPkU8(rntiType,mBuf);
   SPkU16(rnti,mBuf);
   SPkU16(ueid,mBuf);
   SPkU16(subframe,mBuf);

   ysCb.ctfSap.sapPst.event = (Event)EVTCTFWIRESHARKMSG;
   SPstTsk(&ysCb.ctfSap.sapPst, mBuf);

}
#endif

void sendL2WiresharkToApp(U8 *srcBuf, U32 size, U8 cellIdx)
{
   Buffer *mBuf = NULLP;
   if(SGetMsg(ysCb.ysInit[cellIdx].region, ysCb.ysInit[cellIdx].pool, &mBuf) != ROK)
   {
      return;
   }
   SAddPreMsgMultInOrder(srcBuf,size,mBuf);
   ysCb.ctfSap.sapPst.event = (Event)EVTCTFL2WIRESHARK_BAICELLS;
   SPstTsk(&ysCb.ctfSap.sapPst, mBuf);
}

void sendRadioStatsToApp(U8 *srcBuf, U32 size, U8 index)
{
   Buffer *mBuf = NULLP;
   if(SGetMsg(ysCb.ysInit[index].region, ysCb.ysInit[index].pool, &mBuf) != ROK)
   {
      return;
   }
   SAddPreMsgMultInOrder(srcBuf,size,mBuf);
   ysCb.ctfSap.sapPst.event = (Event)EVTMACSTATSMSG;
   SPstTsk(&ysCb.ctfSap.sapPst, mBuf);
}

void sendFapiWiresharkToApp(U8 *srcBuf, U32 size,U8 type, U16 index)
{
   Buffer *mBuf = NULLP;
   if(SGetMsg(ysCb.ysInit[index].region, ysCb.ysInit[index].pool, &mBuf) != ROK)
   {
      return;
   }
   SAddPreMsgMultInOrder(srcBuf,size,mBuf);
   ysCb.ctfSap.sapPst.event = (Event)(EVTCTFWIRESHARKMSG + type); 
   SPstTsk(&ysCb.ctfSap.sapPst, mBuf);
}



/********************************************************************30**

         End of file:     yw_ms_utl.c@@/main/TeNB_Main_BR/6 - Wed Jun 11 13:19:54 2014

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---      rp   1. initial release.
/main/1    ys004.102  vr   1. Merged MSPD code with phy 1.7
*********************************************************************91*/

